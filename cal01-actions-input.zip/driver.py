#!/usr/bin/env python3
"""Infrastructure adapter: frozen computation, no statistical aggregation."""
import argparse,ast,csv,hashlib,importlib.util,json,math,os,platform,shutil,sys,time,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent; WORK=HERE/'work'; ROOT=WORK/'VOY-REFLOW-CAL-01'; OUT=ROOT/'output'
ARCH=HERE/'VOY-REFLOW-CAL-01_CHECKPOINT.zip'; SHA='6043b1935029ba0e5b53e0cd9f65d0b70601b1d998e605840fa32cb805541a4d'; COMMIT='0fb8b0ddb2ab1281758834e501f166669646518e'
SERIES=('ZL3b','IT2a'); KEYS=[(g,r) for g in range(2) for r in range(1,21)]
AUDIT=json.loads((HERE/'CAL01_CHECKPOINT_AUDIT.json').read_text()); SAMPLES={x['id']:x for x in AUDIT['shards']}; FILES=('H1.json','stream.sha256','reflow.csv','execution_environment.json')
def check(ok,msg):
    if not ok:raise RuntimeError(msg)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def label(g,r):return f'{SERIES[g]}_{r:02d}'
def prefix(key):
    if key not in SAMPLES:return b''
    with zipfile.ZipFile(ARCH) as z:return z.read(f'VOY-REFLOW-CAL-01/output/{key}/reflow.csv')
def setup(frozen):
    check(sha(ARCH)==SHA,'archive hash');check(not WORK.exists(),'work exists')
    with zipfile.ZipFile(ARCH) as z:check(z.testzip() is None,'zip CRC');z.extractall(WORK)
    (WORK/'reflow_execution/r5work').mkdir();(WORK/'reflow_execution/r5work/generator').symlink_to('../generator',target_is_directory=True)
    frozen=Path(frozen).resolve()
    for n in ('PROTOCOL.md','run.py','FREEZE_MANIFEST.json','SOURCE_MANIFEST_DRAFT.json'):check((ROOT/n).read_bytes()==(frozen/n).read_bytes(),f'frozen bytes {n}')
    check(json.loads((ROOT/'REMOTE_RECEIPT.json').read_text())['commit']==COMMIT,'receipt commit')
    for key,v in SAMPLES.items():check(sha(OUT/key/'reflow.csv')==v['csv_sha256'],'checkpoint hash')
    spec=importlib.util.spec_from_file_location('frozen',ROOT/'run.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.gate();m.init();return m
def adapt(m,ids=None,budget=0):
    # Reuse frozen AST through the CSV append block; omit summary tail.
    # Replace ONLY loop iterator to select replay IDs / stop between replicas.
    node=next(n for n in ast.parse((ROOT/'run.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='job')
    i=next(i for i,n in enumerate(node.body) if isinstance(n,ast.With));check(i==16,'frozen AST');node.body=node.body[:i+1]
    loop=next(n for n in ast.walk(node.body[-1]) if isinstance(n,ast.For));check(ast.unparse(loop.iter)=='range(len(prev) + 1, N + 1)','frozen iterator')
    end=time.monotonic()+budget if budget else float('inf')
    def schedule(start,stop):
        for j in (ids if ids is not None else range(start,stop)):
            if time.monotonic()>=end:break
            yield j
    m.__dict__['_infra_schedule']=schedule;loop.iter.func=ast.Name(id='_infra_schedule',ctx=ast.Load());ast.fix_missing_locations(node)
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(ROOT/'run.py'),'exec'),m.__dict__);return m.job
def rows(p,g,r,full=False):
    raw=p.read_bytes();check(raw.endswith(b'\r\n'),'CSV ending');check(raw.startswith(prefix(label(g,r))),'original prefix changed')
    with p.open(newline='') as f:
        rd=csv.DictReader(f);check(rd.fieldnames==['geometry','realization','reflow_id','seed','n_transitions','gain_nats','status','error'],'fields');v=list(rd)
    check(len(v)<=1000 and (not full or len(v)==1000),'count')
    for i,x in enumerate(v,1):check(None not in x and x['geometry']==SERIES[g] and x['realization']==str(r) and x['reflow_id']==str(i) and x['seed']==f'20261124:502:{g}:{r}:{i}' and x['status']=='OK' and x['error']=='' and int(x['n_transitions'])==(2977 if g==0 else 2936) and math.isfinite(float(x['gain_nats'])),f'invalid row {g}/{r}/{i}')
    return len(v)
def expected(p,g,r,full=False):
    key=label(g,r);n=rows(p/'reflow.csv',g,r,full)
    if key in SAMPLES:check((p/'stream.sha256').read_text().strip()==SAMPLES[key]['stream_sha256'],'stream hash')
    return dict(g=g,r=r,geometry=SERIES[g],rows=n,complete=n==1000,frozen_commit=COMMIT,archive_sha256=SHA,original_rows=SAMPLES.get(key,{}).get('rows',0),files={x:sha(p/x) for x in FILES})
def validate(p,g,r,full=False):
    m=json.loads((p/'manifest.json').read_text());check(m==expected(p,g,r,full),'manifest mismatch');return m
def replay(frozen):
    m=setup(frozen);t=time.monotonic();a=m.stream(24,m.rng(501,99,1));b=m.stream(24,m.rng(501,99,1));check(sum(m.split(a,[9,8,7]),[])==sum(m.split(b,[7,9,8]),[]),'invariance');result=[]
    for key,v in SAMPLES.items():
        r=int(key.split('_')[-1]);p=OUT/key;old=prefix(key).splitlines(keepends=True);old_h1=(p/'H1.json').read_bytes();shutil.rmtree(p);ids=[x['replica_id'] for x in v['samples']];adapt(m,ids=ids)((0,r));new=(p/'reflow.csv').read_bytes().splitlines(keepends=True)[1:];check(len(new)==len(ids),'sample count');check((p/'stream.sha256').read_text().strip()==v['stream_sha256'],'stream replay');check((p/'H1.json').read_bytes()==old_h1,'H1 replay mismatch')
        for row,s in zip(new,v['samples']):
            i=s['replica_id'];d=hashlib.sha256(row).hexdigest();check(row==old[i] and d==s['checkpoint_row_sha256'],f'REPLAY FAIL {key}/{i}');result.append(dict(key=key,id=i,sha256=d))
    (HERE/'replay-report.json').write_text(json.dumps(dict(status='PASS',frozen_commit=COMMIT,rows=result,elapsed_seconds=time.monotonic()-t,python=sys.version),indent=2)+'\n');print('PASS 12/12 exact CSV hashes; 4/4 streams')
def run(frozen,g,r,prior,budget,dest):
    check((g,r) in KEYS,'job identity');dest=Path(dest).resolve();prior=Path(prior).resolve() if prior else None;m=setup(frozen);p=OUT/label(g,r)
    if prior:
        validate(prior,g,r);p.mkdir(parents=True,exist_ok=True)
        for n in FILES:shutil.copy2(prior/n,p/n)
    old=(p/'reflow.csv').read_bytes() if (p/'reflow.csv').exists() else b'';old_stream=(p/'stream.sha256').read_bytes() if (p/'stream.sha256').exists() else None
    old_h1=(p/'H1.json').read_bytes() if (p/'H1.json').exists() else None
    if old:rows(p/'reflow.csv',g,r)
    history=json.loads((p/'execution_environment.json').read_text()) if (p/'execution_environment.json').exists() else []
    adapt(m,budget=budget)((g,r));check((p/'reflow.csv').read_bytes().startswith(old),'prior rows changed')
    if old_stream is not None:check((p/'stream.sha256').read_bytes()==old_stream,'prior stream changed')
    if old_h1 is not None:check((p/'H1.json').read_bytes()==old_h1,'prior H1 changed')
    import scipy,sklearn
    history.append(dict(python=platform.python_version(),numpy=m.np.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__,platform=platform.platform(),run_id=os.getenv('GITHUB_RUN_ID'),run_attempt=os.getenv('GITHUB_RUN_ATTEMPT'),prior_rows=old.count(b'\n')-1 if old else 0,legacy_checkpoint_rows=SAMPLES.get(label(g,r),{}).get('rows',0)))
    (p/'execution_environment.json').write_text(json.dumps(history,indent=2)+'\n')
    mf=expected(p,g,r);(p/'manifest.json').write_text(json.dumps(mf,sort_keys=True,indent=2)+'\n');shutil.copytree(p,dest);print(label(g,r),mf['rows'],flush=True);return 0 if mf['complete'] else 75
def verify(collected):
    p=Path(collected).resolve();check(sha(ARCH)==SHA,'archive');check(len([x for x in p.iterdir() if x.is_dir()])==40,'shards');ids=set();hashes=[];n=0
    for g,r in KEYS:
        key=label(g,r);m=validate(p/key,g,r,True);n+=m['original_rows'];hashes.append(f'{sha(p/key/"manifest.json")}  {key}/manifest.json\n');ids.update((g,r,i) for i in range(1,1001))
    check(len(ids)==40000 and n==850,'global counts');q=p/'GLOBAL_SHA256.txt';q.write_text(''.join(hashes));print('PASS 40 manifests, 40000 unique IDs, 850 preserved; global SHA256',sha(q))
def main():
    ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest='cmd',required=True);p=sub.add_parser('replay');p.add_argument('--frozen',required=True);p=sub.add_parser('run');p.add_argument('--frozen',required=True);p.add_argument('--g',type=int,required=True);p.add_argument('--r',type=int,required=True);p.add_argument('--prior');p.add_argument('--budget',type=int,default=19200);p.add_argument('--dest',required=True);p=sub.add_parser('verify');p.add_argument('--collected',required=True);a=ap.parse_args();return replay(a.frozen) if a.cmd=='replay' else run(a.frozen,a.g,a.r,a.prior,a.budget,a.dest) if a.cmd=='run' else verify(a.collected)
if __name__=='__main__':sys.exit(main())
