import json,math,hashlib,pathlib,zipfile
P=pathlib.Path(__file__).resolve().parent
# Features are manually transcribed from independent bibliographic descriptions, NOT image-extracted.
source='https://www.voynich.nu/q09/'
diagrams={
 'f68r3':{'sectors':8,'dense_star_fields':4,'other_sectors':4,'isolated_star_counts':[1,2,3,4],'central_figure':'moon face','special_seven_cluster':True},
 'f68v2':{'sectors':8,'dense_star_fields':4,'other_sectors':4,'isolated_star_counts':[1,1,1,1],'central_figure':'8-point blue star','special_seven_cluster':False},
}
a,b=diagrams.values()
result={'source':source,'observations':diagrams,
 'checks':{'same_eight_sector_topology':a['sectors']==b['sectors']==8,'same_four_plus_four_alternation':a['dense_star_fields']==b['dense_star_fields']==4,'same_number_of_single_star_groups':len(a['isolated_star_counts'])==len(b['isolated_star_counts'])==4,'same_labelled_star_multiplicities':a['isolated_star_counts']==b['isolated_star_counts'],'moon_centered_both':a['central_figure']==b['central_figure']=='moon face'},
 'total_stars_in_counted_sparse_sectors':{'f68r3':sum(a['isolated_star_counts']),'f68v2':sum(b['isolated_star_counts'])},
 'difference_of_sparse_sector_stars':sum(a['isolated_star_counts'])-sum(b['isolated_star_counts']),
 'combinatorial_note':{'ways_choose_four_of_eight':math.comb(8,4),'alternating_binary_patterns':2,'conditional_fraction_under_uniform_random_placements':2/math.comb(8,4),'is_inferential_p_value':False},
 'interpretation':'Repeated 8-sector alternating template with different stellar multiplicities; this weighs in favour of schematic compositional rules vs literal fixed star chart, but cannot identify astronomy or language.',
 'limitations':['counts transcribed from secondary descriptions, not new pixel annotation','two diagrams on opposite sides of same folio: non-independent','no historical astronomical coordinates or independent date constraints','numerical progression 1,2,3,4 already documented; not a novel discovery']}
(P/'RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(result['checks'],ensure_ascii=False)); print('star totals',result['total_stars_in_counted_sparse_sectors'])
