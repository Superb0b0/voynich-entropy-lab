# ASTRO-05 — il controllo gemello di f68r3
12 novembre 2026 · Ricerca esplorativa in sola lettura; nessuna modifica RC1.4.2.

## Domanda falsificabile
La struttura di f68r3 va trattata come mappa di posizioni celesti o come impaginazione geometrico-simbolica? Il primo controllo è una previsione semplice: in un diagramma dello stesso formato la progressione 1–2–3–4 delle stelle isolate deve ricomparire se è una regola strutturale costante. L'assenza non falsifica l'astronomia in generale, ma falsifica la **regola universale 1–2–3–4** per i due disegni.

## Fonte e dati
La descrizione documentaria di René Zandbergen (https://www.voynich.nu/q09/) attribuisce a f68r3 otto settori alternati: quattro campi con molte piccole stelle e quattro settori con stelle isolate etichettate; il numero di stelle isolate forma 1, 2, 3, 4 (oltre al gruppo compatto delle sette e alla Luna centrale). La stessa fonte descrive f68v2 come otto settori alternati fra quattro campi densi e quattro con **una sola stella** e testo. f68v2 ha un astro blu a otto punte al centro, non la Luna antropomorfa di f68r3.

Questo non è un conteggio automatico dei pixel: è un confronto strutturale riproducibile di descrizioni già pubblicate. Le due figure sono sullo stesso foglio e non costituiscono due test indipendenti.

## Risultati
- Architettura: **8 settori, 4 densi e 4 radi con stelle etichettate** in entrambe.
- Molteplicità nei quattro settori radi: **f68r3 = [1, 2, 3, 4]**; **f68v2 = [1, 1, 1, 1]**. Totali 10 vs 4 stelle isolate.
- Centro: f68r3 figura lunare, f68v2 astro azzurro a 8 punte.
- Quindi una presunta regola universale «i gruppi numerici crescono da 1 a 4» **non si trasferisce** nemmeno al diagramma formalmente più vicino.
- L'alternanza di quattro settori su otto avrebbe soltanto 2 disposizioni su 70 sotto un modello astratto di posizioni casuali equiprobabili. **1/35 NON è un p-value del Voynich**, perché i disegni non sono campionati casualmente e la coppia è selezionata a posteriori.

## Controllo storico esterno
Walters Art Museum, W.73.2V (tardo XII sec.): diagramma dei sette corpi celesti medievali, **inclusa la Luna**, rappresentati in anelli concentrici attorno alla Terra. È una rappresentazione del cosmo diversa dal diagramma a otto settori del Voynich. Non dimostra che quest'ultimo sia non astronomico; impedisce solo di presumere una corrispondenza diretta fra *sette stelle separate e sette pianeti* senza spiegare la Luna centrale. Fonte: https://art.thewalters.org/object/W.73.2V/.

## Decisione
L'ipotesi **SCHEMA GEOMETRICO RIUTILIZZATO** è corroborata descrittivamente dall'architettura condivisa. L'ipotesi **FOTOGRAFIA DI UN CIELO REALE** non è testabile sui soli otto settori: manca una regola predeterminata che trasformi le stelle dipinte in coordinate e in epoca. L'ipotesi *Pleiadi* resta iconografica, non lessicale. Nessun nome o data astronomica ottenuto.

**Passo successivo giustificato**, prima di altra analisi di linguaggio: confronto iconografico esterno della struttura alternata a 8 settori, cercando nei manoscritti medievali un diagramma con **stesso ordine dei settori, stesso tipo di marcatori e legenda leggibile**. Il numero 8 da solo non basta.
