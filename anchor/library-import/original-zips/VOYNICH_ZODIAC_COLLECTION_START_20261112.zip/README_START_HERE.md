# Voynich zodiac: avvio raccolta indipendente su 12 pannelli

**Stato verificato al 12 novembre 2026:** sono stati identificati 8 canvas per 12 pannelli, ma solo **2 JPEG Yale di anteprima** sono disponibili nell'archivio locale del pilota. Le altre **6 immagini non sono state scaricate** in questo ambiente. Per il pacchetto uniforme sono ancora da scaricare **tutte e otto le scansioni integrali**; le due anteprime locali non sono sostituti equivalenti. Non esiste ancora un pacchetto completo per revisori, né due revisori reclutati, né annotazioni indipendenti. **Questo pacchetto è uno strumento di acquisizione e annotazione, non un risultato scientifico.**

## Cosa contiene

- `custodian/ACQUISITION_MANIFEST.json`: 8 URL di scansioni complete su archive.org, canvas Yale corrispondenti, dimensioni e SHA-256 pubblicati nel manifest di terze parti `sunkencity999/voynich-atlas/data/folios.json`. Gli hash non sono stati verificati su download in questo ambiente. Le dimensioni dei canvas `1006201` e `1006202` coincidono con i due `info.json` Yale già conservati nel pilota; per gli altri sei canvas il controllo resta pendente.
- `custodian/PANEL_CANVAS_CROSSWALK_PRIVATE.csv`: 12 pannelli → 8 canvas, basato sull'inventario storico del pilota; **non è verità di annotazione** e non va ai revisori.
- `custodian/pilot_reference_only`: due immagini Yale di consultazione già disponibili, risoluzione 1800 px, **non** da mescolare alle otto scansioni integrali.
- `acquire_and_pack.py`: scarica le 8 scansioni, verifica dimensioni, byte e SHA-256, genera un ZIP identico da consegnare separatamente ai revisori. Fallisce se anche una sola immagine manca o non verifica.
- `reviewer_template/annotate_offline.html`: interfaccia locale per delimitare ruote, figure e regioni di testo, con export/import JSON. Non invia nulla in rete.
- `reviewer_template/ISTRUZIONI_REVISORE.md`: istruzioni senza conteggi attesi, EVA, coordinate precedenti o diagnostica.
- `custodian/INDEPENDENCE_DECLARATION_BLANK.md`: dichiarazione di indipendenza da firmare prima della consegna.

## Passaggi concreti, eseguibili sul computer del custode

Richiede Python 3.10+ e Pillow (`python -m pip install Pillow`) e connessione internet per il download.

```bash
python acquire_and_pack.py status
python acquire_and_pack.py download
python acquire_and_pack.py pack
```

Il download recupera le scansioni **da archive.org**, mirror dichiarato della digitalizzazione Yale, e ne verifica gli hash contro i valori di un manifest pubblico di terze parti. Se il mirror non è disponibile o l'hash non coincide, lo script si ferma; **non sostituisce automaticamente le immagini con versioni diverse**. L'archivio dei revisori compare soltanto se tutte le otto scansioni sono verificate. Non confondere un hash corrispondente al manifest di terze parti con una verifica diretta del master originale Yale.

Il custode deve: verificare che tutte le ruote siano integralmente visibili e che il mapping storico dei pannelli non presenti omissioni; raccogliere due dichiarazioni di indipendenza firmate; inviare a ciascun revisore lo **stesso identico ZIP** e registrare timestamp UTC e SHA-256; attendere due JSON indipendenti chiusi prima di confrontarli. Le ruote e i candidati vengono **annotati ex novo**: non mostrare i conteggi del manifest privato.

## Scopo scientifico, distinto dal vecchio gate

Questa raccolta risponde prima di tutto a fattibilità e concordanza descrittiva di **rilevazione degli oggetti e delimitazione**. Nessun matching figura-etichetta viene effettuato o validato dal tool. Il vecchio gate R01 v1.1 rimane archivio metodologico, non requisito per questa raccolta. Una volta ricevute le due annotazioni reali, il confronto potrà riportare conteggi per pannello, accordo sui conteggi, F1 e qualità delle delimitazioni, esplicitando la dipendenza tra pannelli e folii. Non è stata congelata una nuova soglia di accettazione e non viene promessa inferenza su 12 pannelli.

**Stato scientifico invariato:** `PREPARATION_DATASET_PENDING_VALIDATION`; 30 link ufficiali `ambiguous`, zero validati; H-A3R non eseguibile; attributo primario non selezionato; RC1.4.2 bloccato.
