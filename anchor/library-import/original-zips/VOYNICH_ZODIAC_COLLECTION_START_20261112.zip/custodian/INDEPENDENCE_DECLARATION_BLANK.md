# Dichiarazione di indipendenza, da firmare PRIMA della consegna delle immagini

Codice revisore assegnato dal custode: __________________

Dichiaro:
- di non aver prodotto o corretto le coordinate del pilota ANCHOR-01;
- di non aver consultato per questo incarico le coordinate pregresse, le diagnostiche, i risultati del matching, gli inventari di corrispondenze figura-etichetta, EVA o EXP 3B;
- di non avere accesso alle annotazioni dell'altro revisore e di non comunicare con lui/lei durante il lavoro;
- di indicare ogni eventuale esposizione pregressa al manoscritto o alle analisi, anche se parziale, qui: __________________;
- di dichiarare i possibili conflitti di interesse o rapporti di lavoro con i ricercatori qui: __________________;
- di comprendere che la mia firma non attesta la correttezza delle annotazioni ma la loro indipendenza operativa.

Firma: __________________  Data e ora UTC: __________________

**Custode (non revisore):** identità verificata tramite __________________; file firmato conservato in __________________; SHA-256 del file firmato __________________; timestamp UTC di ricezione __________________. La dichiarazione deve essere valutata prima della distribuzione; un'esposizione pregressa rilevante non si cancella con la firma.
