#!/usr/bin/env python3
"""Build a read-only acquisition manifest from independently located mirror metadata.
No download or validation is implied by listing these records.
"""
from pathlib import Path
import csv, json
root=Path(__file__).resolve().parents[1]
rows=[
('1006200','127','70v-part',3945,3772,13324214,'3db96e1cd35d069fde8a0fa9b1d5ae799358e8b2f47a47c60bc42d0ebc3074e0'),
('1006201','128','70v-part-s128',2979,3700,9568346,'bada470a31e4d02de4383baf46540087ee8acee58fa114f6e096ca3ced136794'),
('1006202','129','f71r',2793,3762,9509723,'c0fd25566798bdf7bab3be44dbe52dd9862aac8135474ca562b4e5bed499ca21'),
('1006203','130','71v-and-72r',8865,3018,19108047,'a5918371500af9d946f597ff9e022198af694be3d93aa9e800ee31a9807baccf'),
('1006204','131','72v-part',5976,3794,19963528,'8d26a9603c06f17f3ac61bf2a265a1ef4614138ae907b36fd5ce9901b54b69f2'),
('1006205','132','72v-part-s132',2979,3712,10073282,'a0a22578dad926c8ad347944e4ddceb6595693170ebbc984a2a918a50d40d9be'),
('1006206','133','f73r',2834,3761,9363406,'7fa9bf491f95b2cfc78e87d28a4556f7c2bb60eb0de1494020b3d4a5954b713b'),
('1006207','134','f73v',2979,3724,9727871,'965d768f7131687ac967530a0ed6ca0b1f1cb65ccacefb8120f1179c332dc058'),
]
# Fixed non-folio sequence. Both reviewers must see exactly this same sequence.
order=['1006204','1006200','1006206','1006203','1006201','1006207','1006205','1006202']
by_id={x[0]:x for x in rows}
items=[]
for idx,cid in enumerate(order,1):
 id,num,label,w,h,nbytes,sha=by_id[cid]
 items.append(dict(image_alias=f'IMG_{idx:02d}.jpg',canvas_oid=id,mirror_seq=int(num),mirror_url=f'https://archive.org/download/voynich/{num}.jpg',expected_sha256=sha,expected_bytes=nbytes,expected_width=w,expected_height=h,mirror_label=label,source='Beinecke MS 408, 2014 digitization; mirror archive.org/voynich',status='NOT_DOWNLOADED_OR_VERIFIED'))
manifest=dict(schema_version='1.0', source='https://github.com/sunkencity999/voynich-atlas/blob/master/data/folios.json', source_status='third_party_metadata_not_independently_verified_in_this_session',image_count=8, expected_panels=12, caveat='12 panels on 8 canvases; historical panel counts and identifications must not be sent to reviewers',items=items)
(root/'custodian'/'ACQUISITION_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
# This private crosswalk comes from the existing project inventory; it is not annotation ground truth.
with (root/'custodian'/'PANEL_CANVAS_CROSSWALK_PRIVATE.csv').open('w',newline='',encoding='utf8') as f:
 wr=csv.writer(f); wr.writerow(['panel_id','canvas_oid','reviewer_image_alias','historical_status'])
 lookup={x['canvas_oid']:x['image_alias'] for x in items}
 for pid,cid in [('f70v1','1006201'),('f70v2','1006200'),('f71r','1006202'),('f71v','1006203'),('f72r1','1006203'),('f72r2','1006203'),('f72r3','1006203'),('f72v1','1006205'),('f72v2','1006204'),('f72v3','1006204'),('f73r','1006206'),('f73v','1006207')]:
  wr.writerow([pid,cid,lookup[cid],'historical_inventory_only_not_reviewed'])
print('Wrote 8-image source manifest and private 12-panel crosswalk.')
