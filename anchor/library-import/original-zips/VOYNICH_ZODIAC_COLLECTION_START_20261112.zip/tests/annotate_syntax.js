
(()=>{'use strict';
const $=id=>document.getElementById(id);let files={},loaded={},active='',img=null,scale=1,drag=null;
let data={schema_version:'ZODIAC-12P-ANNOTATION-1.0',reviewer_id:'',review_status:'IN_PROGRESS',completed_utc:null,wheel_regions:[],objects:[],notes:''};
const canvas=$('stage'),ctx=canvas.getContext('2d');
const sortedFiles=()=>Object.keys(files).sort();
function message(s){$('notice').textContent=s}
function imageInfo(){return img?{w:img.naturalWidth,h:img.naturalHeight}:null}
function imgCoords(evt){let r=canvas.getBoundingClientRect();return {x:Math.max(0,Math.min(img.naturalWidth,(evt.clientX-r.left)/scale)),y:Math.max(0,Math.min(img.naturalHeight,(evt.clientY-r.top)/scale))}}
function box(a,b){return [Math.round(Math.min(a.x,b.x)),Math.round(Math.min(a.y,b.y)),Math.round(Math.max(a.x,b.x)),Math.round(Math.max(a.y,b.y))]}
function drawBox(b,color,txt){if(!b)return;ctx.strokeStyle=color;ctx.lineWidth=Math.max(1.5,2/scale);ctx.strokeRect(b[0]*scale,b[1]*scale,(b[2]-b[0])*scale,(b[3]-b[1])*scale);ctx.fillStyle=color;ctx.font='bold 12px sans-serif';ctx.fillText(txt,b[0]*scale+4,b[1]*scale+14)}
function render(){if(!img){ctx.fillStyle='#ddd';ctx.fillRect(0,0,canvas.width,canvas.height);return}
const fit=Math.min(1150/img.naturalWidth,760/img.naturalHeight,1);scale=Math.min(1,fit*Number($('zoom').value));canvas.width=Math.round(img.naturalWidth*scale);canvas.height=Math.round(img.naturalHeight*scale);ctx.drawImage(img,0,0,canvas.width,canvas.height);$('zoomText').textContent=Math.round(scale*100)+'%';
for(const w of data.wheel_regions.filter(x=>x.image_alias===active))drawBox(w.bbox_px,'#1976d2',w.wheel_local_id);
for(const o of data.objects.filter(x=>x.image_alias===active))drawBox(o.bbox_px,o.source_object_kind==='text_region'?'#e96a22':'#19a86b',o.wheel_local_id+':'+o.source_object_kind);
if(drag)drawBox(box(drag.a,drag.b),'#a120c0','in corso');
const wheels=data.wheel_regions.filter(x=>x.image_alias===active),objs=data.objects.filter(x=>x.image_alias===active);
$('stats').textContent=active+' | '+img.naturalWidth+'×'+img.naturalHeight+' px | '+wheels.length+' ruote | '+objs.length+' oggetti';
$('items').innerHTML='';for(const w of wheels){let d=document.createElement('div');d.textContent='RUOTA '+w.wheel_local_id+' '+w.bbox_px.join(',');$('items').appendChild(d)}for(const o of objs){let d=document.createElement('div');d.textContent='OGGETTO '+o.wheel_local_id+' '+o.source_object_kind+' / '+o.annotation_status+' / '+o.confidence+' '+(o.bbox_px||[]).join(',');$('items').appendChild(d)}
}
function setImage(name){if(!files[name])return;active=name;$('imageSel').value=name;if(loaded[name]){img=loaded[name];render();return}let u=URL.createObjectURL(files[name]);let im=new Image();im.onload=()=>{URL.revokeObjectURL(u);loaded[name]=im;img=im;render();message('Pronto: '+name)};im.onerror=()=>message('Impossibile aprire '+name);im.src=u}
$('images').onchange=e=>{let chosen=Array.from(e.target.files);if(!chosen.length)return;files={};loaded={};for(const f of chosen){if(!/^IMG_\d\d\.jpg$/i.test(f.name)){message('Nome non conforme: '+f.name);return}files[f.name]=f}const names=sortedFiles();$('imageSel').innerHTML='';for(const n of names){let o=document.createElement('option');o.value=n;o.textContent=n;$('imageSel').appendChild(o)}setImage(names[0]);if(names.length!==8)message('ATTENZIONE: caricati '+names.length+'/8 JPEG. Nessuna consegna completa possibile.')};
$('imageSel').onchange=e=>setImage(e.target.value);$('zoom').oninput=render;
canvas.onpointerdown=e=>{if(!img)return;canvas.setPointerCapture(e.pointerId);drag={a:imgCoords(e),b:imgCoords(e)};render()};
canvas.onpointermove=e=>{if(drag){drag.b=imgCoords(e);render()}};
canvas.onpointerup=e=>{if(!drag)return;drag.b=imgCoords(e);const b=box(drag.a,drag.b);drag=null;if(b[2]-b[0]<4||b[3]-b[1]<4){message('Regione troppo piccola: ignorata');render();return}const wid=$('wheelId').value.trim();if(!/^W[1-9]\d*$/.test(wid)){message('ID ruota deve essere W1, W2, ...');render();return}
if($('mode').value==='wheel')data.wheel_regions.push({image_alias:active,wheel_local_id:wid,bbox_px:b,notes:$('note').value.trim()});else data.objects.push({id:'O'+String(data.objects.length+1).padStart(4,'0'),image_alias:active,wheel_local_id:wid,source_object_kind:$('kind').value,annotation_status:$('status').value,confidence:$('confidence').value,bbox_px:b,notes:$('note').value.trim()});$('note').value='';render()};
$('addNull').onclick=()=>{if(!active)return message('Seleziona prima un’immagine');if($('status').value!=='not_localizable')return message('Imposta stato not_localizable');if(!$('note').value.trim())return message('Nota obbligatoria per un oggetto non localizzabile');data.objects.push({id:'O'+String(data.objects.length+1).padStart(4,'0'),image_alias:active,wheel_local_id:$('wheelId').value.trim(),source_object_kind:$('kind').value,annotation_status:'not_localizable',confidence:'low',bbox_px:null,notes:$('note').value.trim()});$('note').value='';render()};
$('undo').onclick=()=>{const objs=data.objects.filter(x=>x.image_alias===active),wheels=data.wheel_regions.filter(x=>x.image_alias===active);if(objs.length){let o=objs.at(-1);data.objects.splice(data.objects.indexOf(o),1)}else if(wheels.length){let w=wheels.at(-1);data.wheel_regions.splice(data.wheel_regions.indexOf(w),1)}render()};
$('export').onclick=()=>{data.reviewer_id=$('reviewer').value.trim();if(!data.reviewer_id)return message('Inserisci un ID revisore');data.completed_utc=new Date().toISOString();data.review_status='DRAFT_EXPORTED_NOT_CLOSED';data.images=sortedFiles().map(n=>({image_alias:n,bytes:files[n].size,width:loaded[n]?.naturalWidth||null,height:loaded[n]?.naturalHeight||null}));let blob=new Blob([JSON.stringify(data,null,2)+'\n'],{type:'application/json'});let u=URL.createObjectURL(blob);let a=document.createElement('a');a.href=u;a.download='ANNOTATION_'+data.reviewer_id+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);message('JSON esportato. La chiusura formale avviene SOLO presso il custode.')};
$('import').onchange=async e=>{const f=e.target.files?.[0];if(!f)return;try{let obj=JSON.parse(await f.text());if(obj.schema_version!=='ZODIAC-12P-ANNOTATION-1.0'||!Array.isArray(obj.objects)||!Array.isArray(obj.wheel_regions))throw Error('Schema incompatibile');data=obj;$('reviewer').value=obj.reviewer_id||'';render();message('JSON caricato; verifica immagini e regioni prima di proseguire.')}catch(err){message('Errore import: '+err.message)}};
render();
})();
