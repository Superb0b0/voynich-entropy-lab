import importlib.util, hashlib, json, pathlib, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('acq',ROOT/'acquire_and_pack.py')
acq=importlib.util.module_from_spec(spec);spec.loader.exec_module(acq)
class CollectionTests(unittest.TestCase):
 def test_manifest_8_distinct_canvases(self):
  items=acq.get_manifest();self.assertEqual(len(items),8)
  self.assertEqual(len(set(x['canvas_oid'] for x in items)),8)
  self.assertEqual(len(set(x['image_alias'] for x in items)),8)
 def test_crosswalk_12_panels(self):
  import csv
  with (ROOT/'custodian'/'PANEL_CANVAS_CROSSWALK_PRIVATE.csv').open() as f: rows=list(csv.DictReader(f))
  self.assertEqual(len(rows),12)
  self.assertEqual(len(set(x['panel_id'] for x in rows)),12)
  self.assertEqual(len(set(x['canvas_oid'] for x in rows)),8)
 def test_preview_images_valid_for_local_fixture(self):
  for cid in ('1006201','1006202'):
   p=ROOT/'custodian'/'pilot_reference_only'/(cid+'_preview_only.jpg')
   (w,h),fmt=acq.dimensions(p)
   self.assertEqual(h,1800);self.assertEqual(fmt,'JPEG')
   rec=dict(expected_bytes=p.stat().st_size,expected_sha256=acq.sha256(p),expected_width=w,expected_height=h)
   self.assertEqual(acq.validate(p,rec),(True,'VERIFIED'))
   bad=dict(rec,expected_sha256='0'*64)
   self.assertIn('SHA256_MISMATCH',acq.validate(p,bad)[1])
 def test_missing_images_block_packet(self):
  items=acq.get_manifest()
  self.assertFalse(all(acq.validate(acq.ORIGINALS/(x['canvas_oid']+'.jpg'),x)[0] for x in items))
  self.assertFalse((acq.OUTPUT/'VOYNICH_12_PANEL_REVIEWER_BLIND_IDENTICAL.zip').exists())
 def test_private_crosswalk_not_in_reviewer_template(self):
  for p in (ROOT/'reviewer_template').iterdir():
   if p.is_file():
    txt=p.read_text(encoding='utf8')
    self.assertNotIn('Grove-Stolfi',txt)
    self.assertNotIn('f70v1.13',txt)
if __name__=='__main__':unittest.main()
