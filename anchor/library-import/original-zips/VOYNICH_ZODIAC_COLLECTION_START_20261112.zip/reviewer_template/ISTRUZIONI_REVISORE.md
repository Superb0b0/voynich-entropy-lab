# Revisione indipendente delle illustrazioni zodiacali (Beinecke MS 408)

**Compito:** annotare autonomamente le ruote zodiacali visibili negli otto JPEG forniti, senza usare trascrizioni, coordinate, inventari, analisi precedenti o confrontarsi con altri revisori. Nessun conteggio atteso di figure o testi viene comunicato.

Aprire `annotate_offline.html` in un browser, selezionare i JPEG `IMG_01.jpg` ... `IMG_08.jpg`, tracciare un rettangolo per ogni ruota visibile (modalità `ruota`) e rettangoli separati per le regioni oggetto (modalità `oggetto`). Esportare il JSON frequentemente. Il file funziona localmente e non invia dati a un server. Se una ruota è parzialmente visibile, registrarla con una nota e non ricostruire elementi mancanti.

Classi strutturali per gli oggetti: `human_candidate` (figura umana o apparentemente tale), `central_star` (stella centrale), `other_depicted_object` (altra raffigurazione), `text_region` (regione con segni grafici assimilabili a scrittura). Non trascrivere né interpretare il testo. Non usare contenitore, postura o indumento come attributo primario. Ogni oggetto visibile va delimitato con un rettangolo anche se la forma non è regolare; evitare di includere oggetti vicini quando possibile.

Stati: `present` (oggetto distinguibile), `ambiguous` (non è possibile decidere con sicurezza se la regione costituisca un oggetto distinto), `not_localizable` (oggetto presumibile ma impossibile delimitarlo). `not_localizable` può avere rettangolo nullo, con nota obbligatoria. Non inventare oggetti assenti. Le aree incerte non devono essere cancellate per aumentare la concordanza.

Confidence: `high` = contorno riconoscibile e sostanzialmente visibile; `medium` = contorno parzialmente occluso o incerto ma localizzabile; `low` = delimitazione largamente congetturale. È una valutazione visiva, non la probabilità di collegamento con un testo.

Ogni regione oggetto deve indicare l'ID locale della ruota, ad esempio `W1`, `W2`, ecc., assegnato da te all'interno della singola immagine. Puoi annotare prima le ruote e poi gli oggetti. Se l'immagine non contiene una ruota riconoscibile, lascia la sezione vuota e annotalo nelle note. L'ordine degli ID locali non esprime un ordinamento codicologico.

**Consegna:** esporta il JSON, verifica che si riapra correttamente e consegnalo solo al custode. Non comunicarlo all'altro revisore. Non riceverai gli esiti di accordo fino a quando entrambi i file saranno chiusi e datati. La tua dichiarazione di indipendenza viene raccolta separatamente dal custode.

L'annotazione non deve stabilire quale etichetta appartenga a quale figura. La sola concordanza geometrica non valida un collegamento figura-testo.
