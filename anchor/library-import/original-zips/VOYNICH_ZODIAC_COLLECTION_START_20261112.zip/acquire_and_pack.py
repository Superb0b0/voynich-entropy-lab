#!/usr/bin/env python3
"""Fetch eight archival scans, fail closed on SHA/dimensions, assemble identical blind reviewer packets.
This script never submits annotations, recruits reviewers, or claims independent review.
"""
from __future__ import annotations
import argparse, datetime as dt, hashlib, json, shutil, sys, time, urllib.request, zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
MANIFEST=ROOT/'custodian'/'ACQUISITION_MANIFEST.json'
ORIGINALS=ROOT/'custodian'/'downloaded_originals'
OUTPUT=ROOT/'custodian'/'completed_packets'
REVIEWER=ROOT/'reviewer_template'

def sha256(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
 return h.hexdigest()

def dimensions(path):
 try:
  from PIL import Image
 except ImportError:
  raise RuntimeError('Pillow required for pixel dimensions: python -m pip install Pillow')
 with Image.open(path) as im:
  im.verify()
 with Image.open(path) as im:
  return im.size, im.format

def validate(path,rec):
 if not path.is_file(): return False,'MISSING'
 if path.stat().st_size!=rec['expected_bytes']: return False,f'BYTE_COUNT_MISMATCH ({path.stat().st_size})'
 observed=sha256(path)
 if observed!=rec['expected_sha256']: return False,f'SHA256_MISMATCH ({observed})'
 try: (w,h),fmt=dimensions(path)
 except Exception as e: return False,f'INVALID_IMAGE ({e})'
 if (w,h)!=(rec['expected_width'],rec['expected_height']): return False,f'DIMENSIONS_MISMATCH ({w}x{h})'
 if fmt!='JPEG': return False,f'UNEXPECTED_FORMAT ({fmt})'
 return True,'VERIFIED'

def get_manifest():
 obj=json.loads(MANIFEST.read_text(encoding='utf8'))
 assert len(obj['items'])==8 and len({x['canvas_oid'] for x in obj['items']})==8
 return obj['items']

def report(items):
 results=[]
 for x in items:
  ok,reason=validate(ORIGINALS/(x['canvas_oid']+'.jpg'),x)
  results.append(dict(alias=x['image_alias'],canvas_oid=x['canvas_oid'],verified=ok,reason=reason))
  print(f"{x['image_alias']} ({x['canvas_oid']}): {reason}")
 return results

def download(items):
 ORIGINALS.mkdir(parents=True,exist_ok=True)
 for x in items:
  target=ORIGINALS/(x['canvas_oid']+'.jpg')
  ok,reason=validate(target,x)
  if ok:
   print(f"{target.name}: already verified")
   continue
  if target.exists():
   raise RuntimeError(f'{target.name}: existing file fails validation ({reason}). Refusing overwrite. Move it aside manually.')
  temp=target.with_suffix('.part')
  if temp.exists(): raise RuntimeError(f'Stale partial file {temp}; remove after inspection')
  print(f"Downloading {x['image_alias']} from mirror, {x['expected_bytes']/1e6:.1f} MB")
  try:
   req=urllib.request.Request(x['mirror_url'],headers={'User-Agent':'VoynichResearchImageAcquisition/1.0 (archival study)'})
   with urllib.request.urlopen(req,timeout=120) as r, open(temp,'wb') as out:
    while True:
     chunk=r.read(1024*1024)
     if not chunk: break
     out.write(chunk)
     if out.tell()>x['expected_bytes']+1024: raise RuntimeError('Downloaded bytes exceed expected length')
   ok,reason=validate(temp,x)
   if not ok: raise RuntimeError(f'{x["image_alias"]}: {reason}')
   temp.rename(target)
  except Exception:
   temp.unlink(missing_ok=True)
   raise
  time.sleep(1)

def pack(items):
 status=report(items)
 if not all(x['verified'] for x in status):
  raise RuntimeError('PACKET_BLOCKED: missing or unverified scans; no reviewer packet created.')
 OUTPUT.mkdir(parents=True,exist_ok=True)
 dest=OUTPUT/'VOYNICH_12_PANEL_REVIEWER_BLIND_IDENTICAL.zip'
 if dest.exists(): raise RuntimeError('Refusing to overwrite existing reviewer packet')
 now=dt.datetime.now(dt.timezone.utc).isoformat()
 with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_STORED) as z:
  for x in items:
   z.write(ORIGINALS/(x['canvas_oid']+'.jpg'),arcname=x['image_alias'])
  for filename in ('ISTRUZIONI_REVISORE.md','annotate_offline.html','annotation_template.json'):
   z.write(REVIEWER/filename,arcname=filename)
  checks=''.join(f'{x["expected_sha256"]}  {x["image_alias"]}\n' for x in items)
  z.writestr('IMAGE_SHA256SUMS.txt',checks)
 receipt=dict(utc=now,packet_name=dest.name,packet_sha256=sha256(dest),image_count=len(items),images=[dict(alias=x['image_alias'],sha256=x['expected_sha256'],canvas_oid_private=x['canvas_oid']) for x in items],reviewer_distribution='NOT_DISTRIBUTED',annotation_status='NOT_STARTED',independence_forms='NOT_RECEIVED')
 (OUTPUT/'PACKET_RECEIPT_PRIVATE.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
 print('CREATED',dest, 'SHA256',receipt['packet_sha256'])
 print('WARNING: do not send private receipt to reviewers; custody forms must be signed first.')

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('command',choices=['status','download','pack'])
 a=p.parse_args()
 items=get_manifest()
 if a.command=='status': report(items)
 if a.command=='download': download(items);report(items)
 if a.command=='pack': pack(items)

if __name__=='__main__':
 try: main()
 except Exception as e:
  print('STOP:',e,file=sys.stderr);sys.exit(2)
