import re,collections,json,hashlib,pathlib
ROOT=pathlib.Path('/mnt/data/files')
def get(f):
 data=(ROOT/f).read_text()
 loci=[]
 for line in data.splitlines():
  m=re.match(r'^<([^<>]+)>\s+(.*)$',line)
  if not m or ',' not in m.group(1):continue
  locus,body=m.groups(); page,kind=locus.rsplit(',',1)
  # remove comments, braces, lacuna and markup; keep whole clear EVA tokens only
  body=re.sub(r'<!.*?>','',body)
  body=re.sub(r'<[^>]*>','',body)
  words=re.findall(r'(?<![a-z])([a-z]{2,})(?![a-z])',body)
  loci.append((page,kind,words))
 return data,loci
out={}
for fn in ['ZL3b-n.txt','IT2a-n.txt']:
 data,loci=get(fn)
 global_freq=collections.Counter(x for p,k,ws in loci for x in ws)
 # labels only, excluding star circle and radial text
 labfreq=collections.Counter(x for p,k,ws in loci if 'L' in k for x in ws)
 stars=[(p,k,ws) for p,k,ws in loci if re.match(r'f68r3\.(?:1[0-9]|20|21),',p+','+k)]
 # f68r3.10 to 21 = 12 star/curve labels; others f68r3.22 circle
 stars=[(p,k,ws) for p,k,ws in stars if 10<=int(p.split('.')[1])<=21]
 records=[]
 for p,k,ws in stars:
  records.append(dict(locus=p,kind=k,words=ws,global_counts={w:global_freq[w] for w in ws},label_counts={w:labfreq[w] for w in ws}))
 out[fn]={'bytes':len(data.encode()),'sha256':hashlib.sha256(data.encode()).hexdigest(),'loci':len(loci),'total_word_pieces':sum(map(len,(x[2] for x in loci))),'star_labels':records,'star_words':sum(len(x[2]) for x in stars),'star_unique_globally':sum(global_freq[w]==1 for p,k,ws in stars for w in ws),'other_label_tokens':sum(c for x,c in labfreq.items()),'other_label_hapax_rate':sum(c for x,c in labfreq.items() if global_freq[x]==1)/max(1,sum(labfreq.values()))}
print(json.dumps(out,indent=2,ensure_ascii=False))
pathlib.Path('/mnt/data/ASTRO_ANCHOR_01_RESULTS.json').write_text(json.dumps(out,indent=2,ensure_ascii=False))
