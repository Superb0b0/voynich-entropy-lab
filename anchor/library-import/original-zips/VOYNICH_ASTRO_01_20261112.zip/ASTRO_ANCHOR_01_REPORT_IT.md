# ASTRO-01 — Verifica dell'ancora Pleiadi in f68r3

Data: 12 novembre 2026. Ramo indipendente, esplorativo, in sola lettura. Gli artefatti RC1.4.2 congelati non sono stati modificati.

## Domanda
La sequenza `doaro`, scritta presso il gruppo di sette stelle di f68r3 spesso identificato con le Pleiadi, fornisce una corrispondenza semantica riutilizzabile e verificabile su altri folii?

## Input
- `ZL3b-n.txt`: SHA-256 `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc`.
- `IT2a-n.txt`: seconda trascrizione indipendente, consultata in parallelo.
- Riferimenti esterni: Jorge Stolfi, pagina descrittiva f68r3; René Zandbergen, descrizione delle illustrazioni astronomiche (voynich.nu).

## Risultati empirici

| Misura | ZL3b | IT2a |
|---|---:|---:|
| Occorrenze esatte di `doaro` | 1 | 1 |
| Occorrenze esatte di `oalcheol` | 1 | 1 |
| Stringhe alfabetiche, segmento di etichette f68r3.10–.21 | 14 | 14 |
| Stringhe che compaiono una volta nell'intera trascrizione | 5/14 (35,7%) | 4/14 (28,6%) |
| Proporzione descrittiva di token etichetta unici nell'intera trascrizione | 36,0% | 39,9% |

Unicità di `doaro` e `oalcheol` verificata con il controllo sui loci e con ricerca lessicale esatta. Le etichette sono registrate in f68r3.11 e f68r3.12 rispettivamente. Il gruppo di sette stelle e la linea curva sono descritti nella documentazione iconografica; l'etichetta non è decifrata.

Le frequenze delle etichette sono descrittive e non indipendenti: molte stringhe derivano da uno stesso diagramma, le trascrizioni divergono in alcuni segni e il semplice tokenizer regex non è un parser IVTFF canonico. Le percentuali non sono un test di significatività.

## Decisione
- **PASS**: identificazione del locus e conferma della stringa `doaro` in due trascrizioni.
- **FAIL**: verifica di ripetizione della stessa stringa in un secondo contesto iconografico indipendente; non c'è alcuna seconda occorrenza esatta.
- **NON TESTABILE**: l'equivalenza semantica `doaro = Pleiadi` e il recupero di una regola di cifratura.

Il diagramma ha una lettura figurativa plausibile ma non fornisce ancora un'ancora lessicale validata. Non inferire nessuna parola tradotta, nessuna data astronomica, nessuna chiave.

## Prossima decisione razionale
Passare a un simbolo o a una legenda astronomica che contenga **due rappresentazioni indipendenti della stessa referenza** (per esempio un nome leggibile e un'immagine, oppure una serie numerica esplicita ripetuta), e fissare l'osservazione predetta prima di ispezionare il testo Voynich di verifica. La sola identificazione delle Pleiadi non supera questa soglia.

## Riproducibilità
`astro_anchor_check.py` analizza in sola lettura i due file sotto `/mnt/data/files`, restituisce le etichette dei loci .10–.21, i conteggi lessicali e la sintesi. `ASTRO_ANCHOR_01_RESULTS.json` contiene l'output completo. Il controllo del codice non è una replica della semantica, soltanto dei conteggi.
