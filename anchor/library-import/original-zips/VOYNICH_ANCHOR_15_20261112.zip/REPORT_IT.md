# ANCHOR-15 | L’accoppiamento del bifoglio f18v/f23r

**Data:** 12 novembre 2026. **Stato:** confronto documentale e verifica lessicale limitata; nessuna decifrazione.

## Risultato solido (preesistente)

Le piante disegnate su **f18v** e **f23r**, lati dello stesso bifoglio fisico, ricompaiono come frammenti farmaceutici **212** (f102r2, terza riga, prima posizione) e **213** (f102r2, terza riga, seconda posizione). Questo legame era stato notato da René Zandbergen e riportato pubblicamente nel 2010; non è una scoperta nuova.

Il dato sostiene che chi ha allestito la sezione farmaceutica potrebbe aver consultato il bifoglio illustrato come una unità fisica, oppure utilizzato una fonte comune che ne preservava la disposizione. Non distingue fra le due possibilità e non determina il nome di alcuna pianta.

## Verifica nuova e circoscritta sui byte del corpus

- Per f18v la prima parola della prima riga del testo continuo in ZL3b è **`told`**; l'etichetta farmacologica 212 è **`koldarod`**.
- Per f23r la prima parola della prima riga è **`pydchdom`**; l'etichetta 213 è **`odalydary`**.
- Nessuna delle due coppie coincide come stringa esatta. Non si deve concludere che i nomi siano assenti dal testo: le prime parole potrebbero non essere nomi, e i nomi potrebbero usare una codifica diversa.
- Il corpus è letto in sola lettura; nessun artefatto RC1.4.2 è alterato.

## Una pista storico-iconografica da trattare senza scorciatoie

La tradizione degli **erbari alchemici** utilizza immagini di radici fantastiche e una sequenza relativamente stabile di circa 98 piante, ma non è stata qui trovata alcuna identificazione esterna *specifica e verificata* per la coppia f18v/f23r. René Zandbergen riferiva di non avere trovato una copia integrale identica del disegno Voynich fra 50 erbari confrontati.

Perciò: **nessuna corrispondenza con una pianta denominata medievalmente può ancora essere impiegata come chiave**.

## Test futuro che cambierebbe le conclusioni

Servono tre prove concatenate: (1) un'identificazione iconografica indipendente e specifica degli stessi due esemplari in un codice non Voynich; (2) nomi o rubriche leggibili associati esplicitamente a ciascuna immagine; (3) una regola testuale che spieghi entrambe le etichette Voynich e predica nuove etichette fuori campione. È vietato adattare la regola dopo aver visto il secondo esemplare.

## Fonti

- https://voynich.nu/q03/index.html
- https://voynich.nu/q19/index.html
- https://ciphermysteries.com/2010/02/17/rene-zs-bifolio-surprise
- https://www.ic.unicamp.br/en/~stolfi/EXPORT/voynich/00-06-07-word-grammar/Notes/064/work/projects/voynich/projects/programs/c/big/big/projects/voynich/Notes/091/report/report_091.html
- https://philipneal.net/voynichsources/alchemical/
