# ANCHOR-27 | Attacco ciphertext-only, controllo sintetico

**Data:** 12 novembre 2026. **Stato:** completato per il modello sintetico. Nessuna decifrazione Voynich.

## Ipotesi

Una permutazione sconosciuta delle lettere può essere recuperata dal solo testo cifrato con un attacco elementare basato su frequenze, in un sistema a due rappresentazioni per lettera. Il modello è ispirato alla famiglia dei cifrari con sostituzione e omofoni, ma **non implementa il cifrario Naibbe originale**.

## Disegno

- Bersaglio: 282 lettere latine normalizzate dal testo pubblicato del cifrario Borg, facciata 0010r, tenute segrete durante l'attacco.
- Riferimento linguistico indipendente dal bersaglio: 399 lettere estratte dalle facciate 0010v e 0011r dello stesso manoscritto. Il genere e la lingua sono quindi noti: questo favorisce l'attaccante.
- Una nuova permutazione nascosta dell'alfabeto a 22 lettere per ognuna di 100 prove; ciascun carattere cifrato ha due varianti, estratte casualmente.
- L'attaccante vede solo il messaggio cifrato, conosce i confini e sa quali due simboli rappresentano uno stesso carattere cifrato, ma **non** come quel carattere corrisponda alla lettera latina.
- Ricostruisce la mappa ordinando i caratteri cifrati e quelli del testo di riferimento secondo frequenza.
- Un comparatore usa una chiave casuale, valutata separatamente. L'originale è consultato solo per misurare gli errori.

## Risultato effettivamente ottenuto

| Misura | Risultato |
|---|---:|
| Prove | 100 |
| Accuratezza media dell'attacco a frequenze | 22,18% |
| Intervallo fra prove | 9,93%-37,59% |
| Accuratezza media chiave casuale | 5,59% |
| Intervallo chiavi casuali | 0%-23,40% |

**Verdetto:** il metodo ricava segnale superiore alla chiave casuale in media, ma fallisce ampiamente l'obiettivo della decifrazione. Non può essere applicato come prova di significato al Voynich.

## Limiti critici

1. Attacco elementare, non ottimizzato, contro un **simulatore**, non contro il Naibbe storico completo né direttamente contro Voynich.
2. I confini dei simboli e l'accoppiamento degli omofoni sono noti, mentre nel Voynich sono ignoti.
3. Il corpus di riferimento è breve e proviene dallo stesso genere e manoscritto: il caso reale sarebbe molto più difficile.
4. Il corpus bersaglio contiene convenzioni editoriali (testo tra parentesi quadre eliminato), e le lettere sono normalizzate senza spazi.
5. Non è stato condotto un attacco con modelli linguistici n-gram, ricerca combinatoria o IA. Questo risultato negativo **non dimostra impossibilità della decifrazione ciphertext-only**.

## Passo discriminante successivo

Per valutare davvero l'ipotesi Naibbe servono corpus di prova lunghi e autenticati, il generatore originale completo, una chiave nascosta, nessun accesso al testo chiaro in addestramento, un modello linguistico addestrato su fonti indipendenti, prove su pagine riservate e metriche predefinite, compresi i falsi positivi. Il confronto con Voynich si può fare soltanto **dopo** aver dimostrato che il recuperatore supera i test sintetici e storici.

## Riproduzione

`python run_anchor27.py` nella cartella con `borg_0010r_plaintext_extracted.txt`. `results.json` e `replications.json` sono prodotti con seme fisso `20261112`. Non vengono modificati gli artefatti congelati RC1.4.2.
