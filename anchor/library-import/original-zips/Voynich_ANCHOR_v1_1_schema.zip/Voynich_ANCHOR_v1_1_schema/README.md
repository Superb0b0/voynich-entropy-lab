# Schema ANCHOR per la futura v1.1.0

Questo pacchetto è una **bozza di schema**, non una nuova release scientifica e non modifica la v1.0.0.

- Ogni risultato ANCHOR nasce come `PENDING`, classificato `ESPLORATIVO`.
- `PASS` è ammesso soltanto dopo verifica documentata di sorgenti, hash completi, comando/script e riproduzione del controllo specificato. `PASS` non significa decifrazione né sblocco RC1.4.2.
- `NOT_ACQUIRED` segnala documenti o byte mancanti, non un risultato negativo.
- `gate_effect` è obbligatoriamente `NONE`.
- I file sorgente non vengono modificati; le nuove evidenze creano nuove voci/versioni.
- SHA-256 assente è `null`, mai una stringa abbreviata spacciata per digest.
- L'ID `$id` usa un dominio `.invalid` segnaposto e non rappresenta un endpoint.

Stato test browser della v1.0.0: non certificato. Non allegare un verbale PASS finché non sono verificati hash browser, filtri combinati, export JSON e persistenza note dopo reload.
