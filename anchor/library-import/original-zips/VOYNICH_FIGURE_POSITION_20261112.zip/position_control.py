from pathlib import Path
import numpy as np, pandas as pd, json, csv, hashlib
ROOT=Path(__file__).resolve().parent
D=pd.read_csv(ROOT/'source_labels_rings.csv',keep_default_na=False)
D=D[D['clean'].astype(str).str.lower()=='true'].copy()
D['ot']=D.word.str.startswith('ot').astype(int);D['o']=D.word.str.startswith('o').astype(int)
def angle(x):
 try:
  h,m=map(int,x.split(':'));return ((h%12)*60+m)/720*360
 except:return np.nan
D['angle']=D.clock.apply(angle)
D['quadrant']=((D.angle+45)//90 %4).astype('Int64')
D['symbol']='Figure accompanied by star; individual star/gesture not independently annotated'
D['tub']='unverified individual'
D.to_csv(ROOT/'figure_label_manifest.csv',index=False)
# exact/group-conditional MC: constrain ring group and clock quadrant, preserving page totals, only ZL
out=[]
for tr in ['ZL3b','IT2a']:
 a=D[D.transcription==tr]
 for strat_name,cols in [('page',['folio']),('page_o',['folio','o']),('page_quadrant',['folio','quadrant'])]:
  if strat_name=='page_quadrant' and tr=='IT2a': continue
  t=a.copy().reset_index(drop=True)
  if strat_name=='page_quadrant':t=t.dropna(subset=['quadrant']).reset_index(drop=True)
  groups=[v.index.to_numpy() for _,v in t.groupby(cols,dropna=False)]
  x=t.ot.to_numpy();mask=t.ring.to_numpy().astype(int)==1
  def stat(mm):
   return float(np.mean([x[(t.folio.to_numpy()==f)&mm].mean()-x[(t.folio.to_numpy()==f)&~mm].mean() for f in t.folio.unique()]))
  obs=stat(mask)
  rng=np.random.default_rng(20261112)
  B=9999;vals=[]
  for j in range(B):
   mm=mask.copy()
   for inds in groups:mm[inds]=rng.permutation(mm[inds])
   vals.append(stat(mm))
  vals=np.array(vals)
  p=(1+(np.abs(vals-vals.mean())>=abs(obs-vals.mean())-1e-12).sum())/(B+1)
  out.append({'transcription':tr,'control':strat_name,'n':len(t),'observed_5_minus_10':obs,'p_two_sided':p,'null_std':vals.std(),'null_mean':vals.mean(),'distinct_groupings_upper_bound':int(np.prod([__import__('math').comb(len(g),int(mask[g].sum())) for g in groups]))})
# focus directly on f72r1 (tub difference by annulus), versus other all-tub pages
for tr in ['ZL3b','IT2a']:
 a=D[D.transcription==tr]
 for f,v in a.groupby('folio'):
  lo=v[v.ring==0];hi=v[v.ring==1]
  out.append({'transcription':tr,'control':'descriptive_'+f,'n':len(v),'observed_5_minus_10':round(hi.ot.mean()-lo.ot.mean(),4),'p_two_sided':None,'null_std':None,'null_mean':None,'distinct_groupings_upper_bound':None})
pd.DataFrame(out).to_csv(ROOT/'position_results.csv',index=False)
(ROOT/'results.json').write_text(json.dumps(out,indent=2)+'\n')
print(pd.DataFrame(out).to_string(index=False))
