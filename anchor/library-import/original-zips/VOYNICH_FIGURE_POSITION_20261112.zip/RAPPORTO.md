# EXP-FIRST-WORD-03 — Controllo condizionale posizione/etichetta

Data: 2026-11-12. **Esplorativo, post-hoc, non una decifrazione.** RC1.4.2 congelato e non modificato.

## Scopo
Verificare l'eccesso della prima parola EVA che inizia per `ot` nel gruppo di 5 etichette rispetto al gruppo di 10 delle mezze ruote zodiacali f70v1, f71r, f71v e f72r1. L'obiettivo era tentare un collegamento fra parola e figura; NON è stato possibile convalidare attributi individuali sufficientemente discriminanti e indipendenti.

## Fonti
- Input: `source_labels_rings.csv`, derivato da ZL3b-n.txt e IT2a-n.txt, stesse etichette del manoscritto.
- Descrizioni esterne dei folii: https://voynich.nu/q10/index.html e https://voynich.nu/q11/index.html. Gli anelli contengono 10 e 5 figure/etichette; le descrizioni qualificano quasi tutte le figure come accompagnate da stelle. f72r1 differisce per le figure senza tinozza in un anello. Si tratta di descrizioni delle pagine, non di annotazioni indipendenti delle singole figure.
- Il parametro `ring` nel dataset è l'ordine dei due gruppi delimitati da `@Lz` nel testo, NON un'identificazione geometrica indipendente di anello interno/esterno.

## Dati
- ZL3b: 58 primi token non ambigui, tutti con informazioni orarie.
- IT2a: 60 primi token non ambigui, ma nessun dato orario nel file di input.
- Una riga del manifesto è una prima parola di un'etichetta, con folio, gruppo, orario (se disponibile), indicatore iniziale `o` e indicatore iniziale `ot`.
- Per le caratteristiche individuali della figura, l'attributo rimane `unverified`: NON sono stati inventati colore, abito, gesti o tipo di vasca per singola etichetta.

## Metodo
Contrasto osservato: media, con uguale peso per ciascuno dei quattro folii, della proporzione di etichette `ot` nel gruppo da 5 meno la proporzione nel gruppo da 10. Nulli per permutazione (9.999, seed 20261112), che rimescolano l'assegnazione di gruppo conservando i totali in ogni strato:
1. Pagina;
2. Pagina × indicatore `inizia_o`;
3. Pagina × quadrante orario derivato dal marcatore (solo ZL3b).

Nei controlli con stratificazione supplementare la distribuzione nulla può avere media diversa da zero; il p a due code è calcolato dalla distanza rispetto alla **media del nullo**, non rispetto a zero. Questi controlli sono scelti dopo che l'effetto `ot` è stato scoperto; non sono validazioni cieche.

## Risultati

| Trascrizione | Nullo | Differenza 5-10 | p due code |
|---|---|---:|---:|
| ZL3b | pagina | 0,304 | 0,0311 |
| ZL3b | pagina × iniziale o | 0,304 | 0,0867 |
| ZL3b | pagina × quadrante | 0,304 | 0,0235 |
| IT2a | pagina | 0,300 | 0,0403 |
| IT2a | pagina × iniziale o | 0,300 | 0,0701 |

I p sono nominali, senza correzione per tutti i confronti precedenti. ZL3b e IT2a sono trascrizioni dello stesso manoscritto, non campioni indipendenti.

## Verdetto
Nessuna correlazione convincente fra `ot` e specifico oggetto/attributo delle singole figure. L'ipotetica preferenza di `ot` per il gruppo da cinque non è abbastanza robusta al controllo per l'iniziale `o`, ed era già non significativa con correzione multipla nell'esperimento precedente. Il null per il quadrante non è un controllo visivo degli attributi della figura. **Prima parola non identificata.**

## Prossima prova veramente utile
Definire e ottenere un dataset di sessanta ritagli a risoluzione sufficiente con mascheramento del testo, con coordinate figura↔etichetta validate singolarmente da due revisori indipendenti. Registra `star_held`, `container`, `clothing`, `gesture`, `color` come presenti/assenti/incerti, poi testa predizioni congelate su altre ruote. La sola descrizione per folio non fornisce questi dati.

## Riproduzione
Da `VOYNICH_FIGURE_POSITION_20261112/`, con i sorgenti contenuti nella stessa cartella:

```bash
python position_control.py
```

Dipendenze: numpy, pandas. Output: `figure_label_manifest.csv`, `position_results.csv`, `results.json`.
