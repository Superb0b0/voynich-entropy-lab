EXP-FIRST-WORD-03: controllo condizionale delle etichette di Ariete/Toro. Leggere RAPPORTO.md. Non è una traduzione. Input deriva dal dossier VOYNICH_LABEL_RING_20261112. RC1.4.2 invariato.
