#!/usr/bin/env python3
"""EXP-BRT-01: fixed, exploratory candidate process; never reads heldout tokens for generation.
Three distinct mechanisms: birth, reuse of already born forms, cross-line propagation.
Historical heldout layout only. Models specified before generation output inspection.
"""
from pathlib import Path
from collections import Counter,defaultdict
from types import SimpleNamespace
import numpy as np, csv, json, sys, math, statistics, hashlib
ROOT=Path(__file__).resolve().parent
PREV=(ROOT/'dependencies' if (ROOT/'dependencies').exists() else ROOT.parent/'VOYNICH_MORPHOGEN_20261112')
old=(PREV/'family.py').read_text()
ns={'__file__':str(PREV/'family.py'),'__name__':'brt_setup'}
exec(compile(old[:old.index('result={')],str(PREV/'family.py'),'exec'),ns)
folios,meta,base,val,test=ns['folios'],ns['meta'],ns['base'],ns['val'],ns['test']
summary,matched_or,build,mutation=ns['summary'],ns['matched_or'],ns['build'],ns['mutation']
# Configs are FIXED a priori, cannot optimize on output.
SETTINGS={
 'control_family_10_30':{'local_copy':.10,'recent_mutate':.30,'birth':0.,'birth_reuse':0.,'folio_reuse':0.},
 'three_process_conservative':{'local_copy':.12,'recent_mutate':.08,'birth':.09,'birth_reuse':.05,'folio_reuse':.08},
 'three_process_diverse':{'local_copy':.09,'recent_mutate':.14,'birth':.08,'birth_reuse':.04,'folio_reuse':.08},
 'three_process_recycling':{'local_copy':.14,'recent_mutate':.09,'birth':.06,'birth_reuse':.10,'folio_reuse':.12},
}
SEEDS=[4401,4402,4403,4404,4405]

def generator(trans,setting,seed,spec):
 vocab,alpha,charw,licensed,dist=spec
 weights=SETTINGS[setting];rng=np.random.default_rng(seed)
 out=[]; counters=Counter()
 for folio in sorted(test):
  words,cdf=dist[meta[folio]]
  born=[]; history=[]
  for paragraph in folios[folio]:
   prev=[]
   for true_row in paragraph:
    recent=[w for r in prev[-2:] for w in r]
    arr=[]
    for _ in range(len(true_row[trans])):
     z=rng.random();acc=0.;w=None;which=None
     for name in ['local_copy','recent_mutate','birth','birth_reuse','folio_reuse']:
      acc+=weights[name]
      if z<acc:
       which=name;break
     if which is None:which='global'
     if which=='local_copy' and recent:w=recent[int(rng.integers(len(recent)))]
     elif which=='recent_mutate' and recent:
      anchor=recent[int(rng.integers(len(recent)))]
      w=mutation(anchor,rng,alpha,charw,licensed,True,vocab) or anchor
      if w not in vocab and w not in born:born.append(w)
     elif which=='birth':
      anchor=words[int(np.searchsorted(cdf,rng.random(),side='right'))]
      w=mutation(anchor,rng,alpha,charw,licensed,True,vocab) or anchor
      if w not in vocab and w not in born:born.append(w)
     elif which=='birth_reuse' and born:w=born[int(rng.integers(len(born)))]
     elif which=='folio_reuse' and history:w=history[int(rng.integers(len(history)))]
     else:w=words[int(np.searchsorted(cdf,rng.random(),side='right'))]
     counters[which]+=1
     arr.append(w)
    out.append(arr);prev.append(arr);history.extend(arr)
 return out,counters

def descriptor(rows,base_vocab):
 tokens=[w for row in rows for w in row];fs=Counter(tokens);types=set(fs)
 return {'oov_type_rate':len(types-base_vocab)/len(types),
         'oov_token_rate':sum(fs[w] for w in types-base_vocab)/len(tokens),
         'distinct_oov_types':len(types-base_vocab),
         'oov_singletons':sum(fs[w]==1 for w in types-base_vocab),
         'oov_repeat_fraction':sum(fs[w]>1 for w in types-base_vocab)/max(1,len(types-base_vocab)),
         'token_mean_len':sum(map(len,tokens))/len(tokens),
         'y_first':sum(row[0].startswith('y') for row in rows if row)/len(rows)}

out={'experiment':'EXP-BRT-01','regime':'EXPLORATORY_POSTHOC_REUSED_HOLDOUT','seeds':SEEDS,'models':SETTINGS,'notes':['No y-first intervention; test positional structure emerges or fails','Historical heldout row lengths reused, NOT generated','The test folios have been examined in past experiments; not confirmatory','ZL3b and IT2a two transcriptions of same manuscript','No parameter tuning based on any generated results','Base vocabulary and permitted character bigrams only from base folios'], 'reference':{},'runs':[]}
for trans in ['zl','it']:
 spec=build(trans);ref=[list(row[trans]) for f in sorted(test) for par in folios[f] for row in par]
 out['reference'][trans]={**summary(ref),**descriptor(ref,spec[0]),'yo_or':matched_or(ref)['or']}
 print('START',trans,'reference',out['reference'][trans],flush=True)
 for kind in SETTINGS:
  for seed in SEEDS:
   rows,channels=generator(trans,kind,seed,spec)
   m={**summary(rows),**descriptor(rows,spec[0]),'yo_or':matched_or(rows)['or']}
   assert m['tokens']==out['reference'][trans]['tokens'] and m['lines']==out['reference'][trans]['lines']
   out['runs'].append({'trans':trans,'model':kind,'seed':seed,**m,'channel_counts':dict(channels)})
   print(trans,kind,seed,'hapax',round(m['hapax'],3),'adj',round(m['adjacency'],3),'oov',round(m['oov_token_rate'],3),flush=True)
(ROOT/'results.json').write_text(json.dumps(out,indent=2))
keys=['trans','model','seed','tokens','lines','types','density','adjacency','repetition','hapax','edit1_between_adjacent_rows','oov_type_rate','oov_token_rate','oov_repeat_fraction','token_mean_len','y_first','yo_or']
with (ROOT/'runs.csv').open('w',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=keys);wr.writeheader();wr.writerows([{k:r.get(k) for k in keys} for r in out['runs']])
# Leave all models locked; no ranking selects a model as a fitted success.
for trans in ('zl','it'):
 print('REFERENCE',trans, {k:round(out['reference'][trans][k],4) for k in ['density','adjacency','repetition','hapax','oov_type_rate','oov_token_rate','yo_or']})
 for kind in SETTINGS:
  rr=[r for r in out['runs'] if r['trans']==trans and r['model']==kind]
  print('MODEL',trans,kind,{k:round(np.mean([x[k] for x in rr]),4) for k in ['density','adjacency','repetition','hapax','oov_type_rate','oov_token_rate','yo_or']})
print('COMPLETE',len(out['runs']),flush=True)
