#!/usr/bin/env python3
"""EXP-BRT-02 exploratory posthoc models. Fixed before any BRT-02 output inspection.
No synthetic lexical leakage. Same formerly inspected test layout. Three variants.
"""
from pathlib import Path
import json, csv, numpy as np
from collections import Counter
ROOT=Path(__file__).resolve().parent
script=(ROOT/'test.py').read_text();ns={'__file__':str(ROOT/'test.py'),'__name__':'survival_setup'}
exec(compile(script[:script.index('out={')],str(ROOT/'test.py'),'exec'),ns)
folios,meta,base,test=ns['folios'],ns['meta'],ns['base'],ns['test']
build,mutation,summary,descriptor,matched_or=ns['build'],ns['mutation'],ns['summary'],ns['descriptor'],ns['matched_or']
SEEDS=[5501,5502,5503,5504,5505]
# Birth rate 10%, recent mutation 8%; exact recent reuse 6%. No position intervention.
# Each inherited novelty is a local generated form, never the heldout test's words.
MODELS={
 'flatten_only':{'temp':.65,'birth':0.,'recent_mut':0.,'recent_copy':0.,'archive_prob':0.,'archive_policy':'off'},
 'limited_reuse':{'temp':.65,'birth':.10,'recent_mut':.08,'recent_copy':.06,'archive_prob':.05,'archive_policy':'one_reuse'},
 'decaying_reuse':{'temp':.65,'birth':.10,'recent_mut':.08,'recent_copy':.06,'archive_prob':.05,'archive_policy':'exp2'},
 'flat_unaltered_birth':{'temp':1.0,'birth':.10,'recent_mut':.08,'recent_copy':.06,'archive_prob':.05,'archive_policy':'one_reuse'}
}

def generate(trans,model,seed,spec):
 setting=MODELS[model];vocab,alphabet,charweights,licensed,by=spec
 rng=np.random.default_rng(seed);out=[];counts=Counter()
 # Global word distributions learned only from base; flatten by fixed exponent.
 worddraw={}
 for cls,(words,cdf) in by.items():
  orig=np.diff(np.concatenate([[0],cdf]));p=np.power(orig,setting['temp']);p=p/p.sum();worddraw[cls]=(words,np.cumsum(p))
 for f in sorted(test):
  words,cdf=worddraw[meta[f]];born={}  # word -> [creation_row, additional_reuses]
  for par in folios[f]:
   prev=[]
   for true_row in par:
    recent=[w for r in prev[-2:] for w in r];row_index=len(out);arr=[]
    for col in range(len(true_row[trans])):
     p=rng.random();acc=setting['birth'];choice='global'
     if p<acc:choice='birth'
     elif p<(acc:=acc+setting['recent_mut']):choice='recent_mut'
     elif p<(acc:=acc+setting['recent_copy']):choice='recent_copy'
     elif p<(acc:=acc+setting['archive_prob']):choice='archive'
     if choice=='archive':
      elig=[];wt=[]
      for w,(created,reused) in born.items():
       if setting['archive_policy']=='one_reuse' and reused>=1:continue
       weight=(np.exp(-(row_index-created)/2) if setting['archive_policy']=='exp2' else 1.)
       if weight<1e-9:continue
       elig.append(w);wt.append(weight)
      if elig:
       ww=np.asarray(wt,dtype=float);ww/=ww.sum();w=elig[int(rng.choice(len(elig),p=ww))]
       born[w][1]+=1
      else:choice='global'
     if choice=='recent_copy':
      if recent:w=recent[int(rng.integers(len(recent)))]
      else:choice='global'
     if choice in ['birth','recent_mut']:
      if choice=='recent_mut' and recent:anchor=recent[int(rng.integers(len(recent)))]
      else:anchor=words[int(np.searchsorted(cdf,rng.random(),side='right'))]
      w=mutation(anchor,rng,alphabet,charweights,licensed,True,vocab) or anchor
      if w not in vocab and w not in born:born[w]=[row_index,0]
     if choice=='global':w=words[int(np.searchsorted(cdf,rng.random(),side='right'))]
     counts[choice]+=1;arr.append(w)
    out.append(arr);prev.append(arr)
 return out,counts

report={'experiment':'EXP-BRT-02','regime':'POSTHOC_EXPLORATORY_REUSED_HOLDOUT','models':MODELS,'seeds':SEEDS,
'notes':['No position swap or OR control programmed.','Original lengths and folio-paragraph structure used, not predicted.','All models specified before generating samples.','Same previously examined folios, cannot serve as independent confirmation.'], 'reference':{},'runs':[]}
for trans in ('zl','it'):
 spec=build(trans);real=[list(row[trans]) for f in sorted(test) for p in folios[f] for row in p]
 report['reference'][trans]={**summary(real),**descriptor(real,spec[0]),'yo_or':matched_or(real)['or']}
 for model in MODELS:
  for seed in SEEDS:
   rows,counts=generate(trans,model,seed,spec)
   m={**summary(rows),**descriptor(rows,spec[0]),'yo_or':matched_or(rows)['or']}
   m.update({'trans':trans,'model':model,'seed':seed,'channels':dict(counts)})
   report['runs'].append(m)
   print(trans,model,seed,'hap',round(m['hapax'],4),'adj',round(m['adjacency'],4),'oov',round(m['oov_token_rate'],4),flush=True)
(ROOT/'survival_results.json').write_text(json.dumps(report,indent=2))
keys=['trans','model','seed','density','adjacency','repetition','hapax','edit1_between_adjacent_rows','oov_type_rate','oov_token_rate','oov_repeat_fraction','token_mean_len','y_first','yo_or']
with (ROOT/'survival_runs.csv').open('w',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=keys);wr.writeheader();wr.writerows([{k:r[k] for k in keys} for r in report['runs']])
for trans in ('zl','it'):
 print('TARGET',trans,{k:round(report['reference'][trans][k],4) for k in keys[3:]})
 for model in MODELS:
  r=[x for x in report['runs'] if x['trans']==trans and x['model']==model]
  print('MEAN',trans,model,{k:round(np.mean([x[k] for x in r]),4) for k in ['density','adjacency','repetition','hapax','oov_type_rate','yo_or']})
print('DONE',len(report['runs']))
