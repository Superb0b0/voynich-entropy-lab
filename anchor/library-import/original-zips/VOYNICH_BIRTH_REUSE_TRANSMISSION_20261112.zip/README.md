# EXP-BRT-01/02

80 generazioni fissate in codice; due trascrizioni; 8 varianti × 5 semi. Nessun gate superato.

- `REPORT.md` spiegazione completa e limiti.
- `test.py`, `survival.py` esecutori offline, richiedono NumPy.
- `within_paragraph.py`, `within_paragraph.csv`: controllo rigoroso dei confini di paragrafo.
- `runs.csv`, `survival_runs.csv`, `summary.csv`: misure per replica e aggregate.
- `results.json`, `survival_results.json`: output numerici completi.
- `dependencies`: copie dei codici e corpus necessari a rendere autonomo il pacchetto.

Esecuzione: `python test.py && python survival.py && python within_paragraph.py`. Non sono confronti ciechi; righe e paragrafi reali sono forniti come layout.
