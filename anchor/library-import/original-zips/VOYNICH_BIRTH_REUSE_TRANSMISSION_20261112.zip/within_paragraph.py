#!/usr/bin/env python3
"""Independent within-paragraph measurement of fixed BRT-01/BRT-02 generations."""
from pathlib import Path
from collections import Counter
import numpy as np,csv,json
ROOT=Path(__file__).resolve().parent
r=ROOT/'test.py'; ns={'__file__':str(r),'__name__':'within_brt1'}
s=r.read_text();exec(compile(s[:s.index('out={')],str(r),'exec'),ns)
folios,meta,base,test=ns['folios'],ns['meta'],ns['base'],ns['test']
gen1,build=ns['generator'],ns['build']
r=ROOT/'survival.py';nm={'__file__':str(r),'__name__':'within_brt2'}
s=r.read_text();exec(compile(s[:s.index('report={')],str(r),'exec'),nm)
gen2=nm['generate']

def measure(rows,trans):
 layout=[];boundaries=[];q=0
 for folio in sorted(test):
  for par in folios[folio]:
   n=len(par);layout.append(n);q+=n;boundaries.append(q)
 assert q==len(rows)
 adj=[];rep=[];cross=[];j=0
 for n in layout:
  for k in range(j+1,j+n):
   a=set(rows[k-1]);b=set(rows[k]);den=len(a|b)
   adj.append(len(a&b)/den if den else 0)
   rep.append(sum(w in a for w in rows[k])/len(rows[k]) if rows[k] else 0)
  j+=n
 start=set(boundaries[:-1]);
 for k in range(1,len(rows)):
  if k not in start:continue
  a=set(rows[k-1]);b=set(rows[k]);cross.append((len(a&b)/len(a|b) if a|b else 0, sum(w in a for w in rows[k])/len(rows[k]) if rows[k] else 0))
 return {'n_pairs_within':len(adj),'jaccard_within':float(np.mean(adj)),'repetition_within':float(np.mean(rep)),
         'jaccard_cross':float(np.mean([x[0] for x in cross])),'repetition_cross':float(np.mean([x[1] for x in cross]))}
rows=[]
for trans in ('zl','it'):
 spec=build(trans);real=[list(row[trans]) for f in sorted(test) for p in folios[f] for row in p]
 rows.append({'experiment':'reference','trans':trans,'model':'voynich','seed':'original',**measure(real,trans)})
 for model in ns['SETTINGS']:
  for seed in ns['SEEDS']:
   seq,_=gen1(trans,model,seed,spec)
   rows.append({'experiment':'BRT-01','trans':trans,'model':model,'seed':seed,**measure(seq,trans)})
 for model in nm['MODELS']:
  for seed in nm['SEEDS']:
   seq,_=gen2(trans,model,seed,spec)
   rows.append({'experiment':'BRT-02','trans':trans,'model':model,'seed':seed,**measure(seq,trans)})
with (ROOT/'within_paragraph.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
for trans in ('zl','it'):
 print('TRANS',trans)
 for model in ['voynich','three_process_conservative','three_process_diverse','decaying_reuse','flat_unaltered_birth']:
  a=[r for r in rows if r['trans']==trans and r['model']==model]
  print(model, {k:round(float(np.mean([x[k] for x in a])),5) for k in ['jaccard_within','repetition_within','jaccard_cross','repetition_cross']})
print('DONE',len(rows))
