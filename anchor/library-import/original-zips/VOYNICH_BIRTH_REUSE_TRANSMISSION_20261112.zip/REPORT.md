# EXP-BRT-01/02 | Nascita, riuso e trasmissione delle forme nel Voynich

**12 novembre 2026. Stato: ESPLORATIVO, GATE NON SUPERATO.**

## Scopo e procedura

È stato confrontato un modello generativo che separa (1) la nascita di una nuova forma per edit singolo autorizzato da bigrammi del corpus di addestramento; (2) il riuso di forme introdotte in un folio; (3) la propagazione esatta o mutata da una delle ultime due righe. Si usano soltanto vocabolario e vincoli grafici appresi sui folii BASE, non le parole dei folii TEST. Dei folii TEST si forniscono al generatore solo quantità, dimensioni delle righe e confini di paragrafo. Questi folii erano **già stati esaminati** negli studi precedenti e **non sono un holdout indipendente**.

Sono state svolte **80 generazioni** (8 configurazioni × 5 semi × 2 trascrizioni), conservando tutte le repliche. EXP-BRT-01 esplora l'archivio con riutilizzo costante; EXP-BRT-02 predefinisce tre controlli: campionamento globale con frequenze appiattite, archivio con al massimo un riuso aggiuntivo, riuso con decadimento esponenziale e una variante a frequenze originali. EXP-BRT-02 è stata formulata dopo avere esaminato EXP-BRT-01: nessuna inferenza confirmatoria.

**Non viene imposta una regola di posizione y/o.** È un test avversariale: l'OR deve emergere o fallire. I valori non sono confrontabili con quelli dell'esperimento MORPHOGEN precedente se si ignora questa modifica.

## Risultato principale

| Misura | Voynich ZL3b (TEST) | Archivio costante conservativo | Riuso con decadimento | Nascita, frequenze originali |
|---|---:|---:|---:|---:|
| Densità | 0.9468 | 0.9472 | 0.9292 | 0.9481 |
| Adiacenza | 0.0271 | 0.0547 | 0.0277 | 0.0303 |
| Ripetizione locale | 0.0569 | 0.1042 | 0.0533 | 0.0578 |
| Hapax | 0.7157 | 0.5546 | 0.5574 | 0.5902 |
| Occorrenze OOV | 0.2033 | 0.2378 | 0.2339 | 0.2353 |
| OR yX/oX | 3.5998 | 0.9184 | 0.9591 | 1.2772 |

**Verifica del gate:** 0/80 repliche hanno superato insieme le quattro bande storiche (`density`: 0,91–0,96; `adjacency`: 0,02–0,04; `repetition`: 0,045–0,07; `hapax`: 0,65–0,75). Anche le configurazioni che si avvicinano all'adiacenza e alla ripetizione falliscono sul rapporto di hapax e sull'OR posizionale (in genere vicino a 1, non al ~3–3,6 del campione). Il test posizionale è aggiuntivo e non incluso nelle quattro bande.

**Interpretazione:** il riuso a probabilità costante sovracampiona le forme ricorrenti e riduce gli hapax. Il decadimento della probabilità di riuso può ridurre l'eccesso di adiacenza, ma non ristabilisce da solo la diversità del lessico. Appiattire le frequenze globali isolatamente peggiora ulteriormente continuità e hapax. Nessuna combinazione testata genera autonomamente il profilo posizionale. Non interpretare i confronti come esclusione di ogni processo morfologico storico.


## Controllo aggiuntivo: confini del paragrafo

La funzione `summary` di origine conta anche coppie di righe separate da confini di paragrafo e folio. Per verificare la trasmissione realmente locale è stata eseguita un'analisi nuova, `within_paragraph.py`, che considera solo coppie *interne* a ogni paragrafo. La stessa funzione riporta separatamente le transizioni attraverso i confini.

| Misura | Voynich ZL3b | Riuso con decadimento | Voynich IT2a | Riuso con decadimento |
|---|---:|---:|---:|---:|
| Jaccard entro paragrafo | 0,03050 | 0,03278 | 0,03277 | 0,03212 |
| Ripetizione entro paragrafo | 0,06430 | 0,06350 | 0,06698 | 0,06232 |
| Jaccard oltre confine | 0,01389 | 0,00819 | 0,01469 | 0,00919 |
| Ripetizione oltre confine | 0,02865 | 0,01402 | 0,02922 | 0,01574 |

I valori sintetici sono medie di 5 semi, su due trascrizioni. È un riscontro locale promettente ma il modello fallisce il benchmark globale e il posizionamento `yX/oX`. La distanza dalle transizioni oltre confine indica che il modello tratta i paragrafi come compartimenti troppo isolati. Questi confronti supplementari sono esplorativi e non erano un gate preregistrato.

Dati: `within_paragraph.csv`. Codice: `within_paragraph.py`.

## Limiti decisivi

- Le due trascrizioni rappresentano lo stesso manoscritto, non due campioni indipendenti.
- I folii TEST non sono realmente nuovi. La scelta di questa classe di modelli è successiva alla lettura delle prestazioni precedenti.
- Si impone al generatore la geometria del testo reale: numero e lunghezza delle righe, confini di paragrafo e folio. Le proprietà della geometria non sono quindi previsioni del generatore.
- I modelli non rappresentano linguistica latina, semantica o una chiave di cifratura.
- Il codice è riproducibile ma la sua capacità di predire nuove pagine non è validata indipendentemente.

## Programmi e riproduzione

Requisiti: Python 3.10+ e NumPy. Lanciare dalla cartella estratta: `python test.py`, `python survival.py` e `python within_paragraph.py`. Le cartelle `dependencies` includono copie delle dipendenze dei precedenti esperimenti e i file di corpus, per la riproduzione offline. I due programmi riscrivono `results.json`, `runs.csv`, `survival_results.json`, `survival_runs.csv` usando seed fissi. Il file `summary.csv` è una semplice aggregazione dei risultati osservati, non un endpoint statistico preregistrato.

**Prossimo esperimento razionale:** uno schema *a nascita condizionata da famiglia latente*, calibrato solo su nuovi folii BASE/VALIDATION, che riproduca contemporaneamente la diversità e la ricorrenza; il primo confronto veramente probante richiederà folii mai usati neppure per scegliere il modello. Evitare aggiustamenti per conseguire bande note sui TEST già esaminati.

RC1.4.2 non modificata; gate `CLOSED_PENDING_VALIDATION`.
