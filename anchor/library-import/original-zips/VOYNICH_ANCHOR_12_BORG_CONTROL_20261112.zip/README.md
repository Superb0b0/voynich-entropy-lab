# ANCHOR-12, controllo storico Borg

È un controllo positivo su un cifrario storico **diverso dal Voynich**. La chiave viene appresa da 76 caratteri di testo noto e applicata a un segmento riservato.

### Riproduzione

Recuperare dal repository pubblico di ricerca `matthewdgreen/cipher_benchmark`:

- `benchmark/sources/borg/transcriptions/borg_0010r.diplomatic.txt`
- `benchmark/sources/borg/plaintext/borg_0010r.txt`

Collocare i rispettivi file in `inputs/` con i nomi `borg_0010r_diplomatic_extracted.txt` e `borg_0010r_plaintext_extracted.txt` e verificare i Git blob di provenienza indicati in `REPORT_IT.md`.

Eseguire: `python run_anchor12.py`. Richiede solo Python standard library.

Sono inclusi gli output di riferimento (sintesi, conteggi dei falsi allineamenti e piccolo campione di verifica su pagina separata). **I testi integrali delle edizioni non sono ridistribuiti.**

L'apprendimento della chiave non legge il gold riservato, ma la valutazione finale sì. La fonte completa e i diritti di ridistribuzione sono verificabili nel repository originale.
