#!/usr/bin/env python3
"""ANCHOR-12 positive control: known-plaintext learning on authenticated Borg page.

Training input = first 76 cipher glyphs + matching first 76 Latin letters.
No published cipher key is read. Remaining page and another folio are evaluated only.
The ciphertext and plaintext excerpts were manually copied from the public
matthewdgreen/cipher_benchmark source. The copies are NOT certified byte-identical.
"""
from __future__ import annotations
from collections import defaultdict, Counter
from pathlib import Path
import csv, json, hashlib, re, difflib
ROOT=Path(__file__).resolve().parent
IN=ROOT/'inputs'; OUT=ROOT/'results'; OUT.mkdir(exist_ok=True)
raw=(IN/'borg_0010r_diplomatic_extracted.txt').read_text()
gold=(IN/'borg_0010r_plaintext_extracted.txt').read_text()
assert '<CLEARTEXT-LA Laxatiuum bonum>' in raw
assert '[Laxatiuum bonum]' in gold
cipher_train, rest = raw.split('<CLEARTEXT-LA Laxatiuum bonum>',1)
cipher_test=rest.split('<CLEARTEXT-LA Mixtura Lenitiua>',1)[0]
plain_train,restgold=gold.split('[Laxatiuum bonum]',1)
plain_test=restgold.split('[Mixtura Lenitiua]',1)[0]
nc=lambda s: ''.join(x for x in s if x.isalpha() or x.isdigit())
np=lambda s: ''.join(x.upper() for x in s if x.isalpha())
ct=nc(cipher_train); pt=np(plain_train)
assert len(ct)==len(pt)==76,(len(ct),len(pt))
votes=defaultdict(Counter)
for c,p in zip(ct,pt): votes[c][p]+=1
assert all(len(c)==1 for c in votes.values()), 'Training contradicts a simple substitution'
key={c:counts.most_common(1)[0][0] for c,counts in votes.items()}
cv=nc(cipher_test); goldnorm=np(plain_test)
pred=''.join(key.get(c,'?') for c in cv)
assert len(cv)==209 and len(goldnorm)==210
# Evaluation ONLY. Pairing uses best possible alignment to handle one editorial expansion.
blocks=difflib.SequenceMatcher(None,pred,goldnorm,autojunk=False).get_opcodes()
matched=sum(i2-i1 for tag,i1,i2,j1,j2 in blocks if tag=='equal')
assert matched == len(cv)-pred.count('?')
# Conservative exact test of a separate manuscript page using 15 individually reported tokens.
with (IN/'borg_0010v_first_15_words.csv').open() as f: rows=list(csv.DictReader(f))
cross=[]
for row in rows:
 observed=''.join(key.get(c,'?') for c in row['cipher'])
 correct=observed==row['reference_plain']
 cross.append({'n':int(row['index']),'cipher':row['cipher'], 'prediction':observed,
              'gold':row['reference_plain'],'exact':correct,'notes':row['notes']})
result={
 'experiment':'ANCHOR-12', 'status':'HISTORICAL_KNOWN_PLAINTEXT_POSITIVE_CONTROL',
 'source':'Borg.lat.898 folio 10r/10v, matthewdgreen/cipher_benchmark; transcription based on Aldarrab/Knight/Megyesi',
 'not_Fontana':True, 'not_blind_ciphertext_only':True,
 'train_n_cipher_chars':len(ct),'train_n_plain_chars':len(pt),'learned_symbols':len(key),
 'train_conflicting_assignments':0,'learned_key':dict(sorted(key.items())),
 'holdout_cipher_chars':len(cv),'holdout_gold_chars':len(goldnorm),
 'holdout_decoded_with_learned_key':len(cv)-pred.count('?'),
 'holdout_unresolved_chars':pred.count('?'),
 'holdout_coverage':round((len(cv)-pred.count('?'))/len(cv),6),
 'holdout_gold_agreement_in_best_alignment':matched,
 'holdout_editorial_expansion_discrepancy':'gold [ana] vs cipher AU (length 3 vs 2)',
 'crosspage_words_tested':len(cross),
 'crosspage_words_exact':sum(x['exact'] for x in cross),
 'crosspage_ambiguous_initial_M':[x['n'] for x in cross if x['cipher'].startswith('M')],
 'corpus_origin_hashes_git_blob':{
  'borg_0010r_diplomatic':'89627cb3671b23b5b790c9c30866192cd0cd39c0',
  'borg_0010r_plaintext':'4c107117d117fc8a5098f6693816fd0e668a98a3',
  'borg_0010v_diplomatic':'093e541ccb7b43de8d4f0a10568c49694a394713',
  'borg_0010v_plaintext':'4d7883a36131a77bc420919ff802c9a2ee8f09f0',
 },
 'local_copy_fidelity':'MANUALLY_TRANSCRIBED_EXCERPTS_NOT_BINARY_ATTESTED'
}
(OUT/'test_results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
with (OUT/'holdout_prediction.txt').open('w') as f:
 f.write('DECIPHERED_WITH_LEARNED_KEY (question marks = unlearned symbols):\n'+pred+'\nGOLD:\n'+goldnorm+'\n')
with (OUT/'crosspage_predictions.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=cross[0].keys());w.writeheader();w.writerows(cross)
print(json.dumps({k:result[k] for k in ('train_n_cipher_chars','learned_symbols','holdout_cipher_chars','holdout_decoded_with_learned_key','holdout_unresolved_chars','holdout_coverage','holdout_gold_agreement_in_best_alignment','crosspage_words_exact','crosspage_words_tested')},indent=2))
# Negative controls: all 75 nonzero circular shifts of the true crib.
# A false crib should generate contradictory symbol assignments in training.
negative=[]
for shift in range(1,len(pt)):
 fake=pt[shift:]+pt[:shift]
 assignments=defaultdict(set)
 for c,p in zip(ct,fake):assignments[c].add(p)
 contradictions=sum(len(s)>1 for s in assignments.values())
 # majority-vote fallback, evaluated on the same heldout gold
 candidates=defaultdict(Counter)
 for c,p in zip(ct,fake):candidates[c][p]+=1
 kfake={a:v.most_common(1)[0][0] for a,v in candidates.items()}
 wrong=''.join(kfake.get(c,'?') for c in cv)
 blocks2=difflib.SequenceMatcher(None,wrong,goldnorm,autojunk=False).get_opcodes()
 agree=sum(i2-i1 for tag,i1,i2,j1,j2 in blocks2 if tag=='equal')
 negative.append({'shift':shift,'symbols_with_conflicting_assignments':contradictions,
                  'heldout_correct_chars_best_alignment':agree})
res={'n_false_cribs':len(negative),'false_cribs_with_no_conflicts':sum(x['symbols_with_conflicting_assignments']==0 for x in negative),
     'minimum_conflicting_symbols':min(x['symbols_with_conflicting_assignments'] for x in negative),
     'median_conflicting_symbols':sorted(x['symbols_with_conflicting_assignments'] for x in negative)[len(negative)//2],
     'best_false_crib_heldout_correct':max(x['heldout_correct_chars_best_alignment'] for x in negative),
     'true_crib_heldout_correct':matched}
(OUT/'negative_controls.json').write_text(json.dumps({'summary':res,'shifts':negative},indent=2)+'\n')
print('NEGATIVE_CONTROLS:',json.dumps(res))
