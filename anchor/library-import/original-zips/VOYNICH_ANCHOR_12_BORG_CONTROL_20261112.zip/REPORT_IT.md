# ANCHOR-12 — Recupero di un cifrario storico a partire da un frammento noto

Data: 12 novembre 2026. Stato: **controllo positivo storico completato; nessuna decifrazione del Voynich**.

## Scopo

Misurare la capacità di un metodo minimale di ricostruire una chiave di sostituzione da una breve sequenza di simboli e da una corrispondente lettura latina attendibile; verificare la lettura sulla parte di pagina tenuta fuori dall'apprendimento e controllare 75 ancore errate.

## Fonte e provenienza

- Manuscript: Cifrario Borg, Borg.lat.898 (Biblioteca Vaticana), trascrizione e decifrazione curate nella tradizione Aldarrab/Knight/Megyesi.
- Distribuzione tecnica consultata: `matthewdgreen/cipher_benchmark`, `benchmark/sources/borg/transcriptions/borg_0010r.diplomatic.txt` e `benchmark/sources/borg/plaintext/borg_0010r.txt`; seconda facciata `borg_0010v`.
- Identificativi blob Git, rilevati tramite connettore GitHub: diplomatic 0010r `89627cb3671b23b5b790c9c30866192cd0cd39c0`, plaintext 0010r `4c107117d117fc8a5098f6693816fd0e668a98a3`. Non è stata compiuta una verifica binaria delle copie di lavoro, ricostruite da estratti testuali.
- I file testuali integrali **non sono ridistribuiti** in questo pacchetto: devono essere reperiti dalla fonte, nel rispetto dei diritti.

## Metodo

1. Primi 76 caratteri cifrati del folio 0010r, escludendo spazi e punteggiatura, allineati con 76 lettere del latino noto nella stessa posizione.
2. Apprendimento di una sostituzione per voto maggioritario simbolo→lettera. Qualsiasi simbolo con più lettere contraddittorie avrebbe invalidato il controllo positivo. La chiave storicamente pubblicata **non entra nell'algoritmo**.
3. Il resto della pagina non è letto durante l'apprendimento. Si producono `?` dove non esiste una corrispondenza appresa. Valutazione post-hoc contro il latino edito con miglior allineamento, dato che un'abbreviazione viene espansa editorialmente.
4. Controllo esterno su 15 parole della facciata successiva 0010v. Le maiuscole che convivono con il testo in chiaro possono avere un comportamento differente dai segni cifrati.
5. Controllo negativo: 75 rotazioni non nulle del crib latino (sono falsi allineamenti che preservano esattamente il contenuto e la frequenza delle lettere del frammento vero).

## Risultati

| Prova | Esito |
|---|---|
| Lettere del crib iniziale | 76 |
| Simboli distinti con valore recuperato | 16 |
| Contraddizioni sul crib vero | 0 |
| Simboli cifrati riservati | 209 |
| Posizioni coperte dalla chiave appresa | 195 (93,30%) |
| Posizioni senza corrispondenza appresa | 14 |
| Caratteri coperti corretti nel miglior allineamento | 195/195 |
| Parole integralmente ricostruite sul foglio distinto | 13 su 15 |
| Ancore false in rotazione senza contraddizioni | 0 su 75 |
| Numero minimo di simboli contraddittori con ancore false | 12 |
| Migliore falso crib: caratteri esatti nel miglior allineamento | 61 (contro 195 del vero) |

Questo **non** è un test *ciphertext-only*: il latino dei primi 76 caratteri è fornito come informazione esterna. Il secondo foglio contiene due iniziali `M` ambigue in contesti di testo misto; non vanno promosse a una nuova regola di decifrazione.

Non si attribuisce un valore p ai controlli negativi: le 75 rotazioni sono sistematiche e dipendenti, non un campione casuale di tutti i possibili significati falsi.

## Implicazione per il Voynich

Il controllo mostra che un **crib autentico e sufficientemente lungo** può recuperare una chiave di sostituzione e fare previsioni su testo mai visto. Mostra anche che una falsa corrispondenza produce contraddizioni. **Non fornisce un crib autentico del Voynich**, né dimostra che il Voynich usi la stessa classe di cifrario. Un'interpretazione iconografica ipotetica, per esempio `doaro` = Pleiadi, non può essere usata come oro d'addestramento.

Fontana resta un confronto storico pertinente ma non qualificato al benchmark senza trascrizione dei glifi e gold latino allineati, con fonte controllabile. Per la sua opera si vedano l'originale BSB Cod.icon.242 e Battisti & Saccaro Battisti (1984).

## Tracciabilità

Lo script `run_anchor12.py` produce `test_results.json`, `negative_controls.json` e `crosspage_predictions.csv`. I risultati distribuiti sono stati generati con copie testuali di lavoro. Per la riproduzione indipendente occorre acquisire i due file integrali della facciata 0010r dalla sorgente e confrontare prima i blob SHA; poi eseguire lo script. Non vengono modificati i file o i gate del ramo Voynich RC1.4.2.
