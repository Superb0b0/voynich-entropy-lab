# ASTRO-06 | Verifica delle analogie cosmografiche
Data: 12 novembre 2026. Stato: ricerca iconografica documentale, **non** decifrazione.

## Domanda
Esiste un precedente medievale che spieghi una combinazione di caratteristiche dei diagrammi cosmologici Voynich, non soltanto il cerchio a otto settori?

## Fonti consultate
1. Stolfi, scheda f68r3: https://vib.tamagothi.de/index.php?id=f68r3&show=page
2. Stolfi, scheda f68v2: https://vib.tamagothi.de/index.php?id=f68v2&show=page
3. Stolfi, scheda f68v3: https://vib.tamagothi.de/index.php?id=f68v3&show=page
4. René Zandbergen, Illustrazioni: https://www.voynich.nu/illustr.html
5. René Zandbergen, Quire 9: https://www.voynich.nu/q09/index.html
6. Robert Teague, confronto del 2014 con Oresme: https://voynichology.wordpress.com/2014/09/
7. Walters Art Museum, diagramma dei venti XII secolo: https://art.thewalters.org/object/W.73.2R/
8. Walters Art Museum, diagramma stagioni/elementi: https://art.thewalters.org/object/W.73.8R/
9. BnF fr. 565 discussione storica: https://ciphermysteries.com/2017/10/18/bnf-francais-565-nicole-oresme-jean-de-berrys-library

## Tratti osservabili, senza attribuzione semantica
- **f68r3**: 8 raggi; 4 settori con stelle numerose non etichettate e 4 con stelle etichettate in progressione 1,2,3,4; presenza aggiuntiva di gruppo compatto di 7 stelle.
- **f68v2**: 8 raggi; 4 settori con 8-9 stelle non etichettate e 4 con singola stella etichettata; stessa alternanza strutturale, ma non la progressione numerica.
- **f68v3**: centro tripartito (T rovesciata); regione stellata confinata da bordo ondulato; 8 bande di scrittura spiraliformi. I primi due elementi insieme sono confrontabili con cosmografie nella tradizione di Nicole Oresme.

## Controlli esterni
| Documento | Cerchio + raggi | Centro T/O tripartito | Zona stellata + confine ondulato | Alternanza 4 settori stellati e 4 etichettati | Esito |
|---|---|---|---|---|---|
| Voynich f68r3 | Sì | No | No | Sì | Bersaglio |
| Voynich f68v2 | Sì | No | No | Sì | Ripetizione interna |
| Voynich f68v3 | Sì (spirali) | Sì | Sì | Non nello stesso senso | Bersaglio |
| BnF Français 565, cosmografia Oresme | Geometria circolare | Sì | Sì | Non documentata | Parallelo composito *parziale* per f68v3 |
| Walters W.73.2R, venti | Sì | Sì, T-O geografico | Non documentato | No | Controllo di genere, non modello completo |
| Walters W.73.8R, stagioni e umori | Sì | No documentato | No documentato | No | Controllo di genere, non modello completo |

I campi «No documentato» non equivalgono a un'assenza verificata a livello di pixel. La griglia è una codifica *qualitativa da descrizioni e documentazione*, non una nuova annotazione cieca delle scansioni.

## Decisioni
- Ipotesi di **mappa stellare letterale**: nessun supporto nuovo.
- Ipotesi dei **sette pianeti** da sette stelle: non sostenuta.
- Interpretazione **diagramma di cosmografia medievale** per f68v3: sostenuta dalla combinazione iconografica, ma non dimostrata in modo univoco.
- Ipotesi che l'autore **abbia copiato direttamente BnF fr. 565**: non dimostrata; l'alternanza e i raggi Voynich non sono spiegati dal parallelo.
- **Significato delle parole Voynich**: totalmente indeterminato.

## Previsione da verificare su materiale non usato
Se il Vocabolario iconografico è cosmografico, altre immagini Voynich dovrebbero mostrare combinazioni di confini del cielo (nebuly), terra/mondo tripartita, venti, elementi e stagioni. Il test dovrà preregistrare le caratteristiche e confrontare immagini di almeno due tradizioni esterne distinte. Nessun p-value è calcolabile dai confronti curati a posteriori.

## Rigorosità
Questo dossier riporta un candidato storico *già noto*; il contributo di ASTRO-06 è la distinzione fra analogia di genere e presenza della combinazione centrale T/O + fascia ondulata + stelle, insieme alla specificazione dei limiti del modello della ruota a otto settori.
