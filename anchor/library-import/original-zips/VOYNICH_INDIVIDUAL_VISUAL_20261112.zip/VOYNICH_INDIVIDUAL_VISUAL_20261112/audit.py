from pathlib import Path
import pandas as pd, numpy as np, itertools, csv, json, hashlib
here=Path(__file__).resolve().parent
src=here/'input'/'figure_label_manifest.csv'
d=pd.read_csv(src).copy()
# ring 0 outer 10, ring 1 inner 5, in this data, based on locus grouping
visual=[]
for fol in ('f70v1','f71r','f71v','f72r1'):
  for ring,n in ((0,10),(1,5)):
    tub='absent' if fol=='f72r1' and ring==0 else 'present'
    visual.append(dict(folio=fol,ring=ring,expected_figures=n,tub_visual=tub,star_visual='present',evidence='René Zandbergen q10/q11 page descriptions',evidence_resolution='ring-level only',individual_headgear='unverified',individual_clothes='unverified',individual_gesture='unverified'))
v=pd.DataFrame(visual)
v.to_csv(here/'ring_visual.csv',index=False)
d=d.merge(v,on=['folio','ring'],validate='many_to_one')
d['match_class']='ring-level proxy, NOT individually paired by image coordinate'
d['transcription_variant_note']='same manuscript: two transcriptions not independent replicates'
d.to_csv(here/'label_visual_join.csv',index=False)
rows=[]
for tr,g in d.groupby('transcription'):
  rates=g.groupby(['folio','ring']).agg(n=('starts_ot','count'),ot=('starts_ot','sum'),o=('starts_o','sum'),length=('length','mean')).reset_index()
  rates['ot_rate']=rates.ot/rates.n
  outer=rates[rates.ring==0].sort_values('folio')
  inner=rates[rates.ring==1].sort_values('folio')
  for _,r in rates.iterrows():
    rows.append(dict(transcription=tr,folio=r.folio,ring=int(r.ring),n=int(r.n),ot=int(r.ot),starts_o=int(r.o),ot_rate=float(r.ot_rate),mean_word_length=float(r.length),tub='absent' if r.folio=='f72r1' and r.ring==0 else 'present'))
  # 1 treated folio among four, exact label permutation at FOLIO level (not token-level)
  x=outer.set_index('folio')['ot_rate'].sort_index()
  observed=float(x['f72r1']-x.drop('f72r1').mean())
  perm={folio:float(val-x.drop(folio).mean()) for folio,val in x.items()}
  p_two=sum(abs(val)>=abs(observed)-1e-12 for val in perm.values())/len(perm)
  diff=rates.pivot(index='folio',columns='ring',values='ot_rate')
  dy=diff[0]-diff[1]
  d_obs=float(dy['f72r1']-dy.drop('f72r1').mean())
  dperm={folio:float(val-dy.drop(folio).mean()) for folio,val in dy.items()}
  pdid=sum(abs(val)>=abs(d_obs)-1e-12 for val in dperm.values())/len(dperm)
  summary={'transcription':tr,'outer_no_tub_folio':'f72r1','outer_ot_absent_tub_rate':float(x['f72r1']),'outer_ot_tub_present_rate_mean':float(x.drop('f72r1').mean()),'outer_ot_rate_difference':observed,'exact_two_sided_folio_p':p_two,'exact_support_folios':len(perm),'difference_in_differences':d_obs,'exact_two_sided_folio_p_did':pdid,'folio_permutation_details':perm,'did_permutation_details':dperm}
  (here/f'result_{tr}.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False))
pd.DataFrame(rows).to_csv(here/'folio_ring_rates.csv',index=False)
print(pd.read_csv(here/'folio_ring_rates.csv').to_string(index=False))
for tr in ['ZL3b','IT2a']:
 print(tr,json.loads((here/f'result_{tr}.json').read_text()))
