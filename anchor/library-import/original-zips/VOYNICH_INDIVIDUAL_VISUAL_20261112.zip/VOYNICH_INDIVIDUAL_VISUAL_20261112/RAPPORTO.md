# EXP-FIRST-WORD-04 · Individui, vasche, etichette

**Data:** 12 novembre 2026. **Stato:** esplorativo, nessuna decifrazione; RC1.4.2 invariato.

## Fonti visive

- René Zandbergen, quire 10: https://voynich.nu/q10/index.html (f70v1, Ariete).
- René Zandbergen, quire 11: https://voynich.nu/q11/index.html (f71r Ariete, f71v Toro, f72r1 Toro).
- Le descrizioni attestano che tutte le 15 figure delle quattro pagine recano stelle e che solo in **f72r1 nell'anello esterno** spariscono le vasche. Queste sono **annotazioni di anello**, non certificazioni figura-per-figura.
- Le immagini verificate sono accessibili con gli URL riportati nella scheda di revisione.

## Dataset

60 etichette IT2a, 58 leggibili ZL3b; ogni gruppo si ripartisce in anello 0 (dieci figure, esterno) e anello 1 (cinque figure, interno). Per f72r1 il primo gruppo contiene nove etichette ZL3b leggibili. I valori sono ricavati dal manifest dell'esperimento EXP-FIRST-WORD-03. Le due trascrizioni rappresentano lo stesso manoscritto, non repliche indipendenti.

## Ipotesi e test

H: la frequenza delle iniziali `ot` diminuisce dove scompaiono le vasche. Trattamento: l'anello esterno di f72r1. Confronto a livello **folio**, non di singola etichetta, mediante scelta esatta di un folio 'trattato' su quattro. Il p è bilaterale per |differenza|; il confronto con differenza fra anelli controlla l'effetto generale della posizione.

| Trascrizione | ot su esterno f72r1 | media `ot` sugli esterni delle altre pagine | p esatto | p aggiustato con differenza fra anelli |
|---|---:|---:|---:|---:|
| ZL3b | 3/9 (33,3%) | 53,3% | 0,75 | 0,75 |
| IT2a | 3/10 (30%) | 50,0% | 1,00 | 1,00 |

**Esito:** nessun sostegno statisticamente utilizzabile per l'interpretazione di `ot` come vasca o contenitore. Le quattro pagine non consentono una valida identificazione semantica; il test è esplorativo e l'ipotesi `ot` era stata scelta dopo analisi precedenti.

## Limite decisivo

Non è stato possibile validare attribuzioni individuali di copricapo, costume, gesti o orientamento con un collegamento immagine ↔ etichetta indipendente. I 60 record `BLIND_IMAGE_REVIEW.csv` sono **schede da compilare**, non annotazioni effettuate. Le variabili visive positive e negative attualmente disponibili sono **a livello di anello** e non permettono un modello individuale di iconografia contro testo.

## Riproducibilità

`python audit.py` ricalcola i CSV e i due JSON leggendo `input/figure_label_manifest.csv`. I risultati non sono frutto di nuovi parametri di addestramento. `SHA256SUMS.txt` riporta le impronte dei file, escluso il manifest stesso.
