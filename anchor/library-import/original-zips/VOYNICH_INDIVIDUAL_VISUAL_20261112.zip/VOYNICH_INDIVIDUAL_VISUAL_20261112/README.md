EXP-FIRST-WORD-04: eseguire `python audit.py` e consultare RAPPORTO.md. La scheda BLIND_IMAGE_REVIEW.csv è vuota di annotazioni individuali verificate.
