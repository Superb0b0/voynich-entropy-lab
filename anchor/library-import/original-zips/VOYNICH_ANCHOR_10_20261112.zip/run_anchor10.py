#!/usr/bin/env python3
"""ANCHOR-10 exploratory check: independent corpus occurrence of f/p replacements.
Reads pinned corpus bytes; DOES NOT import or run any RC1.4.* audit or parser.
"""
from pathlib import Path
from collections import Counter, defaultdict
from hashlib import sha256
import re, json, csv

HERE=Path(__file__).resolve().parent
BASE=HERE/'inputs'
EXPECTED={'ZL3b-n.txt':'bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc',
          'IT2a-n.txt':'7f27a8b0feed8f6de0a99900df6bf912dd1d295c38e5f830bac8b41c3f536fb5'}

def parse(name):
    raw=(BASE/name).read_bytes()
    h=sha256(raw).hexdigest()
    assert h==EXPECTED[name], f'hash mismatch {name}: {h}'
    lines=raw.decode('utf-8-sig').splitlines()
    records=[]; ring=None
    for line in lines:
        m=re.match(r'^<([^>]+)>\s*(.*)',line)
        if not m: continue
        locus, body=m.groups()
        if locus.startswith('f57v.3,'):
            ring= re.sub(r'<![^>]*>','',body).strip()
        if not re.search(r',\+P\d+',locus):continue
        folio=locus.split('.')[0]
        body=re.sub(r'<![^>]*>',' ',body)
        body=re.sub(r'\[[^\]]*\]',' ',body)
        body=re.sub(r'\{[^}]*\}',' ',body)
        body=re.sub(r'<[^>]*>',' ',body)
        for t in re.findall(r'[a-z]+',body):
            if len(t)>=2:records.append((folio,locus,t))
    assert ring
    ring_tokens = ring.split('.') if name.startswith('ZL') else ring.split('<->')
    return records,ring_tokens

def templ_stats(records, pair):
    bytemplate=defaultdict(lambda: defaultdict(list))
    for folio,locus,w in records:
        hits=[ch for ch in w if ch in pair]
        if len(hits)!=1:continue
        ch=hits[0];template=w.replace(ch,'#')
        bytemplate[template][ch].append((folio,locus,w))
    mixed={t:vals for t, vals in bytemplate.items() if len(vals)==2}
    sorted_pair=sorted(pair)
    allhits=sum(sum(len(rows) for rows in d.values()) for d in bytemplate.values())
    mixedhits=sum(sum(len(rows) for rows in d.values()) for d in mixed.values())
    minmass=sum(min(len(d[sorted_pair[0]]),len(d[sorted_pair[1]])) for d in mixed.values())
    # A token with one of the two signs has an exact counterpart on a DIFFERENT folio.
    with_foreign={c:0 for c in pair}
    rare_counts={c:0 for c in pair}
    distinct_cross=[]
    within_folio=[]
    for temp,d in bytemplate.items():
        for c,items in d.items():
            rare_counts[c]+=len(items)
            other=sorted_pair[0] if c==sorted_pair[1] else sorted_pair[1]
            if other not in d: continue
            other_folios={r[0] for r in d[other]}
            with_foreign[c]+=sum(len(other_folios-{fol})>0 for fol,_,_ in items)
        if len(d)==2 and ({r[0] for r in d[sorted_pair[0]]} != {r[0] for r in d[sorted_pair[1]]} or len({r[0] for x in d.values() for r in x})>=2):
            folios1={r[0] for r in d[sorted_pair[0]]}
            folios2={r[0] for r in d[sorted_pair[1]]}
            if any(i!=j for i in folios1 for j in folios2):
                distinct_cross.append({'template':temp,'a':len(d[sorted_pair[0]]),'b':len(d[sorted_pair[1]]),
                                       'folios_a':len(folios1),'folios_b':len(folios2)})
    for temp,d in mixed.items():
        same={r[0] for r in d[sorted_pair[0]]} & {r[0] for r in d[sorted_pair[1]]}
        for fol in same: within_folio.append({'template':temp,'folio':fol})
    return dict(within_folio_template_pairs=len(within_folio),within_folio_distinct_templates=len({r['template'] for r in within_folio}),pair=pair,templates_total=len(bytemplate),mixed_templates=len(mixed),
                mixed_tokens=mixedhits,all_pair_tokens=allhits,mixed_fraction=round(mixedhits/allhits,5),
                min_pair_mass=minmass,with_foreign_folio=with_foreign,pair_counts=rare_counts,
                foreign_fraction={k:round(with_foreign[k]/rare_counts[k],5) for k in rare_counts},
                crossfolio_templates=len(distinct_cross),
                top_crossfolio=sorted(distinct_cross,key=lambda q:q['a']+q['b'],reverse=True)[:12])

out={"label":"EXPLORATORY_NOT_SEMANTIC_VALIDATION","inputs":{},"pairwise":{},"ring":{}}
for name in EXPECTED:
    rec, ring=parse(name)
    out['inputs'][name]={'sha256':EXPECTED[name],'P_records_len_ge2':len(rec),'P_distinct_folios':len({t[0] for t in rec})}
    out['pairwise'][name]={p:templ_stats(rec,p) for p in ['fp','kt','fk','ft','pk','pt']}
    out['ring'][name]={'unit_count_literal':len(ring),'fp_slots_1_based':[i+1 for i,x in enumerate(ring) if x in ('f','p')],
                       'fp_values':[x for x in ring if x in ('f','p')],
                       'tail':ring[-5:],
                       'notes':'Literal dot-separated groups (ZL3b) or <-> separated groups (IT2a); glyph count on the image not settled.'}
(HERE/'results.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
for name in EXPECTED:
    print(name, 'ring',out['ring'][name])
    for p in ['fp','kt','fk','ft','pk','pt']:
        r=out['pairwise'][name][p]
        print(p,'mixed',r['mixed_templates'],'crossfolio',r['crossfolio_templates'],'foreign',r['foreign_fraction'],'tops',r['top_crossfolio'][:3])
