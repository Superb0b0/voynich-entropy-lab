# ANCHOR-10

Materiale autonomo e riproducibile sul confronto f/p e f57v. Avviare `python run_anchor10.py` con Python >=3.9; richiede soltanto la standard library.

- `inputs/ZL3b-n.txt`, `inputs/IT2a-n.txt`: due trascrizioni originali, SHA verificato.
- `run_anchor10.py`: analisi descrittiva indipendente dagli audit RC1.4.2.
- `results.json`: risultati numerici già calcolati.
- `REPORT_IT.md`: conclusioni e limiti.

**Nessuna traduzione ottenuta.** I dati congelati del progetto non sono stati alterati.
