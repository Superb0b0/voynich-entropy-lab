# VOYNICH — ANCHOR-10
## Il contrasto `f/p` nel diagramma f57v e il controllo esterno

**Data:** 12 novembre 2026. **Stato:** indagine esplorativa in sola lettura. **Non è una decifrazione.**

### Domanda
Nell'anello f57v si osserva una sequenza `f, f, p, p`, in corrispondenza di quattro settori contenenti figure descritte nella letteratura come due maschili e due femminili. La relazione individua una contrapposizione semantica maschio/femmina, oppure un'alternanza consentita dalla scrittura?

### Fonti e materiali
- Originali digitalizzati: Beinecke Library, Yale, MS 408; descrizioni di f57v nel Voynich Information Browser, https://vib.tamagothi.de/index.php?id=f57v&show=page .
- René Zandbergen, *The Writing System*, https://www.voynich.nu/writing.html (inclusa l'attribuzione delle mani secondo Lisa Fagin Davis).
- V. Averyanov, *The list pages*, https://voynich.site/en/findings/list-pages/ (2026). Riporta per `f/p` somiglianza coseno contestuale di 0,948: la nostra misura non è una riproduzione della sua metrica.
- E. M. Honeycutt III, preprint del 30 settembre 2026, https://zenodo.org/records/23068602 e il manoscritto Hartlieb Cgm 7958, identificativo IIIF ufficiale BSB https://api.digitale-sammlungen.de/iiif/presentation/v2/bsb00144181/manifest . Parallelo di genere, non medesima lingua o chiave.
- Trascrizioni ZL3b-n.txt e IT2a-n.txt con SHA256 verificati nel file results.json.

### Risultato 1 — L'anello presenta una differenza di segmentazione fra trascrizioni
- ZL3b f57v.3: **68 gruppi separati da punti**, equivalenti a 4 × 17 nella codifica letterale. Le posizioni 9, 26, 43, 60 recano `f, f, p, p`.
- IT2a f57v.3: **69 gruppi separati dal suo marcatore `<->`**, con lo stesso `f, f, p, p` alle stesse posizioni. La trascrizione termina `... y c r n` dove ZL3b termina `... y c @172;`.
- Non è stata rieseguita una lettura paleografica dell'originale ad alta risoluzione. Il fatto che una fonte recente descriva 18 segni per periodo anziché 17 può dipendere dalle regole di conteggio o da segni composti. Nessun numero «fisico» viene certificato dal semplice split dei file.

### Risultato 2 — Varianti `f/p` all'interno della stessa struttura di parola

Estratte esplorativamente le righe `+P` da ciascun corpus, evitando alternative fra parentesi quadre e markup. Non si tratta del parser RC1.4 né di un aggiornamento degli artefatti congelati.

| Indicatore | ZL3b | IT2a |
|---|---:|---:|
| Token P alfabetici di lunghezza ≥ 2 | 30.835 | 30.864 |
| Modelli con due forme distinte solo per `f/p` | 64 | 63 |
| Modelli con coppie attestate su fogli differenti | 64 | 62 |
| Coppie modello-foglio con ambedue le varianti | 19 | 20 |
| Quota dei token con `f` che hanno una controparte `p` su un altro foglio | 49,37% | 44,02% |
| Modelli con due forme distinte solo per `k/t`, per confronto | 613 | 620 |

Esempi esatti: `fchedy / pchedy`, `ofchedy / opchedy`, `qofchedy / qopchedy`.

**Interpretazione limitata:** la sostituzione `f/p` ricorre in testo ordinario e in fogli differenti; non è una proprietà esclusiva della ruota di f57v. La presenza di coppie minime non prova che due parole abbiano lo stesso significato: possono differire semanticamente pur avendo lo stesso contesto grafico. Le frequenze `k/t` sono molto maggiori, quindi i conteggi grezzi non sono una graduatoria corretta di «intercambiabilità» né confutano direttamente il coseno di Averyanov.

### Risultato 3 — L'illustrazione non discrimina sesso, orientazione e posizione
Nel quadro iconografico descritto da Stolfi, le figure Nord/Est sono maschili e Sud/Ovest femminili. La corrispondenza con `f/f/p/p` è potenzialmente suggestiva ma è stata selezionata dopo aver visto sia il testo sia le immagini. Con quattro elementi, la distinzione coincide con una divisione spaziale in settori consecutivi. Mancano un'annotazione fisica indipendente e una seconda ruota con ordine iconografico rimescolato.

**Decisione:** sospendere l'ipotesi `f=maschio`, `p=femmina`. Non è stata formalmente confutata in ogni possibile sistema, ma non è confermata e non costituisce una lettura.

### Risultato 4 — Indizio paleografico e comparatore archivistico
La ricerca paleografica di Lisa Fagin Davis attribuisce f57v alla mano 1 e le restanti tre pagine del bifolio f57/f66 alla mano 5 (attribuzione con una precisazione: il testo f57v è molto breve e pieno di segni rari). Questo suggerisce che f57v possa avere una funzione grafica o redazionale particolare; non prova che sia una chiave né che sia stato aggiunto dopo.

Un confronto concreto è il Cgm 7958 di Hartlieb (BSB Monaco), testo del 1456 con una macchina onomantica, una ruota a quattro quadranti, valori di lettere e inventari alfabetici, già discusso da Honeycutt nel 2026. È un **parallelo tipologico**, non una scoperta nostra, e non fornisce una corrispondenza di segni o una traduzione del Voynich. La differenza fra 28 mansioni documentate nel comparatore e 17/18 unità per giro nel Voynich è un potenziale elemento falsificante per una equivalenza diretta, non un invito a costruire una numerologia arbitraria.

### Decisione operativa
1. **STOP** a qualunque traduzione `f/p` derivata da f57v; tenere la pista grafico-redazionale, non semantica.
2. Per testare l'ipotesi «tavola di lavoro» cercare un confronto esterno con **sequenza di segni, inventario e ordine** riscontrabili, non una generica somiglianza fra cerchi.
3. Richiedere per l'anello la trascrizione grafica indipendente del gruppo finale e il criterio di segmentazione 17/18 prima di inferenze numeriche.
4. Privilegiare in futuro un'ancora semantica esterna con due occorrenze indipendenti, non un'interpretazione post hoc della stessa pagina.
5. RC1.4.2 resta `CLOSED_PENDING_VALIDATION`; RP-01 e f085v irrisolti. Nessun parser/builder congelato eseguito.

### Riproducibilità
Eseguire `python run_anchor10.py` dopo aver disposto i due originali in `inputs/`. Il programma verifica SHA-256, estrae i token `+P` con una procedura **esplorativa autonoma**, e produce `results.json`. Non utilizza internet. La procedura è progettata per mettere alla prova una specifica ipotesi e non per affermare una decifrazione.
