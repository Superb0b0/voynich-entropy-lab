# Voynich v1.1.0: verifica browser esterna (NON ESEGUITA)

Questo kit è un allegato di verifica, non una nuova release. Non altera gli archivi originali.

## Istruzioni

1. Estrarre questo ZIP su un computer con browser autorizzato.
2. Aprire `site/index.html` in Chrome/Chromium, preferibilmente attraverso un server locale (`python -m http.server 18765` dalla cartella estratta, poi http://127.0.0.1:18765/site/index.html).
3. Compilare `ESITI_DA_COMPILARE.json`, usando PASS solo con evidenza osservabile; allegare screenshot, export, log, versione browser e ora.
4. Verificare che il digest del file HTML corrisponda a `DIGEST.json`.
5. Non modificare il manifest v1.0.0, né promuovere ANCHOR-02 o il gate.

## Sei prove

- base_hash: la dicitura esatta `Hash dati verificato nel browser ✔` compare e non è solo testo statico.
- anchor_navigation: selezionare ANCHOR e trovare ANC-0001.
- anchor_hash: il controllo digest ANCHOR è effettivamente calcolato dal browser.
- combined_filters: scegliere due filtri non predefiniti e dimostrare che il risultato è l'intersezione, non solo che i valori restano selezionati.
- export_json: scaricare JSON, verificarne parsing e contenuto rispetto alle note effettivamente salvate.
- notes_persistence: salvare una nota univoca, ricaricare e verificare che riappaia; cancellare la nota di test dopo l'acquisizione dell'evidenza.

**Tutte le prove sono PENDING finché non vengono eseguite e documentate.**

## Distinzione delle evidenze

L'integrità dei file nello ZIP è distinta dal comportamento browser, e quest'ultimo è distinto dalla riproduzione scientifica.
