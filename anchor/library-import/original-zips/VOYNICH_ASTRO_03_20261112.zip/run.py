import importlib.util, collections, numpy as np, json, hashlib, re, itertools
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
source=Path('/mnt/data/files/ZL3b-n.txt'); old=Path('/mnt/data/VOYNICH_ASTRO_02_20261112/run.py')
spec=importlib.util.spec_from_file_location('astro02',old);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
d=collections.defaultdict(list)
for line in source.read_text(encoding='utf-8-sig').splitlines():
 a=m.RX.match(line)
 if a:
  f,_,typ,body=a.groups()
  if 'Lz' in typ:
   body=re.sub(r'\{[^}]+\}','',body)
   body=re.sub(r'\[([^]:]+):[^]]+\]',r'\1',body)
   w=re.findall(r'[a-z]+',body)
   if w:d[f].append(' '.join(w))
fs=m.PANELS
texts=[' '.join(d[f]) for f in fs]
res={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_code':str(old),'panel_count':[len(d[f]) for f in fs]}
for n in [(2,2),(3,3)]:
 vec=TfidfVectorizer(analyzer='char',ngram_range=n); X=vec.fit_transform(texts); sim=cosine_similarity(X)
 # same zodiac pairs and other adjacencies in full order
 adjacency=[{'a':fs[i],'b':fs[i+1],'score':float(sim[i,i+1]),'same_sign':m.SIGNS[i]==m.SIGNS[i+1]} for i in range(11)]
 same=[x['score'] for x in adjacency if x['same_sign']];other=[x['score'] for x in adjacency if not x['same_sign']]
 # equal-size samples, shrink all panels to 15 labels at random, score and adjacency ranking, shared full-corpus vectorizer vocabulary
 rng=np.random.default_rng(9032026)
 observations=[];score_arrays=[]
 for rep in range(500):
  ss=[' '.join([d[f][j] for j in sorted(rng.choice(len(d[f]),15,replace=False))]) for f in fs]
  V=vec.transform(ss)
  S=cosine_similarity(V)
  adj=np.array([S[i,i+1] for i in range(11)])
  score_arrays.append(adj)
  observations.append((np.mean([adj[1],adj[3]]),np.mean(np.delete(adj,[1,3])),float(np.mean([adj[1],adj[3]])-np.mean(np.delete(adj,[1,3])))))
 vals=np.array(observations);pctl=np.mean([(np.count_nonzero(v>=np.mean([v[1],v[3]]))/11) for v in score_arrays]);better=np.mean(vals[:,2]>0)
 # permutation: exactly two adjacent edges nonoverlapping among eleven, best contrasts? adjacency variable, nonuniform across panels and sample size
 edges=list(itertools.combinations(range(11),2));pairs=[(i,j) for i,j in edges if abs(i-j)>1];mat=np.array(score_arrays);actual=mat[:,[1,3]].mean(axis=1); ref=[]
 for i,j in pairs:ref.append(float(np.mean(mat[:,[i,j]].mean(axis=1))))
 real=float(np.mean(actual));p=sum(r>=real-1e-12 for r in ref)/len(ref)
 res[str(n)]={'cross_folio_controls': {'Aries':float(mat[:,1].mean()),'Taurus':float(mat[:,3].mean()),'Libra_Scorpio':float(mat[:,9].mean()),'two_of_three_rank_p':float(sum((mat[:,[i,j]].mean(axis=1).mean()>=real-1e-12) for i,j in [(1,3),(1,9),(3,9)])/3)},'adjacency_full':adjacency,'same_mean_full':np.mean(same),'other_mean_full':np.mean(other),'same_diff_mean_resampled':float(vals[:,2].mean()),'same_diff_5_95':list(map(float,np.quantile(vals[:,2],[.05,.95]))),'same_mean_resampled':real,'other_mean_resampled':float(vals[:,1].mean()),'other_nonoverlap_adjacent_pairs':len(pairs),'nonoverlap_edge_pair_rank_p_exploratory':p,'fraction_resamples_diff_positive':float(better),'same_edge_average_rank':float(pctl),'edge_control_ranges':{'min':min(ref),'median':float(np.median(ref)),'max':max(ref)}}
print(json.dumps(res,indent=2,ensure_ascii=False))
Path('/mnt/data/ASTRO_03_RESULTS.json').write_text(json.dumps(res,indent=2,ensure_ascii=False))
