# ASTRO-03 | Il segno zodiacale supera l'effetto della vicinanza?
12 novembre 2026. Analisi esplorativa, ramo astronomico; gate RC1.4.2 non modificato.

## Ipotesi
Le etichette delle due metà dell'Ariete (f70v1, f71r) e del Toro (f71v, f72r1) sono testualmente simili perché rappresentano lo stesso segno, oppure perché le tavole sono vicine e perché entrambe le coppie attraversano confini di foglio?

## Materiali e metodo
ZL3b-n.txt, SHA-256 `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc`. Le etichette @Lz/&Lz di dodici pannelli zodiacali, ordini e categorie ripresi dal programma ASTRO-02. TF-IDF dei bigrammi e trigrammi di caratteri, similarità coseno. Per eliminare l'ovvia differenza di numerosità (15 etichette nelle due metà di Ariete/Toro; 29-30 altrove) vengono estratti 15 elementi per pannello per 500 replicazioni con seed fisso. Per Ariete/Toro si usano necessariamente tutte le 15. L'IDF è ricavato dai documenti originali interi, quindi non è riappreso su ciascun campione.

## Risultati

| Misura | Bigrammi | Trigrammi |
| --- | ---: | ---: |
| Media Ariete/Ariete e Toro/Toro con 15 etichette | 0,7777 | 0,4693 |
| Media altre nove coppie adiacenti campionate a 15 | 0,6714 | 0,3472 |
| Delta | +0,1063 | +0,1221 |
| Posizione fra tutte le 45 coppie di archi adiacenti disgiunti | 2/45 o migliori (0,0444) | 2/45 o migliori (0,0444) |

**La cifra 0,0444 NON è un p-value inferenziale valido**. Le 45 alternative non sono permutazioni scambiabili: differiscono per numero originale delle etichette, supporto fisico e posizione nell'ordine dei segni; la scelta dei confronti segue una scoperta già osservata in ASTRO-02. Il confronto è descrittivo e post-selezione.

### Il controllo fisico decisivo
Entrambe le coppie dello stesso segno attraversano un confine di folio: f70v1→f71r e f71v→f72r1. Tra i 12 pannelli, l'unico altro passaggio della stessa categoria è f72v1→f73r (Bilancia/Scorpione). Il controllo rigoroso disponibile ha quindi **solo tre archi**.

| Arco attraversando un nuovo numero di folio | Bigrammi originali | Bigrammi a 15 etichette | Trigrammi a 15 etichette |
| --- | ---: | ---: | ---: |
| Ariete / Ariete | 0,7779 | 0,7779 | 0,4674 |
| Toro / Toro | 0,7776 | 0,7776 | 0,4712 |
| Bilancia / Scorpione | 0,8109 | 0,7178 | 0,3848 |

Le due coppie del medesimo segno superano il terzo arco **solo dopo il campionamento a 15 etichette**. Prima del controllo sulla numerosità, il passaggio fra segni diversi, Bilancia/Scorpione, è più simile di entrambi. Fra le tre possibilità di scegliere due archi, la coppia Ariete+Toro è la migliore dopo la normalizzazione: posizione 1/3, p nominale = 1/3 soltanto sotto ipotesi forti di scambiabilità non giustificate.

## Verdetto
**Inconcludente.** Le due coppie dello stesso segno hanno una similarità superiore alle coppie adiacenti medie dopo il pareggiamento della numerosità, ma il confronto pertinente per supporto fisico si riduce a tre casi. Non è identificabile separatamente l'effetto semantico del segno zodiacale dall'effetto della posizione, dalle differenze fra testi lunghi e brevi e dal confine di folio. Nessuna parola EVA è tradotta. L'esperimento *non* supporta attribuzioni semantiche.

## Riproduzione
`python run.py` nella struttura di lavoro originale con corpus letto da `/mnt/data/files/ZL3b-n.txt` e precedente script ASTRO-02 per il parser. `numpy` e `scikit-learn` sono richiesti. Le frequenze e i punteggi sono in `results.json`. Eseguire in sola lettura rispetto ai corpus e agli artefatti congelati.

## Passo che sarebbe davvero decisivo
Un'ancora esterna con molte repliche dello stesso concetto visivo *in localizzazioni fisiche diverse*, e selezionata prima della lettura delle etichette. I quattro pannelli ripetuti di Ariete/Toro non offrono sufficiente indipendenza per questo test.
