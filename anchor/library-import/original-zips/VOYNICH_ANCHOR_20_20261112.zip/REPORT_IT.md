# VOYNICH — ANCHOR-20 | Le radici distinguono davvero le copie?

**Data:** 12 novembre 2026. **Stato:** verifica retrospettiva documentale; non esperimento visivo indipendente, non decifrazione. Gli artefatti congelati RC1.4.2 non sono stati modificati.

## Domanda
Le somiglianze delle radici, che in ANCHOR-19 comparivano in 9/9 confronti botanico-farmaceutici considerati convincenti, sono sufficienti a distinguere confronti convincenti da confronti storicamente dubbi?

## Fonte e dati
Fonte: Jorge Stolfi, *Repeated plant drawings*, https://www.ic.unicamp.br/en/~stolfi/EXPORT/voynich/00-06-07-word-grammar/Notes/064/work/projects/voynich/projects/programs/c/big/big/projects/voynich/Notes/096/work/Notes/091/report/report_091.html (pagina consultata il 12 novembre 2026). Il catalogo elenca 9 coppie classificate come *matches between Herbal and Pharma* e 2 coppie sotto *poor matches*. Per entrambe le coppie dubbie descrive una radice somigliante, ma non foglie o fiori. Lo stesso vale per f18v e f23r fra le coppie positive. 

I valori nel CSV `pairs_11.csv` descrivono **le componenti che l'autore segnala come corrispondenti**, non la presenza o assenza di componenti nell'originale. Le classificazioni 'positive' e 'poor' non sono una verità oggettiva: sono il giudizio dell'autore del catalogo.

## Risultati (n=11, stesso catalogo)

| Feature segnalata | Classificati positivi: sì / totale | Classificati dubbi: sì / totale | Sensibilità descrittiva | Specificità descrittiva |
|---|---:|---:|---:|---:|
| Somiglianza radici | 9/9 | 2/2 | 100% | **0%** |
| Somiglianza foglie | 7/9 | 0/2 | 77,8% | 100% |
| Somiglianza fiori | 1/9 | 0/2 | 11,1% | 100% |

**Risultato operativo:** nei confronti già selezionati dal catalogo, la presenza di radici simili **non distingue** le coppie che l'autore ritiene convincenti da quelle che considera dubbie (balanced accuracy 50%). La presenza di foglie simili è più discriminante in questo piccolissimo inventario, ma 2 casi dubbi sono troppo pochi per stimare prestazioni generali.

## Limite fondamentale: circolarità
Le descrizioni e l'assegnazione delle categorie provengono dallo **stesso autore**. È ragionevole sospettare che l'autore abbia usato proprio le caratteristiche 'radici + foglie' nel formulare il suo giudizio. Pertanto i risultati **NON** validano un classificatore d'immagini indipendente; classificano retrospettivamente il criterio descrittivo. I due 'poor matches' non sono falsi abbinamenti dimostrati. Non riportare p-value come prova di somiglianza esterna, e non trasferire queste percentuali a tutto il manoscritto.

## Reindirizzamento
1. Per ogni pianta originale e frammento farmaceutico ottenere immagini integre e una coppia di crop separati, senza informazioni testuali.
2. Due annotatori indipendenti e ciechi codificano: radice (nodi, rami, orientamento, simmetria), foglie (numero, disposizione, forma), fiori/frutti (presenza, anatomia), errori bizzarri replicati. Includere coppie non abbinate selezionate *prima* di conoscere i giudizi storici.
3. Pre-registrare la metrica di combinazione e una valutazione con esclusione per famiglia manoscritta e per foglio. Evitare lo stesso inventario come training e test.
4. Solo dopo, cercare corrispondenze in fonti esterne e usare i nomi per proporre una regola testuale da valutare fuori campione.

## Riscontro bibliografico esterno
Nel suo intervento del 2012, René Zandbergen riferiva di aver confrontato le immagini con **50 erbari senza trovare una singola pianta Voynich copiata integralmente** da questi. Segnalava invece somiglianze di singoli dettagli con gli erbari alchemici e con il *Tractatus de herbis*, oltre a possibili disegni compositi. La fonte non prova che non esista un modello perduto; obbliga tuttavia a cercare somiglianze di componenti e combinazioni di dettagli, non una semplice identificazione 1:1. Fonte: https://www.voynich.nu/papers/Voynich100_RZ_2012.pdf, p. 25.

## Esito
**STOP** per 'radice simile = copia sicura' e per 'una stessa pianta = parola già riconosciuta'. **GO** solo per un dataset di immagini originali e controlli ciechi con annotazioni indipendenti. Nessun significato Voynich assegnato.

## Riproducibilità
`run_anchor20.py` produce `pairs_11.csv` e `results.json`. Il test riproduce esclusivamente i dati descrittivi pubblicati. Nessuna rete o libreria esterna richiesta.
