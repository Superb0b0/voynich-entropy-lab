#!/usr/bin/env python3
"""Historical-documentary diagnostic; not an independent image-classifier test."""
import csv,json,hashlib,pathlib
root=pathlib.Path(__file__).resolve().parent
rows=[
 ('f1v','f102r1_3:2',1,1,0,'positive'),
 ('f18v','f102r2_3:1',1,0,0,'positive'),
 ('f19r','f102v1_2:3',1,1,0,'positive'),
 ('f23r','f102r2_3:2',1,0,0,'positive'),
 ('f37v','f102r1_3:1',1,1,0,'positive'),
 ('f32v','f102r2_1:2',1,1,1,'positive'),
 ('f47v','f102r2_1:1',1,1,0,'positive'),
 ('f48r','f89v3_3:4',1,1,0,'positive'),
 ('f48v','f89v3_1:5',1,1,0,'positive'),
 ('f51r','f99r_3:1',1,0,0,'poor'),
 ('f90v1','f99v_3:2',1,0,0,'poor'),
]
fields=['herbal','pharma','root_match','leaves_match','flower_match','historical_class']
with (root/'pairs_11.csv').open('w',newline='') as out:
 writer=csv.writer(out); writer.writerow(fields);writer.writerows(rows)
metrics={}
for feature in ('root_match','leaves_match','flower_match'):
 tp=sum(r[5]=='positive' and r[fields.index(feature)]==1 for r in rows)
 fn=sum(r[5]=='positive' and r[fields.index(feature)]==0 for r in rows)
 fp=sum(r[5]=='poor' and r[fields.index(feature)]==1 for r in rows)
 tn=sum(r[5]=='poor' and r[fields.index(feature)]==0 for r in rows)
 metrics[feature]={'TP':tp,'FN':fn,'FP':fp,'TN':tn,'sensitivity':tp/(tp+fn),'specificity':tn/(tn+fp),'balanced_accuracy':(tp/(tp+fn)+tn/(tn+fp))/2}
res={'design':'retrospective non-blind description-level diagnostic','sample_size':len(rows),'historical_positive':9,'historical_poor':2,'metrics':metrics,'limitations':['Features and categories are both transcribed from the SAME author descriptions. Not an independent classifier evaluation.','Poor matches are not proven non-copies; they are historically rated uncertain.','The descriptions cannot tell how many component types were originally present.','No generalization, significance claim, or species identification is justified.'],'source':'https://www.ic.unicamp.br/en/~stolfi/EXPORT/voynich/00-06-07-word-grammar/Notes/064/work/projects/voynich/projects/programs/c/big/big/projects/voynich/Notes/096/work/Notes/091/report/report_091.html'}
(root/'results.json').write_text(json.dumps(res,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(res,indent=2))
