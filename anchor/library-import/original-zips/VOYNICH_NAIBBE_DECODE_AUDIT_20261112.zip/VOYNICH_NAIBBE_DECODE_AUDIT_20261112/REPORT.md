# Voynich: audit della recuperabilità del ciphertext Naibbe

**Data:** 12 novembre 2026  
**Tipo:** controllo empirico di cifrario sintetico, **non** tentativo di decifrazione del Voynich.  
**Stato:** risultato in memoria sul campione pubblicato, ottenuto attraverso il connettore GitHub; controllo con script Python locale limitato a self-test sintetico. Esecuzione del programma Python originale di Greshko: **PENDING**.

## Domanda

Se un cifrario verbose produce token simili a quelli del Voynich, quanto cambia la *recuperabilità* del testo latino sottostante quando si fondono alcuni confini fra token? Il test distingue tre concetti:

1. Contenuto informativo originario, noto per costruzione (plaintext latino di riferimento).
2. Riuscita del decoder pubblicato (`decrypt_naibbe.py`, `BASIC=True`, `MARK_COMPOUND=True`).
3. Unicità delle decodifiche *consentite dalla grammatica del cifrario*, senza conoscenza dei confini persi, dei mazzi estratti e senza prior linguistico.

## Sorgenti

Repository di Michael A. Greshko: <https://github.com/greshko/naibbe-cipher>, commit `5145f526b52741a6dca14201147f687e62c7162e`.

- `references/naibbe_tables.csv`: Git blob `5cd34fb81d80faf3b4d57dbf1719c05ffde25302`.
- `encrypted/nathist_output_ciphertext.txt`: `fb5f1e7509773361ea1acf5b4019efdc83cd17e4`.
- `encrypted/nathist_output_ciphertext_respaced.txt`: `c95b95507e603ca9a7b0dadba2d13eb314e9b7ea`.
- `respaced_plaintext/nathist_pre_encryption_respaced_plaintext.txt`: `e1cca30c06fb5f99aff480e1e128245529b63a35`.
- `decrypt_naibbe.py`: `b56a1e6e615a7b2e31ad386efdf7e6f2ef2b9d7b`.

Il connettore GitHub ha letto i quattro file di dati e lo script del decoder. Sono stati replicati, in JavaScript in memoria, le scelte del decoder: precedenza a unigrammi, ricerca degli split prefisso/suffisso, esplicitazione delle letture ambigue e tentativo di lettura dei composti mediante la tabella. **Non si è eseguito direttamente `decrypt_naibbe.py`.**

Il programma `audit_public_naibbe_pair.py`, accluso, riproduce indipendentemente il conteggio in Python *una volta che i quattro file pubblici siano presenti*, dopo averne controllato l'identità Git blob. Il self-test locale passa; la riproduzione integrale locale non può ancora essere attestata.

## Risultati osservati

| Proprietà | Conteggio |
|---|---:|
| Token ciphertext originale | 34.764 |
| Ngram plaintext allineati | 34.764 |
| Decodifiche originali esatte, univoche | 34.517 (99,29%) |
| Decodifiche originali esplicitamente ambigue | 247 (0,71%) |
| Letture originali univoche scorrette | 0 |
| Token ciphertext dopo la rimozione di spazi | 33.750 |
| Confini eliminati | 1.014 |
| Gruppi fusi | 985 |
| Gruppi fusi leggibili esattamente e univocamente dal decoder pubblicato | 219 (22,23%) |
| Gruppi fusi segnalati `"[?]"` dal decoder pubblicato | 743 (75,43%) |
| Gruppi fusi con altri risultati, non univoci/esatti | 23 |

**Verifica di allineamento:** per ogni riga, la concatenazione dei caratteri del ciphertext originale è *identica* a quella della versione rispaziata. La differenza riguarda quindi solo i confini; plaintext e ciphertext non sono stati modificati nei glifi.

## Controllo di grammatica: il problema è del decoder o dei confini?

Ho costruito il vocabolario dei glifi *effettivamente producibili* mediante le tabelle: unigrammi, oppure prefisso+ suffisso per una coppia di lettere, escludendo le collisioni con gli unigrammi vietate dall'encoder. Esistono **18.947 tipi grafici legali** in tale vocabolario, considerando le alternative v1. Per ogni gruppo fuso ho contato, tramite programmazione dinamica, tutte le segmentazioni in almeno due token legali e le relative letture di lettere latine. Nessuna scelta usa la frequenza linguistica, il testo originale o lo stato del mazzo per selezionare una lettura. Le letture originali sono usate *soltanto per verifica successiva*.

| Risultato | Gruppi su 985 |
|---|---:|
| Esiste almeno una decodifica valida | 985 |
| La lettura originale compare fra le opzioni | 985 |
| Una sola lettura possibile | **56 (5,69%)** |
| Due o più letture possibili | **929 (94,31%)** |

La rispaziatura non cancella necessariamente l'informazione codificata nei glifi. **Distrugge però l'unicità dell'interpretazione sotto la grammatica grafica in assenza di ulteriori vincoli.** Questo risultato non è causato esclusivamente dall'implementazione del decoder pubblicato: l'ambiguità permane anche con enumerazione esaustiva dei confini.

Una verifica di sensibilità mostra che, *se sapessimo dall'esterno* che un certo gruppo è composto esattamente da due ngram, **671 dei 957 gruppi di due ngram** sarebbero decifrabili univocamente sotto il vocabolario. L'incertezza sul **numero** di token fusi è dunque una parte sostanziale del problema.

**Limiti:** è stato ignorato lo stato del mazzo di carte e non è stato applicato un modello linguistico. Entrambi potrebbero eliminare molte ambiguità. L'esperimento valuta una nozione precisa di recuperabilità locale, non la possibilità teorica di decifrare un intero messaggio con informazioni aggiuntive. Non stima la qualità delle segmentazioni del Voynich, i cui token e plaintext sono ignoti.

## Controllo v1 / v2 sul vocabolario dei glifi

Per enumerazione di 138 elementi prefisso × 138 elementi suffisso:

- 19.044 coppie codice originarie.
- v1: 18.913 coppie ammesse dopo l'esclusione delle collisioni con unigrammi; 18.711 producono una lettura unica e 202 una lettura ambigua (conteggi *non* pesati per frequenza).
- v2: le 202 coppie ambigue aggiuntive sono escluse; le 18.711 coppie rimanenti sono tutte univocamente interpretabili **come token isolati**.

La modifica v2 risolve quella specifica ambiguità intratoken, **non** l'incertezza dovuta a confini soppressi.

## Implicazione per il progetto Voynich

Il controllo dimostra che *somiglianza di superficie*, *presenza di un plaintext* e *recuperabilità pratica della segmentazione* sono dimensioni diverse. Il campione Naibbe è un esempio controllato: il messaggio noto resta compatibile con i glifi ma, senza confini, quasi tutti i gruppi fusi hanno più di un'interpretazione lecita sotto un decoder senza contesto.

Il risultato non identifica il meccanismo storico del Voynich. Non assolve né esclude la famiglia dei cifrari verbose. Per un ulteriore passo credibile, occorre verificare il Python originale byte-per-byte e applicare lo stesso protocollo di rimozione dei confini a più generazioni indipendenti, includendo eventuali vincoli globali del mazzo.

**RC1.4.2 non è stato modificato:** stato `CLOSED_PENDING_VALIDATION`; nessuna PCA, clustering o coupling.

## Riproduzione

```bash
python audit_public_naibbe_pair.py --self-test
# In una postazione con GitHub raggiungibile:
python audit_public_naibbe_pair.py --download --source-dir source_cache --output recomputed.json
# Oppure fornire manualmente i quattro file al percorso source_cache/ mantenendo le sottocartelle.
```

I numeri calcolati nella sessione, con digest delle sorgenti, sono conservati in `observed_from_connector.json`. La rigenerazione dello stesso JSON tramite il runner *non è dichiarata già avvenuta*. La sorgente originale richiede la citazione:

Greshko, Michael A. (2025). *The Naibbe cipher: a substitution cipher that encrypts Latin and Italian as Voynich Manuscript-like ciphertext*. *Cryptologia*. <https://doi.org/10.1080/01611194.2025.2566408>.
