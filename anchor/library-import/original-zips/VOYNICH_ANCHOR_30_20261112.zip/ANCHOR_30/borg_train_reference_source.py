#!/usr/bin/env python3
"""Ciphertext-only baseline for an alphabet-permuted two-homophone synthetic code.
No plaintext, secret mapping or answer key is used by the attacker.
Uses independent authentic Borg plaintext pages as language reference.
NOT a full Naibbe model or a Voynich decryption.
"""
import random,re,json,statistics,hashlib,pathlib,collections
OUT=pathlib.Path(__file__).resolve().parent
TARGET=(OUT/'borg_0010r_plaintext_extracted.txt').read_text()
# Copied from independently published page transcriptions: Borg 0010v and 0011r.
TRAIN='''[R C]onserue leni,,ui larum partem unam uel [drachmam] medulle cassie [uncias II] [M]uscilaginis psil[r?] [M]isce et accipe ad placentum. [Hostia laxatiua] [R. A]que rosarum [libram I] farrine tritici alb[e] fac pulmentum, adde hu[c] [D]iagredy [unciam semis, Z]achari f[i] ni [uncias II]puluericent[ur] prius subtiliter, mi[s] ce deinde cum predic[to] pulmento, et fac hos tias, et poteris adde[re]
[2] uel [3] secundum quod uidebitur et sunt for tassis [24] doses dan do pro dosi [?] grana [D]ia gridy. [Nebulae Laxatiuae] [R.] farrine frumenti uel tritici aut zacari [uncias VII(?)] [D]istemperentur cum lacte titimalli et fi ant nebule. [Ad relaxandum uen trem quando(?) possunt capere medicinas.] [R. L]ardum et ipsum arden tem destilla super'''
def norm(x):
 x=re.sub(r'\[[^\]]*\]','',x.lower())
 return ''.join(re.findall('[a-z]',x))
train=norm(TRAIN);target=norm(TARGET)
ALPH=sorted(set(train)|set(target))
assert len(ALPH)>15
# Ciphertext has two known token variants per transformed letter, but the
# permutation linking transformed letters to plaintext is secret.
# This is deliberately easier than real Naibbe (known token boundaries).
attacker_ref=collections.Counter(train)
rank_ref=sorted(ALPH,key=lambda c:(-attacker_ref[c],c))
# The attacker sees two coded variants indexed by transformed-letter ID.
# It can merge variants but cannot infer the secret alphabet permutation.
seed=20261112;rng=random.Random(seed)
reps=100;results=[];example={}
for rep in range(reps):
 perm=ALPH[:];rng.shuffle(perm)
 plain_to_code=dict(zip(ALPH,perm))
 coded=[(plain_to_code[c],rng.randrange(2)) for c in target]
 code_counts=collections.Counter(c for c,_ in coded)
 rank_code=sorted(ALPH,key=lambda c:(-code_counts[c],c))
 decoded_code_to_plain=dict(zip(rank_code,rank_ref))
 candidate=''.join(decoded_code_to_plain[code] for code,_ in coded)
 acc=sum(a==b for a,b in zip(candidate,target))/len(target)
 # Random guesses constitute a separate null, not consulted during attack.
 random_decode=ALPH[:];rng.shuffle(random_decode)
 dec_rand=dict(zip(ALPH,random_decode))
 nul=sum(dec_rand[code]==real for (code,_),real in zip(coded,target))/len(target)
 results.append(dict(run=rep,accuracy=round(acc,6),null_accuracy=round(nul,6),token_count=len(target)))
 if rep==0:example={'cipher_excerpt':['%s%s'%(c,v) for c,v in coded[:35]],'guessed_plaintext_excerpt':candidate[:90],'true_excerpt_FOR_EVALUATION_ONLY':target[:90]}
acc=[x['accuracy'] for x in results];null=[x['null_accuracy'] for x in results]
summary={'experiment':'ANCHOR-27','status':'SYNTHETIC_CIPHERTEXT_ONLY_BASELINE','source':'Borg 0010r held out; language-reference corpus Borg 0010v + 0011r','attacker_access':'ciphertext, token boundaries, two variants per coded character, independent reference frequency; NO target plaintext or secret key','target_characters':len(target),'reference_characters':len(train),'alphabet_size':len(ALPH),'replications':reps,'rank_frequency_accuracy_mean':statistics.mean(acc),'rank_frequency_accuracy_range':[min(acc),max(acc)],'random_key_accuracy_mean':statistics.mean(null),'random_key_accuracy_range':[min(null),max(null)],'sample':example,'caveats':['Source and reference are different pages of the same Latin medical manuscript; language and genre known','The attack exploits known homophone grouping, an advantage absent for the Voynich','Frequency-only attacker; no modern ngram or neural decoder tried','Synthetic cipher inspired by two-column Naibbe unigram encodings, not original Naibbe algorithm','Ciphertext-only cannot be validated as a true Voynich solution without external plaintext']}
(OUT/'results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
(OUT/'replications.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('sample','caveats')},indent=2))
