# ANCHOR-30 | Recupero con confini cifrati ignoti

**Data:** 12 novembre 2026. **Perimetro:** esperimento sintetico esplorativo, separato dal ramo Voynich RC1.4.2 (`CLOSED_PENDING_VALIDATION`). **Non si tratta di una decifrazione del Voynich.**

## Domanda

Quanto degrada un recuperatore ciphertext-only quando non conosce né la chiave né i confini fra simboli cifrati? E quanto dipende dalla reale ambiguità del vocabolario di codici?

## Disegno

Tre brani latini disgiunti (282, 204 e 195 lettere), tratti da due trascrizioni dello stesso manoscritto Borg. A turno si usa un brano come bersaglio e gli altri due per stimare un modello di bigrammi latini. Ogni bersaglio viene cifrato con tre chiavi segrete (9 prove per regime). L'alfabeto comprende 22 lettere, ciascuna rappresentata da due possibili codici arbitrari. La codifica è sintetica e non rappresenta il Naibbe completo.

L'attaccante riceve soltanto il flusso continuo cifrato, il **vocabolario completo dei codici** (facilitazione sostanziale), il numero di classi e la distribuzione del modello di lingua. Non riceve il testo originale, la chiave o la segmentazione autentica. Un algoritmo di programmazione dinamica segmenta il flusso favorendo codici corti o lunghi; quindi un algoritmo di scambi con 3 riavvii × 1.300 iterazioni tenta di recuperare la mappatura segreta, senza conoscere i raggruppamenti omofonici.

Due regimi prefissati nel lavoro:

1. **2–3 segni:** 16 codici corti di lunghezza 2, 28 lunghi di lunghezza 3. Segmentazione relativamente facile.
2. **1–2 segni:** 8 codici corti di lunghezza 1, 36 lunghi di lunghezza 2. Segmentazione intenzionalmente ambigua, con numerosi prefissi sovrapposti.

La condizione *oracle* rivela i soli confini e consente di misurare quanto costi la segmentazione ignota; **non è** un attacco ciphertext-only pieno. La valutazione rigorosa conta come giusto un carattere soltanto quando l'intero simbolo cifrato è segmentato nei confini autentici **e** decodificato con la lettera corretta.

## Risultati

| Regime | Segmentazione corta, caratteri corretti | Segmentazione lunga, caratteri corretti | Confini noti, caratteri corretti | Precisione confini con segmentazione lunga |
|---|---:|---:|---:|---:|
| 2–3 segni | 15,3% | 20,5% | 26,0% | 99,0% |
| 1–2 segni | 0,7% | 10,9% | 18,6% | 87,4% |

Nel regime 1–2 segni, la **recall** dei confini con segmentazione lunga è 84,9%; la precisione è 87,4%. Il regime 2–3 segni è più facile di quanto fosse desiderabile, dunque non può sostenere una dichiarazione forte.

I controlli con chiave casuale e confini veri producono rispettivamente 9,1% e 3,2% in queste piccole serie. Sono controlli descrittivi ad alta varianza, **non livelli teorici del caso** né test di significatività.

## Verdetto

**EFFETTO REALE MA NON GENERALIZZABILE.** Una segmentazione ambigua riduce l'accuratezza del recupero nel piccolo esperimento sintetico. L'esperimento identifica un collo di bottiglia del nostro specifico recuperatore; **non esclude algoritmi che stimino congiuntamente la segmentazione e la chiave**, modelli linguistici migliori o altre architetture di cifratura.

### Limiti

- L'inventario completo dei codici è fornito al recuperatore; nel Voynich non è noto.
- Sono utilizzati soltanto tre brani dello stesso manoscritto, non generi/autori indipendenti. Le tre chiavi per brano sono repliche dipendenti.
- La scelta ex post del migliore tra due segmentatori rende il migliore dei due un risultato esplorativo. Entrambi sono documentati nei JSON.
- Nessuna sintassi di parole, varianti testuali, riordino, regole elaborate Naibbe o cifratura medievale autentica sono simulate.
- La segmentazione e la chiave sono stimati **in due fasi**, non congiuntamente. Il titolo non deve suggerire un recuperatore già ottimale.
- Nessun trasferimento semantico al Voynich è autorizzato. Nessun frammento Voynich è stato tradotto.

## Riproduzione

`python run.py` ripete il regime 2–3; `python run_ambiguous.py` ripete il regime 1–2. I file testuali di input sono inclusi. Il manifest `SHA256SUMS.txt` contiene le impronte degli artefatti. Nessun file RC1.4.2 viene letto o modificato.
