#!/usr/bin/env python3
"""ANCHOR-30: hidden variable-length codeword boundaries; declared codebook; no known key or plaintext.
Attack uses only the ciphertext stream, public codeword inventory and out-of-target Latin model.
Ablations compare oracle boundaries and random baseline. Not complete Naibbe.
"""
import numpy as np, random, re, json, pathlib, statistics, hashlib, time
from functools import lru_cache
ROOT=pathlib.Path(__file__).resolve().parent
src=(ROOT/'borg_train_reference_source.py').read_text()
TRAIN=src.split("TRAIN='''",1)[1].split("'''",1)[0]
TARGET=(ROOT/'borg_0010r_plaintext_extracted.txt').read_text()
def norm(x): return ''.join(re.findall('[a-z]',re.sub(r'\[[^]]*\]','',x.lower())))
raw=[norm(TARGET),norm(TRAIN[:len(TRAIN)//2]),norm(TRAIN[len(TRAIN)//2:])]
assert min(map(len,raw))>100
alpha=sorted(set(''.join(raw))); m=len(alpha); idx={x:i for i,x in enumerate(alpha)}

def train_model(s):
 vals=[idx[c] for c in s]
 B=np.full((m,m),0.5,dtype=float); U=np.ones(m)
 for x in vals:U[x]+=1
 for a,b in zip(vals[:-1],vals[1:]):B[a,b]+=1
 return np.log(B/B.sum(axis=1,keepdims=True)),np.log(U/U.sum())

def encrypt(s,seed):
 rng=random.Random(seed); alphabet='abcdefgh'
 # Codebook public, but variable-length and not prefix-free. Sym IDs and true homophone pairs hidden.
 short=list(alphabet)
 long=[a+b for a in alphabet for b in alphabet];rng.shuffle(long)
 words=short+long[:2*m-8];rng.shuffle(words)
 sym=list(range(2*m));rng.shuffle(sym)
 p_to_ids={c:(sym[2*idx[c]],sym[2*idx[c]+1]) for c in alpha}
 keys=np.zeros(2*m,dtype=np.int16)
 for c,(a,b) in p_to_ids.items():keys[a]=keys[b]=idx[c]
 code=np.array([rng.choice(p_to_ids[c]) for c in s],dtype=np.int16)
 stream=''.join(words[x] for x in code)
 boundaries=[];p=0
 for x in code:p+=len(words[x]);boundaries.append(p)
 return stream,code,keys,words,boundaries

def parse(stream,words,prefer_short=True, lang_map=None,S=None,U=None):
 # Dynamic program for best path over *public* codebook; fixed 1/2-char priors.
 # 'lang_map' permits an iteration using guessed letter transitions, but first segmentation key-blind.
 lookup={w:i for i,w in enumerate(words)};N=len(stream)
 dp=np.full(N+1,-1e18);dp[0]=0
 prev=[None]*(N+1)
 for j in range(1,N+1):
  for L in (1,2):
   i=j-L
   if i<0:continue
   sym=lookup.get(stream[i:j]);
   if sym is None or dp[i]<-1e17:continue
   # structural prior; no plaintext, no true boundary, no hidden-key info
   bonus=(0.13 if L==1 else 0) if prefer_short else (0.13 if L==2 else 0)
   val=dp[i]+bonus-0.001
   if val>dp[j]:dp[j]=val;prev[j]=(i,sym)
 if dp[N]<-1e17:raise ValueError('No path')
 ids=[];bounds=[];j=N
 while j:
  i,sym=prev[j];ids.append(sym);bounds.append(j);j=i
 return np.array(ids[::-1],dtype=np.int16),bounds[::-1]

def attack(code,S,Ul,seed,restarts=3,steps=1300):
 n=2*m;counts=np.bincount(code,minlength=n)
 rank=sorted(range(m),key=lambda x:(-Ul[x],x)); order=sorted(range(n),key=lambda x:(-counts[x],x))
 base=np.zeros(n,dtype=np.int16)
 for i,cs in enumerate(order):base[cs]=rank[i//2]
 A=np.zeros((n,n),dtype=np.int32)
 for a,b in zip(code[:-1],code[1:]):A[a,b]+=1
 def score(p):return float(np.sum(A*S[np.ix_(p,p)]))+.5*float(np.dot(counts,Ul[p]))
 rng=np.random.default_rng(seed+999);best=base.copy();bestscore=score(best)
 for r in range(restarts):
  p=base.copy() if r==0 else rng.permutation(np.repeat(np.arange(m,dtype=np.int16),2))
  sc=score(p)
  for st in range(steps):
   a,b=rng.choice(n,2,replace=False)
   if p[a]==p[b]:continue
   p[a],p[b]=p[b],p[a]
   v=score(p);temp=2.4*(1-st/steps)+.05
   if v>=sc or rng.random()<np.exp(max(-700,(v-sc)/temp)):sc=v
   else:p[a],p[b]=p[b],p[a]
   if sc>bestscore:bestscore=sc;best=p.copy()
 return best

runs=[];samples=[]
for tid,t in enumerate(raw):
 ref=''.join(raw[j] for j in range(len(raw)) if j!=tid)
 S,Ul=train_model(ref);plain=np.array([idx[x] for x in t],dtype=np.int16)
 for rep in range(3):
  seed=20261112+1000*tid+137*rep
  stream,truth,key,words,bounds=encrypt(t,seed)
  # Two deterministic segment hypotheses with publicly known codebook, no oracle.
  guessedA,ba=parse(stream,words,True);guessedB,bb=parse(stream,words,False)
  variants=[]
  for method,seq,predbounds in [('prefer_short',guessedA,ba),('prefer_long',guessedB,bb),('oracle_boundaries',truth,bounds)]:
   est=attack(seq,S,Ul,seed)
   # compare character alignment only where the segmented codeword ends at the same true boundary
   boundary_to_truth={b:i for i,b in enumerate(bounds)}
   recovered=[est[int(cs)]==plain[boundary_to_truth[b]] for cs,b in zip(seq,predbounds) if b in boundary_to_truth]
   # exact codeword segmentation counts true boundary and true symbol identity
   exact=len(seq)==len(truth) and np.array_equal(seq,truth)
   b_prec=len(set(predbounds)&set(bounds))/len(predbounds)
   b_recall=len(set(predbounds)&set(bounds))/len(bounds)
   # direct correctness requires aligned symbol START and END, nonmatching portions count wrong
   starts=[0]+predbounds[:-1];realstarts=[0]+bounds[:-1]
   true_segments={(a,b):i for i,(a,b) in enumerate(zip(realstarts,bounds))}
   correct=0
   for cs,a,b in zip(seq,starts,predbounds):
    if (a,b) in true_segments and est[cs]==plain[true_segments[(a,b)]]:correct+=1
   variants.append({'condition':method,'token_count':len(seq),'token_accuracy_strict':correct/len(truth),
      'boundary_precision':b_prec,'boundary_recall':b_recall,
      'exact_full_segmentation':exact})
  rng=np.random.default_rng(seed+88);rand=rng.permutation(np.repeat(np.arange(m,dtype=np.int16),2))
  randomacc=np.mean(rand[truth]==plain)
  row={'target':tid,'seed':seed,'truth_token_count':len(truth),'stream_length':len(stream),'random_acc_oracle_boundaries':float(randomacc), 'conditions':variants}
  runs.append(row)
  if rep==0:samples.append({'target':tid,'stream_prefix':stream[:120], 'public_codeword_count':len(words),'true_text_prefix_EVALUATION_ONLY':t[:80], 'short_parse_prefix':[words[int(x)] for x in guessedA[:15]]})

result={'experiment':'ANCHOR-30-AMBIGUOUS','scope':'Synthetic ciphertext-only with public variable-length non-prefix-free codebook, hidden symbol boundaries and key. Not full Naibbe and NOT Voynich decryption.',
 'controls':'Oracle boundaries; random secret mapping; same LM trained only on non-target Latin segments',
 'caveats':['Published codeword inventory is disclosed to attacker: significant simplifying assumption.',
   'The two segmentation rules do not jointly optimize segmentation and key: this is a lower-capability baseline, not impossibility proof.',
   'All three passages belong to the same Borg manuscript; only 3 held-out passages, each with 3 secret keys.',
   'The displayed token_accuracy_strict penalizes incorrect segment boundaries, and is comparable to the known-boundary condition.',
   'No statistical inference across independent languages or genres.'], 'results':runs, 'means':{}, 'examples':samples}
for name in ['prefer_short','prefer_long','oracle_boundaries']:
 for key in ['token_accuracy_strict','boundary_precision','boundary_recall']:
  vals=[next(z for z in r['conditions'] if z['condition']==name)[key] for r in runs]
  result['means'][name+'_'+key]=round(statistics.mean(vals),6)
result['means']['random_acc_oracle_boundaries']=round(statistics.mean(x['random_acc_oracle_boundaries'] for x in runs),6)
(ROOT/'results_ambiguous.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'n':len(runs),'m':m,'means':result['means'],'sample_lengths':[len(x) for x in raw]},indent=2))
