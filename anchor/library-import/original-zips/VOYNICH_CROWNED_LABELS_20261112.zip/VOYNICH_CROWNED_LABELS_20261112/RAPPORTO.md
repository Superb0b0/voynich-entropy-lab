# EXP-FIRST-WORD-06: etichette delle figure coronate

**Data:** 12 novembre 2026. **Stato:** esplorativo, nessuna traduzione, nessun gate superato. Pipeline RC1.4.2 immutata.

## Domanda
Le etichette di tre figure coronate condividono una forma grafica eccezionalmente simile, come ci aspetteremmo da una denominazione letterale comune?

## Provenienza delle associazioni
- Cancro f72r3, figura dell'anello interno a circa 03:00/03:05, trascrizione ZL3b locus 30: `ytoar.shar`. Corrispondenza riportata nel Voynich Information Browser, scheda con John Grove, etichetta X.5 / S3.5.
- Leone f72v3, anello interno figura con corona, locus 26 ZL3b: `odairan`. VIB / Grove S2.7. VIB segmenta `odair.an` in un'altra trascrizione; **la segmentazione è variabile**.
- Bilancia f72v1, associata al locus 8 ZL3b `oees` secondo un catalogo web recente, **non verificata indipendentemente**. La descrizione generale di René Zandbergen conferma la corona nella pagina ma non la singola etichetta.
- Scorpione f73r, locus 15 `oteedyy`: *possibile quarta corona* secondo catalogo recente, in contrasto con il conteggio delle tre corone nel repertorio di Zandbergen. Escluso dal test principale.

Fonti: https://vib.tamagothi.de/index.php?id=f72r3&show=page ; https://vib.tamagothi.de/index.php?id=f72v3&show=page ; https://voynich.nu/q11/index.html ; https://end.rito.one/solved/figures.html . L'ultimo sito propone una propria soluzione, che non è considerata accertata.

## Test
Trascrizione ZL3b originale SHA-256 `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc`. Il codice estrae direttamente le righe `Lz`; esclude token contenenti incertezze, marca come candidato il locus della figura coronata, e calcola la distanza di Levenshtein minima fra le parole di ogni coppia di etichette. Esegue due nulli esatti: una etichetta per pagina tra tutte le 28 eleggibili (28^3=21.952); e una etichetta per pagina *nello stesso anello* (7×12×18=1.512).

Etichette coronate: `ytoar.shar` / `odairan` / `oees`. La più piccola distanza tra parole appartenenti a due etichette diverse è 4; somma delle tre distanze minime = 15. Nessuna parola intera condivisa. Per gli insiemi casuali di etichette, la frequenza di somma delle distanze >= osservato è 0,474 (senza vincolo d'anello) e 0,459 (vincolo d'anello). La quota con prima parola iniziante `o` in almeno due delle tre etichette è 0,858 e 0,764 nei nulli rispettivi.

**Verdetto:** nessuna somiglianza grafica anomala per le tre etichette. Le differenze non dimostrano che le corone non abbiano un significato scritto, e non distinguono la presenza di un codice omofonico o una lingua; l'effetto misurato non sostiene un termine ricorrente per 'corona'.

## Limiti
Il campione ha solo tre etichette, una attribuzione (Bilancia) necessita verifica indipendente, le parole multiunità e la segmentazione EVA variano fra trascrittori, le etichette con incertezze sono escluse, la corrispondenza visiva è basata su annotazioni esterne e non su una nostra annotazione cieca di scansioni Yale. Il null d'anello non controlla per lunghezza. Perciò il test è *descrittivo e diagnostico*, non una conferma della falsità di qualsiasi ipotesi semantica.

## Prossimo test falsificabile
Acquisire manualmente sulle immagini Yale un registro indipendente delle singole corone, copricapi simili ma non coronati e loro etichette, con doppio annotatore ignaro della trascrizione. Ripetere il confronto con abbinamenti appaiati per folio/anello/lunghezza. Nessuna etichetta tradotta allo stato attuale.
