#!/usr/bin/env python3
"""Exploratory crown-label audit. Not a reading or a decipherment.
Transcription taken from frozen ZL3b; visual locator from VIB/J.Grove,
Libra from independent secondary catalogue, fourth Scorpio sensitivity only.
"""
import re, csv, json, itertools, hashlib
from pathlib import Path
from collections import Counter
S=Path(__file__).resolve().parent
SOURCE=S/'ZL3b-n.txt'
FOLIOS=['f72r3','f72v3','f72v1']
CROWN={'f72r3':30,'f72v3':26,'f72v1':8,'f73r':15}
L=re.compile(r'^<(?P<folio>f\d+[rv]\d?)\.(?P<locus>\d+),[^>]*Lz>\s*<![^>]+>(?P<raw>.*)$')
def words(raw):
    raw=re.sub(r'\{[^}]*\}', '',raw)
    raw=re.sub(r'\[[^\]]*\]', '?',raw)
    raw=re.sub(r'@\d+;', '?',raw)
    raw=raw.replace(',', '.')
    out=[x for x in raw.split('.') if x]
    return [x for x in out if re.fullmatch('[a-z]+',x)]
records=[]
for line in SOURCE.read_text(encoding='utf8').splitlines():
    m=L.match(line)
    if not m or m.group('folio') not in FOLIOS+['f73r']: continue
    f=m.group('folio'); loc=int(m.group('locus')); raw=m.group('raw').strip()
    tok=words(raw)
    records.append(dict(folio=f,locus=loc,raw=raw,words=' '.join(tok),n_words=len(tok),clean=bool(tok),crowned_candidate=int(loc==CROWN[f]),confidence=('visual+VIB' if f=='f72r3' else 'visual+Grove' if f=='f72v3' else 'secondary_catalogue'),note='Scorpio crown contested' if f=='f73r' else ''))
with (S/'all_labels.csv').open('w',newline='') as h:
    w=csv.DictWriter(h,fieldnames=records[0].keys());w.writeheader();w.writerows(records)
by={f:[r for r in records if r['folio']==f and r['clean']] for f in FOLIOS}
C=[next(r for r in by[f] if r['crowned_candidate']) for f in FOLIOS]
assert all(c['words'] for c in C)

def ed(a,b):
    old=list(range(len(b)+1))
    for i,ch in enumerate(a,1):
        new=[i]+[0]*len(b)
        for j,q in enumerate(b,1):new[j]=min(new[j-1]+1,old[j]+1,old[j-1]+int(ch!=q))
        old=new
    return old[-1]
def pair_min(a,b):
    return min(ed(x,y) for x in a.split() for y in b.split())
def score(items):
    p=[pair_min(items[i]['words'],items[j]['words']) for i,j in [(0,1),(0,2),(1,2)]]
    fs=[items[i]['words'].split()[0] for i in range(3)]
    return (sum(int(x.startswith('o')) for x in fs),min(p),sum(p),len(set(fs)))
obs=score(C)
cnt=Counter();n=0
for triple in itertools.product(*(by[f] for f in FOLIOS)):
    s=score(triple);cnt['n']+=1
    for k,v in zip(['o_first_count','minimum_edit','sum_min_edits','distinct_first'],s):
        cnt[k+'_ge']+=int(v>=obs[['o_first_count','minimum_edit','sum_min_edits','distinct_first'].index(k)])
        cnt[k+'_le']+=int(v<=obs[['o_first_count','minimum_edit','sum_min_edits','distinct_first'].index(k)])
    n+=1
summary={'title':'Zodiac crowned nymph label audit exploratory','transcription':'ZL3b','corpus_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'scope':'three established crowned pages only (Cancer, Leo, Libra)','crown_matches':[{k:r[k] for k in ['folio','locus','raw','words','confidence']} for r in C], 'labels_eligible_per_page':{f:len(by[f]) for f in FOLIOS},'enumerated_triplets':n,'observed':dict(zip(['o_first_count','minimum_edit','sum_min_edits','distinct_first'],obs)), 'null_rates':{k:cnt[k]/n for k in cnt if k!='n'},'control':'Exact one label from each of the same three zodiac pages; ignores ring and graphic length, exploratory only', 'fourth_crown':next((r for r in records if r['folio']=='f73r' and r['crowned_candidate']),None)}
(S/'results.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(summary,indent=2,ensure_ascii=False))

# Ring-matched exact control (locally documented ring segmentation, not a blind result).
RING_RANGES={'f72r3':(27,33),'f72v3':(21,32),'f72v1':(2,21)}
ring={f:[r for r in by[f] if RING_RANGES[f][0]<=r['locus']<=RING_RANGES[f][1]] for f in FOLIOS}
N=0;ct=Counter()
for triple in itertools.product(*(ring[f] for f in FOLIOS)):
    val=score(triple);N+=1
    ct['sum_edits_ge']+=int(val[2]>=obs[2]);ct['sum_edits_le']+=int(val[2]<=obs[2]);ct['min_edit_ge']+=int(val[1]>=obs[1]);ct['prefix_o_ge']+=int(val[0]>=obs[0]);ct['pair_first_word_exact']+=int(val[3]<3)
summary['ring_matched_control']={'per_page':{f:len(ring[f]) for f in FOLIOS},'all_combinations':N,'p_sum_edit_ge':ct['sum_edits_ge']/N,'p_sum_edit_le':ct['sum_edits_le']/N,'p_min_edit_ge':ct['min_edit_ge']/N,'p_prefix_o_ge':ct['prefix_o_ge']/N,'rate_pair_first_word_exact':ct['pair_first_word_exact']/N,'limitation':'ring assignments from locus ranges; labels incomplete excluded; no control for word length or transcription uncertainty'}
(S/'results.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
print('RING MATCHED',summary['ring_matched_control'])
