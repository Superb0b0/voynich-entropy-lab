# VOYNICH CROWNED LABELS 2026-11-12

Contains the exploratory reproducible audit of crowned zodiac figure labels.
- `crown_audit.py` input source is the bundled `ZL3b-n.txt`; verify its SHA-256.
- `all_labels.csv`: parsed labelled loci from four folios. Unknown readings omitted from null candidate set.
- `results.json`: exact permutation/enumeration results for 3 figures and fourth contested record.
- `RAPPORTO.md`: methodology and limitations.

No assertions of translation, name, encryption, or semantic meaning.
