#!/usr/bin/env python3
"""EXP-COMP-01: posthoc compositional word-family falsification.
Training-vocabulary only; test supplies row/paragraph lengths but not words.
Two predeclared generation hypotheses; no y-position intervention.
"""
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np,json,csv,hashlib,sys
HERE=Path(__file__).resolve().parent
UP=HERE/'dependencies'/'latent.py'
env={'__file__':str(UP),'__name__':'setup_only'}
source=UP.read_text()
exec(compile(source[:source.index('out={')],str(UP),'exec'),env)
folios,meta,base,val,test=env['folios'],env['meta'],env['base'],env['val'],env['test']
summary,matched_or,local_metrics=env['summary'],env['matched_or'],env['local_metrics']
assert not(set(base)&set(test) or set(val)&set(test))
SEEDS=(8101,8102,8103)
# Frozen before results are seen.  No probabilistic y-first hack.
CONFIG={
 'independent_comp':dict(family=.0,recent=.0,compose=.50,roots=0,ttl=0,persist=False),
 'folio_comp':dict(family=.23,recent=.08,compose=.50,roots=24,ttl=6,persist=True),
}

def make_training(trans):
 counts={k:Counter() for k in ('A','B','?')}
 for f in base:
  for par in folios[f]:
   for row in par:counts[meta[f]].update(row[trans])
 allv=set().union(*(set(c) for c in counts.values()))
 licensed=set();[licensed.update(zip(w,w[1:])) for w in allv]
 # Components from words in training ONLY; suffixes/prefixes counted by frequency.
 comps={}
 for cat in counts:
  if not counts[cat]: counts[cat]=sum(counts.values(),Counter())
  words=sorted(counts[cat]);ps=np.array([counts[cat][w]+.1 for w in words],float);ps/=ps.sum()
  pcs,scs=Counter(),Counter()
  for w,n in counts[cat].items():
   for l in (1,2):
    if len(w)>=l+3:pcs[w[:l]]+=n;scs[w[-l:]]+=n
  pwords=sorted(pcs);swords=sorted(scs)
  pp=np.array([pcs[x] for x in pwords],float);pp/=pp.sum()
  sp=np.array([scs[x] for x in swords],float);sp/=sp.sum()
  comps[cat]=dict(words=words,cdf=np.cumsum(ps),prefix=pwords,pcdf=np.cumsum(pp),suffix=swords,scdf=np.cumsum(sp))
 return comps,licensed,allv

def choice(rng,words,cdf):
 return words[min(len(words)-1,int(np.searchsorted(cdf,rng.random(),side='right')))]

def build_word(root,rng,bank,licensed):
 # compositional, preserving a mid-stem from a single parent and drawing reusable affixes
 # no ad-hoc edit-one nearest neighbor; 18 retries for phonotactic bigram validity.
 if len(root)<5:return root,False
 for _ in range(18):
  left=int(rng.integers(1,3));right=int(rng.integers(1,3))
  core=root[left:len(root)-right]
  if len(core)<2:continue
  p=choice(rng,bank['prefix'],bank['pcdf'])
  s=choice(rng,bank['suffix'],bank['scdf'])
  word=p+core+s
  if word!=root and 2<=len(word)<=16 and all((a,b) in licensed for a,b in zip(word,word[1:])):
   return word,True
 return root,False

def generate(trans,mode,seed,spec):
 cfg=CONFIG[mode];banks,licensed,vocab=spec;rng=np.random.default_rng(seed)
 rows=[];layout=[];stats=Counter()
 for f in sorted(test):
  bank=banks[meta[f]]
  global_pick=lambda:choice(rng,bank['words'],bank['cdf'])
  roots=[global_pick() for _ in range(cfg['roots'])]
  active=[]
  for pi,par in enumerate(folios[f]):
   if roots:
    if not active:
     ids=rng.choice(len(roots),size=4,replace=False)
     active=[(roots[int(i)],cfg['ttl']) for i in ids]
    elif cfg['persist']:
     k=int(rng.integers(len(active)));active[k]=(roots[int(rng.integers(len(roots)))],cfg['ttl'])
    else:
     ids=rng.choice(len(roots),size=4,replace=False)
     active=[(roots[int(i)],cfg['ttl']) for i in ids]
   prev=[]
   for source_row in par:
    recent=[w for r in prev[-2:] for w in r]
    row=[]
    for _ in range(len(source_row[trans])):
     u=rng.random();chan='global'
     if active and u<cfg['family']:
      root=active[int(rng.integers(len(active)))][0];chan='active'
     elif recent and u<cfg['family']+cfg['recent']:
      root=recent[int(rng.integers(len(recent)))];chan='recent'
     else:root=global_pick()
     w=root
     if rng.random()<cfg['compose']:
      w,ok=build_word(root,rng,bank,licensed)
      stats['compose_success' if ok else 'compose_failure']+=1
      if ok:chan+='_compose'
     row.append(w);stats[chan]+=1
    prev.append(row);rows.append(row);layout.append((f,pi))
    if active:
     tmp=[]
     for root,life in active:
      if life>1:tmp.append((root,life-1))
      else:tmp.append((roots[int(rng.integers(len(roots)))],cfg['ttl']))
     active=tmp
 return rows,layout,stats

def fast_metrics(rows,layout):
 # Summary from upstream with full graph edit1, plus a boundary-specific check.
 result=summary(rows); result.update(local_metrics(rows,layout));result['yo_or']=matched_or(rows)['or']
 return result

def main():
 results={'experiment':'EXP-COMP-01','status':'EXPLORATORY_POSTHOC_REUSED_HELDOUT','seed':list(SEEDS),'config':CONFIG,
 'limitations':['Same folios examined in prior work, hence NOT a blinded validation.',
 'True heldout layout and paragraph divisions provided, no real heldout words used in generation.',
 'Source vocabulary, bigram legality and affixes estimated exclusively from BASE folios.',
 'Affix recombination was proposed after seeing earlier failures: not preregistered.',
 'No explicit y/o positional reweighting, a required negative test.',
 'ZL3b and IT2a describe the same manuscript, not independent experiments.'],'reference':{},'runs':[]}
 for trans in ('zl','it'):
  spec=make_training(trans)
  ref=[list(row[trans]) for f in sorted(test) for p in folios[f] for row in p]
  lay=[(f,pi) for f in sorted(test) for pi,par in enumerate(folios[f]) for row in par]
  results['reference'][trans]=fast_metrics(ref,lay)
  print('REFERENCE',trans,{k:round(results['reference'][trans][k],4) for k in ('density','adjacency','repetition','hapax','yo_or')},flush=True)
  for mode in CONFIG:
   for seed in SEEDS:
    rows,layout,stats=generate(trans,mode,seed,spec)
    assert all(len(r)==len(q) for r,q in zip(rows,ref)) and len(rows)==len(ref)
    m=fast_metrics(rows,layout)
    m.update(transcription=trans,mode=mode,seed=seed,channels=dict(stats),novel_occurrences=sum(w not in spec[2] for row in rows for w in row),novel_types=len(set(w for row in rows for w in row if w not in spec[2])))
    results['runs'].append(m)
    print('RUN',trans,mode,seed,{k:round(m[k],4) for k in ('density','adjacency','repetition','hapax','yo_or')},flush=True)
 (HERE/'results.json').write_text(json.dumps(results,indent=2,ensure_ascii=False))
 cols=['transcription','mode','seed','density','adjacency','repetition','hapax','edit1_between_adjacent_rows','jaccard_within','repetition_within','jaccard_cross','repetition_cross','yo_or','novel_occurrences','novel_types','tokens','types']
 with (HERE/'runs.csv').open('w',newline='') as fh:
  out=csv.DictWriter(fh,fieldnames=cols);out.writeheader();out.writerows([{c:x.get(c) for c in cols} for x in results['runs']])
 print('FINISHED',len(results['runs']),flush=True)
if __name__=='__main__': main()
