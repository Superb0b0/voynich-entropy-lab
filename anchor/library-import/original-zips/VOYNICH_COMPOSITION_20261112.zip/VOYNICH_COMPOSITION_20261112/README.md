# EXP-COMP-01

Eseguire `python composition.py` seguito da `python edit_position.py` in questa cartella. Requisito: Python 3, NumPy. La cartella `dependencies` è una copia portabile degli input e del codice precedente. Non leggere le parole TEST nel codice generativo: sono usate soltanto per shape e valutazione. La suddivisione dei folii è quella preesistente, non cieca.

Risultati: `results.json`, `runs.csv`, `edit_positions.json`, `edit_positions.csv`. Rapporto: `RAPPORTO.md`. Controlli di integrità: `SHA256SUMS.txt`.
