# EXP-COMP-01 | Generazione composizionale e falsificazione delle famiglie morfologiche

**Data:** 12 novembre 2026. **Regime:** esclusivamente ESPLORATIVO, post-hoc su folii già analizzati. **Gate globale: FAIL (0/12).**

## Domanda

La ricombinazione di componenti grafiche di parole viste in addestramento (prefisso, nucleo interno, suffisso) può riprodurre contemporaneamente densità, hapax, continuità lessicale e vicinanza grafica del Voynich?

## Metodo

- 2 trascrizioni dello stesso manoscritto (ZL3b e Takahashi IT2a), identica divisione BASE/VAL/TEST del generatore precedente. Le parole TEST sono nascoste al generatore; **lunghezza delle righe, confini di paragrafo e classe Currier del folio sono forniti**. I folii TEST erano già stati esaminati in esperimenti precedenti: non sono un nuovo controllo cieco.

- In addestramento sono appresi vocabolario, frequenze dei singoli e doppi caratteri, prefissi/suffissi di 1–2 caratteri; la composizione mantiene un nucleo di almeno due lettere di una parola origine e prova fino a 18 giunzioni autorizzate dai bigrammi dell’addestramento. Le nuove forme possono coincidere con forme già viste, non sono costrette a essere OOV.

- Modello A (`independent_comp`): 50% tentativi di composizione su parole estratte dal repertorio globale Currier. Modello B (`folio_comp`): 23% selezione da quattro radici attive (24 disponibili per folio, durata 6 righe), 8% da righe recenti; le famiglie sopravvivono in parte ai confini, e 50% tentativi di composizione. Le probabilità sono dichiarate nel codice.

- 3 semi fissi (8101–8103), per ciascuna combinazione di 2 modelli e 2 trascrizioni: 12 generazioni complete. **Nessuna regola iniziale y/o inserita**. Nessuna ricerca a griglia sui risultati.

## Risultati

| Trascrizione | Modello | Densità | Adiacenza | Ripetizione | Hapax | Edit1 tra righe | OR y/o |
|---|---|---:|---:|---:|---:|---:|---:|
| zl | **Voynich** | 0.9468 | 0.0271 | 0.0569 | 0.7157 | 0.2060 | 3.5998 |
| zl | independent_comp | 0.9016 | 0.0110 | 0.0221 | 0.7680 | 0.1108 | 0.9216 |
| zl | folio_comp | 0.8981 | 0.0439 | 0.0894 | 0.7522 | 0.1154 | 1.0596 |
| it | **Voynich** | 0.9632 | 0.0290 | 0.0592 | 0.6965 | 0.2162 | 3.2024 |
| it | independent_comp | 0.9237 | 0.0109 | 0.0217 | 0.7635 | 0.1139 | 1.0268 |
| it | folio_comp | 0.9219 | 0.0430 | 0.0896 | 0.7434 | 0.1137 | 1.2237 |

I quattro intervalli globali ereditati (`density` 0,91–0,96, `adjacency` 0,02–0,04, `repetition` 0,045–0,07, `hapax` 0,65–0,75) **non sono superati simultaneamente in nessuna replica**. Sono intervalli storici dell’analisi precedente, non calibrati su questo sottoinsieme di controllo, e pertanto sono soltanto un segnale diagnostico. L’OR y/o va confrontato con il riferimento della stessa trascrizione e dello stesso campione.

## Controllo indipendente: dove si trova la modifica grafica?

Per ogni coppia distinta di parole a distanza di Levenshtein esattamente 1 in righe consecutive dello **stesso paragrafo**, si registra se la modifica cade nei primi due caratteri, negli ultimi due oppure nella parte interna. Nei vocaboli corti, eventuali sovrapposizioni sono attribuite per convenzione ai primi due caratteri. Queste sono frequenze descrittive, non p-value.

| Trascrizione | Modello | Coppie edit1 per coppia di righe | Modifiche interne | Modifiche iniziali |
|---|---|---:|---:|---:|
| zl | REAL | 1.881 | 18.461% | 54.992% |
| zl | independent_comp | 0.930 | 9.481% | 62.597% |
| zl | folio_comp | 0.927 | 10.022% | 62.202% |
| it | REAL | 1.988 | 18.997% | 53.087% |
| it | independent_comp | 0.953 | 9.757% | 59.685% |
| it | folio_comp | 0.889 | 9.915% | 59.278% |

Il generatore produce meno coppie graficamente vicine e concentra troppo le differenze nelle estremità delle parole. Non basta cambiare il nucleo del vocabolario: serve un controllo sulle trasformazioni effettive. Il risultato **non** identifica una morfologia linguistica e potrebbe dipendere in parte dalla distribuzione delle lunghezze, che qui non è controllata per la composizione delle forme.

## Limiti e decisione

1. Selezione dei meccanismi post-hoc; lo stesso TEST è stato più volte esaminato. Nessuna indipendenza sperimentale delle due trascrizioni.
2. L’informazione sul layout reale è fornita; questo esperimento non genera la geometria.
3. Ricombinazione grafica non equivale a morfologia storica; nessuna semantica, traduzione o chiave del cifrario.
4. Il modello non riproduce l’OR y/o senza regola aggiunta e non supera il gate multivariato.
5. Le differenze di posizione delle modifiche non sono corrette per lunghezza/parole candidate: sono descrittive, da confermare con stratificazione.

**Decisione:** scartare la composizione indipendente come meccanismo completo; mantenere i generatori come controlli negativi. Priorità futura: test predittivo su trasformazioni interne, controllato per lunghezza e frequenza, con un campione nuovo o una valida procedura di cross-validation annidata. Stato RC1.4.2 invariato: `CLOSED_PENDING_VALIDATION`.
