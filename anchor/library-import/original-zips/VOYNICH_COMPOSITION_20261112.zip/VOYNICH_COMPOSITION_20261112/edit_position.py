#!/usr/bin/env python3
"""Independent diagnostic on original and generated adjacent-line Levenshtein-1 edits.
Predeclared categories: beginning=first 2 chars, end=last 2 chars, interior=all else.
Each distinct adjacent-row pair counted once; a pair can have overlapping categories
for short words.  Observed/synthetic same convention. No model-fitting.
"""
import json,csv
from pathlib import Path
from collections import Counter
from composition import folios,test,make_training,generate,SEEDS
BASE=Path(__file__).resolve().parent

def one_edit(a,b):
 # Return ('sub'/'insdel', position in longer string); different words only.
 if a==b or abs(len(a)-len(b))>1:return None
 if len(a)==len(b):
  dif=[i for i,(x,y) in enumerate(zip(a,b)) if x!=y]
  return ('sub',dif[0],len(a)) if len(dif)==1 else None
 short,long=sorted((a,b),key=len)
 for i in range(len(long)):
  if long[:i]+long[i+1:]==short:return 'insdel',i,len(long)
 return None

def diag(rows,layout):
 C=Counter();N=0;rowpairs=0
 for j in range(1,len(rows)):
  if layout[j]!=layout[j-1]:continue
  rowpairs+=1;prev=set(rows[j-1]);nxt=set(rows[j]);
  for a in prev:
   for b in nxt:
    e=one_edit(a,b)
    if e is None:continue
    op,pos,L=e;C[op]+=1;N+=1
    if pos<2:C['first2']+=1
    elif pos>=L-2:C['last2']+=1
    else:C['middle']+=1
 return dict(N=N,compared_rowpairs=rowpairs,first2=C['first2']/N if N else None,last2=C['last2']/N if N else None,middle=C['middle']/N if N else None,substitution=C['sub']/N if N else None,insertion_deletion=C['insdel']/N if N else None,edits_per_rowpair=N/rowpairs if rowpairs else None)

if __name__=='__main__':
 out={'experiment':'EXP-COMP-EDIT-POS-01','status':'EXPLORATORY','definitions':'Distinct edit1 pairs in consecutive lines of same paragraph; location relative to longer string; first two, last two, or middle; if short word categories overlap priority to first2; no model fitting.','rows':[]}
 for t in ('zl','it'):
  layout=[(f,pi) for f in sorted(test) for pi,par in enumerate(folios[f]) for row in par]
  ref=[list(row[t]) for f in sorted(test) for par in folios[f] for row in par]
  d=diag(ref,layout);out['rows'].append(dict(transcription=t,mode='REAL',seed='real',**d));print(t,'REAL',d,flush=True)
  spec=make_training(t)
  for mode in ('independent_comp','folio_comp'):
   for seed in SEEDS:
    rr,ll,_=generate(t,mode,seed,spec)
    x=diag(rr,ll);out['rows'].append(dict(transcription=t,mode=mode,seed=seed,**x))
    print(t,mode,seed,{k:round(v,4) if isinstance(v,float) else v for k,v in x.items()},flush=True)
 (BASE/'edit_positions.json').write_text(json.dumps(out,indent=2))
 with (BASE/'edit_positions.csv').open('w',newline='') as fh:
  writer=csv.DictWriter(fh,fieldnames=list(out['rows'][0]));writer.writeheader();writer.writerows(out['rows'])
