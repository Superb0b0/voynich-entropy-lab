# VOYNICH ANCHOR-24 | Un codice reversibile non basta

**Data:** 12 novembre 2026. Ramo esplorativo separato da RC1.4.2, che rimane `CLOSED_PENDING_VALIDATION`.

## Domanda

Un cifrario verboso e omofonico reversibile, definito senza consultare il Voynich, riproduce automaticamente il testo Voynich? E una breve porzione di testo noto permette di recuperare il testo riservato?

## Contratto del test

- Testo latino storico: Borg 0010r (edizione del corpus di controllo già utilizzata in ANCHOR-23); 59 parole, escluse annotazioni tra parentesi e parole di una lettera.
- Addestramento: prime 35 parole; riserva: ultime 24 parole, non usate per l'apprendimento delle sostituzioni osservate.
- Codifica giocattolo prefix-free: lettere comuni ricevono un codice di un glifo; le altre sequenze usano `x`, `y` o `z` come prefisso di fuga e il glifo seguente. Ogni lettera ha un codice lungo e le lettere meno comuni hanno due codici lunghi omofonici. Scelte pseudocasuali, seme 20261112.
- L'encoder **conosce la chiave generata**. Il decoder con chiave completa ricostruisce sempre il testo. In una seconda prova il decoder apprende soltanto le corrispondenze *viste nel frammento noto*, conservando come `?` quelle mai osservate.
- Il sistema NON è una riproduzione di una tecnica medievale attestata: è un controllo ingegneristico con cifratura senza perdita di informazione.

## Decodifica (senza leggere il testo di verifica durante l'apprendimento)

- Roundtrip con chiave completa su addestramento e riserva: **PASS/PASS**.
- Codici osservati nell'addestramento: **36/52**.
- Caratteri riservati riconosciuti attraverso la sola chiave parziale: **116/118 (98.3%)**; ignoti: **2**.
- Parole riservate completamente recuperate: **22/24**.

## Confronto strutturale (descrittivo)

| Metrica | Borg originale test | Codice verboso test | Codice fisso a 2 caratteri test | ZL3b intero | IT2a intero |
|---|---:|---:|---:|---:|---:|
| mean_length | 4.9167 | 7.8333 | 9.8333 | 5.015 | 5.1051 |
| short_le3 | 0.5417 | 0.25 | 0.0 | 0.1823 | 0.1583 |
| double | 0.125 | 0.0833 | 0.4583 | 0.2552 | 0.2579 |
| odd_length | 0.5 | 0.75 | 0.0 | 0.4895 | 0.4973 |
| mean_unique_word_ratio | 0.9167 | 0.9583 | 0.9167 | 0.1941 | 0.2031 |

## Verdetto

La **reversibilità da sola** è un vincolo troppo debole: costruire un codice decifrabile non produce necessariamente il profilo osservato del Voynich. La chiave recuperata da un piccolo frammento noto è generalmente **incompleta quando esistono omofoni non osservati**. Questa è una difficoltà concreta di identificabilità, non un problema del decoder.

Il confronto usa un campione latino troppo breve per test inferenziali sulle statistiche: le percentuali NON sono p-value. Il sistema ha confini di parola noti e un prefisso di fuga visibile, che semplificano la decodifica rispetto a qualsiasi ipotetico cifrario Voynich. Non è una confutazione dei cifrari verbosi in generale.

### Una proposta falsificabile da qui in avanti

Bisogna valutare **simultaneamente** il realismo del testo cifrato *e* la possibilità di recuperare il plaintext senza conoscere la chiave. Prossimo riferimento da replicare criticamente: Naibbe di Greshko (2025, Cryptologia DOI 10.1080/01611194.2025.2566408), che riproduce molte statistiche Voynich ma non fornisce la chiave del manoscritto. Nessun ulteriore giro di corrispondenze botaniche prima di questa prova.

## Integrità

- borg: `0d46338eb517b58c70169b1a12653838cdfce1394645bc24f6f52820be27da13`
- ZL3b: `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc`
- IT2a: `7f27a8b0feed8f6de0a99900df6bf912dd1d295c38e5f830bac8b41c3f536fb5`
