from pathlib import Path
import re,hashlib,random,json,collections,statistics,zipfile,math
BASE=Path('/mnt/data/VOYNICH_ANCHOR_24_20261112');BASE.mkdir(exist_ok=True)
BORG=Path('/mnt/data/VOYNICH_ANCHOR_12_20261112/inputs/borg_0010r_plaintext_extracted.txt')
ZL=Path('/mnt/data/files/ZL3b-n.txt'); IT=Path('/mnt/data/files/IT2a-n.txt')
seed=20261112
# Freeze design: exact lowercase A-Z, split first 60% of words as known plaintext, remainder reserved.
raw=re.sub(r'\[[^\]]*\]',' ',BORG.read_text().lower()); plain=re.findall(r'\b[a-z]{2,}\b',raw)
split=int(len(plain)*.60); train=plain[:split];test=plain[split:]
train_counts=collections.Counter(''.join(train))
# Fixed synthetic symbol inventory (not a transcription of historic cryptographic alphabet).
# 10 common letters have single-glyph codes, all 26 letters have a long code;
# the 16 others have two long homophones.
EVA='abcdefghijklmnopqrstuvwxyz'
most=[x for x,_ in sorted(train_counts.items(),key=lambda kv:(-kv[1],kv[0]))][:10]
if len(most)<10: most += [x for x in 'abcdefghijklmnopqrstuvwxyz' if x not in most][:10-len(most)]
single={c:EVA[i] for i,c in enumerate(most)}
markers='xyz'; payload=[c for c in EVA if c not in markers]
longcodes=[p+s for p in markers for s in payload]
charmap={c:([single[c]] if c in single else []) for c in 'abcdefghijklmnopqrstuvwxyz'}
k=0
for c in 'abcdefghijklmnopqrstuvwxyz':charmap[c].append(longcodes[k]);k+=1
for c in 'abcdefghijklmnopqrstuvwxyz':
 if c not in single:charmap[c].append(longcodes[k]);k+=1
code_to_plain={code:c for c, variants in charmap.items() for code in variants}
assert len(code_to_plain)==sum(len(v) for v in charmap.values())
assert set(markers).isdisjoint(set(single.values()))

def encode(words,rng):
    return [''.join(rng.choice(charmap[c]) for c in w) for w in words]

def parse_codes(s):
    out=[];i=0
    while i<len(s):
        if s[i] in markers:
            if i+1>=len(s): raise ValueError('Truncated escaped codeword')
            out.append(s[i:i+2]);i+=2
        else:out.append(s[i]);i+=1
    return out

def decode_full(words):return [''.join(code_to_plain[p] for p in parse_codes(w)) for w in words]
rng=random.Random(seed)
train_enc=encode(train,rng);test_enc=encode(test,rng)
assert decode_full(train_enc)==train and decode_full(test_enc)==test
# Infer only mappings observed in known plaintext/ciphertext pair, with boundaries known, not full key.
learned={}
for a,b in zip(train,train_enc):
    codes=parse_codes(b)
    assert len(codes)==len(a)
    for code,c in zip(codes,a):
        if code in learned:assert learned[code]==c
        else: learned[code]=c
pred=[];unknown=0;correct=0;total=0
for w in test_enc:
    codes=parse_codes(w);d=''.join(learned.get(code,'?') for code in codes)
    pred.append(d)
    total+=len(w) if False else len(codes)
    unknown += d.count('?')
for p,t in zip(pred,test):correct+=sum(a==b for a,b in zip(p,t))

def feat(words):
  return {'n':len(words),'mean_length':round(statistics.mean(len(w) for w in words),4),
          'short_le3':round(sum(len(w)<=3 for w in words)/len(words),4),
          'double':round(sum(any(w[i]==w[i+1] for i in range(len(w)-1)) for w in words)/len(words),4),
          'mean_unique_word_ratio':round(len(set(words))/len(words),4),
          'odd_length':round(sum(len(w)%2!=0 for w in words)/len(words),4)}
def extract_corpus(path):
    out=[]
    for line in path.read_text().splitlines():
        if not re.match(r'^<[^>]+,\+P\d+>',line):continue
        s=line.split('>',1)[1].split('<!',1)[0]
        s=re.sub(r'\[[^\]]*\]',' ',s)
        s=re.sub(r'<[^>]*>',' ',s)
        out.extend(re.findall(r'(?<![a-z])[a-z]{2,}(?![a-z])',s))
    return out
vzl=extract_corpus(ZL);vit=extract_corpus(IT)
# Baseline quick reversible method: 2-char 1:1 fixed code, preserves boundaries but doubles length.
fixed_codes={c: 'abcdefghijklmnop'[i//16]+ 'abcdefghijklmnop'[i%16] for i,c in enumerate('abcdefghijklmnopqrstuvwxyz')}
fixed_test=[''.join(fixed_codes[c] for c in w) for w in test]
# Paired codebook not present in report: only derived coverage statistics to prevent accidental answer-key usage.
result={'title':'ANCHOR-24: controlled reversible verbose homophonic toy vs Voynich','seed':seed,
 'input_sha256':{'borg':hashlib.sha256(BORG.read_bytes()).hexdigest(),'ZL3b':hashlib.sha256(ZL.read_bytes()).hexdigest(),'IT2a':hashlib.sha256(IT.read_bytes()).hexdigest()},
 'design':{'plain_words':len(plain),'train_words':len(train),'heldout_words':len(test),'train_selection':'first 60% contiguous words','code':'13? no: 10 short codes for most frequent train letters, every letter has one escaped two-character form, remaining 16 have one more escaped homophone; three escape glyphs x/y/z; spaces kept; no Voynich-informed fitting','length_two_comparator':'simple fixed 2-character code per Latin letter'},
 'decoding':{'full_key_roundtrip_train':decode_full(train_enc)==train,'full_key_roundtrip_test':decode_full(test_enc)==test,'learned_codewords':len(learned),'all_possible_codewords':len(code_to_plain),'heldout_characters':total,'correct_characters_from_crib':correct,'unknown_characters_from_crib':unknown,'accuracy_with_unknown_as_wrong':round(correct/total,4),'word_exact':sum(a==b for a,b in zip(pred,test)),'heldout_word_count':len(test)},
 'features':{'plain_train':feat(train),'plain_test':feat(test),'verbose_holdout':feat(test_enc),'fixed2_holdout':feat(fixed_test),'Voynich_ZL3b':feat(vzl),'Voynich_IT2a':feat(vit)},
 'limits':['Synthetic codebook, NOT an attested medieval or Naibbe implementation','Tiny 59-word source control; no population-level inference','Known ciphertext boundaries, known codeword segmentation; blind to held-out plaintext but NOT blind to cipher family','Using different languages or homophone rates changes output; no optimizing to target Voynich','No evidence that actual Voynich encodes Latin, or that its spaces delimit original words']}
(BASE/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(BASE/'heldout_ciphertext.txt').write_text(' '.join(test_enc)+'\n')
(BASE/'crib_partial_decoding.txt').write_text(' '.join(pred)+'\n')
(BASE/'run_anchor24.py').write_text(Path(__file__).read_text())
report=f'''# VOYNICH ANCHOR-24 | Un codice reversibile non basta

**Data:** 12 novembre 2026. Ramo esplorativo separato da RC1.4.2, che rimane `CLOSED_PENDING_VALIDATION`.

## Domanda

Un cifrario verboso e omofonico reversibile, definito senza consultare il Voynich, riproduce automaticamente il testo Voynich? E una breve porzione di testo noto permette di recuperare il testo riservato?

## Contratto del test

- Testo latino storico: Borg 0010r (edizione del corpus di controllo già utilizzata in ANCHOR-23); {len(plain)} parole, escluse annotazioni tra parentesi e parole di una lettera.
- Addestramento: prime {len(train)} parole; riserva: ultime {len(test)} parole, non usate per l'apprendimento delle sostituzioni osservate.
- Codifica giocattolo prefix-free: lettere comuni ricevono un codice di un glifo; le altre sequenze usano `x`, `y` o `z` come prefisso di fuga e il glifo seguente. Ogni lettera ha un codice lungo e le lettere meno comuni hanno due codici lunghi omofonici. Scelte pseudocasuali, seme {seed}.
- L'encoder **conosce la chiave generata**. Il decoder con chiave completa ricostruisce sempre il testo. In una seconda prova il decoder apprende soltanto le corrispondenze *viste nel frammento noto*, conservando come `?` quelle mai osservate.
- Il sistema NON è una riproduzione di una tecnica medievale attestata: è un controllo ingegneristico con cifratura senza perdita di informazione.

## Decodifica (senza leggere il testo di verifica durante l'apprendimento)

- Roundtrip con chiave completa su addestramento e riserva: **PASS/PASS**.
- Codici osservati nell'addestramento: **{len(learned)}/{len(code_to_plain)}**.
- Caratteri riservati riconosciuti attraverso la sola chiave parziale: **{correct}/{total} ({correct/total:.1%})**; ignoti: **{unknown}**.
- Parole riservate completamente recuperate: **{result['decoding']['word_exact']}/{len(test)}**.

## Confronto strutturale (descrittivo)

| Metrica | Borg originale test | Codice verboso test | Codice fisso a 2 caratteri test | ZL3b intero | IT2a intero |
|---|---:|---:|---:|---:|---:|
'''
for metric in ['mean_length','short_le3','double','odd_length','mean_unique_word_ratio']:
    report+='| '+metric+' | '+' | '.join(str(result['features'][k][metric]) for k in ['plain_test','verbose_holdout','fixed2_holdout','Voynich_ZL3b','Voynich_IT2a'])+' |\n'
report+='''
## Verdetto

La **reversibilità da sola** è un vincolo troppo debole: costruire un codice decifrabile non produce necessariamente il profilo osservato del Voynich. La chiave recuperata da un piccolo frammento noto è generalmente **incompleta quando esistono omofoni non osservati**. Questa è una difficoltà concreta di identificabilità, non un problema del decoder.

Il confronto usa un campione latino troppo breve per test inferenziali sulle statistiche: le percentuali NON sono p-value. Il sistema ha confini di parola noti e un prefisso di fuga visibile, che semplificano la decodifica rispetto a qualsiasi ipotetico cifrario Voynich. Non è una confutazione dei cifrari verbosi in generale.

### Una proposta falsificabile da qui in avanti

Bisogna valutare **simultaneamente** il realismo del testo cifrato *e* la possibilità di recuperare il plaintext senza conoscere la chiave. Prossimo riferimento da replicare criticamente: Naibbe di Greshko (2025, Cryptologia DOI 10.1080/01611194.2025.2566408), che riproduce molte statistiche Voynich ma non fornisce la chiave del manoscritto. Nessun ulteriore giro di corrispondenze botaniche prima di questa prova.

## Integrità
'''
for name,hashv in result['input_sha256'].items():report+=f'\n- {name}: `{hashv}`'
(BASE/'REPORT_IT.md').write_text(report+'\n')
with zipfile.ZipFile('/mnt/data/VOYNICH_ANCHOR_24_20261112.zip','w',zipfile.ZIP_DEFLATED) as z:
  for f in sorted(BASE.iterdir()):z.write(f,arcname=f.name)
print(json.dumps({'words':(len(train),len(test)),'decoding':result['decoding'],'features':result['features']},indent=2))
