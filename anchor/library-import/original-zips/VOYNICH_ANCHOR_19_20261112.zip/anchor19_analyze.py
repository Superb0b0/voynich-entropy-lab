#!/usr/bin/env python3
"""ANCHOR-19: descriptive extraction from Stolfi inventory, no image-recognition claims."""
import csv,hashlib,itertools,json
from pathlib import Path
from scipy.stats import kendalltau
BASE=Path('/mnt/data')
source=BASE/'VOYNICH_ANCHOR_15_20261112/REGISTER_VISUAL_MATCHES.csv'
rows=list(csv.DictReader(source.open(encoding='utf-8-sig',newline='')))
# Morphological features transcribed from Stolfi's published descriptions (NOT image annotations)
features={
'f1v':('root','leaves'),
'f18v':('root',),
'f19r':('root','leaves'),
'f23r':('root',),
'f37v':('root','leaves'),
'f32v':('root','leaves','flower'),
'f47v':('root','leaves'),
'f48r':('root','leaves'),
'f48v':('root','leaves'),
}
assert len(rows)==9 and {r['folio_erbario'] for r in rows}==set(features)
root=sum('root' in x for x in features.values()); leaves=sum('leaves' in x for x in features.values()); flower=sum('flower' in x for x in features.values())
# Diagram reading-order assumption: top-to-bottom rows then left-to-right columns.
selected=sorted((r for r in rows if r['frammento_farmaceutico']=='f102r2'),key=lambda r: int(r['folio_erbario'][1:-1]))
def order_at(r):
 a,b=map(int,r['posizione_riga_colonna'].split(':'));return (a,b)
ph_order=sorted(selected,key=order_at)
rank={r['folio_erbario']:i+1 for i,r in enumerate(selected)}
permutation=tuple(rank[r['folio_erbario']] for r in ph_order)
tau=float(kendalltau(range(1,5),permutation).statistic)
null=[float(kendalltau(range(1,5),p).statistic) for p in itertools.permutations(range(1,5))]
p_two=sum(abs(v)>=abs(tau)-1e-10 for v in null)/len(null)
p_forward=sum(v>=tau-1e-10 for v in null)/len(null)
p_reverse=sum(v<=tau+1e-10 for v in null)/len(null)
result={'experiment':'ANCHOR-19','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'n_documented_matches':len(rows),'matched_components_count':{'root':root,'leaves':leaves,'flower':flower},'caution':'These are components documented as matching between illustrations, not counts of botanical components present in originals. Cannot infer copying selection from these proportions.','panel':'f102r2','n_ordered_pairs':4,'herbal_order':[r['folio_erbario'] for r in selected],'pharma_order':[r['folio_erbario'] for r in ph_order],'pharma_rank_sequence':permutation,'kendall_tau':tau,'exact_permutation_null_size':len(null),'p_two_sided':p_two,'p_one_sided_forward':p_forward,'p_one_sided_reverse':p_reverse,'limitations':['only four matches in panel','not a random sample','row/column direction and source selection may be post hoc','matched illustrated component is not evidence of selective omission']}
out=BASE/'ANCHOR_19';out.mkdir(exist_ok=True)
(out/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
with (out/'component_inventory.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.writer(f);w.writerow(['herbal_folio','pharma_panel','row_col','documented_matching_root','documented_matching_leaves','documented_matching_flower']);
 for r in rows:w.writerow([r['folio_erbario'],r['frammento_farmaceutico'],r['posizione_riga_colonna'],int('root' in features[r['folio_erbario']]),int('leaves' in features[r['folio_erbario']]),int('flower' in features[r['folio_erbario']])])
print(json.dumps(result,ensure_ascii=False,indent=2))
