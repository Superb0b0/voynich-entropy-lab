# ANCHOR-19 | Ordine e componenti nelle copie botanico-farmaceutiche

Data: 12 novembre 2026. **Esplorativo, non è una decifrazione.** Nessuna modifica agli artefatti RC1.4.2 (`CLOSED_PENDING_VALIDATION`).

## Domande
1. Le copie nel pannello f102r2 conservano l'ordine dei fogli botanici?
2. Quali componenti sono documentate come *corrispondenti* negli esemplari botanici e nei relativi frammenti farmaceutici?

## Fonti
- Registro storico di nove accostamenti di Jorge Stolfi: https://www.ic.unicamp.br/en/~stolfi/EXPORT/voynich/00-06-07-word-grammar/Notes/064/work/projects/voynich/projects/programs/c/big/big/projects/voynich/Notes/102/work/Notes/091/report/report_091.html
- Registro locale dell'esperimento ANCHOR-15, `REGISTER_VISUAL_MATCHES.csv`, SHA-256: `85dcc54c99804e5f2066ad51bdf205c224f788f25211f9c9c30f22f95a5f099e`.
- Contesto storico alchemico: https://philipneal.net/voynichsources/alchemical/
- Discussione di f35v: https://www.voynich.nu/q05/

## Risultato 1: test esatto sull'ordine (n=4)
Con ordinamento del testo farmaceutico dall'alto al basso e da sinistra a destra, i quattro casi di f102r2 sono `f47v,f32v,f18v,f23r`, mentre nei fogli botanici il loro ordine è `f18v,f23r,f32v,f47v`. Kendall tau = **-2/3**. Distribuzione nulla enumerata sulle **24** permutazioni: **p due code = 1/3**, p per inversione = 1/6, p per ordine crescente = 23/24. Non emerge supporto per una copia diretta in ordine crescente, né prova sufficiente di un'inversione.

Questo test è descrittivo ed esplorativo: i quattro elementi non sono un campione casuale e la selezione delle corrispondenze è stata fatta originariamente dopo aver visto i disegni.

## Risultato 2: componenti documentate come corrispondenti (n=9)
Nelle descrizioni pubblicate delle nove coppie le **radici** sono fra le parti corrispondenti in **9/9**, le **foglie** in **7/9** e i **fiori** in **1/9**. Nella coppia f32v/f102r2 la descrizione dell'accostamento floreale stesso presenta una cautela sulla possibile aggiunta successiva.

**Punto essenziale:** i numeratori sono la presenza fra le *parti che corrispondono* secondo l'inventario, non fra le parti effettivamente presenti nei nove originali. Non abbiamo i denominatori (quanti originali possedevano fiori, quante foglie furono deliberatamente omesse), quindi non possiamo concludere che il copista selezionasse sistematicamente radici o che scartasse fiori.

La preminenza visiva delle radici è una **pista per un esperimento cieco**, non una dimostrazione causale.

## Prossimo test falsificabile
Per ciascuna coppia, annotare indipendentemente il contenuto della pianta originale e della copia: `root_present`, `leaves_present`, `flowers_present`, `fruit_present`, `root_shape_distinctive`, `orientation`, `extra_features`. Calcolare la ritenzione condizionata alla presenza nel disegno originale. Misurare l'accordo fra due annotatori ciechi all'ipotesi. Confrontare con un insieme di immagini farmaceutiche di controllo non abbinate, per stimare l'effetto di selezione del catalogo. Soltanto dopo passare alla prova delle etichette.

## Limiti e decisione
Nessuna nuova parola decifrata. Nessuna evidenza numerica per una copia sequenziale semplice. È documentata una frequenza elevata di radici fra i dettagli che fanno riconoscere gli accostamenti già scelti; è soggetta a bias di selezione. La parentela iconografica f35v / `edera nigra` resta ipotesi, e i test non autorizzano a tradurre la pagina.

`anchor19_analyze.py` legge soltanto il registro di ANCHOR-15, verifica nove identificativi, calcola le 24 permutazioni e produce `results.json` e `component_inventory.csv`.
