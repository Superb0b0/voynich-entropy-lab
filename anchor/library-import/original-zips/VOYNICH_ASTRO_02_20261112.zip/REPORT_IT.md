# ASTRO-02 · Pannelli dello zodiaco e identità del mese
12 novembre 2026 | Ramo astronomico indipendente, esplorativo. RC1.4.2 invariato e congelato.

## Domanda
Le due tavole che illustrano l'Ariete (f70v1 e f71r) e quelle che illustrano il Toro (f71v e f72r1) sono più simili fra loro nella distribuzione delle sequenze EVA delle etichette delle figure rispetto agli abbinamenti incrociati? Il confronto è ancorato ai segni identificabili *dalle immagini* e ai nomi dei mesi romanzi aggiunti successivamente, non a letture immaginate delle etichette.

## Campione e regole
Analizzate le 12 tavole zodiacali conservate, nell'ordine dei segni da Pesci a Sagittario. Le quattro tavole Ariete/Toro hanno 15 etichette per tavola: 60 etichette complessive. Altre tavole hanno normalmente 30 etichette (Gemelli ne ha 29 nella trascrizione). Sono state estratte esclusivamente le righe etichettate @Lz/&Lz dal testo IVTFF ZL3b. L'analisi non interpreta il significato delle parole. Le 15 etichette per tavola sono concatenate in un documento testuale; si misura la similarità coseno fra vettori TF-IDF di bigrammi di caratteri. Controllo di sensibilità con trigrammi.

## Risultati del test esatto, limitato alle quattro tavole di uguale numerosità

| Coppie di pannelli, punteggio medio | Bigrammi | Trigrammi |
| --- | ---: | ---: |
| Ariete/Ariete + Toro/Toro (vero) | 0,7781 | 0,4696 |
| Primo abbinamento incrociato | 0,7025 | 0,4102 |
| Secondo abbinamento incrociato | 0,6936 | 0,3617 |

Il raggruppamento corretto ha il massimo fra le 3 partizioni possibili. Esattamente **p unilaterale = 1/3**, non statisticamente convincente. Le tavole vicine nel manoscritto tendono anche a essere più simili e questo crea un possibile confondente (pagina, mano e posizione). Il confronto non separa l'effetto del segno zodiacale da questi fattori.

## Cosa sappiamo indipendentemente
Un repertorio documenta i nomi di mesi in grafia romanza **aggiunti da una mano posteriore** presso i segni: *mars* per Pesci, *aberil* per Ariete, *may* per Toro, ecc. Questa è un'ancora per le immagini e il calendario, NON una traduzione coeva delle etichette Voynich. Le ripetizioni dei mesi su Ariete e Toro non sono prove di una coppia di sinonimi in EVA.

## Verdetto
**DEBOLE, NON RISOLUTIVO**. La direzione osservata è compatibile con una componente di contesto mensile nelle etichette, ma anche con copie simili per mano o prossimità e con uno sfondo statistico comune del 'labelese'. Non abbiamo imparato una sola parola Voynich. Nessuna attribuzione semantica individuale. Nessuna inferenza sullo zodiaco completo perché i pannelli Acquario e Capricorno sono mancanti.

## Fonti esterne
- René Zandbergen, *Voynich MS · Writing System*, tabella dei nomi dei mesi, https://www.voynich.nu/writing.html
- René Zandbergen, *Voynich MS · Illustrations*, struttura dei segni, https://www.voynich.nu/illustr.html
- Corpus ZL3b-n.txt, fonte originale EVMT; SHA-256 nel file `results.json`.

## Riproduzione
`python run.py /path/to/ZL3b-n.txt --output results.json`
Dipendenze: numpy, scikit-learn. Il parser legge il corpus in sola lettura; non modifica gli artefatti congelati.
