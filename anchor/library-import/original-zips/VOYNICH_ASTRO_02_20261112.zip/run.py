#!/usr/bin/env python3
"""ASTRO-02. Read-only IVTFF analysis of 12 zodiac panels.
Uses TF-IDF character ngrams, not decoded readings. Reproducible with sklearn/numpy.
"""
import argparse,collections,hashlib,itertools,json,re
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
PANELS=['f70v2','f70v1','f71r','f71v','f72r1','f72r2','f72r3','f72v3','f72v2','f72v1','f73r','f73v']
SIGNS=['Pisces','Aries','Aries','Taurus','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius']
RX=re.compile(r'^<((?:f70v[12]|f71[rv]|f72[rv][123]|f73[rv]))\.(\d+),([^>]+)>\s+(?:<![^>]*>)?\s*(.*)')

def main():
 ap=argparse.ArgumentParser();ap.add_argument('corpus');ap.add_argument('--output',default='results.json'); args=ap.parse_args()
 d=collections.defaultdict(list)
 data=open(args.corpus,'rb').read();raw=data.decode('utf-8-sig')
 for line in raw.splitlines():
  m=RX.match(line)
  if not m:continue
  folio,_,type_,body=m.groups()
  if 'Lz' not in type_:continue
  body=re.sub(r'\{[^}]+\}','',body)
  body=re.sub(r'\[([^]:]+):[^]]+\]',r'\1',body)
  # Remove editorial uncertainty punctuation (question mark etc), preserve actual EVA tokens.
  words=re.findall(r'[a-z]+',body)
  if words:d[folio].append(words)
 texts=[' '.join(' '.join(ws) for ws in d[f]) for f in PANELS]
 out={'method':'cosine similarity, per-panel aggregate nymph labels; TF-IDF char ngrams',
      'corpus_sha256':hashlib.sha256(data).hexdigest(),
      'panels':[{'folio':f,'sign':s,'nymph_label_lines':len(d[f])} for f,s in zip(PANELS,SIGNS)],
      'tests':{}}
 actual=[(1,2),(3,4)]
 possible_partitions=[[(1,2),(3,4)],[(1,3),(2,4)],[(1,4),(2,3)]]
 for n in [(2,2),(3,3)]:
  sim=cosine_similarity(TfidfVectorizer(analyzer='char',ngram_range=n).fit_transform(texts))
  scores=[float(np.mean([sim[a,b] for a,b in pairs])) for pairs in possible_partitions]
  # Restricted, exact conditional test: four equal-size panels only. 3 equiprobable partitions.
  out['tests'][str(n)]={'observed_pair_scores':{'Aries':float(sim[1,2]),'Taurus':float(sim[3,4])},
    'three_15_label_pairing_scores':scores,
    'exact_one_sided_p':sum(s >= scores[0]-1e-12 for s in scores)/len(scores),
    'rank_of_correct_pairing':1+sum(s>scores[0]+1e-12 for s in scores),
    'interpretation':'descriptive exact pairing; too few groups for a decisive inference'}
  if n==(2,2):
   ranks=sorted([(float(sim[a,b]),PANELS[a],PANELS[b]) for a in range(12) for b in range(a+1,12)],reverse=True)
   out['tests'][str(n)]['top_5_unrestricted_pairs']=ranks[:5]
 with open(args.output,'w') as f:json.dump(out,f,indent=2,ensure_ascii=False)
 print(json.dumps(out,indent=2,ensure_ascii=False))
if __name__=='__main__':main()
