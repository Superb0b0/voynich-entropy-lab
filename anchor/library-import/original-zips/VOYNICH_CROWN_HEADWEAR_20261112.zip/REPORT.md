# EXP-FIRST-WORD-07: corona e specificità delle etichette

**Stato:** esclusivamente esplorativo. Nessuna prima parola identificata. RC1.4.2 resta CLOSED_PENDING_VALIDATION.

## Fonti

La fonte di riferimento sul quire 11 (https://www.voynich.nu/q11/index.html) attesta tre ninfette coronate: Cancro f72r3, Leone f72v3, Bilancia f72v1. Le associazioni con loci sono tratte dal dossier EXP-FIRST-WORD-06, con affidabilità diversa (Bilancia da fonte secondaria). La quarta figura su f73r è segnalata nel repertorio https://end.rito.one/solved/figures.html e non è confermata indipendentemente; il sito avanza una propria proposta di soluzione non accertata. Il repertorio di 299 figure descrive anche molte acconciature e copricapi, ma queste categorie non sono state qui verificate in cieco. Le categorie visive non possono quindi ancora costituire un vero campione corona-vs-copricapo.

## Materiali e test

Originale ZL3b verificato nel dossier precedente. Questo pacchetto porta una copia immutata dell'estrazione `all_labels.csv`, il codice nuovo e i risultati. Per ciascuna pagina, sono selezionate le etichette leggibili di una fascia corrispondente approssimativamente a quella della figura coronata. Sono preferite quelle la cui lunghezza grafica differisce al massimo di due caratteri dal candidato; se la fascia rimane con una sola possibilità si usa la fascia intera. Per f73r l'attribuzione della fascia è **provvisoria**. L'unità statistica è l'etichetta di ciascuna pagina; non 299 figure indipendenti.

Calcolo per tutte le combinazioni disponibili: media delle sei (o tre) distanze Levenshtein normalizzate minime fra le parole di ciascuna coppia di etichette. Test esatto unilaterale per *maggiore distanza* rispetto ai controlli e misure secondarie di somiglianza. Il test non è preregistrato; non sostiene inferenze confermative.

## Risultati

Tre corone, 256 combinazioni: distanza osservata 0.85714, controllo medio 0.76338, p(maggiore o uguale) = 0.16406.

Quattro corone, sensibilità Scorpione, 4096 combinazioni: distanza osservata 0.80952, controllo medio 0.73711, p(maggiore o uguale) = 0.15747.

Nessuna parola condivisa; nessuna coppia con identico prefisso di due caratteri. Nessun confronto raggiunge evidenza statistica significativa.

## Limiti decisivi

1. Il confronto specifico **corona contro copricapo non coronato** non è realizzato: manca un catalogo verificato indipendentemente che identifichi in modo certo tutte le figure col cappello nella stessa fascia.
2. Gli abbinamenti visivi di Bilancia e Scorpione non hanno lo stesso grado di affidabilità di quelli di Cancro e Leone.
3. I limiti delle fasce e le distanze di Levenshtein non equivalgono a un modello linguistico.
4. Test esplorativo successivo a numerosi controlli sugli stessi folii, senza significatività confermativa.

**Verdetto:** nessuna prima parola; nessuna corrispondenza corona-vocabolo attestata. Non modificare RC1.4.2.
