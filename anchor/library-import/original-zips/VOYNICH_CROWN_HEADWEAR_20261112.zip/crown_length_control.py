#!/usr/bin/env python3
"""Read-only exploratory crown-label specificity test. No decoding claims.
Inputs: earlier ZL3b audit, source classification documented separately.
Exact ring- and graphic-length-matched comparison, plus 4th crown sensitivity.
"""
import csv, itertools, json, math, hashlib
from pathlib import Path
from collections import Counter
P=Path(__file__).resolve().parent
R=list(csv.DictReader((P/'all_labels_input.csv').open()))
C={'f72r3':30,'f72v3':26,'f72v1':8,'f73r':15}
B={'f72r3':(27,33),'f72v3':(21,32),'f72v1':(2,21),'f73r':(1,21)} # Scorpio first ring only provisional, based on secondary source

def ed(a,b):
 p=list(range(len(b)+1))
 for i,x in enumerate(a,1):
  q=[i]
  for j,y in enumerate(b,1):q.append(min(q[-1]+1,p[j]+1,p[j-1]+(x!=y)))
  p=q
 return p[-1]
def toks(r):return r['words'].split()
def length(r):return sum(map(len,toks(r)))
def norm(a,b):return min(ed(x,y)/max(len(x),len(y)) for x in toks(a) for y in toks(b))
def score(rs):
 vals=[norm(a,b) for a,b in itertools.combinations(rs,2)]
 return {'mean_normalized_min_edit':sum(vals)/len(vals),'min_normalized_edit':min(vals),'shared_exact_pairs':sum(v==0 for v in vals),'same_2char_prefix_pairs':sum(any(x[:2]==y[:2] for x in toks(a) for y in toks(b)) for a,b in itertools.combinations(rs,2))}

def run(folios):
 c=[next(r for r in R if r['folio']==f and int(r['locus'])==C[f]) for f in folios]
 pools={}
 for f,cr in zip(folios,c):
  lo,hi=B[f]
  pool=[r for r in R if r['folio']==f and r['clean']=='True' and lo<=int(r['locus'])<=hi]
  # Prefer matched lengths +/- 2 chars. If no >=2 distinct candidates, include all same-ring words.
  matched=[r for r in pool if abs(length(r)-length(cr))<=2]
  if len(matched)<2:matched=pool
  assert cr in matched,(f,len(matched),cr['words'])
  pools[f]=matched
 obs=score(c)
 N=0;ct=Counter();sum_val=0
 for items in itertools.product(*(pools[f] for f in folios)):
  v=score(items);N+=1
  sum_val+=v['mean_normalized_min_edit']
  ct['mean_ge']+=v['mean_normalized_min_edit']>=obs['mean_normalized_min_edit']-1e-12
  ct['mean_le']+=v['mean_normalized_min_edit']<=obs['mean_normalized_min_edit']+1e-12
  ct['min_le']+=v['min_normalized_edit']<=obs['min_normalized_edit']+1e-12
  ct['shared_ge']+=v['shared_exact_pairs']>=obs['shared_exact_pairs']
  ct['prefix_ge']+=v['same_2char_prefix_pairs']>=obs['same_2char_prefix_pairs']
 return {'folios':folios,'observed_crown_labels':[{ 'folio':r['folio'],'locus':r['locus'],'label':r['words'],'graphic_length':length(r)} for r in c], 'pool_count':{f:len(pools[f]) for f in folios},'enumerations':N,'observed':obs,'null_mean_normalized_edit':sum_val/N,'p_exact':{k:v/N for k,v in ct.items()},'caveat':'Same-ring locators are approximate; visual headwear other than crown is not independently classified. This is a LABEL ANOMALY test, NOT a crown-vs-hat experiment.'}
res={'three_crowns':run(['f72r3','f72v3','f72v1']),'four_crowns_sensitivity':run(['f72r3','f72v3','f72v1','f73r']),'source_of_crown_designations':'For Cancer Leo Libra: Zandbergen q11 + label associations (third less certain). Scorpio only via end.rito.one; a site proposing an unverified decipherment.','status':'EXPLORATORY; NOT DECIPHERED; no verified crown-versus-other-headgear pairs. RC1.4.2 unchanged.'}
(P/'results.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(res,ensure_ascii=False,indent=2))
