#!/usr/bin/env python3
"""Descriptive-only sensitivity audit of the frozen ANCHOR-01 pilot.

No geometry changes, no label/figure assignment, no statistical inference.
Requires original ANCHOR_01_GEOMETRY_PILOT.zip; outputs CSV/JSON/MD.
"""
import csv, io, json, hashlib, math, statistics, zipfile, collections, sys, pathlib

ORIGINAL=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else '/workspace/scratch/a912548bb506/ANCHOR_01_GEOMETRY_PILOT.zip')
OUT=pathlib.Path(sys.argv[2] if len(sys.argv)>2 else '/mnt/data/ANCHOR01_GEOMETRY_DIAGNOSTIC')
OUT.mkdir(parents=True, exist_ok=True)
BASE='ANCHOR_01_GEOMETRY_PILOT/'
THRESHOLDS=[2.0,0.5,0.3,0.2]

def sha(b):return hashlib.sha256(b).hexdigest()
def read_csv(z,filename):return list(csv.DictReader(io.StringIO(z.read(BASE+filename).decode('utf-8-sig'))))
def fmt(x):return f'{x:.6f}'

with zipfile.ZipFile(ORIGINAL) as z:
    assert z.testzip() is None
    rule=z.read(BASE+'GEOMETRY_RULE_FROZEN.json')
    coords=z.read(BASE+'coordinates_draft.json')
    lock=json.loads(z.read(BASE+'COORDINATES_LOCK.json'))
    assert sha(rule)==lock['rule_sha256'], 'frozen rule changed'
    assert sha(coords)==lock['coordinates_sha256'], 'locked coordinates changed'
    assert json.loads(rule)['max_normalized_distance']==2.0
    audit=read_csv(z,'link_audit.csv')
    distances=read_csv(z,'all_candidate_distances.csv')
    review=read_csv(z,'independent_review.csv')
    assert len(audit)==30 and len(distances)==250
    assert all(r['review_completed']=='False' for r in review)
    assert len(review)==60
    by=collections.defaultdict(list)
    for r in distances:
        by[r['label_locus_id']].append(r)
    assert len(by)==30
    assert len({r['label_locus_id'] for r in audit})==30
    assert all(r['geometric_outcome']=='ambiguous' for r in audit)
    assert all(r['validation_status']=='pending_independent_review' for r in audit)
    assert all(r['attribute_primary']=='' and r['attribute_value']=='' for r in audit)

summary={str(t):collections.Counter() for t in THRESHOLDS}
per=[]
for r in audit:
    locus=r['label_locus_id']
    ds=sorted(by[locus],key=lambda x:float(x['distance_norm']))
    d1,d2=map(lambda x:float(x['distance_norm']),ds[:2])
    first=ds[0]['figure_id']
    assert first==r['nearest_candidate_figure_id']
    assert abs(d1-float(r['distance_normalized']))<1e-10
    assert len(ds)==sum(1 for x in distances if x['label_locus_id']==locus)
    zero=(d1==0.0)
    warn=(r['source_warning']=='True')
    nonrecip=(r['reciprocal_nearest']=='False')
    item={
        'label_locus_id':locus,'page_id':r['page_id'],'ring':r['ring'],
        'nearest_candidate_figure_id':first,
        'first_distance_norm':fmt(d1),'second_distance_norm':fmt(d2),
        'second_minus_first_norm':fmt(d2-d1),
        'first_distance_native_px':r['nearest_distance_native_px'],
        'distance_resolution_floor':str(zero).lower(),
        'source_warning':str(warn).lower(),
        'nonreciprocal_nearest':str(nonrecip).lower(),
        'ratio_second_first': 'undefined_zero_first' if zero else fmt(d2/d1),
        'original_frozen_outcome':r['geometric_outcome'],
        'validation_status':r['validation_status'],
    }
    for t in THRESHOLDS:
        within=sum(float(x['distance_norm'])<=t for x in ds)
        possible=sum(float(x['assumed_distance_norm_low'])<=t for x in ds)
        guaranteed=sum(float(x['assumed_distance_norm_high'])<=t for x in ds)
        hypothetical=('unlinked' if within==0 else 'unique_candidate' if within==1 else 'multiple_candidates')
        # These intervals come from the *assumed*, not empirically validated, coordinate tolerance.
        stable=(possible==guaranteed==1)
        suffix=str(t).replace('.','p')
        item[f'n_within_r{suffix}']=within
        item[f'descriptive_r{suffix}']=hypothetical
        item[f'uniqueness_stable_under_assumed_error_r{suffix}']=str(stable).lower()
        s=summary[str(t)]
        s[hypothetical]+=1
        if stable:s['unique_stable_under_assumed_error']+=1
        if stable and not (zero or warn or nonrecip):s['unique_stable_without_three_flags']+=1
        if possible!=guaranteed:s['candidate_count_sensitive_to_assumed_error']+=1
    per.append(item)

firsts=[float(r['first_distance_norm']) for r in per]
seconds=[float(r['second_distance_norm']) for r in per]
zeros=[r['label_locus_id'] for r in per if r['distance_resolution_floor']=='true']
nonrec=[r['label_locus_id'] for r in per if r['nonreciprocal_nearest']=='true']
warned=[r['label_locus_id'] for r in per if r['source_warning']=='true']
assert len(zeros)==10 and len(nonrec)==3 and len(warned)==5
assert summary['2.0']['multiple_candidates']==30
assert (summary['0.5']['unique_candidate'],summary['0.5']['multiple_candidates'])==(22,8)
assert (summary['0.3']['unlinked'],summary['0.3']['unique_candidate'],summary['0.3']['multiple_candidates'])==(4,20,6)
assert (summary['0.2']['unlinked'],summary['0.2']['unique_candidate'],summary['0.2']['multiple_candidates'])==(7,20,3)

with (OUT/'per_locus_diagnostic.csv').open('w',newline='',encoding='utf-8') as f:
    writer=csv.DictWriter(f,fieldnames=list(per[0]));writer.writeheader();writer.writerows(per)
with (OUT/'threshold_summary.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f)
    w.writerow(['hypothetical_radius','unlinked','unique_candidate','multiple_candidates','unique_stable_under_assumed_error','unique_stable_without_three_flags','candidate_count_sensitive_to_assumed_error'])
    for t in THRESHOLDS:
        s=summary[str(t)]
        w.writerow([t,s['unlinked'],s['unique_candidate'],s['multiple_candidates'],s['unique_stable_under_assumed_error'],s['unique_stable_without_three_flags'],s['candidate_count_sensitive_to_assumed_error']])
with (OUT/'review_priority.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['label_locus_id','priority','reason','reviewer_1_status','reviewer_2_status'])
    for r in per:
        flags=[]
        if r['distance_resolution_floor']=='true':flags.append('zero_polygon_distance_check_boundary')
        if r['nonreciprocal_nearest']=='true':flags.append('nonreciprocal_nearest_check_geometry')
        if r['source_warning']=='true':flags.append('source_warning_check_ring_and_locus')
        if r['descriptive_r0p5']=='multiple_candidates':flags.append('multiple_candidates_even_at_r0.5')
        if not flags:flags.append('routine_double_review')
        priority='high' if flags!=['routine_double_review'] else 'standard'
        w.writerow([r['label_locus_id'],priority,';'.join(flags),'pending','pending'])

result={
    'status':'PREPARATION_DATASET_PENDING_VALIDATION',
    'scope':'descriptive_only; frozen_rule_unchanged; no new assignments',
    'source_zip':str(ORIGINAL),'source_zip_sha256':sha(ORIGINAL.read_bytes()),
    'frozen_rule_sha256':sha(rule),'locked_coordinates_sha256':sha(coords),
    'n_labels':len(per),'n_candidate_distances':len(distances),
    'first_distance_norm':{'min':min(firsts),'median':statistics.median(firsts),'max':max(firsts)},
    'second_distance_norm':{'min':min(seconds),'median':statistics.median(seconds),'max':max(seconds)},
    'zero_distance_loci':zeros,'nonreciprocal_loci':nonrec,'source_warning_loci':warned,
    'hypothetical_threshold_diagnostic':{k:dict(v) for k,v in summary.items()},
    'independent_reviews_completed':0,'validated_links':0,'validated_blind_attributes':0,
    'RC1_4_2':'CLOSED_PENDING_VALIDATION_UNCHANGED',
    'H_A3R':'NOT_EXECUTABLE',
}
(OUT/'diagnostic_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
md=f'''# ANCHOR-01 — Addendum diagnostico del pilota geometrico

**Stato:** `PREPARATION_DATASET_PENDING_VALIDATION`. Questo documento non modifica la regola congelata (`SHA-256 {sha(rule)}`) né le coordinate (`SHA-256 {sha(coords)}`). Le soglie alternative sono **controfattuali descrittivi**, non criteri adottati e non nuovi collegamenti validati.

## Diagnostica dei 30 loci

- Distanza normalizzata del primo candidato: minimo **{min(firsts):.3f}**, mediana **{statistics.median(firsts):.3f}**, massimo **{max(firsts):.3f}**.
- Secondo candidato: minimo **{min(seconds):.3f}**, mediana **{statistics.median(seconds):.3f}**, massimo **{max(seconds):.3f}**.
- **{len(zeros)}** distanze prime esattamente nulle. Indicano poligoni sovrapposti/tangenti o insufficiente risoluzione dei contorni, **non** un abbinamento perfetto. Il rapporto seconda/prima è indefinito.
- **{len(nonrec)}** non reciprocità del primo vicino: {', '.join(nonrec)}.
- **{len(warned)}** avvertimenti della fonte: {', '.join(warned)}.

| Raggio ipotetico | Senza candidato | Un candidato | Più candidati | Unico stabile sotto errore *assunto* | Unico stabile senza 0 px / warning / non reciprocità |
|---:|---:|---:|---:|---:|---:|
'''
for t in THRESHOLDS:
    s=summary[str(t)]
    md+=f"| {t:g} | {s['unlinked']} | {s['unique_candidate']} | {s['multiple_candidates']} | {s['unique_stable_under_assumed_error']} | {s['unique_stable_without_three_flags']} |\n"
md+='''
Le colonne "stabile" derivano **solo** dagli intervalli di sensibilità già presenti nel pacchetto, basati su una tolleranza ipotizzata, non misurata indipendentemente. **Non sono collegamenti certi, probabili o validati.** In particolare il controllo su 0 px è obbligatorio anche dove la stabilità numerica sembra buona.

## Interpretazione e vincoli

1. L'universalità di `ambiguous` a raggio 2,0 è in larga parte conseguenza della soglia permissiva e della regola che considera ambigua qualunque molteplicità. La distribuzione delle prime/seconde distanze documenta questa causa **senza cambiare il criterio**.
2. Non si può ancora attribuire tutto alla soglia: 10 sovrapposizioni di poligoni, 3 non reciprocità e 5 avvertimenti di fonte richiedono controllo delle coordinate e degli identificativi. L'esito della regola congelata resta **30/30 `ambiguous`**.
3. La metrica angolare/radiale è una possibile ipotesi per una **futura** versione, non un sostituto retroattivo. Un coefficiente 0,7 scelto ora sarebbe arbitrario; prima occorre verificare centro, anelli, orientamento e precisione dei poligoni con revisori indipendenti.
4. Non si esegue un secondo audit "indipendente" con lo stesso operatore o lo stesso modello. `review_priority.csv` è una lista di lavoro per **due revisori umani distinti**, non una scheda completata.
5. Non si esegue annotazione cieca degli attributi né analisi di potenza o inferenza su H-A3R. I 4 folii fisici restano il vincolo di dipendenza del disegno.

**Decisione:** revisione indipendente delle geometrie e delle identità dei loci prima di qualsiasi `GEOMETRY_RULE_FROZEN v2`. H-A3R **non eseguibile**; RC1.4.2, f085v e RP-01 invariati.

## Riproducibilità

Lanciare `python reproduce_diagnostic.py /percorso/ANCHOR_01_GEOMETRY_PILOT.zip /cartella/output`. Lo script verifica gli hash della regola e delle coordinate contro il lock, controlla il numero di distanze, lo stato delle schede di revisione e non riscrive il pacchetto originale. Il report è un addendum descrittivo, non una nuova preregistrazione.
'''
(OUT/'GEOMETRY_DIAGNOSTIC_ADDENDUM.md').write_text(md,encoding='utf-8')
print(json.dumps({'source_zip_sha256':result['source_zip_sha256'],'first_median':statistics.median(firsts),'second_median':statistics.median(seconds),'zero':len(zeros),'nonrec':len(nonrec),'thresholds':result['hypothetical_threshold_diagnostic']},indent=2))
