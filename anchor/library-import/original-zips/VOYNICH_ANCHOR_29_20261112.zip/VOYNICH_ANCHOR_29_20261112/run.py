#!/usr/bin/env python3
"""ANCHOR-29: no known plaintext, no known homophone grouping, independent page/block holds.
Toy synthetic 2-homophone cipher with explicit character boundaries. The attacker uses
only ciphertext and a different Latin passage for a language model. No target plaintext
or actual cipher key is used in scoring. Fixed seeds and hyperparameters.
"""
import re, random, json, pathlib, numpy as np, collections, hashlib, zipfile, statistics
ROOT=pathlib.Path(__file__).resolve().parent
P27=ROOT.parent/'VOYNICH_ANCHOR_27_20261112'
source=(P27/'run_anchor27.py').read_text()
TRAIN=source.split("TRAIN='''",1)[1].split("'''",1)[0]
TARGET=(P27/'borg_0010r_plaintext_extracted.txt').read_text()
def norm(x):
 x=re.sub(r'\[[^\]]*\]','',x.lower());return ''.join(re.findall('[a-z]',x))
# Three disjoint test passages. Block identities explicitly retained, not asserted independent authors.
raw=[norm(TARGET), norm(TRAIN[:len(TRAIN)//2]),norm(TRAIN[len(TRAIN)//2:])]
assert min(map(len,raw))>120
alpha=sorted(set(''.join(raw))); m=len(alpha);idx={c:i for i,c in enumerate(alpha)}
# Ensure all 3 texts are separately used as held out; model excludes the tested passage.
def train_model(other):
 letters=[idx[c] for c in other]
 B=np.full((m,m),0.5,dtype=float);U=np.ones(m,dtype=float)
 for x in letters:U[x]+=1
 for a,b in zip(letters[:-1],letters[1:]):B[a,b]+=1
 # unigram distribution + smoothed bigram conditional with short-reference regularization
 return np.log(B/B.sum(axis=1,keepdims=True)),np.log(U/U.sum())
def encrypt(t,seed):
 rng=random.Random(seed)
 # secret mapping from (plain-letter,variant) to 2*m arbitrary code IDs, with no grouping disclosed
 sym=list(range(2*m));rng.shuffle(sym)
 p_to_sym={letter:(sym[2*idx[letter]],sym[2*idx[letter]+1]) for letter in alpha}
 code=np.array([rng.choice(p_to_sym[ch]) for ch in t],dtype=np.int16)
 key=np.zeros(2*m,dtype=np.int16)
 for letter,(a,b) in p_to_sym.items():key[a]=key[b]=idx[letter]
 return code,key

def attack(code,S,Ul,seed,known_grouping=False):
 # Fixed slots: each plaintext letter is the value for exactly two hidden symbols.
 n=2*m; counts=np.bincount(code,minlength=n)
 if known_grouping:
  raise NotImplementedError
 # No use of true pairing; initialize using frequency rankings only.
 rank=sorted(range(m),key=lambda x:(-Ul[x],x))
 order=sorted(range(n),key=lambda x:(-counts[x],x))
 base=np.zeros(n,dtype=np.int16)
 for i,code_sym in enumerate(order):base[code_sym]=rank[i//2]
 A=np.zeros((n,n),dtype=np.int32)
 for a,b in zip(code[:-1],code[1:]):A[a,b]+=1
 # objective evaluated on code-symbol bigram count matrix, no plaintext info.
 def score(p):return float(np.sum(A*S[np.ix_(p,p)]))+float(0.5*np.dot(counts,Ul[p]))
 rng=np.random.default_rng(seed+999)
 best=base.copy();best_sc=score(best)
 # search with no secret grouping, starts chosen before evaluation
 for restart in range(6):
  p=base.copy() if restart==0 else rng.permutation(np.repeat(np.arange(m,dtype=np.int16),2))
  cur=score(p)
  for step in range(2200):
   a,b=rng.choice(n,2,replace=False)
   if p[a]==p[b]:continue
   p[a],p[b]=p[b],p[a]
   nxt=score(p)
   temp=2.4*(1-step/2200)+0.05
   if nxt>=cur or rng.random()<np.exp(max(-700,(nxt-cur)/temp)):
    cur=nxt
   else:p[a],p[b]=p[b],p[a]
   if cur>best_sc:best_sc=cur;best=p.copy()
 return best,best_sc

def oracle_group_attack(code,key,S,Ul,seed):
 # For fairness, 'easier' upper-resource comparison: grouping is exposed,
 # but not the mapping of groups to plaintext letters.
 groups=sorted({tuple(np.flatnonzero(key==k)) for k in range(m)}) # WARNING grouping constructed from key for evaluation condition only
 gids=np.zeros(2*m,dtype=np.int16)
 for g,pair in enumerate(groups):gids[list(pair)]=g
 c=gids[code];counts=np.bincount(c,minlength=m)
 rank=sorted(range(m),key=lambda x:(-Ul[x],x));order=sorted(range(m),key=lambda x:(-counts[x],x))
 base=np.zeros(m,dtype=np.int16)
 for i,s in enumerate(order):base[s]=rank[i]
 A=np.zeros((m,m),dtype=np.int32)
 for a,b in zip(c[:-1],c[1:]):A[a,b]+=1
 def score(p):return float(np.sum(A*S[np.ix_(p,p)]))+float(.5*np.dot(counts,Ul[p]))
 rng=np.random.default_rng(seed+999);best=base.copy();bestsc=score(best)
 for r in range(6):
  p=base.copy() if r==0 else rng.permutation(m).astype(np.int16);cur=score(p)
  for st in range(2200):
   a,b=rng.choice(m,2,replace=False);p[a],p[b]=p[b],p[a];v=score(p);temp=2.4*(1-st/2200)+.05
   if v>=cur or rng.random()<np.exp(max(-700,(v-cur)/temp)):cur=v
   else:p[a],p[b]=p[b],p[a]
   if cur>bestsc:bestsc=cur;best=p.copy()
 return best[gids],bestsc

runs=[];snapshots=[]
for tid,t in enumerate(raw):
 ref=''.join(raw[j] for j in range(len(raw)) if j!=tid)
 S,Ul=train_model(ref)
 plain=np.array([idx[c] for c in t],dtype=np.int16)
 for rep in range(4):
  seed=20261112+1000*tid+rep*137;code,key=encrypt(t,seed)
  guessed,score=attack(code,S,Ul,seed)
  easy,escore=oracle_group_attack(code,key,S,Ul,seed)
  rng=np.random.default_rng(seed+88);rand=rng.permutation(np.repeat(np.arange(m,dtype=np.int16),2))
  row={'test_block':tid,'cipher_seed':seed,'test_chars':len(t),'reference_chars':len(ref),'alphabet':m,
       'no_group_accuracy':float(np.mean(guessed[code]==plain)),
       'known_group_accuracy':float(np.mean(easy[code]==plain)),
       'random_accuracy':float(np.mean(rand[code]==plain)),
       'no_group_true_pair_agreement':float(np.mean([guessed[a]==guessed[b] for a in range(2*m) for b in range(a+1,2*m) if key[a]==key[b]])),
       'no_group_likelihood':score,'known_group_likelihood':escore}
  runs.append(row)
  if rep==0:snapshots.append({'test_block':tid,'guessed_excerpt':''.join(alpha[x] for x in guessed[code][:100]),'reference_for_evaluation_only':t[:100]})
result={'experiment':'ANCHOR-29','design':'Ciphertext-only attack with hidden code-key and hidden 2-homophone grouping, 3 disjoint held-out Latin passages from two Borg page transcriptions; four encrypted permutations each. Evaluation plaintext never accessed in score.',
'method':'swap simulated annealing using smoothed bigram and unigram Latin model trained exclusively on other passages. 6 restarts x 2200 iterations. fixed hyperparameters.',
'caveats':['Three passages are disjoint, but all come from the same manuscript and two are split from one prior reference, not independent authors or genres.', 'The synthetic cipher has explicit encoded-character boundaries, unlike the Voynich.', 'Known-group reference is an easier comparator, not a valid ciphertext-only attack.', 'Small reference corpus. Model hyperparameters chosen a priori for this run, but approach follows ANCHOR-28 and is not a preregistered discovery.', 'Four secret permutations per passage are dependent replications, so inferential sample size is 3.', 'The cipher is not the full Naibbe system.'],
'runs':runs,'summaries':{},'examples':snapshots}
for k in ['no_group_accuracy','known_group_accuracy','random_accuracy','no_group_true_pair_agreement']:
 result['summaries'][k]={'mean':statistics.mean(x[k] for x in runs),'by_test_block':[statistics.mean(x[k] for x in runs if x['test_block']==i) for i in range(3)],'min':min(x[k] for x in runs),'max':max(x[k] for x in runs)}
(ROOT/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'lengths':[len(x) for x in raw],'alphabet':m,'summaries':result['summaries']},indent=2))
