# ANCHOR-29 · recupero ciphertext-only senza classi omofoniche note

Data: 12 novembre 2026. Esperimento sintetico, separato dall'audit RC1.4.2 congelato.

## Domanda e protocollo
Verificare se si recuperi una chiave di sostituzione omofonica con due simboli segreti per lettera senza conoscere né il messaggio né il raggruppamento dei simboli. Tre brani latini disgiunti, appartenenti allo stesso manoscritto Borg, sono stati impiegati a turno come bersaglio; per ciascuno il modello di riferimento usa solo gli altri due. Quattro cifrature indipendenti per ogni brano misurano la variabilità dovuta alla chiave; non moltiplicano il numero di testi indipendenti.

Alfabeto 22 lettere; tre brani di 282, 204, 195 caratteri. L'attaccante conosce la dimensione dell'alfabeto e il fatto che ogni lettera ha esattamente due codici, ma non sa quali due appartengano alla stessa lettera. Il confine di ogni codice rimane noto; questa è una semplificazione sostanziale rispetto al Voynich e al Naibbe completo.

Modello bigramma smussato 0,5 e unigramma; ottimizzazione per scambi su mappatura 2m→m con due codici per lettera; 6 riavvii × 2.200 iterazioni, parametri costanti. Durante l'attacco non viene consultato il plaintext bersaglio, né la chiave segreta. Il plaintext compare soltanto dopo nel punteggio.

## Risultati
| Condizione | Media su 12 cifrature | Per brano (4 cifrature ciascuno) |
|---|---:|---|
| Chiave casuale | 4.4% | 2.0%, 5.8%, 5.4% |
| Attacco senza gruppi noti | 30.5% | 31.4%, 23.8%, 36.4% |
| Controllo agevolato con gruppi noti | 63.7% | 74.6%, 46.9%, 69.5% |

L'attacco senza gruppi correla correttamente in media 9.8% delle coppie omofoniche vere. Questo è un controllo diagnostico effettuato dopo la stima, non una misura usata per costruire la chiave.

## Verdetto
**PROGRESSO PARZIALE, NESSUNA DECIFRAZIONE.** Il recuperatore senza gruppi noti supera la chiave casuale, ma resta lontano dall'accuratezza necessaria per leggere affidabilmente testo sconosciuto. Il confronto con gruppi conosciuti quantifica il vantaggio improprio di cui disponeva ANCHOR-28.

Limiti: brani disgiunti ma ricavati da due pagine dello stesso manoscritto, non da tre autori; un testo è stato diviso in due; cifrario sintetico molto più semplice di Naibbe; confini dei codici noti; lingua e genere del corpus di riferimento noti; solo tre blocchi di test, senza intervalli di confidenza formali; la progettazione è una prosecuzione di precedenti esperimenti, non preregistrazione indipendente. Qualsiasi affermazione sul Voynich sarebbe ingiustificata.

## Prossimo test discriminante
Corpus di latino più ampio con documenti effettivamente indipendenti, simboli senza confini preassegnati, valutazione delle chiavi anche su testo aggiuntivo mai visto e confronto con modelli non cifrati. La verifica a posteriori di una lettura Voynich richiederebbe un ancoraggio esterno.

## Riproducibilità
Eseguire `python run.py` in una cartella con a fianco `VOYNICH_ANCHOR_27_20261112` e il relativo file di testo. SHA-256 del JSON risultati dopo due esecuzioni identiche: `d2a6e208635bf5b32f3662efda7136f032e1b1ab53e7be3591bd0391fec2d43d`. Il codice non modifica l'audit RC1.4.2.
