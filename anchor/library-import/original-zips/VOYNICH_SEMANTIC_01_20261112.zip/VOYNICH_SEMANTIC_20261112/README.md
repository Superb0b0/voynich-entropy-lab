# Voynich EXP-SEMANTIC-01

**Esito: non supera il controllo rigoroso (p=0,058).** Predire 16 punteggi visivi da parole EVA/ZL3b dà un miglioramento di MSE dello 0,526% rispetto ai metadati, non convincente dopo 999 permutazioni entro sezione illustrativa, Currier e quire.

Il dossier contiene codici riproducibili, 3 input sorgente, 2 rapporti numerici, tutti i null permutativi e il manifest dei folii inclusi. I punteggi visivi sono automatici, NON etichette semantiche verificate. La provenienza dei profili resta soggetta a RP-01, RC1.4.2.

Leggere `RAPPORTO.md` per i dettagli e le istruzioni di riproduzione.
