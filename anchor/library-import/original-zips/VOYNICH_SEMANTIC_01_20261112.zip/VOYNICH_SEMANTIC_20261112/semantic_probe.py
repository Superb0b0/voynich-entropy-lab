#!/usr/bin/env python3
"""EXP-SEMANTIC-01 exploratory read-only multimodal probe.
    Not a test of meaning: outcomes are model-derived visual archetype scores.
    Separately-fitted train-only TF-IDF, leaf-disjoint 5fold, fixed Ridge alpha=20.
    Null: permute image outcomes within illustration/Currier strata (100 times).
"""
import json,re,csv,hashlib,collections,os
from pathlib import Path
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import OneHotEncoder,StandardScaler
from sklearn.linear_model import Ridge
from sklearn.model_selection import GroupKFold
from scipy import sparse

OUT=Path(__file__).resolve().parent
P=OUT/'input/voynich_profiles.json'
TSV=OUT/'input/zl3b_P_ms408.tsv'
HEADER=OUT/'input/ZL3b-n.txt'
assert all(p.exists() for p in (P,TSV,HEADER))

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
profiles=json.loads(P.read_text())
by_id={re.sub(r'^f0*', 'f', x['image_id']):x for x in profiles if re.fullmatch(r'f\d+[rv]',x['image_id'])}
texts=collections.defaultdict(list)
for line in TSV.read_text().splitlines():
    f,t=line.split('\t',1)
    texts[f].extend(t.split())
meta={}
for line in HEADER.read_text().splitlines():
    m=re.match(r'^<([^>,.]+)>\s*<!',line)
    if m:meta[m.group(1)]=dict(re.findall(r'\$(\w+)=([^\s>]+)',line))

records=[]
for f in sorted(texts):
    if f not in by_id or f not in meta or len(texts[f])<75:continue
    p=by_id[f]
    scores=p['archetype_scores']
    if not isinstance(scores,dict) or len(scores)!=16:continue
    n=int(re.match(r'f(\d+)',f).group(1))
    m=meta[f]
    records.append(dict(folio=f,leaf=re.sub(r'[rv]$','',f),index=n,
         I=m.get('I','?'),L=m.get('L','?'),Q=m.get('Q','?'),
         tokens=texts[f],visual=scores))

keys=sorted(records[0]['visual']);n=len(records)
Y=np.asarray([[d['visual'][k] for k in keys] for d in records],dtype=float)
cat=np.asarray([[d[k] for k in ['I','L','Q']] + [str((d['index']-1)//10)] for d in records],dtype=object)
continuous=np.asarray([[np.log1p(len(d['tokens']))] for d in records])
groups=[d['leaf'] for d in records]
folds=list(GroupKFold(n_splits=5).split(np.arange(n),groups=groups))
assert all(not set(groups[i] for i in tr)&set(groups[i] for i in te) for tr,te in folds)

# Model predictions out of fold. Prespecified vectors: individual words min_df 2 max 600, no optimize.
def fit_predict(Ytarget, with_text):
    prediction=np.zeros_like(Ytarget)
    for train,test in folds:
        oh=OneHotEncoder(handle_unknown='ignore',dtype=np.float64)
        A=oh.fit_transform(cat[train]);B=oh.transform(cat[test]);
        scal=StandardScaler();ac=scal.fit_transform(continuous[train]);bc=scal.transform(continuous[test]);
        Xtr=sparse.hstack((A,sparse.csr_matrix(ac))).tocsr()
        Xte=sparse.hstack((B,sparse.csr_matrix(bc))).tocsr()
        if with_text:
            tf=TfidfVectorizer(token_pattern=r'(?u)\b[^\s]+\b',min_df=2,max_features=600,sublinear_tf=True,norm='l2')
            a=tf.fit_transform([' '.join(records[i]['tokens']) for i in train]);
            b=tf.transform([' '.join(records[i]['tokens']) for i in test]);
            Xtr=sparse.hstack((Xtr,a)).tocsr();Xte=sparse.hstack((Xte,b)).tocsr()
        model=Ridge(alpha=20.0,fit_intercept=True,solver='lsqr')
        model.fit(Xtr,Ytarget[train]);prediction[test]=model.predict(Xte)
    return prediction

# Fixed original scale standardization for omnibus equal-weight diagnostic; no fitted parameters in score.
scale=Y.std(axis=0);scale[scale<1e-10]=1
base=fit_predict(Y,False);aug=fit_predict(Y,True)
def get_loss(y,p):return float(np.mean(((y-p)/scale)**2))
MSE0=get_loss(Y,base);MSE1=get_loss(Y,aug)
per_dim=[]
for i,k in enumerate(keys):
    d0=float(np.mean((Y[:,i]-base[:,i])**2));d1=float(np.mean((Y[:,i]-aug[:,i])**2));
    per_dim.append(dict(archetype=k,baseline_mse=d0,text_mse=d1,delta=d0-d1,r2_gain=(d0-d1)/(np.var(Y[:,i])+1e-20)))

# Within strata preserves main illustration class AND Currier variation.
rng=np.random.default_rng(261112)
strata=collections.defaultdict(list)
for i,r in enumerate(records):strata[(r['I'],r['L'])].append(i)
perms=[]
for q in range(99):
    index=np.arange(n)
    for ids in strata.values():
        if len(ids)>1:index[ids]=rng.permutation(ids)
    Yn=Y[index]
    # Compare both models on equally permuted outcomes. Need per-target variance same.
    pp0=fit_predict(Yn,False);pp1=fit_predict(Yn,True)
    perms.append(get_loss(Yn,pp0)-get_loss(Yn,pp1))
observed=MSE0-MSE1
p=(1+sum(x>=observed for x in perms))/(len(perms)+1)

source={'profiles':digest(P),'zl3b_P':digest(TSV),'ZL3b_full':digest(HEADER)}
result=dict(status='EXPLORATORY_NOT_SEMANTIC_VALIDATION',n_profiles=len(profiles),n_text_folios=len(texts),n_joined_eligible=n,
  n_leaves=len(set(groups)),folds=5,
  image_labels='16 machine-generated visual archetype scores; NOT human-validated iconographic ground truth',
  shape_joins='exact fN[r/v] only, >=75 tokens, single folio / excludes ambiguous multipanel and nonfolio',
  predictors={'baseline':'illustration I, Currier L, quire Q, folio-index decade, log token count',
              'text':'baseline plus 600-max word TF-IDF, min_df2, fit on training leaves only',
              'ridge_alpha':20.0},
  original={'baseline_std_mse':MSE0,'text_std_mse':MSE1,'improvement':observed,'relative_improvement':observed/MSE0},
  null={'permutations':len(perms),'strata':'I x L','groups_permutation':[len(x) for x in strata.values()],
        'mean_improvement':float(np.mean(perms)),'median_improvement':float(np.median(perms)),
        'max_improvement':float(np.max(perms)), 'p_one_sided':p,
        'caveat':'Permuted image outcomes held fixed per run across model folds; within I x L, but may break quire/physical adjacency'},
  per_archetype=per_dim,files_sha256=source,
  warnings=['Repeated exploratory exposure to same manuscript folios: no fresh blinded test.',
   'Machine visual scores are not verified annotations of depicted objects or semantic topics.',
   'The visual profiles include unresolved provenance gap RP-01 in RC1.4.2; do not promote.',
   'No builder, PCA, clustering or conditional coupling run; stand-alone read-only experiment.',
   'Any positive cross-modal prediction does not establish decoding or information semantics.'])
(OUT/'results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
with (OUT/'archetype_scores.csv').open('w',newline='') as fo:
 w=csv.DictWriter(fo,fieldnames=per_dim[0].keys());w.writeheader();w.writerows(per_dim)
with (OUT/'permutation_null.csv').open('w',newline='') as fo:
 w=csv.writer(fo);w.writerow(['permutation','mse_improvement']);w.writerows((i+1,x) for i,x in enumerate(perms))
with (OUT/'joined_manifest.csv').open('w',newline='') as fo:
 w=csv.writer(fo);w.writerow(['folio','leaf','I','L','Q','tokens'])
 for x in records:w.writerow([x['folio'],x['leaf'],x['I'],x['L'],x['Q'],len(x['tokens'])])
print(json.dumps({k:result[k] for k in ('n_joined_eligible','n_leaves','original','null')},indent=2))
