# EXP-SEMANTIC-01 | Test esplorativo testo–immagine del manoscritto Voynich

**12 novembre 2026 | Stato: NON SUPERATO | Analisi autonoma in sola lettura**

## Domanda

Aggiungere le parole trascritte di un folio consente di prevedere meglio 16 punteggi visivi, oltre a quanto consentito dai soli metadati di struttura del manoscritto?

**Attenzione:** i 16 archetype_scores sono prodotti da un modello visivo: NON sono categorie iconografiche accertate da specialisti, né significati del testo. Si verifica soltanto un'eventuale dipendenza statistica fra queste rappresentazioni.

## Dati e join

- Profili: `voynich_profiles.json`, 206 record, **versione storica con rilievo di provenienza RC1.4.2 RP-01 non risolto**.
- Testo: righe P ZL3b di `zl3b_P_ms408.tsv`, con metadati di folio Currier (`$L`), categoria illustrativa (`$I`), quire (`$Q`) dal file `ZL3b-n.txt`.
- Join strettamente diretto fra `fNNNr/v` e `fN r/v` normalizzato. Esclusi copertine, ritagli multipannello, record senza metadati e pagine con <75 token.
- **131 pagine eleggibili, 77 fogli fisici.** La riduzione dal totale dei profili non può essere ignorata e limita la generalizzabilità.
- Nessun recupero semantico da immagini nell'esperimento: si usano punteggi precedentemente computati.

## Disegno

- Cinque fold GroupKFold, con recto e verso dello stesso foglio sempre nello stesso fold.
- Modello di controllo: one-hot di illustrazione I, Currier L, quire Q, fascia numerica del folio, log(1+numero di token).
- Modello arricchito: controllo + TF-IDF di parole, massimo 600 forme, min_df=2, vocabolario ricostruito esclusivamente sui fold di addestramento.
- Regressione Ridge con alpha=20, stabilito prima di questo confronto; 16 punteggi visivi predetti congiuntamente.
- End-point omnibus: differenza di MSE standardizzato su tutte le 16 dimensioni, con varianza delle dimensioni usata solo come scala comune.
- Primo null: 99 permutazioni delle etichette visive entro I×L.
- Null principale più rigoroso: **999 permutazioni** delle etichette visive entro **I×L×Q**, lasciando invariati testo, folii, folds, covariate e iperparametri.
- Le permutazioni entro quire mantengono più struttura storica e riducono la libertà del controllo.

## Risultati

| Quantità | Valore |
|---|---:|
| MSE standardizzato del controllo | 0,567118 |
| MSE del controllo + testo | 0,564137 |
| Riduzione assoluta MSE | 0,002981 |
| Riduzione relativa | **0,526%** |
| p empirica, null I×L, 99 repliche | 0,050 |
| p empirica, null I×L×Q, 999 repliche | **0,058** |
| Media del miglioramento sotto null rigoroso | 0,000701 |
| 95º percentile null rigoroso | 0,003068 |

La conferma con l'algoritmo veloce di matrice di influenza Ridge fornisce delta 0,00297984 anziché 0,00298097: differenza numerica ~0,00000113, senza impatto sulla conclusione. Il null rigoroso è appena oltre il 95º percentile della distribuzione nulla, non al di sopra.

**Verdetto:** non si rileva una prova statisticamente convincente di associazione testo–punteggi visivi oltre a sezione, Currier, quire, posizione e lunghezza della pagina. Non ci sono parole decifrate né una corrispondenza testuale-iconografica stabilita.

## Perché il risultato non è una prova semantica

1. **Mancanza di verità iconografica indipendente:** la variabile di risposta è la valutazione di un modello; potrebbe riflettere colori, disegno o testo riconoscibile nell'immagine, anziché referenti illustrati.
2. **Difetto documentale aperto:** la provenienza dei profili visivi non è stata formalmente riattestata nella pipeline RC1.4.2. Nessun gate è stato sbloccato.
3. **Controlli sviluppati durante il lavoro:** il null più stretto è stato progettato dopo il valore borderline del primo null; entrambi gli esiti sono esplorativi.
4. **Folio già esaminati:** altre analisi hanno esposto questi stessi dati; cinque fold qui non costituiscono un nuovo campione indipendente.
5. **Dimensione e selezione:** soltanto 131 pagine direttamente allineabili e con almeno 75 token.
6. **Possibili confondimenti residui:** quire, classe illustrativa, layout e vicinanza codicologica non garantiscono controlli perfetti della storia del manoscritto.
7. **Non equivalenza di conclusioni:** un test nullo non dimostra assenza di significato e un test positivo non avrebbe dimostrato una decifrazione.

## Decisione scientifica

NON promuovere alcuna delle 16 dimensioni a significato di parola o famiglia. NON usare questi risultati per adattare il corpus visivo congelato. Il passo realmente informativo è reperire/creare etichette *umane* e localizzate su oggetti concreti nei disegni, definite indipendentemente dalle parole, poi stabilire un nuovo holdout per foglio e per categoria, con controlli permutativi I×L×Q. Questo richiede revisione esplicita del gate di provenienza prima di un join ufficiale multimodale.

## Riproduzione

Da questa directory, con Python 3.10+, numpy/scipy/scikit-learn:

```
OPENBLAS_NUM_THREADS=1 python semantic_probe.py
OPENBLAS_NUM_THREADS=1 python strict_fast.py
```

La seconda esecuzione usa una forma matematica equivalente della regressione Ridge, con matrici di influenza precomputate, per replicare 999 permutazioni entro I×L×Q senza ricampionare i parametri. Output `results.json`, `strict_results.json`, manifest e CSV delle permutazioni.

I file di input sono copiati nel pacchetto per riproducibilità; i byte sorgente sono preservati. Le analisi NON mutano alcun input originale, non avviano builder/PCA/clustering e lasciano il gate RC1.4.2 a `CLOSED_PENDING_VALIDATION`.
