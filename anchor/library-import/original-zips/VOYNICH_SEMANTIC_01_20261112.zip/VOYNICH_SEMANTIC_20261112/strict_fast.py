import numpy as np,re,json,collections,csv
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import OneHotEncoder,StandardScaler
from scipy import sparse
ns={'__file__':str(Path(__file__).resolve().with_name('semantic_probe.py')),'__name__':'read_only'}
text=Path(ns['__file__']).read_text().split('# Model predictions out of fold.')[0]
exec(compile(text,ns['__file__'],'exec'),ns)
for k,v in ns.items():
 if k in ('records','cat','continuous','groups','folds','Y','keys','n','scale','OUT') :globals()[k]=v

def Hat(with_text):
 h=np.zeros((n,n))
 for train,test in folds:
  oh=OneHotEncoder(handle_unknown='ignore',dtype=float)
  A=oh.fit_transform(cat[train]);B=oh.transform(cat[test])
  sc=StandardScaler(); a=sc.fit_transform(continuous[train]);b=sc.transform(continuous[test])
  Xtr=sparse.hstack([A,sparse.csr_matrix(a)]).toarray()
  Xte=sparse.hstack([B,sparse.csr_matrix(b)]).toarray()
  if with_text:
   tf=TfidfVectorizer(token_pattern=r'(?u)\b[^\s]+\b',min_df=2,max_features=600,sublinear_tf=True,norm='l2')
   tr=[' '.join(records[i]['tokens']) for i in train];te=[' '.join(records[i]['tokens']) for i in test]
   Xtr=np.hstack([Xtr,tf.fit_transform(tr).toarray()]);Xte=np.hstack([Xte,tf.transform(te).toarray()])
  xmean=Xtr.mean(axis=0); V=Xtr-xmean;W=Xte-xmean
  K=V@V.T
  Ktest=W@V.T
  Bmat=np.linalg.solve(K+20.0*np.eye(len(train)),Ktest.T).T
  h[np.ix_(test,train)]=Bmat+(1-Bmat.sum(axis=1))[:,None]/len(train)
 return h
H0=Hat(False);H1=Hat(True)
S=Y.std(axis=0);S[S<1e-10]=1

def metric(a):
 p0=H0@a;p1=H1@a
 return np.mean(((a-p0)/S)**2)-np.mean(((a-p1)/S)**2)
orig=metric(Y)
print('ORIGINAL',orig,flush=True)
rng=np.random.default_rng(261112);strata=collections.defaultdict(list)
for i,r in enumerate(records):strata[(r['I'],r['L'],r['Q'])].append(i)
null=[]
for rep in range(999):
 idx=np.arange(n)
 for ids in strata.values():
  if len(ids)>1:idx[ids]=rng.permutation(ids)
 null.append(metric(Y[idx]))
result={
 'status':'EXPLORATORY_STRICT_NULL', 'total_joined':n,'strata':'illustration x Currier x quire',
 'strata_sizes':sorted([len(v) for v in strata.values()],reverse=True),
 'nontrivial_strata':sum(len(v)>1 for v in strata.values()),
 'unswappable_folios':sum(len(v)==1 for v in strata.values()),
 'n_permutations':len(null),'original_mse_improvement':float(orig),'null_mean':float(np.mean(null)),
 'null_median':float(np.median(null)),'null_q95':float(np.quantile(null,.95)),
 'null_max':float(max(null)),'p_one_sided':float((1+sum(v>=orig for v in null))/(len(null)+1)),
 'note':'All fold predictions based on same fixed alpha20 Ridge using precomputed kernel hat matrices, group split by physical leaf. Permuted outcomes within illustration x Currier x quire. This is not iconographic human labeling, no semantic validation.'}
(OUT/'strict_results.json').write_text(json.dumps(result,indent=2))
with (OUT/'strict_null.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['permutation','delta_mse']);w.writerows(enumerate(null,1))
print(json.dumps(result,indent=2),flush=True)
