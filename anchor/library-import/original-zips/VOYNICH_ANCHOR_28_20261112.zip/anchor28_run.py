#!/usr/bin/env python3
"""ANCHOR-28: ciphertext-only monoalphabetic key recovery. Synthetic grouped homophones.
No plaintext of test is used inside estimators. All metrics calculated only after decoding.
"""
import re, json, random, collections, hashlib, pathlib, statistics, zipfile
import numpy as np
ROOT=pathlib.Path('/mnt/data/VOYNICH_ANCHOR_28_20261112'); ROOT.mkdir(exist_ok=True)
PREV=pathlib.Path('/mnt/data/VOYNICH_ANCHOR_27_20261112')
source=(PREV/'run_anchor27.py').read_text()
TRAIN=source.split("TRAIN='''",1)[1].split("'''",1)[0]
def norm(x):
 x=re.sub(r'\[[^]]*\]','',x.lower());return ''.join(re.findall('[a-z]',x))
train=norm(TRAIN)
target=norm((PREV/'borg_0010r_plaintext_extracted.txt').read_text())
alpha=sorted(set(train)|set(target)); m=len(alpha); idx={c:i for i,c in enumerate(alpha)}
ref=np.array([idx[c] for c in train],dtype=np.int16)
# Laplace smoothing of one-step conditional log probabilities; note short reference text.
B=np.full((m,m),0.5,dtype=float)
for a,b in zip(ref[:-1],ref[1:]):B[a,b]+=1
B=B/B.sum(axis=1,keepdims=True)
S=np.log(B)
refcounts=collections.Counter(train)
ref_rank=sorted(alpha,key=lambda c:(-refcounts[c],c))
def encrypt(t,seed):
 rng=random.Random(seed); perm=list(range(m));rng.shuffle(perm)
 plain=np.array([idx[c] for c in t],dtype=np.int16)
 code=np.array([perm[x] for x in plain],dtype=np.int16)
 # Two homophone variants generated but grouping is given to attackers, as prior experiment.
 variants=[rng.randrange(2) for _ in plain]
 return plain,code,variants

def unigram_guess(code):
 counts=np.bincount(code,minlength=m)
 rank_code=sorted(range(m),key=lambda k:(-counts[k],k))
 assign=np.zeros(m,dtype=np.int16)
 for c,p in zip(rank_code,ref_rank):assign[c]=idx[p]
 return assign

def ngram_guess(code,seed,starts=13,steps=750):
 # Objective uses bigrams in target and smoothed reference ONLY.
 A=np.zeros((m,m),dtype=np.int32)
 for a,b in zip(code[:-1],code[1:]):A[a,b]+=1
 rng=np.random.default_rng(seed)
 base=unigram_guess(code)
 def score(p):return float(np.sum(A*S[np.ix_(p,p)]))
 best=base.copy();bestscore=score(best)
 for restart in range(starts):
  p=base.copy() if restart==0 else rng.permutation(m).astype(np.int16)
  cur=score(p)
  for step in range(steps):
   i,j=rng.choice(m,2,replace=False)
   p[i],p[j]=p[j],p[i]
   nxt=score(p)
   temp=max(0.1,2.0*(1-step/steps))
   if nxt>=cur or rng.random()<np.exp((nxt-cur)/temp):cur=nxt
   else:p[i],p[j]=p[j],p[i]
   if cur>bestscore:bestscore=cur;best=p.copy()
 return best,bestscore

runs=[]
# non-independent key permutations are replicated only to assess random key invariance.
segments=[('full',target),('part1',target[:94]),('part2',target[94:188]),('part3',target[188:])]
for seg,t in segments:
 for rep in range(8):
  seed=12771+rep*311+len(t)*17
  plain,code,variants=encrypt(t,seed)
  freq=unigram_guess(code)
  ng,lik=ngram_guess(code,seed+99)
  f=float(np.mean(freq[code]==plain));n=float(np.mean(ng[code]==plain))
  # realized random key null
  rng=np.random.default_rng(seed+202)
  rand=rng.permutation(m)
  null=float(np.mean(rand[code]==plain))
  runs.append({'segment':seg,'run':rep,'n':len(t),'freq':round(f,6),'ngram':round(n,6),'null':round(null,6),'ngram_likelihood':round(lik,3)})
  if rep==0:
   (ROOT/f'decode_{seg}.txt').write_text(f'SEGMENT: {seg}\nNGRAM GUESSED: '+''.join(alpha[k] for k in ng[code])+'\nGROUND TRUTH (EVALUATION ONLY): '+t+'\n',encoding='utf8')

summary={'experiment':'ANCHOR-28','scope':'Synthetic two-homophone cipher with known variant grouping; alphabet substitution hidden; not full Naibbe', 'data':'Borg 0010r test, Borg 0010v+0011r separate reference text','reference_characters':len(train),'target_characters':len(target),'alphabet_size':m,'method':'bigram log-likelihood, 0.5 additive smoothing, 13 restarts x 750 swaps per case, fixed schedule; rank-frequency baseline', 'limitations':['Test plaintext is only 282 characters; 3 segments from same text are not independent documents','8 permutations per segment are renamings of the same text, not independent messages','An alphabet with variant groupings already known is substantially easier than full Naibbe and Voynich','Ngram fit to short genre-specific reference may overfit; result is a toy proof of concept']}
for seg,_ in segments:
 r=[x for x in runs if x['segment']==seg]
 summary[seg]={'n':r[0]['n'], 'freq_mean':statistics.mean(x['freq'] for x in r),'ngram_mean':statistics.mean(x['ngram'] for x in r),'null_mean':statistics.mean(x['null'] for x in r),'ngram_better_in':sum(x['ngram']>x['freq'] for x in r),'n_runs':len(r)}
(ROOT/'results.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
(ROOT/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
(ROOT/'reference_train.txt').write_text(train+'\n')
(ROOT/'target_evaluation.txt').write_text(target+'\n')
(ROOT/'anchor28_run.py').write_text(pathlib.Path(__file__).read_text())
print(json.dumps({k:summary[k] for k in ['full','part1','part2','part3']},indent=2))
