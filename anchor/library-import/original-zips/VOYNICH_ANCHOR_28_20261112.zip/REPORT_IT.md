# ANCHOR-28 — Recupero ciphertext-only con bigrammi

Data: 12 novembre 2026. Ramo sperimentale separato dal gate RC1.4.2.

## Domanda
Un recuperatore che utilizza i bigrammi di un corpus latino indipendente migliora rispetto a un attacco che ordina soltanto le frequenze delle lettere, senza conoscere il messaggio né la chiave del test?

## Metodo
- Testo di valutazione: Borg 0010r, 282 caratteri latini, non incluso nel modello di lingua.
- Riferimento linguistico: trascrizioni Borg 0010v e 0011r (399 caratteri alfabetici dopo normalizzazione e rimozione delle integrazioni tra parentesi).
- Codifica sintetica: permutazione segreta dell'alfabeto, con due varianti di cifratura per lettera; il raggruppamento delle varianti viene fornito all'attaccante. Non è l'algoritmo completo Naibbe.
- Algoritmi: baseline di frequenze singole; nuova ricerca su 13 ripartenze, 750 scambi ciascuna, massimizzando la log-verosimiglianza dei bigrammi con smoothing additivo 0,5. Il testo originale non è letto dalle funzioni di attacco.
- 4 porzioni di test: intero 282 caratteri, tre segmenti consecutivi di 94 caratteri. 8 chiavi per porzione. **Le chiavi diverse sugli stessi segmenti non producono messaggi indipendenti.**

## Risultati verificati

| Bersaglio | Frequenze singole | Bigrammi | Bigrammi migliori / 8 |
|---|---:|---:|---:|
| 282 caratteri | 19,7% | 50,1% | 8 |
| Primo terzo, 94 caratteri | 16,8% | 30,3% | 5 |
| Secondo terzo, 94 caratteri | 23,4% | 16,6% | 3 |
| Terzo terzo, 94 caratteri | 2,3% | 34,2% | 8 |

I valori sono medie empiriche di accuratezza carattere per carattere; sono disponibili i dati individuali in `runs.json`. Non interpretiamo una differenza nei punteggi come una stima precisa di generalizzazione: il numero di messaggi indipendenti è uno, suddiviso in porzioni correlate.

## Decisione
**RISULTATO MISTO.** L'attacco a bigrammi migliora nettamente sul testo intero, ma non è affidabile su tutti i segmenti. Il recupero senza plaintext è ancora insufficiente per una lettura. La compatibilità statistica con la scrittura Voynich non fornisce una chiave. La prossima verifica dovrebbe testare su molti messaggi indipendenti e includere l'effettiva segmentazione Naibbe e l'assenza di gruppi di omofoni forniti all'attaccante. Applicare ora la procedura al Voynich non darebbe una traduzione verificabile.

## Provenienza e limiti
File di input estratti dall'esperimento ANCHOR-27, precedentemente ottenuti da trascrizioni Borg. Modelli linguistici molto piccoli; nessuna ottimizzazione su ZL3b/Takahashi; nessun confronto con una cifra Voynich eseguito in ANCHOR-28. Non sono presentati p-value perché i campioni non sostengono un test di significatività su documenti indipendenti.
