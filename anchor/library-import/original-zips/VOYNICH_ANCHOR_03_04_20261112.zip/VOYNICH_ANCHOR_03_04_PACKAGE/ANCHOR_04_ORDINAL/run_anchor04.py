#!/usr/bin/env python3
import re,csv,json,hashlib,random,collections,itertools,statistics,math,argparse
from pathlib import Path
import numpy as np

PIN='bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc'
SIGNS={'Pisces':['f70v2'],'Aries':['f70v1','f71r'],'Taurus':['f71v','f72r1'],'Cancer':['f72r3'],'Leo':['f72v3'],'Virgo':['f72v2'],'Libra':['f72v1']}
HOLD={'Scorpio':['f73r'],'Sagittarius':['f73v']}
N=20000;SEED=2026111205

def load(path):
    out=collections.defaultdict(list)
    for line in Path(path).read_text().splitlines():
        m=re.match(r'^<([^>,]+),([@&]Lz)>\s*(.*)$',line)
        if not m:continue
        loc=m.group(1);page=loc.split('.')[0]
        s=re.sub(r'<!.*?>','',m.group(3)).strip().lower();t=re.findall('[a-z]+',s)
        if not t:raise ValueError(f'No first group: {loc}')
        out[page].append({'loc':loc,'first':t[0],'raw':s})
    return out

def feat(s):
    return set(s[i:i+k] for k in [2,3] for i in range(max(0,len(s)-k+1)))

def run(path,out):
    if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=PIN:raise RuntimeError('corpus mismatch')
    pages=load(path)
    data={sign:[v for p in pp for v in pages[p]] for sign,pp in SIGNS.items()}
    assert all(len(v)==30 for v in data.values()),{k:len(v) for k,v in data.items()}
    assert all(len([v for p in pp for v in pages[p]])==30 for pp in HOLD.values())
    signs=list(data);rows=[r for sign in signs for r in data[sign]]; words=[r['first'] for r in rows]
    feats=[feat(s) for s in words]
    dic=sorted(set(x for f in feats for x in f));index={v:i for i,v in enumerate(dic)}
    M=np.zeros((len(rows),len(dic)),dtype=np.float32)
    for i,f in enumerate(feats):
        for x in f:M[i,index[x]]=1
    norms=np.linalg.norm(M,axis=1)
    norm=np.divide(M,norms[:,None],out=np.zeros_like(M),where=norms[:,None]>0)
    cos=norm@norm.T
    prefix=np.array([s[:2] for s in words]);suffix=np.array([s[-2:] for s in words]);peq=(prefix[:,None]==prefix[None,:]).astype('float32');seq=(suffix[:,None]==suffix[None,:]).astype('float32')
    matrices=[cos,peq,seq];pair_index=list(itertools.combinations(range(len(signs)),2));pos=np.arange(30)
    baseline=np.arange(len(rows)).reshape(len(signs),30)
    def measure(mapping):
        return np.array([np.mean([mat[mapping[i],mapping[j]].mean() for i,j in pair_index]) for mat in matrices],float)
    observed=measure(baseline)
    rng=np.random.default_rng(SEED)
    perm_scores=np.zeros((N,3),dtype=float)
    for b in range(N):
        candidate=baseline.copy()
        for i in range(len(signs)):
            for sl in (slice(0,15),slice(15,30)):
                candidate[i,sl]=rng.permutation(candidate[i,sl])
        perm_scores[b,:]=measure(candidate)
    avg=perm_scores.mean(axis=0);sd=perm_scores.std(axis=0,ddof=0)
    zs=(observed-avg)/np.maximum(sd,1e-15)
    Z=(perm_scores-avg)/np.maximum(sd,1e-15)
    max_null=Z.max(axis=1)
    ps=(1+(perm_scores>=observed-1e-12).sum(axis=0))/(N+1)
    pmax=(1+np.array([(max_null>=z-1e-12).sum() for z in zs]))/(N+1)
    result={'study':'ANCHOR-04 degree-ordinal repeated signature','status':'EXPLORATORY_NOT_SEMANTIC','source_sha256':PIN,'signs':signs,'n_signs':len(signs),'n_labels':len(rows),'holdout_unseen_by_this_test':list(HOLD),'n_positions':30,'n_sign_pairs':len(pair_index),'permutations':N,'seed':SEED,'within_each_sign_halves_shuffled':True,'results':[{ 'metric':name,'observed':float(observed[i]),'null_mean':float(avg[i]),'null_sd':float(sd[i]),'z':float(zs[i]),'nominal_upper_p':float(ps[i]),'maxT_fwer_p':float(pmax[i])} for i,name in enumerate(['char2to3_presence_cosine','first2_equal','last2_equal'])],'notes':['Does not verify zodiac geometrical slot order, 30 labels are not automatically 30 degree names.','No variation of cyclic offsets, light-half-first conventions, or cross-sign shifts is tested.','Texts had been inspected in previous work and model choice is exploratory; these p values are not externally preregistered.','No claim about numbers, names or plaintext content.']}
    out.mkdir(parents=True,exist_ok=True)
    (out/'anchor04_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    with open(out/'slot_inventory.csv','w',newline='') as fh:
        w=csv.DictWriter(fh,fieldnames=['sign','slot','locus','first','raw']);w.writeheader()
        for sign in signs:
            for ix,r in enumerate(data[sign],1):w.writerow({'sign':sign,'slot':ix,'locus':r['loc'],'first':r['first'],'raw':r['raw']})
    print(json.dumps(result['results'],indent=2))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--corpus',required=True);ap.add_argument('--out',required=True)
    a=ap.parse_args();run(a.corpus,Path(a.out))
