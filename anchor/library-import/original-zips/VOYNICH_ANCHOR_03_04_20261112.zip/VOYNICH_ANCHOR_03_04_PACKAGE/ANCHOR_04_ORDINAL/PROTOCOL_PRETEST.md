# ANCHOR-04: Repeated degree-ordinal signature test, exploratory local precommit

This protocol was authored before running the test; this is NOT external preregistration. Data in earlier exploratory work have been seen, so the reserved samples are not strictly blind.

**Question:** If labels encode the same 1..30 ordinal numbers, degree positions, or reusable per-degree categories in different zodiac signs, is text at matching ordinal locations more morphologically similar than expected when labels are reassigned within the same half of each sign?

**Source:** SHA-pinned ZL3b-n.txt; only @Lz and &Lz classes; parse the FIRST contiguous EVA `[a-z]+` segment after removing inline IVTFF comments; do not infer a translation. Seven 30-label signs selected without new visual review: Pisces=f70v2, Aries=f70v1 then f71r, Taurus=f71v then f72r1, Cancer=f72r3, Leo=f72v3, Virgo=f72v2, Libra=f72v1. Exclude Gemini due 29 labels. Reserve Scorpio=f73r and Sagittarius=f73v for potential challenge; not a strict held-out sample due earlier metadata inspection.

**Degree indexing:** literal IVTFF locus order as recorded in each panel, then concatenation for half-signs in increasing folio order; slots 1..30. Orientation and start phase NOT confirmed by independent geometric review, so a non-result cannot falsify all rotational/ordering variants.

**Locked metrics, all one-sided for positive similarity:** (1) mean cosine of pooled character bigram+trigram presence vectors, computed on the first EVA group only, across 21 pairs of signs at identical ordinal indices; (2) fraction of same first-two-character label among sign-pairs at the same index; (3) same last-two-character label. Text transform only once, no interpretive re-tokenization.

**Null:** 20,000 random permutations that independently shuffle ordinal slots within [1..15] and [16..30] of each sign. Thus page/half lexical variation is preserved, making this a conservative test of repeated **fine** ordinal positions not mere 15+15 differences. Fixed seed 2026111205. Use plus-one Monte Carlo p. Adjust across 3 tests via maxT using standardized permuted null scores (z based on null mean and sd). No optimizing cyclic shifts or sign order; such scans would require a new corrected analysis. Discovery threshold exploratory p_FWER <0.01 AND independent external controls for any semantic claim.
