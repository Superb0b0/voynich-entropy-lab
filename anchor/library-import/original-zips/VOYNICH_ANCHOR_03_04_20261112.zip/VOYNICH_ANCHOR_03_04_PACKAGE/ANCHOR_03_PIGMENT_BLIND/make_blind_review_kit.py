#!/usr/bin/env python3
"""Create a *candidate* text-masked body-only review kit. No blind certification.
Rendered labels were masked with recorded polygons; other unmasked writing may remain.
"""
from pathlib import Path
import csv,json,math,random,hashlib
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from shapely.geometry import Polygon,box

P=Path(__file__).resolve().parent.parent/'ANCHOR_01_GEOMETRY_PILOT'
OUT=Path(__file__).resolve().parent/'results'/'review_kit_UNCERTIFIED'
OUT.mkdir(exist_ok=True,parents=True)
coords=json.loads((P/'coordinates_draft.json').read_text())['records']
bodies=[r for r in coords if r['kind']=='body']
labels=[r for r in coords if r['kind']=='label']
key=list(csv.DictReader(open(Path(__file__).resolve().parent.parent/'ANCHOR_02_RESULTS'/'CUSTODIAN_CROP_KEY.csv')))
fig2blind={r['figure_id']:r['blind_id'] for r in key}
source_img={'f70v1':Image.open(P/'sources'/'1006201.jpg').convert('RGB'), 'f71r':Image.open(P/'sources'/'1006202.jpg').convert('RGB')}
if set(fig2blind)!={r['id'] for r in bodies}:raise ValueError('blind key mismatch')
rows=[]
for fig in bodies:
    f_id=fig['id'];bid=fig2blind[f_id];im=source_img[fig['page_id']].copy()
    bb=np.array(fig['preview_polygon'],float);x1,y1=np.floor(bb.min(axis=0)).astype(int);x2,y2=np.ceil(bb.max(axis=0)).astype(int)
    x1=int(max(0,x1));y1=int(max(0,y1));x2=int(min(im.width,x2));y2=int(min(im.height,y2))
    if x2<=x1 or y2<=y1:raise ValueError(f_id)
    bodypoly=Polygon(bb)
    overlaps=[]
    mask=Image.new('L',im.size,0);d=ImageDraw.Draw(mask)
    for lb in labels:
        if lb['page_id']!=fig['page_id']:continue
        q=Polygon(lb['preview_polygon']);inter=q.intersection(box(x1,y1,x2,y2))
        if not inter.is_empty:
            overlaps.append((lb['id'],round(inter.area/((x2-x1)*(y2-y1)),5),bool(q.intersects(bodypoly))))
            d.polygon([tuple(map(float,p)) for p in lb['preview_polygon']],fill=255)
    # replace known label polygons by a neutral patch, conservative: not a guarantee for unannotated text
    neutral=Image.new('RGB',im.size,(231,216,191))
    im.paste(neutral,(0,0),mask)
    crop=im.crop((x1,y1,x2,y2));crop.save(OUT/(bid+'.png'))
    rows.append({'blind_id':bid,'source_page':fig['page_id'],'figure_id':f_id,'masked_registered_labels':len(overlaps),'masked_label_area_fraction':round(sum(x[1] for x in overlaps),4),'any_label_polygon_touches_body':int(any(x[2] for x in overlaps)),'unregistered_text_leak':'PENDING_INDEPENDENT_VISUAL_CHECK','full_body_visible':'PENDING_INDEPENDENT_VISUAL_CHECK','color_integrity':'UNASSESSED','source_crop_bbox':json.dumps([x1,y1,x2,y2]),'overlap_details':json.dumps(overlaps)})
rows.sort(key=lambda x:x['blind_id'])
with open(OUT/'QC_REVIEW_GATE.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
with open(OUT/'CUSTODIAN_LINK_KEY_INTERNAL.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['blind_id','figure_id','page_id']);w.writeheader();w.writerows([{'blind_id':r['blind_id'],'figure_id':r['figure_id'],'page_id':r['source_page']} for r in rows])
for reviewer in ['R01','R02']:
    with open(OUT/f'ATTRIBUTES_{reviewer}_EMPTY.csv','w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['blind_id','reviewer_id','unregistered_text_visible_yes_no_uncertain','body_complete_yes_no_uncertain','red_pigment_on_figure_yes_no_uncertain','green_pigment_on_figure_yes_no_uncertain','blue_pigment_on_figure_yes_no_uncertain','headwear_yes_no_uncertain','notes']);w.writeheader();w.writerows([{'blind_id':r['blind_id'],'reviewer_id':reviewer} for r in rows])
ids=[r['blind_id'] for r in rows];random.Random(2026111204).shuffle(ids)
W,H=1100,math.ceil(len(ids)/5)*180
board=Image.new('RGB',(W,H),'white');d=ImageDraw.Draw(board)
for idx,bid in enumerate(ids):
    i,j=divmod(idx,5);crop=Image.open(OUT/(bid+'.png'));crop.thumbnail((202,142))
    x=j*220+(220-crop.width)//2;y=i*180+23+(143-crop.height)//2
    board.paste(crop,(x,y));d.text((j*220+12,i*180+4),bid,fill='black')
board.save(OUT/'CONTACT_SHEET_MASKED_UNCERTIFIED.jpg',quality=92)
report={'status':'MASKED_CANDIDATE_NOT_BLIND_CERTIFIED','n':len(rows),'registered_text_polygon_overlap_in_crops':sum(x['masked_registered_labels']>0 for x in rows),'registered_label_polygon_body_intersections':sum(x['any_label_polygon_touches_body']>0 for x in rows),'manual_checks_needed_per_crop':['unregistered writing or watermark present','limbs and garment not cropped out','masked patches do not conceal a visual attribute','true source body ID','no exposure to old figures/figure IDs when annotating'],'warning':'Known label masks are not sufficient to guarantee blindness; reviewer sheets are empty and independent review has not occurred.'}
(OUT/'KIT_STATUS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
