#!/usr/bin/env python3
"""Read-only new color-text cross-modal exploratory test for 30 zodiac labels.
Never imports historical RC1.4.2 modules, never modifies historical sources.
"""
from pathlib import Path
from collections import defaultdict, Counter
import argparse,csv,hashlib,colorsys,json,re,random,math,statistics,sys
import numpy as np
from PIL import Image

SEED=2026111203
B=20000
KNOWN_ZL_SHA='bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc'
COLORS=['red','green','blue','any_color']
LETTERS='acdehklorsty'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def raw_rgb_counts(image, polygon):
    box=np.array(polygon,float)
    x1=max(0,math.floor(box[:,0].min()));x2=min(image.shape[1],math.ceil(box[:,0].max()))
    y1=max(0,math.floor(box[:,1].min()));y2=min(image.shape[0],math.ceil(box[:,1].max()))
    arr=image[y1:y2,x1:x2,:3].astype(float)/255.
    if arr.size==0:raise ValueError('empty region')
    r,g,b=arr[...,0],arr[...,1],arr[...,2]
    mx=np.maximum.reduce([r,g,b]);mn=np.minimum.reduce([r,g,b]);delta=mx-mn
    sat=np.divide(delta,mx,out=np.zeros_like(mx),where=mx>0)
    hue=np.zeros_like(mx);nz=delta>1e-9
    where=nz & (mx==r);hue[where]=(60*((g[where]-b[where])/delta[where])%360)
    where=nz & (mx==g);hue[where]=(60*((b[where]-r[where])/delta[where]+2))
    where=nz & (mx==b);hue[where]=(60*((r[where]-g[where])/delta[where]+4))
    valid=(sat>=.25)&(mx>=.12)&(mx<=.90)
    masks={'red':valid&((hue<20)|(hue>=345)), 'green':valid&(hue>=75)&(hue<175), 'blue':valid&(hue>=175)&(hue<255)}
    v={k:int(x.sum()) for k,x in masks.items()}
    v['any_color']=sum(v.values())
    v['area']=int(arr.shape[0]*arr.shape[1]);v['bbox']=[x1,y1,x2,y2]
    for k in COLORS:v[k+'_frac']=v[k]/v['area']
    return v

def parse_transcriptions(p):
    rx=re.compile(r'^<([^>,]+),([@&]Lz)>\s*(.*)$')
    out={}
    for ln in Path(p).read_text().splitlines():
        m=rx.match(ln)
        if m:
            locus=m.group(1)
            if locus.split('.')[0] not in ('f70v1','f71r'):continue
            s=re.sub(r'<!.*?>','',m.group(3)).strip()
            toks=re.findall('[a-z]+',s.lower())
            if not toks:raise ValueError('No text '+locus)
            if locus in out:raise ValueError('Duplicate Lz '+locus)
            out[locus]={'locus':locus,'raw':s,'first':toks[0], 'n_chunks':len(toks)}
    return out

def build_features(rows):
    N=len(rows);features={}
    prefixes=Counter(r['first'][:2] for r in rows);suffixes=Counter(r['first'][-2:] for r in rows)
    for p,c in sorted(prefixes.items()):
        if 3<=c<=N-3:features['prefix2='+p]=[int(r['first'][:2]==p) for r in rows]
    for p,c in sorted(suffixes.items()):
        if 3<=c<=N-3:features['suffix2='+p]=[int(r['first'][-2:]==p) for r in rows]
    for c in LETTERS:features['has_char='+c]=[int(c in r['first']) for r in rows]
    features['first_length_ge_7']=[int(len(r['first'])>=7) for r in rows]
    features['two_or_more_chunks']=[int(r['n_chunks']>=2) for r in rows]
    return features

def centered(v,blocks):
    y=np.asarray(v,float).copy()
    for inds in blocks:y[inds]-=y[inds].mean()
    return y

def main():
    a=argparse.ArgumentParser();a.add_argument('--pilot',required=True);a.add_argument('--zl3b',required=True);a.add_argument('--geometry',required=True);a.add_argument('--out',required=True);a=a.parse_args()
    base=Path(a.pilot);out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    if sha(a.zl3b)!=KNOWN_ZL_SHA:raise RuntimeError('ZL3b SHA NOT MATCHED')
    coord=json.loads((base/'coordinates_draft.json').read_text())['records']
    labels=parse_transcriptions(a.zl3b)
    imgs={p:np.array(Image.open(base/'sources'/f'{oid}.jpg').convert('RGB')) for p,oid in [('f70v1',1006201),('f71r',1006202)]}
    bodies={r['id']:r for r in coord if r['kind']=='body'}
    assert len(bodies)==30 and len(labels)==30
    pigment={k:raw_rgb_counts(imgs[r['page_id']],r['preview_polygon']) for k,r in bodies.items()}
    with open(a.geometry,newline='') as f: mappings=list(csv.DictReader(f))
    assert len(mappings)==30
    rows=[]
    for m in mappings:
        locus=m['locus']; fig=m['forced_assignment']; r={**labels[locus],**m, 'figure_id':fig, **pigment[fig]}
        r['stratum']=r['page']+'_'+r['ring'];rows.append(r)
    rows.sort(key=lambda r:(r['page'],r['ring'],int(r['locus'].split('.')[-1])))
    strata=defaultdict(list)
    for i,r in enumerate(rows):strata[r['stratum']].append(i)
    blocks=list(strata.values());assert sorted(map(len,blocks))==[5,5,10,10]
    tex=build_features(rows)
    X={name:centered(vals,blocks) for name,vals in tex.items()}
    X={k:v for k,v in X.items() if np.linalg.norm(v)>1e-12}
    Xkeys=list(X)
    Y={c:centered([r[c+'_frac'] for r in rows],blocks) for c in COLORS}
    Ykeys=[k for k,v in Y.items() if np.linalg.norm(v)>1e-12]
    Xarr=np.column_stack([X[k]/np.linalg.norm(X[k]) for k in Xkeys]);Yarr=np.column_stack([Y[k]/np.linalg.norm(Y[k]) for k in Ykeys]);O=np.abs(Xarr.T @ Yarr)
    ii,jj=np.unravel_index(int(np.argmax(O)),O.shape);obs=float(O[ii,jj]);pair=(Xkeys[ii],Ykeys[jj])
    rng=np.random.default_rng(SEED);maxvals=np.empty(B);single=np.empty(B)
    for b in range(B):
        perm=np.arange(len(rows))
        for inds in blocks:perm[inds]=rng.permutation(inds)
        ss=np.abs(Xarr.T@Yarr[perm]);maxvals[b]=ss.max();single[b]=ss[ii,jj]
    pmax=float((1+np.sum(maxvals>=obs-1e-12))/(B+1));pnom=float((1+np.sum(single>=obs-1e-12))/(B+1))
    res={'status':'EXPLORATORY_NOT_VALIDATED','n_loci':len(rows),'n_strata':len(strata),'strata':{k:len(v) for k,v in strata.items()},'n_text_features':len(Xkeys),'n_image_features':len(Ykeys),'n_tests':int(O.size),'test':'within-stratum-centered absolute Pearson, joint pigment permutations within strata, family-wise max statistic','B':B,'seed':SEED,'best_feature':pair[0],'best_color':pair[1],'best_abs_correlation':obs,'uncorrected_nominal_p':pnom,'familywise_maxT_p':pmax,'maxT_null_quantiles':{str(q):float(np.quantile(maxvals,q)) for q in [.50,.90,.95,.99]},'color_ranges':{k:[float(min(r[k+'_frac'] for r in rows)),float(max(r[k+'_frac'] for r in rows))] for k in COLORS},'n_orig_nearest_disagreement':sum(r['forced_assignment']!=r['original_nearest'] for r in rows),'n_source_warnings':sum(r['source_warning']=='True' for r in rows),'source_checksums':{'ZL3b':sha(a.zl3b),'coordinates_draft':sha(base/'coordinates_draft.json'),'geometry_diagnostic_links':sha(a.geometry),'1006201.jpg':sha(base/'sources/1006201.jpg'),'1006202.jpg':sha(base/'sources/1006202.jpg')},'caveats':['One operator geometry; no independent figure-locus validation; 30 ambiguous links','Body bounding polygons include varying amounts of surrounding parchment, colored stars and potentially text; color pixel counts not certified garment colors','Color may have been applied later and can vary for nonsemantic reasons','A significant association would be exploratory only and cannot be interpreted as translation','Labels on same diagram have shared compositional dependencies; 4 strata constrain but do not validate individual-unit independence']}
    best=[]
    for i,key in enumerate(Xkeys):
        for j,col in enumerate(Ykeys):best.append({'text_feature':key,'color_feature':col,'abs_corr':float(O[i,j])})
    best.sort(key=lambda x:-x['abs_corr']);res['top_exploratory_tests']=best[:15]
    (out/'results.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
    keys=['locus','page','ring','figure_id','raw','first','n_chunks','red_frac','green_frac','blue_frac','any_color_frac','source_warning','forced_assignment','original_nearest']
    with (out/'joined_color_text_PROVISIONAL.csv').open('w',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=keys);wr.writeheader();wr.writerows([{k:r[k] for k in keys} for r in rows])
    with (out/'body_pixel_metrics.csv').open('w',newline='') as f:
        keys=['figure_id','page_id','ring','area','red','green','blue','any_color','red_frac','green_frac','blue_frac','any_color_frac','bbox']
        wr=csv.DictWriter(f,fieldnames=keys);wr.writeheader();wr.writerows([{**{'figure_id':fig,'page_id':bodies[fig]['page_id'],'ring':bodies[fig]['ring']},**pigment[fig]} for fig in sorted(bodies)])
    print(json.dumps({k:res[k] for k in ['n_loci','strata','n_text_features','n_image_features','best_feature','best_color','best_abs_correlation','uncorrected_nominal_p','familywise_maxT_p','n_orig_nearest_disagreement','n_source_warnings']},indent=2))

if __name__=='__main__':main()
