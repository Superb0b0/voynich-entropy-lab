#!/usr/bin/env python3
"""Second purely geometric matcher: angular order, not pixel-label semantics.
Tests a cyclic one-to-one order of label and body centroids and center perturbations.
"""
from pathlib import Path
from collections import defaultdict
import json,csv,math,hashlib,statistics
import numpy as np

PILOT=Path(__file__).resolve().parent.parent/'ANCHOR_01_GEOMETRY_PILOT'
GEOM=Path(__file__).resolve().parent.parent/'ANCHOR_02_RESULTS'/'geometry_diagnostic_links.csv'
OUT=Path(__file__).resolve().parent/'results'

def center(q):return np.array(q['preview_polygon'],float).mean(axis=0)
def angle(q,centerxy):
    x,y=center(q)-centerxy
    return math.atan2(y,x)%(2*math.pi)
def circular_abs(x,y):return abs(((x-y+math.pi)%(2*math.pi))-math.pi)
def get_pairing(F,L,c):
    fs=sorted(F,key=lambda z:angle(z,c));ls=sorted(L,key=lambda z:angle(z,c)); n=len(fs)
    candidates=[]
    for k in range(n):
        pairs=[(l,fs[(i+k)%n]) for i,l in enumerate(ls)]
        cost=sum(circular_abs(angle(l,c),angle(f,c)) for l,f in pairs)
        candidates.append((cost,k,pairs))
    candidates.sort(key=lambda x:x[0]);return candidates

def main():
    data=json.load(open(PILOT/'coordinates_draft.json'))['records'];r={q['id']:q for q in data}
    links={q['locus']:q for q in csv.DictReader(open(GEOM))}
    output=[];rows=[]
    for page in ['f70v1','f71r']:
        outer=[q for q in data if q['page_id']==page and q['ring']=='outer' and q['kind']=='body']
        points=np.array([center(q) for q in outer]);fit=np.linalg.lstsq(np.column_stack([2*points,np.ones(len(points))]),np.sum(points*points,axis=1),rcond=None)[0][:2]
        for ring in ['outer','inner']:
            F=[q for q in data if q['page_id']==page and q['ring']==ring and q['kind']=='body']
            L=[q for q in data if q['page_id']==page and q['ring']==ring and q['kind']=='label']
            assert len(F)==len(L) and len(F) in [5,10]
            cand=get_pairing(F,L,fit)
            best,second=cand[:2]
            bdict={l['label_locus_id']:f['id'] for l,f in best[2]}
            gcount=sum(bdict[l]==links[l]['forced_assignment'] for l in bdict)
            shift_grid=range(-40,41,10)
            stable=0
            details=[]
            for dx in shift_grid:
                for dy in shift_grid:
                    pairs=get_pairing(F,L,fit+np.array([dx,dy]))[0][2]
                    cur={l['label_locus_id']:f['id'] for l,f in pairs}
                    count=sum(cur[l]==bdict[l] for l in bdict)
                    stable+=count==len(L)
                    details.append(count)
            for l,f in best[2]:
                rows.append({'locus':l['label_locus_id'],'figure_angular':f['id'],'figure_global_min_cost':links[l['label_locus_id']]['forced_assignment'], 'match_global':int(f['id']==links[l['label_locus_id']]['forced_assignment']),'page':page,'ring':ring,'center_x':round(fit[0],2),'center_y':round(fit[1],2),'angle_distance_deg':round(math.degrees(circular_abs(angle(l,fit),angle(f,fit))),2)})
            output.append({'page':page,'ring':ring,'n':len(F),'fitted_center_preview_px':list(map(float,fit)), 'optimal_cyclic_shift':best[1],'best_angular_cost_deg':math.degrees(best[0]),'next_best_cost_deg':math.degrees(second[0]),'shift_cost_margin_deg':math.degrees(second[0]-best[0]),'matching_angular_vs_global':gcount,'center_perturbations_81_full_match':stable,'mean_loci_matching_baseline_across_81':statistics.mean(details),'joint_one_to_one':true()})
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'angular_order.json').write_text(json.dumps({'status':'NON_INDEPENDENT_GEOMETRIC_DIAGNOSTIC','method':'Ringwise circle fit (outer body centroids); cyclic rank matching chooses minimum total absolute angle and 9x9 center perturbations of +/-40 preview px','rows':output,'matches':sum(x['match_global'] for x in rows),'n':len(rows),'limitation':'Same single-operator polygons, order analysis is NOT an independent validation of figure identity or label reading'},ensure_ascii=False,indent=2)+'\n')
    with open(OUT/'angular_matches.csv','w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print(json.dumps(output,indent=2))
def true():return True
if __name__=='__main__':main()
