# VOYNICH ANCHOR-03 / ANCHOR-04 — 12-11-2026

**Results are exploratory and do NOT decipher any text. Original RC1.4.2 frozen work is not included nor modified.**

## Reproduce color-text test

Run from this directory, Python with `numpy`, `Pillow`, `scipy` (scipy used only in preceding experiment), `shapely` for figure review kit:

```bash
python ANCHOR_03_PIGMENT_BLIND/run_anchor03.py \
  --pilot ANCHOR_01_GEOMETRY_PILOT \
  --zl3b corpus/ZL3b-n.txt \
  --geometry ANCHOR_02_RESULTS/geometry_diagnostic_links.csv \
  --out /tmp/anchor03_verify
python ANCHOR_03_PIGMENT_BLIND/run_angular_order.py
python ANCHOR_04_ORDINAL/run_anchor04.py \
  --corpus corpus/ZL3b-n.txt \
  --out /tmp/anchor04_verify
```

**Warning:** `run_angular_order.py` writes inside ANCHOR_03_PIGMENT_BLIND/results. Historical sources are read-only. `make_blind_review_kit.py` likewise writes a new result kit. Empty reviewer sheets are NOT independently reviewed.

The main package contains link keys and transcriptions. Do NOT share it with blinded figure annotators. Separate reviewer-only archives were also created, but **their crop-blindness gate is not satisfied**: residual writing and body visibility require visual certification first.

SHA256SUMS lists internal file hashes.
