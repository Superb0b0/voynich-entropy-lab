#!/usr/bin/env python3
"""ANCHOR-11 diagnostic. Independent from all RC1.4 parser/builders.
Tests only the strong, explicitly stated notion that f57v.3 is a complete
non-repeating alphabet for literal EVA letters in running text.
No linguistic or semantic inference is coded or claimed.
"""
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXPECTED = {
    "ZL3b-n.txt": "bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc",
    "IT2a-n.txt": "7f27a8b0feed8f6de0a99900df6bf912dd1d295c38e5f830bac8b41c3f536fb5",
}


def analyze(filename):
    raw = (ROOT / "inputs" / filename).read_bytes()
    observed = hashlib.sha256(raw).hexdigest()
    if observed != EXPECTED[filename]:
        raise ValueError(f"SHA-256 mismatch {filename}: {observed}")
    lines = raw.decode("utf-8-sig").splitlines()
    match = next((x for x in lines if x.startswith("<f57v.3,")), None)
    if match is None:
        raise ValueError("f57v.3 not found")
    ring_body = re.sub(r"^\s*<![^>]*>", "", match.split(">", 1)[1]).strip()
    delimiter = "." if filename.startswith("ZL3b") else "<->"
    ring_units = ring_body.split(delimiter)
    base = ring_units[:17]
    # A direct complete alphabet cannot repeat the same sign in the same cycle.
    duplicated = {k: v for k, v in Counter(base).items() if v > 1}
    eva = sorted({x for x in ring_units if re.fullmatch(r"[a-z]", x)})
    ring_set = set(eva)
    words = []
    for line in lines:
        m = re.match(r"^<([^>]+)>\s*(.*)", line)
        if not m or not re.search(r",\+P\d+", m[1]):
            continue
        body = re.sub(r"<![^>]*>", " ", m[2])
        body = re.sub(r"\[[^\]]*\]", " ", body)
        body = re.sub(r"\{[^}]*\}", " ", body)
        body = re.sub(r"<[^>]*>", " ", body)
        words.extend(w for w in re.findall(r"[a-z]+", body) if len(w) >= 2)
    character_counter = Counter("".join(words))
    top_eva = {k for k, _ in character_counter.most_common(len(eva))}
    n_chars = character_counter.total()
    assert n_chars
    return {
        "source_file": filename,
        "sha256": observed,
        "ring_locus": "f57v.3",
        "ring_literal_units": len(ring_units),
        "first_cycle_17_units": base,
        "first_cycle_duplicate_literally_transcribed_units": duplicated,
        "ring_unique_literal_units_all_cycles": len(set(ring_units)),
        "ordinary_single_letter_eva_in_ring_all_cycles": eva,
        "ordinary_single_letter_eva_count": len(eva),
        "P_word_tokens_len_ge_2_exploratory": len(words),
        "P_eva_characters_in_those_words": n_chars,
        "character_coverage_ring_eva": round(sum(character_counter[ch] for ch in ring_set) / n_chars, 6),
        "word_coverage_ring_eva": round(sum(set(w).issubset(ring_set) for w in words) / len(words), 6),
        "frequency_matched_top_letters": sorted(top_eva),
        "character_coverage_top_letters": round(sum(character_counter[ch] for ch in top_eva) / n_chars, 6),
        "word_coverage_top_letters": round(sum(set(w).issubset(top_eva) for w in words) / len(words), 6),
        "most_frequent_letters_absent_from_ring": [[k, v] for k, v in character_counter.most_common() if k not in ring_set][:12],
        "method_caveat": "+P line regex only; literal ASCII glyphs, not physical glyph inventory or RC1.4 tokenization. Ring contains special units and uncertain readings; cannot falsify a partial codebook, operators, or multi-symbol spelling rules.",
    }


def main():
    outputs = [analyze(filename) for filename in EXPECTED]
    assert outputs[0]["P_word_tokens_len_ge_2_exploratory"] == 30835
    assert outputs[1]["P_word_tokens_len_ge_2_exploratory"] == 30864
    out = {"experiment": "ANCHOR-11", "status": "DIAGNOSTIC_EXPLORATORY_NOT_SEMANTIC_VALIDATION", "datasets": outputs,
           "hypothesis": "f57v.3 is a complete alphabet of non-repeating literal EVA signs sufficient to render the running text",
           "verdict": "NOT_SUPPORTED_STRONG_DIRECT_ALPHABET_MODEL", "rc1_4_2_status_unchanged": "CLOSED_PENDING_VALIDATION"}
    (ROOT / "results.json").write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for d in outputs:
        print(d["source_file"], "ring_units", d["ring_literal_units"], "distinct ordinary ring glyphs", d["ordinary_single_letter_eva_count"],
              "word_cov", d["word_coverage_ring_eva"], "char_cov", d["character_coverage_ring_eva"])


if __name__ == "__main__":
    main()
