# VOYNICH — ANCHOR-11

**12 novembre 2026 | Diagnostica esplorativa autonoma. Non è una decifrazione.**

## Domanda

Il ciclo di segni presente in `f57v.3` può fungere direttamente da **alfabeto di sostituzione completo e senza ripetizioni**, sufficiente a leggere il testo corrente? Questo è un modello forte e deliberatamente ristretto. Non è equivalente all'affermazione più generale «il foglio contiene una chiave parziale, una tabella o uno strumento di calcolo».

## Dati e verifica

- `ZL3b-n.txt`: 411.671 byte; SHA-256 `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc`.
- `IT2a-n.txt`: 342.104 byte; SHA-256 `7f27a8b0feed8f6de0a99900df6bf912dd1d295c38e5f830bac8b41c3f536fb5`.
- Entrambe le copie verificate con SHA-256 sui byte effettivi. Nessun file RC1.4.2 modificato o parser relativo eseguito.
- `f57v.3` letto direttamente da ciascuna trascrizione. Le parole testuali sono estratte soltanto dalle righe contrassegnate `+P` con una procedura autonoma: rimossi commenti inline e segmenti incerti fra quadre, poi estratti i gruppi ASCII minuscoli di lunghezza almeno due. Questo **non è** il corpus canonico RC1.4 e non sostituisce alcuna attestazione precedente.

## Calcolo

| Indicatore | ZL3b | IT2a |
|---|---:|---:|
| Unità delimitate nell'anello | 68 | 69 |
| Segni EVA minuscoli singoli distinti nell'intero anello | 13 | 14 |
| Token `+P` di almeno due lettere estratti | 30.835 | 30.864 |
| Proporzione di caratteri testuali appartenenti all'insieme dell'anello | 55,72% | 59,38% |
| Proporzione di parole formate *solo* da segni dell'anello | **9,23%** | **9,02%** |
| Proporzione di parole coperte da un insieme di lettere altrettanto grande ma scelto per frequenza | 63,69% | 77,44% |

L'inventario dell'anello esclude, in entrambe le trascrizioni, unità EVA frequentissime quali `e`, `h`, `a`, `i`, `q`, `s`. Le 17 posizioni del primo ciclo non sono 17 voci uniche: in ZL3b `r` si presenta due volte. In IT2a sono ripetuti `r` e `k` (oltre a più marcatori `?`, la cui conflazione non autorizza a parlare di segni fisicamente uguali).

I risultati sulla **copertura** sono condizionali ai segni EVA: un carattere EVA può essere un componente di un grafema e non una lettera reale. Un alfabeto di cifratura *complesso* può infatti usare gruppi, abbreviazioni, omografi o operatori. Per questo i risultati non dimostrano che f57v sia privo di utilità.

## Confronto storico con Cgm 7958

La Bayerische Staatsbibliothek conserva Cgm 7958, manoscritto collegato alla tradizione di Johannes Hartlieb (1456), digitalizzato come oggetto BSB `bsb00144181`:
https://api.digitale-sammlungen.de/iiif/presentation/v2/bsb00144181/manifest

Il preprint 2026 di Edwin M. Honeycutt III documenta per questo codice un dispositivo onomantico, una ruota di esiti a quattro quadranti (`f.14r`), un inventario di alfabeti (`ff.22r–23v`), conteggi astronomici e tabelle di valore delle lettere. La fonte primaria esiste; in questa sessione **non è stato possibile estrarre e verificare integralmente le sue immagini IIIF ad alta risoluzione**. Non si attribuisce quindi alcun riscontro paleografico nuovo a Cgm 7958.

Il parallelo di classe (strumenti medievali che combinano scritture, diagrammi e calcoli) sopravvive. **Una chiave diretta di lettura non è attestata**: mancano una mappa verificabile dei segni, un ordine univoco preservato e un esempio con operazione e risultato confrontabili nei due manoscritti.

Riferimenti: https://zenodo.org/records/23068602 ; https://www.johanneshartlieb.com/cgm7958 ; https://vib.tamagothi.de/index.php?id=f57v&show=page .

## La decisione

- **Non sostenuta**: lettura di `f57v.3` come alfabeto EVA completo di sostituzione diretta del testo corrente.
- **Aperta ma non dimostrata**: inventario parziale, indice di operatori, dispositivo computazionale o sequenza visiva rituale.
- **Nessuna nuova attribuzione semantica** dei singoli segni.
- **Nessuna equivalenza Hartlieb–Voynich** individuata.

## Priorità seguente: una prova con un oracolo esterno

Giovanni Fontana (prima metà del XV secolo) è un test più falsificabile del semplice «due ruote si somigliano». Due suoi manoscritti cifrati, *Bellicorum instrumentorum liber* (BSB Cod. icon. 242) e *Secretum de thesauro* (BnF NAL 635), utilizzano una sostituzione il cui funzionamento è stato ricostruito. Occorre ottenere una **coppia cifrato/testo decifrato documentata e con folio**, conservarla come controllo positivo, applicare esattamente la stessa procedura al Voynich e aggiungere controlli negativi con sequenze simulabili. Se un modello produce «traduzioni» altrettanto persuasive sul testo mescolato, il test non vale.

La presenza di una chiave di Fontana non dimostra che il Voynich usi lo stesso sistema. Dimostra però che possiamo testare il nostro metodo su un cifrario medievale di cui sappiamo il funzionamento **prima** di usarlo sull'ignoto.

Riferimenti Fontana: https://philipneal.net/voynichsources/fontana_cipher_manuscripts/ ; https://www.persee.fr/doc/scrip_0036-9772_1982_num_36_2_1268 ; https://sas-space.sas.ac.uk/9846/1/VCacopardoMemoryandImaginationPhDthesis.pdf .

## Materiali

`run.py` esegue il calcolo e rigenera `results.json` a partire dai due corpus in `inputs/`; `SHA256SUMS.txt` documenta gli artefatti. Questo pacchetto è **nuovo e indipendente** dagli audit congelati di RC1.4.2 (`CLOSED_PENDING_VALIDATION`, RP-01 aperto, `f085v` irrisolto).
