from pathlib import Path
import re, collections, json, hashlib
p=Path('/mnt/data/files/ZL3b-n.txt')
lines=p.read_text().splitlines()
records=[]
for line in lines:
 m=re.match(r'^<(?P<folio>f\d+[rv]\d?)\.(?P<loc>\d+),(?P<type>[^>]+)>\s+(?P<txt>.*)$',line)
 if not m: continue
 txt=m['txt'].split('<!')[0]  # ignore trailing tags
 words=[]
 for part in re.split(r'[.\s,;]+',txt):
  word=re.sub(r'<[^>]*>', '',part)
  if re.fullmatch('[a-z]+',word): words.append(word)
 records.append((m['folio'],int(m['loc']),m['type'],words))
count=collections.Counter(w for f,i,t,words in records for w in words)
for label in ['otodol','opcholdg']:
 hits=[{'folio':f,'loc':i,'type':t,'position':k} for f,i,t,ws in records for k,w in enumerate(ws) if w==label]
 print(label,count[label],hits)
print('loc f68v3',[{'loc':i,'type':t,'words':ws} for f,i,t,ws in records if f=='f68v3' and i in range(14,20)])
print('f86v3 loc type counts',dict(collections.Counter(t for f,i,t,w in records if f=='f86v3')))
print('f68v3 loc type counts',dict(collections.Counter(t for f,i,t,w in records if f=='f68v3')))
print('corpus sha',hashlib.sha256(p.read_bytes()).hexdigest())
