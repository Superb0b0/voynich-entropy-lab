# ASTRO-08 | Le tre regioni della figura T-O: test del ruolo testuale

Data: 12 novembre 2026. Analisi indipendente in sola lettura del corpus ZL3b. Il ramo RC1.4.2 rimane congelato.

## Ipotesi falsificabile
Se una specifica regione della figura tripartita codifica un ruolo stabile, una seconda istanza del motivo deve consentire di confrontare una scritta situata nella regione equivalente, senza scegliere la regione in base alla stringa stessa.

## Osservazioni documentate
- f68v3: cerchio centrale diviso in due quarti superiori e una metà inferiore. I due quarti contengono le etichette EVA `otodol` (locus f68v3.15,@L0) e `opcholdg` (f68v3.16,=L0). La metà inferiore contiene tre righe di testo (`f68v3.17`–`.19`, tipo `Pb`). La pagina comprende anche una corona testuale intorno al centro e otto fasce spiraliformi.
- f86v3: un piccolo cerchio tripartito è segnalato nelle descrizioni storico-iconografiche; nel corpus ZL3b non è disponibile una coppia di etichette `L0` registrata come scritta nei due quarti del piccolo motivo. Esistono invece paragrafi nella pagina. L'assenza nel parser non prova assenza di segni sul disegno.
- Rosette, piccolo T-O in alto a destra: il motivo è documentato, ma il registro non mette a disposizione tre segmenti di testo confrontabili con quelli di f68v3.

## Controllo testuale eseguito
Ricerca di parole complete, senza emendare grafemi incerti, in tutti i loci disponibili ZL3b: `otodol`: una occorrenza (f68v3.15), `opcholdg`: una (f68v3.16). Nessuna delle due ricorre altrove con la stessa grafia; il controllo non mostra equivalenze di significato. SHA-256 di ZL3b-n.txt: bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc.

## Conclusione
**NON TESTABILE con i tre casi disponibili.** La figura f68v3 è asimmetrica anche nel testo (etichetta, etichetta, paragrafo), dunque un'identità delle tre regioni attraverso i tre esemplari non è verificabile tramite tre parole. Le altre istanze non forniscono testi locali dello stesso tipo e posizione. Non esiste un p-value valido. Non attribuiamo ad alcuna parola il nome di un continente o di un elemento.

## Alternative utili
La descrizione f68v3 è compatibile sia con una mappa T-O con glosse diseguali sia con un diverso riuso cosmografico del medesimo schema. Per distinguerle serve una miniatura con le stesse relazioni grafiche e una legenda leggibile, oppure una nuova istanza Voynich che ripeta la struttura locale delle scritte. Non vale la pena procedere con una statistica su due etichette uniche.

## Fonti
- René Zandbergen, Quire 9: https://voynich.nu/q09/index.html
- René Zandbergen, Illustrations: https://www.voynich.nu/illustr.html
- Corpus ZL3b-n.txt presente localmente e verificato con SHA-256.
