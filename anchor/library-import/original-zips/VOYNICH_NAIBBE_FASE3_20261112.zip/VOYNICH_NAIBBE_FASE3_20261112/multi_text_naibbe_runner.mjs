/*
 EXP-NAIBBE-03 | independent JS simulation of Greshko's Naibbe mapping.
 Research only; not the original Python interpreter.
 Original source: Michael A. Greshko (2025), Cryptologia,
 https://doi.org/10.1080/01611194.2025.2566408
 Source code: https://github.com/greshko/naibbe-cipher
 Comparison texts: Lindemann & Bowern's corpus,
 https://github.com/chirila/Voynich-public
 Note: upstream sources and any original source licences must be respected.
*/
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const BASE=path.dirname(fileURLToPath(import.meta.url));
const CACHE=path.join(BASE,'source_cache');
const GPIN='5145f526b52741a6dca14201147f687e62c7162e';
const CPIN='decc4caaa6515b86e42a219d1da8d81114736f2e';
const GLYPHS={
 url:`https://raw.githubusercontent.com/greshko/naibbe-cipher/${GPIN}/references/naibbe_tables.csv`,
 file:'naibbe_tables.csv',blob:'5cd34fb81d80faf3b4d57dbf1719c05ffde25302'
};
const CORPORA=[
 ['BrunoDeMagia','79310c6515f9c28711ca558d7b58e257c2173c5d'],
 ['Secreta_Secretorum_LAT','836e7880f494c293bfc7e07359cc332eac8e1ecf'],
 ['Rettorica','376d611e483669f367bd61da39fd70fe497c987f'],
 ['Latin_Aix','6cead0c577c77c46f808431e2884e23195941b95'],
 ['Steganographia','1a507eab4258953bbe5c7b30293ab74121c24fbd'],
].map(([name,blob])=>({name,blob,file:name+'.txt',url:`https://raw.githubusercontent.com/chirila/Voynich-public/${CPIN}/Corpora/Historical_texts/${name}`}));
const BANDS={density:[.91,.96],adjacency:[.02,.04],repetition:[.045,.07],hapax:[.65,.75]};
const TABS=['alpha','beta1','beta2','beta3','gamma1','gamma2'],W1=[20,8,8,8,4,4],W2=[28,14,11,11,7,7];
const N=34323;
function gitBlob(bytes){return crypto.createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex');}
async function fetchChecked(p){
 const local=path.join(CACHE,p.file);let b;
 if(fs.existsSync(local))b=fs.readFileSync(local);
 else{
  const res=await fetch(p.url);if(!res.ok)throw Error(`Fetch failed: ${res.status} ${p.url}`);
  b=Buffer.from(await res.arrayBuffer());
  fs.mkdirSync(CACHE,{recursive:true});fs.writeFileSync(local,b);
 }
 if(gitBlob(b)!==p.blob)throw Error(`Git blob mismatch: ${p.file}: ${gitBlob(b)} != ${p.blob}`);
 return b.toString('utf8');
}
function rng32(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
function shuffle(a,r){for(let i=a.length-1;i>0;i--){let j=Math.floor(r()*(i+1));[a[i],a[j]]=[a[j],a[i]];}}
function clean(s){return s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[æÆ]/g,'ae').replace(/[œŒ]/g,'oe').replace(/[ðÐ]/g,'d').replace(/[þÞ]/g,'th').replace(/[łŁ]/g,'l').replace(/ß/g,'ss').replace(/[øØ]/g,'o').replace(/[^a-zA-Z]/g,'').toUpperCase().replace(/W/g,'UU').replace(/J/g,'I').replace(/K/g,'C').toLowerCase();}
function engine(tableString){
 const glyph=new Map(tableString.replace(/^\uFEFF/,'').trim().split(/\r?\n/).slice(1).map(s=>{let i=s.indexOf(',');return[s.slice(0,i),s.slice(i+1)];}));
 const uniq=new Set([...glyph].filter(([k])=>k.startsWith('unigram_')).map(([,g])=>g));
 const amb=new Set(),seen=new Map();
 for(let a of TABS)for(let c of 'abcdefghijklmnopqrstuvwxyz')for(let b of TABS)for(let d of 'abcdefghijklmnopqrstuvwxyz'){
  let p=`prefix_${a}_${c}`,s=`suffix_${b}_${d}`,x=glyph.get(p),y=glyph.get(s);
  if(x==null||y==null)continue;let word=x+y,pair=p+'|'+s;
  if(seen.has(word)&&seen.get(word)!==pair)amb.add(word);else seen.set(word,pair);
 }
 function run(lines,seed,v){
  const rnd=rng32(seed),tokens=[],native=[];let retries=0,fuses=0;
  for(const input of lines){
   let parts=[];for(let i=0;i<input.length;){if(i===input.length-1||rnd()<17/36){parts.push(input[i]);i++;}else{parts.push(input.slice(i,i+2));i+=2;}}
   let deck=[],i=0,row=[];
   function take(){if(i>=deck.length){deck=[];let weights=v===1?W1:W2;for(let j=0;j<TABS.length;j++)for(let k=0;k<weights[j];k++)deck.push(TABS[j]);shuffle(deck,rnd);i=0;}return deck[i++];}
   for(const part of parts){let word;
    if(part.length===1)word=glyph.get(`unigram_${take()}_${part}`);
    else for(let attempt=0;attempt<10000;attempt++){
     let p=glyph.get(`prefix_${take()}_${part[0]}`),s=glyph.get(`suffix_${take()}_${part[1]}`);word=p+s;
     if(!uniq.has(word)&&!(v===2&&amb.has(word)))break;
     retries++;if(attempt===9999)fuses++;
    }
    if(!word||word.includes('undefined'))throw Error('Unmapped glyph in generator');
    row.push(word);tokens.push(word);
   }
   native.push(row);
  }
  return {tokens,native,retries,fuses};
 }
 return run;
}
function merge3(native,seed){
 let r=rng32(seed+1000000),out=[];
 for(const row of native){if(!row.length)continue;let s=row[0];for(let i=1;i<row.length;i++){if(r()<.03)s+=row[i];else{out.push(s);s=row[i];}}out.push(s);}
 return out;
}
function metrics(tokens,lens){
 const f=new Map();for(const w of tokens)f.set(w,(f.get(w)||0)+1);
 const close=new Set(),seen=new Map();
 for(const w of f.keys())for(let i=0;i<w.length;i++){
  let sh=w.slice(0,i)+w.slice(i+1);if(f.has(sh)){close.add(w);close.add(sh);}
  let key=w.slice(0,i)+'*'+w.slice(i+1);if(seen.has(key)){let q=seen.get(key);if(q!==w){close.add(w);close.add(q);}}else seen.set(key,w);
 }
 let den=0,hap=0;for(let [w,n] of f){if(close.has(w))den+=n;if(n===1)hap++;}
 let adj=0,rep=0,pos=0,prev=null,yocount=new Map();
 for(const len of lens){const row=tokens.slice(pos,pos+len),set=new Set(row);pos+=len;
  if(prev!==null){let inter=0;for(const w of set)if(prev.has(w))inter++;const union=set.size+prev.size-inter;adj+=union?inter/union:0;let n=0;for(const w of row)if(prev.has(w))n++;rep+=len?n/len:0;}
  prev=set;
  for(let j=0;j<row.length;j++){
   const w=row[j];if(w.length<4||(w[0]!=='y'&&w[0]!=='o'))continue;
   const k=w.slice(1),q=yocount.get(k)||[0,0,0,0];q[(w[0]==='y'?0:2)+(j===0?0:1)]++;yocount.set(k,q);
  }
 }
 let nn=0,dd=0,ns=0;for(let [a,b,c,d] of yocount.values()){
  let n=a+b+c+d;if(a+b<2||c+d<2||a+c===0||b+d===0)continue;
  ns++;nn+=a*d/n;dd+=b*c/n;
 }
 return {density:den/N,adjacency:adj/(lens.length-1),repetition:rep/(lens.length-1),hapax:hap/f.size,yo_or:dd?nn/dd:null,informative_stems:ns};
}
function toCsv(arr){const cols=['corpus','version','seed','format','generated','merged_total','retries','fuses','density','adjacency','repetition','hapax','yo_or','informative_stems','axes_in_band'];return cols.join(',')+'\n'+arr.map(r=>cols.map(k=>k==='axes_in_band'?r[k].join('|'):r[k]??'').join(',')).join('\n')+'\n';}
async function main(){
 const maxseed=Number(process.env.MAX_SEED||'1030');
 const csv=await fetchChecked(GLYPHS),run=engine(csv);
 const lines=fs.readFileSync(path.join(BASE,'zl3b_P_ms408.tsv'),'utf8').trimEnd().split(/\r?\n/).filter(x=>x.includes('\t')).map(x=>x.split('\t').slice(1).join('\t').trim().split(/\s+/).filter(Boolean).length);
 if(lines.length!==4130||lines.reduce((a,b)=>a+b,0)!==N)throw Error('Voynich line shape mismatch');
 const trials=[];
 for(const corpus of CORPORA){const raw=await fetchChecked(corpus),cleaned=clean(raw).slice(0,80000),chunks=[];
  for(let i=0;i<cleaned.length;i+=56)chunks.push(cleaned.slice(i,i+56));
  for(let version of [1,2])for(let seed=1001;seed<=maxseed;seed++){
   const c=run(chunks,seed,version),m=merge3(c.native,seed);
   if(c.fuses||c.tokens.length<N||m.length<N)throw Error(`Bad sample: ${corpus.name} v${version} seed=${seed}`);
   for(let [format,tokens] of [['raw',c.tokens],['merged',m]]){
    const z=metrics(tokens.slice(0,N),lines),inBand=Object.entries(BANDS).filter(([axis,[a,b]])=>z[axis]>=a&&z[axis]<=b).map(([axis])=>axis);
    trials.push({corpus:corpus.name,version,seed,format,generated:c.tokens.length,merged_total:m.length,retries:c.retries,fuses:c.fuses,...z,axes_in_band:inBand});
   }
  }
 }
 fs.writeFileSync(path.join(BASE,'naibbe_five_corpora_per_seed.csv'),toCsv(trials));
 const groups=[];
 for(let c of CORPORA)for(let v of [1,2])for(let fmt of ['raw','merged']){
  const a=trials.filter(x=>x.corpus===c.name&&x.version===v&&x.format===fmt),mean={},range={};
  for(let k of ['density','adjacency','repetition','hapax','yo_or']){
   const z=a.map(x=>x[k]).filter(x=>x!==null);mean[k]=z.reduce((s,x)=>s+x,0)/z.length;range[k]=[Math.min(...z),Math.max(...z)];
  }
  groups.push({corpus:c.name,version:v,format:fmt,n:a.length,mean,range,any_axis:a.filter(x=>x.axes_in_band.length>0).length,all_four:a.filter(x=>x.axes_in_band.length===4).length});
 }
 const manifest={status:'EXPLORATORY_JS_PORT_NOT_ORIGINAL_PYTHON',date:'2026-11-12',Greshko_commit:GPIN,Chirila_commit:CPIN,
  source_git_blobs:Object.fromEntries(CORPORA.map(x=>[x.name,x.blob])),glyph_blob:GLYPHS.blob,
  historical_text_cleaning:'Unicode NFD + ASCII a-z + W->UU J->I K->C; first 80,000 cleaned characters or all if shorter; chunks of 56 characters',
  n_vms_tokens:N,n_vms_rows:lines.length,seed_min:1001,seed_max:maxseed,
  variants:['original tokens','independent 3% adjacent-space removal within synthetic source lines'],
  core_algorithm:'Independent JavaScript port of published algorithm, mulberry32 seeded PRNG + Fisher-Yates',bands:BANDS,groups};
 fs.writeFileSync(path.join(BASE,'naibbe_five_corpora_summary.json'),JSON.stringify(manifest,null,2)+'\n');
 console.log(JSON.stringify({status:manifest.status,seeds:maxseed-1000,rows:trials.length,all_four:trials.filter(x=>x.axes_in_band.length===4).length,any_axis:trials.filter(x=>x.axes_in_band.length>0).length,groups},null,2));
}
main().catch(e=>{console.error(e);process.exitCode=1;});
