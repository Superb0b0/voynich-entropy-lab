#!/usr/bin/env python3
"""A constructive non-identifiability test.

Four legacy metrics are invariant under permutations inside each line; the
position-dependent y/o odds ratio is not. This is a demonstrator, NOT a
historically motivated cipher or new hypothesis test.
"""
from __future__ import annotations
import csv, json, random, hashlib, re
from collections import Counter,defaultdict
from pathlib import Path
import numpy as np
from statsmodels.stats.contingency_tables import StratifiedTable

BASE=Path(__file__).resolve().parent
OUT=BASE/'EXP_YO_04'
OUT.mkdir(exist_ok=True)
P=BASE/'zl3b_P_ms408.tsv'
text=(BASE/'ZL3b-n.txt').read_text().splitlines()
metadata={}
for ln in text:
 m=re.match(r'^<(f\d+[rv]\d*)>\s*<!',ln)
 if m:
  z=re.search(r'\$L=([^\s>]+)',ln)
  metadata[m[1]]=z[1] if z else '?'
rows=[]
for line in P.read_text().splitlines():
 if '\t' not in line:continue
 folio,body=line.split('\t',1)
 rows.append((folio,metadata.get(folio,'?'),body.split()))
assert len(rows)==4130 and sum(len(r[2]) for r in rows)==34323
folios=sorted({f for f,g,r in rows});rng=random.Random(20261112);tr,te=set(),set()
for g in ['A','B','?']:
 fs=sorted(f for f in folios if metadata.get(f,'?')==g);rng.shuffle(fs)
 tr.update(fs[:len(fs)//2]);te.update(fs[len(fs)//2:])
counts=Counter(w for f,g,row in rows if f in tr for w in row)
stems={w[1:] for w in counts if w.startswith('y') and len(w)>=4 and counts[w]>=2 and counts['o'+w[1:]]>=2}
assert len(stems)==64

def mh(data):
 d=defaultdict(lambda:[0,0,0,0]);nt=0
 for f,cur,row in data:
  if f not in te:continue
  for i,w in enumerate(row):
   if len(w)>=4 and w[0] in 'yo' and w[1:] in stems:
    d[(w[1:],cur)][(0 if w[0]=='y' else 2)+(0 if i==0 else 1)]+=1
 st=[]
 for a,b,c,e in d.values():
  if a+b==0 or c+e==0 or a+c==0 or b+e==0:continue
  st.append([[a,b],[c,e]]);nt+=a+b+c+e
 obj=StratifiedTable(st)
 return {'or':float(obj.oddsratio_pooled),'n_strata':len(st),'n_tokens_in_strata':nt}

def four_metrics(data):
 flat=[w for _,_,r in data for w in r]
 counts=Counter(flat);good=set(); seen={}
 for w in counts:
  for k in range(len(w)):
   sh=w[:k]+w[k+1:]
   if sh in counts:good.add(w);good.add(sh)
   pattern=w[:k]+'*'+w[k+1:]
   if pattern in seen and seen[pattern]!=w:good.add(seen[pattern]);good.add(w)
   else:seen.setdefault(pattern,w)
 d=sum(counts[w] for w in good)/len(flat)
 h=sum(c==1 for c in counts.values())/len(counts)
 ad=repe=0
 for a,b in zip(data,data[1:]):
  p=set(a[2]);q=set(b[2]);ad+=len(p&q)/len(p|q) if p|q else 0
  repe+=sum(w in p for w in b[2])/len(b[2]) if b[2] else 0
 return {'density':d,'adjacency':ad/(len(data)-1),'repetition':repe/(len(data)-1),'hapax':h}

original=four_metrics(rows)
origOR=mh(rows)

def shuffle_rows(seed,p=0.0):
 rng=random.Random(seed)
 out=[];n_swaps=0
 for f,cur,original in rows:
  a=list(original);rng.shuffle(a)
  if f in te and p>0 and rng.random()<p:
   # Post-hoc constructed line-position intervention: move an eligible yX token
   # to start of the line, if there is one and it is not already first.
   j=next((j for j in range(1,len(a)) if a[j].startswith('y') and len(a[j])>=4 and a[j][1:] in stems),None)
   if j is not None:
    a[0],a[j]=a[j],a[0]
    n_swaps+=1
  out.append((f,cur,a))
 return out,n_swaps

B=1000
null=[]
for seed in range(20261112,20261112+B):
 x,_=shuffle_rows(seed)
 null.append(mh(x)['or'])
# Metrics should be invariant. Assert for a few complete recalculations.
for seed in [20261112,20261113,20261114]:
 xx,_=shuffle_rows(seed)
 m=four_metrics(xx)
 assert all(abs(m[k]-original[k])<1e-14 for k in original),(seed,m,original)
interventions=[]
for prob in [0,.02,.05,.10,.20,.40,1.0]:
 for seed in [41001,41002,41003,41004,41005]:
  data,ns=shuffle_rows(seed,prob)
  interventions.append({'probability':prob,'seed':seed,'swaps':ns,'or':mh(data)['or']})
for seed in [41001,41003,41005]:
 m=four_metrics(shuffle_rows(seed,1.0)[0])
 assert all(abs(m[k]-original[k])<1e-14 for k in original)
res={'status':'EXPLORATORY_CONSTRUCTIVE_CONTROL_NOT_CIPHER','source_p_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'n_lines':len(rows),'n_tokens':sum(len(a[2]) for a in rows),'stems_trained':len(stems),'holdout_folios':len(te),'metrics_original':original,'mh_original':origOR,'shuffle':{'B':B,'median':float(np.median(null)),'q025':float(np.quantile(null,.025)),'q975':float(np.quantile(null,.975)),'max':max(null),'ge_original':int(sum(x>=origOR['or'] for x in null)),'p_one_sided':(1+sum(x>=origOR['or'] for x in null))/(B+1)},'bias_interventions':interventions,'all_four_metrics_invariant_to_within_line_word_order':'YES_EXACT','notes':['The four statistics depend only on global word counts and line-level memberships, so ordering words within each line cannot change them.','Position interventions are post-hoc controls and do not constitute a plausible cipher or independent support for a generative hypothesis.','This test does not validate the Naibbe Python implementation.']}
(OUT/'results.json').write_text(json.dumps(res,indent=2)+'\n')
with (OUT/'interventions.csv').open('w',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=interventions[0].keys());wr.writeheader();wr.writerows(interventions)
with (OUT/'shuffle_null.csv').open('w',newline='') as f:
 wr=csv.writer(f);wr.writerow(['seed','or']);wr.writerows((20261112+i,z) for i,z in enumerate(null))
print(json.dumps({k:v for k,v in res.items() if k not in ['bias_interventions','notes']},indent=2))
for prob in sorted({z['probability'] for z in interventions}):
 a=[z for z in interventions if z['probability']==prob]
 print('p',prob,'mean_OR',round(float(np.mean([z['or'] for z in a])),3),'swaps',round(float(np.mean([z['swaps'] for z in a])),1),'minmax',[round(min(z['or'] for z in a),3),round(max(z['or'] for z in a),3)])
