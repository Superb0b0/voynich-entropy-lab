"""Materialize the 20 exact displayed means from the executed in-memory V8 batch.
Not a re-execution and not the per-seed raw trial data.
"""
import csv,json
from pathlib import Path
base=Path(__file__).resolve().parent
rows_txt='''
BrunoDeMagia 1 raw .9985180005632763 .01662647134788016 .03252001809060195 .40345141223512954 1.034814650281524
BrunoDeMagia 1 merged .9738620361468014 .0158241517463005 .030949904228035414 .4961841104855577 .997068643228882
BrunoDeMagia 2 raw .9984908079130612 .0158426761614552 .030963562997397005 .40208506792303905 .9975224010124993
BrunoDeMagia 2 merged .9734628868882867 .014846905242269483 .029046264080798048 .49372693972674125 .9804107024992195
Secreta_Secretorum_LAT 1 raw .9987617632491332 .0168012565164097 .032825875070324945 .40254389154517967 1.0012639329814583
Secreta_Secretorum_LAT 1 merged .9739727490798201 .01571844412295081 .030786492959036925 .4959041844890029 .9515773533291909
Secreta_Secretorum_LAT 2 raw .9987831289028737 .015833639537207244 .030943527999679043 .3980559157081617 1.0247942662646188
Secreta_Secretorum_LAT 2 merged .9738261030018743 .014806163721782124 .028957298615522594 .4909976607285798 1.0493237773137902
Rettorica 1 raw .9980411580184327 .01778343458667185 .03515796197709942 .35503614170455716 .9940454669855908
Rettorica 1 merged .9737891986908681 .016594085120519367 .032755935424950186 .4644711538342435 .9822077900940636
Rettorica 2 raw .9980353310219581 .016734110372839964 .032971249994092844 .34683615769588927 .9551546139045362
Rettorica 2 merged .9733987899270654 .01564088357362444 .030749700748497068 .4568032360088718 1.054722467274178
Latin_Aix 1 raw .9986306558284532 .01619744739319973 .03164959579050668 .4101540424707959 .9747907816451916
Latin_Aix 1 merged .9738901999630957 .015340679790068703 .02999561351619622 .5010564550471676 .9818779067759131
Latin_Aix 2 raw .9986083190086337 .015420999470035517 .03006700059949573 .4071563921467475 1.0405201374873692
Latin_Aix 2 merged .9735619458283561 .014592671303182649 .02847372997501437 .49760212408517057 1.0442353226957366
Steganographia 1 raw .9986122036729501 .01636462780551879 .03199878318469465 .41451083522976234 .9935262884443613
Steganographia 1 merged .9738610649807223 .015224646854089344 .029844701182317298 .5039986243327775 .9947540284141959
Steganographia 2 raw .9986665889733803 .015480610309395449 .030268404645827356 .4127580257128066 1.0478252409372626
Steganographia 2 merged .9736493507754761 .014479775852981025 .02826142393555512 .5004187548461777 1.0035952077672396
'''
rows=[]
for line in rows_txt.strip().splitlines():
 t=line.split(); name,v,kind=t[:3]; nums=list(map(float,t[3:]))
 assert len(nums)==5
 rows.append(dict(source=name,version=int(v),format=kind,n=30,mean_density=nums[0],mean_adjacency=nums[1],mean_repetition=nums[2],mean_hapax=nums[3],mean_yo_or=nums[4],any_single_axis_in_band=0,all_four_in_band=0))
assert len(rows)==20 and sum(r['n'] for r in rows)==600
f=base/'naibbe_five_texts_aggregates_OBSERVED.csv'
with f.open('w',newline='') as out:
 wr=csv.DictWriter(out,fieldnames=rows[0]);wr.writeheader();wr.writerows(rows)
manifest={
 'status':'EXPLORATORY_PORT_JS_OBSERVED_IN_MEMORY','sample_source':'functions.exec batched GitHub corpus access; exact group means transcribed from output, original per-seed output was not persisted',
 'Greshko_commit':'5145f526b52741a6dca14201147f687e62c7162e',
 'Greshko_table_blob':'5cd34fb81d80faf3b4d57dbf1719c05ffde25302',
 'Chirila_commit':'decc4caaa6515b86e42a219d1da8d81114736f2e',
 'comparison_text_blobs':{
   'BrunoDeMagia':'79310c6515f9c28711ca558d7b58e257c2173c5d',
   'Secreta_Secretorum_LAT':'836e7880f494c293bfc7e07359cc332eac8e1ecf',
   'Rettorica':'376d611e483669f367bd61da39fd70fe497c987f',
   'Latin_Aix':'6cead0c577c77c46f808431e2884e23195941b95',
   'Steganographia':'1a507eab4258953bbe5c7b30293ab74121c24fbd'},
 'design':{'corpora':5,'versions':2,'seeds_per_version_per_corpus':30,'spacing_variants':2,'evaluations':600,'tokens_each':34323,'rows_each':4130,'chunk_width_letters':56,'max_cleaned_characters':80000,'original_input_shorter':'BrunoDeMagia 69239 cleaned characters','space_removal':0.03,'space_removal_rng':'independent from encryption','cipher_rng':'mulberry32, not Python random'},
 'four_in_band':0,'any_single_axis_in_band':0,
 'caveats':['Original Python source was not successfully run in the local container due to disabled network/DNS.','The 5 comparison corpora were relineated into arbitrary 56-character groups, not historical lines.','Every reported mean has 30 replicates; the 600 observations are not 600 independent plaintexts.','The y/o synthetic metric selected its own informative suffixes, whereas the Voynich holdout used suffixes preselected in training; not a directly calibrated difference test.','Full per-seed source outputs require rerunning multi_text_naibbe_runner.mjs with the pinned corpora after download.']
}
(base/'naibbe_five_texts_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print('Materialized:',f, 'rows',len(rows))
