# VOYNICH | Prove su Naibbe e posizione nella riga
**12 novembre 2026 | Stato: ESPLORATIVO, non preregistrato.** Nessuna decifrazione e nessun contenuto semantico attribuito ai glifi.

## Riepilogo verificabile

### A. Validazione del Python originale di Greshko: **PENDING, non eseguita**

Ho tentato di eseguire `run_original_python.py` nell'ambiente Python 3.13 disponibile. Il programma richiede quattro input al commit `5145f526b52741a6dca14201147f687e62c7162e`:

- `naibbe.py`: blob `910b7a99532f4630cb59917f9df3de8e98808598`;
- `naibbe_v2.py`: blob `b566ad82e4b6ff0782ecdddebf77718dac44f292`;
- `references/naibbe_tables.csv`: blob `5cd34fb81d80faf3b4d57dbf1719c05ffde25302`;
- `input/examples/nathist_book16.txt`: blob `453d8e1cb7a6626c02bb53467c329ab127d89006`.

Il runner è stato avviato, ma si è fermato durante il **download**, per mancata risoluzione DNS di `raw.githubusercontent.com`. Non ha eseguito il cifrario originale e non ha prodotto nuovi ciphertext in Python. I file sono verificabili tramite il connettore GitHub, ma non sono stati trasferiti come byte nell'ambiente locale. Il runner predisposto rimane nel pacchetto: quando i sorgenti saranno materializzati a byte e con blob coincidenti, l'esecuzione originale dovrà essere ripetuta. **Nessun risultato di questo dossier deve essere presentato come validazione diretta dell'originale Python.**

### B. Cinque plaintext storici: **simulazioni eseguite con adattamento JavaScript**

Ho acquisito e verificato tramite GitHub (accesso in memoria) cinque testi del corpus pubblico `chirila/Voynich-public`, commit `decc4caaa6515b86e42a219d1da8d81114736f2e`: `BrunoDeMagia`, `Secreta_Secretorum_LAT`, `Rettorica` (italiano), `Latin_Aix`, `Steganographia`. Vedi `naibbe_five_texts_manifest.json` per gli hash Git blob.

Per ciascuno: fino a 80.000 caratteri normalizzati (69.239 per `BrunoDeMagia`), suddivisione *artificiale* in blocchi di 56 caratteri, cifratura Naibbe v1 e v2 implementata in JS con glifi originali, 30 seed ciascuna versione (1001–1030). Due osservazioni per replica: spazi intatti e fusione indipendente del 3% degli spazi fra token contigui **entro i blocchi sorgente**. I primi 34.323 token di ciascun output sono disposti nelle 4.130 lunghezze di riga P del Voynich. In tutto **300 cifrature e 600 valutazioni**, ma solo **5 testi sorgente** e 2 varianti crittografiche.

**Esito empirico nella sessione:** 0/600 soddisfa tutte e quattro le bande; 0/600 entra anche in una sola banda. Nessuno degli OR `yX/oX` elaborati per i sintetici raggiunge 2,84. La metrica OR sintetica identifica le code informative separatamente in ogni replica, mentre l'OR 2,84 del Voynich è da code fissate sul training e stratificato per Currier: **questi OR non sono ancora un confronto perfettamente calibrato**.

Il 3% di spazi fusi sposta il rapporto hapax mediamente da ~0,35–0,41 a ~0,46–0,50, ma non fino al valore 0,711 del Voynich. Le medie osservate di ciascuno dei 20 gruppi (5 testi × 2 versioni × 2 formati) sono archiviate in `naibbe_five_texts_aggregates_OBSERVED.csv`. **I 600 record individuali non sono stati persistiti dalla fase in memoria:** non li invento e non dichiaro che siano nel pacchetto. `multi_text_naibbe_runner.mjs` permette di rigenerare i record individuali e il riepilogo con internet o input originali scaricati, verificando i blob, con la logica JS eseguita; la sintassi è stata controllata con `node --check`. L'esecuzione del runner locale con i sorgenti mancanti **non** è stata possibile.

Le bande, fissate nell'analisi originale, sono: densità 0,91–0,96, adiacenza 0,02–0,04, ripetizione locale 0,045–0,070, hapax 0,65–0,75. Non sono soglie con copertura formale calibrata per ogni testo antico o famiglia crittografica.

### C. Effetto `yX/oX` su due tokenizzazioni: **eseguito in Python**

Si conserva il corpus `ZL3b-n.txt` con SHA-256 `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc`. Il parser RC1.2 produce **35.492 token / 4.130 righe**, mentre il corpus P-only delle quattro metriche contiene **34.323 token / 4.130 righe**. I due universi **non sono intercambiabili**.

Con la divisione preesistente in 103 folii di costruzione e 104 di controllo, scelta interna all'analisi esplorativa:

| Dataset | Code y/o da training | OR sul controllo | IC 95% | Permutazioni entro riga |
|---|---:|---:|---:|---:|
| RC1.2 | 69 | **2,8487** | 2,018–4,020 | 0/2.000 ≥ osservato; p = 0,00050 |
| P-only | 64 | **3,0092** | 2,108–4,295 | 0/2.000 ≥ osservato; p = 0,00050 |

Per RC1.2: in Currier A, OR = 1,44 (IC 0,82–2,54); in B, OR = 4,73 (IC 3,00–7,45). Eliminando le righe di apertura del paragrafo l'OR resta 2,81; prima parola contro seconda, 2,21; ultima contro posizioni interne, 0,98. Si tratta di stabilità interna e **non di replica indipendente**, perché la stessa ipotesi `yX/oX` nasce dall'esplorazione dell'intero manoscritto.

Il confronto con prefissi diversi dimostra che l'effetto non è esclusivo di y/o: `kX/tX` ha OR ≈ 5,63 su poche osservazioni informative (65 token RC1.2); le stime di altre coppie possono essere instabili o non identificabili. La tabella `prefix_comparison.csv` contiene anche i denominatori e i p-value esplorativi; non costituisce una ricerca corretta per test multipli né una nuova scoperta linguistica.

### D. Controllo di identificabilità: **eseguito in Python**

Mescolare casualmente le parole *dentro ciascuna riga* lascia invariati, **per definizione**, i quattro discriminanti: il lessico totale non cambia, gli insiemi di parole per riga neppure. Ma distrugge l'arricchimento posizionale.

Su P-only: 1.000 mescolamenti indipendenti danno OR mediano 1,024, intervallo centrale 95% **0,706–1,465**; massimo 1,834; **0/1.000** raggiungono l'OR originale 3,009 (p empirica 0,000999). Il programma ha verificato esplicitamente l'identità numerica di tutte e quattro le metriche per più semi.

Un controllo costruito a posteriori mostra l'opposto: scambiando nella posizione iniziale alcune forme yX già presenti nella stessa riga, l'OR può salire vicino a 3 (probabilità d'intervento 0,20, circa 54 scambi medi), **senza alterare** alcuno dei quattro discriminanti. Non è un cifrario, e questo parametro deriva da una ricognizione esplorativa: serve solo a dimostrare che i nostri quattro discriminanti non identificano la regola di posizionamento.

## Riproducibilità e perimetro

I controlli C e D sono completamente eseguibili **offline** con Python, NumPy, SciPy, pandas e statsmodels:

```bash
python EXP_YO_03_layout_controls.py
python EXP_YO_04_invariance_demo.py
```

Per la simulazione B con i dati storici originali, in una postazione con connessione a GitHub:

```bash
node multi_text_naibbe_runner.mjs
```

Scarica e verifica gli hash dei sorgenti, produce CSV per tutti i seed e un JSON riepilogativo. In alternativa si possono depositare i sei sorgenti originali nella sottocartella `source_cache/`, secondo i nomi e gli hash nel codice.

Per l'originale Python Greshko:

```bash
python run_original_python.py
```

Il runner Python richiede connessione o sorgenti verificati già presenti nella sottocartella `greshko_pinned_sources/`; su questo ambiente l'esecuzione si è interrotta al download. **Il controllo originale è ancora PENDING.**

**Nessun file o stato della pipeline immagini/testo RC1.4.2 è stato modificato: `CLOSED_PENDING_VALIDATION`.** Non è stato eseguito alcun builder, PCA, clustering o conditional coupling.

## Interpretazione provvisoria

Le configurazioni testate del porting Naibbe divergono dalle nostre bande in cinque plaintext, anche con una semplice rispaziatura. Tuttavia questi esperimenti **non falsificano tutta la classe dei cifrari verbose** e non dimostrano che il manoscritto sia cifrato o privo di significato.

Il contributo più robusto del pacchetto è logico-sperimentale: **il benchmark a quattro metriche è cieco all'ordine intrariga**, mentre l'effetto posizionale y/o rimane nei controlli condizionati. I futuri generatori vanno giudicati su entrambi i tipi di proprietà, senza trasformare una somiglianza in identificazione del meccanismo storico.
