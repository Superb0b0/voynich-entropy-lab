#!/usr/bin/env python3
"""Read-only exploratory controls for manuscript word-position effects.

Uses source and original RC1.2 parser from local verified inputs.
Separate ZL3b P-only corpus for side-by-side comparison with four metrics.
No access to or execution of RC1.4.2 builder.
"""
from __future__ import annotations
import csv, json, hashlib, importlib.util, random, re, math
from collections import Counter, defaultdict
from pathlib import Path
import numpy as np
from statsmodels.stats.contingency_tables import StratifiedTable
from scipy.stats import fisher_exact

BASE=Path(__file__).resolve().parent
OUT=BASE/'EXP_YO_03'
OUT.mkdir(exist_ok=True)
SRC=BASE/'ZL3b-n.txt'
PARS=BASE/'ivtff_parser_rc1_2.py'
PONLY=BASE/'zl3b_P_ms408.tsv'
EXPECT='bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc'
assert hashlib.sha256(SRC.read_bytes()).hexdigest()==EXPECT
spec=importlib.util.spec_from_file_location('rc12_for_yo03',PARS)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
parsed=module.parse_corpus(SRC)
raw=SRC.read_text().splitlines()
meta={}
for ln in raw:
 m=re.match(r'^<(f\d+[rv]\d*)>\s*<!',ln)
 if m:
  l=re.search(r'\$L=([^\s>]+)',ln)
  h=re.search(r'\$H=([^\s>]+)',ln)
  meta[m.group(1)]={'currier':l.group(1) if l else '?','hand':h.group(1) if h else '?'}
rows12=[{'folio':r['folio'],'currier':meta.get(r['folio'],{}).get('currier','?'),
         'hand':meta.get(r['folio'],{}).get('hand','?'),
         'para_start':'<%>' in raw[r['physical_line']-1],
         'tokens':r['tokens']} for r in parsed['records']]
with PONLY.open() as f:
 rowsP=[{'folio':line.split('\t',1)[0], 'tokens':line.rstrip('\n').split('\t',1)[1].split()} for line in f if '\t' in line]
for r in rowsP:r.update(currier=meta.get(r['folio'],{}).get('currier','?'),hand=meta.get(r['folio'],{}).get('hand','?'),para_start=None)
assert len(rowsP)==len(rows12)==4130
assert sum(len(r['tokens']) for r in rowsP)==34323
assert sum(len(r['tokens']) for r in rows12)==35492

# Reproduce original pseudo-holdout, without changing seed/order.
folios=sorted(set(r['folio'] for r in rows12))
rand=random.Random(20261112)
train_f,test_f=set(),set()
for group in ['A','B','?']:
 fs=sorted(f for f in folios if meta.get(f,{}).get('currier','?')==group)
 rand.shuffle(fs);train_f.update(fs[:len(fs)//2]);test_f.update(fs[len(fs)//2:])

def select_stems(rows, first, second):
 c=Counter(w for r in rows for w in r['tokens'])
 return sorted({w[1:] for w in c if len(w)>=4 and w[0]==first and c[w]>=2 and c.get(second+w[1:],0)>=2})

def mh(rows,stems,first='y',second='o',with_currier=True,subset=None,position='first_vs_rest', minforms=0):
 strata=defaultdict(lambda:[0,0,0,0]);total=0
 for r in rows:
  if subset=='para_start' and r['para_start'] is not True: continue
  if subset=='non_para_start' and r['para_start'] is not False: continue
  if subset in ('A','B') and r['currier']!=subset:continue
  n=len(r['tokens'])
  for i,w in enumerate(r['tokens']):
   if len(w)<4 or w[1:] not in stems or w[0] not in (first,second):continue
   if position=='first_vs_second':
    if i>1:continue
    p=0 if i==0 else 1
   elif position=='last_vs_middle':
    if i==0:continue
    p=0 if i==n-1 else 1
   elif position=='first_vs_rest':p=0 if i==0 else 1
   else:raise ValueError(position)
   group=r['currier'] if with_currier else '*'
   strata[(w[1:],group)][(0 if w[0]==first else 2)+p]+=1
   total+=1
 tables=[];ninform=0
 for a,b,c,d in strata.values():
  if minforms and (a+b<minforms or c+d<minforms):continue
  if a+b==0 or c+d==0 or a+c==0 or b+d==0:continue
  tables.append([[a,b],[c,d]])
  ninform+=a+b+c+d
 if not tables:return {'or':None,'n_strata':0,'n_inform':0,'n_eligible':total}
 st=StratifiedTable(tables)
 return {'or':float(st.oddsratio_pooled),'ci95':[float(x) for x in st.oddsratio_pooled_confint()],
         'p':float(st.test_null_odds().pvalue),'n_strata':len(tables),
         'n_inform':ninform,'n_eligible':total}

def encrows(rows):
 return [{'folio':r['folio'],'currier':r['currier'],'hand':r['hand'],'para_start':r['para_start'],'tokens':list(r['tokens'])} for r in rows]

train12=[r for r in rows12 if r['folio'] in train_f]
held12=[r for r in rows12 if r['folio'] in test_f]
trainP=[r for r in rowsP if r['folio'] in train_f]
heldP=[r for r in rowsP if r['folio'] in test_f]
ystems12=select_stems(train12,'y','o')
ystemsP=select_stems(trainP,'y','o')
prior=json.loads((BASE/'EXP_YO_02_results.json').read_text())
assert len(ystems12)==prior['train_stems']==69
assert abs(mh(held12,ystems12,with_currier=False)['or']-prior['heldout']['matched_suffix']['or'])<1e-10
controls=[]
for corpus,tr,ho in [('RC1.2',train12,held12),('ZL3b_P_only',trainP,heldP)]:
 for first,second in [('y','o'),('d','o'),('s','o'),('q','o'),('k','t'),('d','q')]:
  stems=select_stems(tr,first,second)
  controls.append({'corpus':corpus,'pair':first+'/'+second,'train_stems':len(stems),
                   'heldout_all':mh(ho,stems),
                   'heldout_currierA':mh(ho,stems,subset='A'),
                   'heldout_currierB':mh(ho,stems,subset='B'),
                   'heldout_start_para':mh(ho,stems,subset='para_start'),
                   'heldout_non_start_para':mh(ho,stems,subset='non_para_start'),
                   'heldout_first_second':mh(ho,stems,position='first_vs_second'),
                   'heldout_last_middle':mh(ho,stems,position='last_vs_middle')})

# Permute exactly one random position as the 'first' token while holding all words and length
# fixed in each heldout row. 2000 repetitions, preallocated encoded matrices.
def permtest(held,stems,seed=20261112,B=2000):
 keys=sorted({(w[1:],r['currier']) for r in held for w in r['tokens'] if len(w)>=4 and w[0] in 'yo' and w[1:] in stems})
 idx={k:i for i,k in enumerate(keys)}
 rows=[];yc=np.zeros(len(keys),dtype=np.int32);oc=yc.copy()
 for r in held:
  x=np.full(len(r['tokens']),-1,dtype=np.int32)
  for j,w in enumerate(r['tokens']):
   if len(w)>=4 and w[0] in 'yo' and w[1:] in stems:
    k=idx[(w[1:],r['currier'])]
    x[j]=2*k+(w[0]=='o')
    if w[0]=='y':yc[k]+=1
    else:oc[k]+=1
  rows.append(x)
 valid=(yc>0)&(oc>0);n=yc+oc
 def statistic(z):
  obs=np.bincount(z[z>=0],minlength=2*len(keys));a=obs[::2];c=obs[1::2]
  b=yc-a;d=oc-c;ok=valid&((a+c)>0)&((b+d)>0)
  num=np.sum(a[ok]*d[ok]/n[ok]);den=np.sum(b[ok]*c[ok]/n[ok])
  return float(num/den) if den else float('inf')
 original=statistic(np.array([r[0] for r in rows],dtype=np.int32))
 rng=np.random.default_rng(seed)
 sims=[]
 for _ in range(B):
  z=np.array([r[rng.integers(len(r))] for r in rows],dtype=np.int32)
  sims.append(statistic(z))
 sims=np.array(sims)
 return {'obs':original,'p_one_sided':float((1+np.sum(sims>=original))/(B+1)),
         'null_quantiles':[float(x) for x in np.quantile(sims,[.025,.5,.975])],
         'exceedances':int(sum(sims>=original)),'B':B}
perm12=permtest(held12,ystems12)
permP=permtest(heldP,ystemsP)

# Invert first/last label to directly check whether the effect is specific to a line start.
# Also check a test designed to be non-optimized for the metric.
report={
 'status':'EXPLORATORY_CONTROLS','source_sha256':EXPECT,
 'rc12_parser_sha256':hashlib.sha256(PARS.read_bytes()).hexdigest(),
 'p_tsv_sha256':hashlib.sha256(PONLY.read_bytes()).hexdigest(),
 'datasets':{'RC12':{'lines':len(rows12),'tokens':sum(len(r['tokens']) for r in rows12)},
            'P_only':{'lines':len(rowsP),'tokens':sum(len(r['tokens']) for r in rowsP)}},
 'split':{'train_folios':len(train_f),'heldout_folios':len(test_f)},
 'y_o':{'rc12_train_stems':len(ystems12),'ponly_train_stems':len(ystemsP),
        'permutation_rc12':perm12,'permutation_ponly':permP},
 'comparison':controls,
 'caveats':['Six prefix contrasts were previously explored; multiplicity and data reuse apply.',
            'The holdout hypothesis y/o was proposed after inspecting the full corpus; this is internal stability only.',
            'P-only TSV and RC1.2 tokenize differently; neither should silently replace the other.',
            'Row-position permutation tests a positional effect, not encryption or semantic identity.']
}
def serializable(z):
 if isinstance(z,dict):return {k:serializable(v) for k,v in z.items()}
 if isinstance(z,list):return [serializable(v) for v in z]
 if isinstance(z,float) and not math.isfinite(z):return None
 return z
(OUT/'results.json').write_text(json.dumps(serializable(report),ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def val(z):return '' if z is None or (isinstance(z,float) and not math.isfinite(z)) else z
with (OUT/'prefix_comparison.csv').open('w',newline='') as f:
 wr=csv.writer(f);wr.writerow(['corpus','pair','n_train_stems','or_all','ci_low','ci_high','p','or_A','or_B','or_para_start','or_not_para_start','or_first_vs_second','or_last_vs_middle'])
 for x in controls:
  a=x['heldout_all'];ci=a.get('ci95',[None,None])
  wr.writerow([val(z) for z in [x['corpus'],x['pair'],x['train_stems'],a.get('or'),*ci,a.get('p'),x['heldout_currierA'].get('or'),x['heldout_currierB'].get('or'),x['heldout_start_para'].get('or'),x['heldout_non_start_para'].get('or'),x['heldout_first_second'].get('or'),x['heldout_last_middle'].get('or')]])
print('Inputs:',report['datasets'])
print('Y/O RC1.2:',controls[0]);print('Y/O P-only:',controls[6]);print('Permutation:',report['y_o'])
print('Comparisons:',[(x['corpus'],x['pair'],x['train_stems'],x['heldout_all'].get('or')) for x in controls])
