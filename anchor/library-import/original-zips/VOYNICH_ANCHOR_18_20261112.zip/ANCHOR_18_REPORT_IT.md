# ANCHOR-18 | Controllo della pista Egerton 747 / BnF Latin 6823

**Data:** 12 novembre 2026  
**Stato:** ricognizione documentale, nessuna decifrazione. RC1.4.2 resta CLOSED_PENDING_VALIDATION e non è stato toccato.

## Risultato fondamentale

Le analogie tra Egerton MS 747 (British Library) e BnF Latin 6823 **non costituiscono due conferme storiche indipendenti**: entrambi appartengono alla tradizione illustrativa del *Tractatus de herbis*, con rapporto di derivazione ampiamente segnalato nella letteratura. In Egerton 747, *ebulus* e *edera nigra* compaiono sul folio 37r, ma il catalogo descrive le voci del manoscritto come organizzate alfabeticamente, quantomeno per iniziale. Entrambe iniziano per E. Perciò la semplice presenza sulla stessa pagina non è un indicatore specifico di rapporto col Voynich, né possiamo assegnargli una probabilità numerica senza un campione comparativo.

## Analisi critica di f35v

La somiglianza fra Voynich f35v e BnF Latin 6823 f60r è pubblicata da René Zandbergen, che considera plausibile un'influenza da illustrazioni affini, non una copia esatta. Il dettaglio è contestato da altri commentatori: un disegno che sembri edera (pianta rampicante, frutti) non autorizza a leggere automaticamente *edera* nel Voynich. F23r = *Sambucus ebulus* è anch'essa un'identificazione proposta, non una determinazione certa.

## Controllo sui byte del corpus

Sorgente ZL3b-n.txt: 411.671 byte, SHA-256 `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc` verificato. Letture controllate sui loci:

- `f23r.1,@P0`: prima parola `pydchdom`;
- `f35v.1,@P0`: prima parola `parchor`;
- `f89r2.4,@Lf`: `saloiinsheol`, etichetta proposta per il frammento #35, **ma la geometria dell'assegnazione non è validata**.

La sequenza letterale `saloiinsheol` non compare nel testo trascritto di f35v. Non significa che un nome cifrato sia stato escluso: l'assenza di ripetizione letterale non discrimina cifratura, abbreviazione o testo descrittivo.

## Decisione

**Nessuna delle due attribuzioni botaniche è promossa ad ancora semantica.** L'ipotesi di dipendenza illustrativa fra il Voynich e la tradizione del Tractatus rimane valutabile, ma richiede una prova visuale cieca con controlli negativi e un modello predefinito che produca previsioni su altri fogli. Un solo confronto morfologico noto non consente di distinguere derivazione diretta e repertorio iconografico comune.

**Prossimo bersaglio utile:** riunire 10-20 disegni di piante con analoghi in manoscritti della tradizione *Tractatus*, più campioni coevi di altra tradizione, ottenere giudizi indipendenti sulle immagini senza didascalie e riservare almeno la metà dei casi per una verifica fuori campione. Soltanto dopo il successo iconografico analizzare le etichette Voynich con un'ipotesi grafema-significato preregistrata.

## Fonti pubbliche

- British Library, catalogo Egerton MS 747: https://searcharchives.bl.uk/catalog/032-001983805
- René Zandbergen, illustrazioni comparative: https://www.voynich.nu/illustr.html
- René Zandbergen, descrizione f35v: https://voynich.nu/q05/index.html
- Analisi delle tradizioni figurative (Università/Ministero della Cultura): https://bupd.cultura.gov.it/wp-content/uploads/2023/07/0cd0b741de10d55bc025d869c46a93fd.pdf
- Controinterpretazione f35v: https://voynichrevisionist.com/2019/05/25/retrospective-justifications/
