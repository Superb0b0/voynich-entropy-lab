#!/usr/bin/env python3
"""ANCHOR-18: strictly limited reproducible check of declared EVA readings."""
import pathlib,re,json,hashlib,sys
p=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else '/mnt/data/files/ZL3b-n.txt')
data=p.read_bytes(); lines=data.decode('utf-8').splitlines()
expected='bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc'
h=hashlib.sha256(data).hexdigest()
if h!=expected: raise SystemExit('FAIL CLOSED: corpus SHA mismatch')
loc={}
for line in lines:
 m=re.match(r'^<([^>]+)>\s+(.*)$',line)
 if m:loc[m.group(1)]=m.group(2).strip()
claims={'f23r.1,@P0':'pydchdom','f35v.1,@P0':'parchor','f89r2.4,@Lf':'saloiinsheol'}
for k,v in claims.items():
 assert k in loc,k
 assert loc[k].replace('<%>','').split('.')[0].strip()==v,(k,loc[k])
labels={k:loc[k] for k in ['f89r2.2,@Lf','f89r2.3,@Lf','f89r2.4,@Lf','f89r2.5,@Lf']}
f35=' '.join(v for k,v in loc.items() if k.startswith('f35v.'))
f23=' '.join(v for k,v in loc.items() if k.startswith('f23r.'))
result={
 'experiment':'ANCHOR-18','date':'2026-11-12','status':'DOCUMENTARY_TRIAGE_NOT_DECIPHERMENT',
 'corpus_sha256':h,'corpus_bytes':len(data),
 'verified_lexical_claims':claims,'f89r2_first_label_run':labels,
 'candidate_ivy_label':'saloiinsheol',
 'candidate_ivy_label_in_f35v_literal':('saloiinsheol' in f35),
 'candidate_ivy_label_in_f23r_literal':('saloiinsheol' in f23),
 'ivy_label_assignment':'UNVERIFIED_GEOMETRY',
 'historical_source_relation':'Egerton MS 747 and BnF Lat. 6823 share a Tractatus illustrative tradition; not independent confirmations of taxonomy',
 'cooccurrence_caveat':'Egerton is organized by initial letter at least; ebulus and edera share E. Folio co-occurrence has no measured evidentiary weight.',
 'taxonomy_status':{'f23r':'Sambucus ebulus candidate only','f35v':'ivy/oak depiction interpretation disputed'},
 'semantic_anchor':'NONE_VALIDATED',
 'release_gate':'CLOSED_FOR_SEMANTIC_PROMOTION',
 'limits':['No blind image rankings or baseline herbarium set was available in this execution', 'No independent Voynich plant names established','Literal string absence is not a cipher falsification']}
print(json.dumps(result,ensure_ascii=False,indent=2))
