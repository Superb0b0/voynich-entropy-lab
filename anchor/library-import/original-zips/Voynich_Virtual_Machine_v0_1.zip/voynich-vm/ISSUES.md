# Limiti della v0.1

1. Continuità fra righe insufficiente. Lo stato si azzera a ogni riga; una futura versione deve confrontare una memoria inter-riga esplicita con un controllo senza memoria, senza copiare righe.
2. Solo sette gruppi nel test e copertura incompleta delle sezioni. Per versioni successive serve una valutazione per gruppi pianificata che copra tutte le sezioni; non si cambia lo split v0.1 dopo averne visto l'esito.
3. Valutatore RC1.4 storico non acquisito. Nessuna attestazione di equivalenza del nuovo valutatore; conservare il profilo RC1.2 e i suoi riferimenti separati.
4. Nessun modulo cifrario o lingua sorgente. Aggiungerlo richiederebbe una specifica generativa esplicita, non una traduzione suggerita a posteriori.
5. Nessuna morfologia scoperta. I contesti di caratteri e i prefissi usati nello stato sono descrittori, non morfemi o glifi storici dimostrati.
