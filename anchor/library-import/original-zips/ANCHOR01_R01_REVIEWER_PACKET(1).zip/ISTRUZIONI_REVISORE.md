# ANCHOR-01-R01 · Delimitazione indipendente di regioni

Ricevi due immagini integrali, A.jpg e B.jpg, nello stesso ordine per entrambi i
revisori. Non contengono overlay aggiunti. I glifi originali, i numeri scritti sul
manoscritto e il layout sono visibili: non si dichiara anonimato del manoscritto o
cecità al contenuto visivo. Non ricevi EVA, warning, coordinate precedenti,
diagnostica, suggerimenti di collegamento o ipotesi semantiche.

Non leggere né trascrivere le etichette. Non cercare significati, associazioni o
corrispondenze figura–testo. Lavora senza consultare l'altro revisore, fonti di
trascrizione, i precedenti risultati o il registro delle correzioni. Se hai già
visto quei risultati o quelle coordinate, dichiaralo al custode prima di iniziare:
il custode deve scegliere un revisore senza tale esposizione per questo protocollo.

## Presentazione e unità

Mantieni l'intera pagina disponibile, senza ritaglio, rotazione o ricampionamento.
Lo zoom del visualizzatore è consentito; registra però i punti nei pixel del file
originale, origine in alto a sinistra. A è 1449 × 1800; B è 1336 × 1800. Nessun
numero atteso di oggetti è fornito o deve essere forzato.

Completa quattro passaggi nell'ordine A/depicted_region, A/glyph_region,
B/depicted_region, B/glyph_region. In ciascuno ispeziona l'intera ruota zodiacale,
dal centro al limite esterno visibile. Non includere scritte marginali esterne o
la foliazione. Registra il completamento anche se non trovi oggetti.

- `depicted_region`: delimita ogni corpo umano visibile e ogni elemento figurativo
  autonomo del centro. Per un corpo includi testa e parti del corpo visibili;
  escludi la stella tenuta e il contenitore come appendici. Non inventare parti
  nascoste. Stelle tenute e contenitori non sono unità aggiuntive da censire.
- `glyph_region`: delimita ogni gruppo discreto di glifi entro la ruota. Testo
  circolare continuo è una regione continua; separa gruppi quando esiste una
  separazione visiva, senza usare la lettura. Non associare il gruppo a una figura.

I passaggi sono domini di lavoro, non classi fini. Puoi assegnare qualsiasi classe
strutturale a una regione di ciascun passaggio: il sistema non usa la classe per
scegliere le corrispondenze. Non correggere una classe per farla coincidere col
nome del passaggio. Non suddividere la stessa regione più volte nello stesso
passaggio. La scelta della segmentazione resta una parte osservabile del disaccordo.

## Campi e delimitazione

Per ciascuna regione usa un ID locale arbitrario univoco, composto da lettere
ASCII, numeri, trattini o underscore. Non usare ID storici o trascrizioni come ID.
Nel campo `polygon_preview_px` inserisci quattro vertici ordinati lungo il bordo,
in senso orario o antiorario: un quadrilatero convesso che racchiude strettamente
la regione visibile. Per testo ruotato usa un quadrilatero ruotato. Non è una
segmentazione anatomica pixel per pixel. Non includere altri oggetti per comodità.

`source_object_kind` descrive solo il tipo di oggetto:

| Valore | Definizione visiva |
|---|---|
| human_candidate | Rappresentazione riconoscibile di un corpo umano, senza attribuirne sesso o identità |
| central_star | Elemento stellare autonomo posto nel centro della composizione; non una stella tenuta |
| other_depicted_object | Altro elemento figurativo autonomo centrale, per esempio l'animale zodiacale |
| text_region | Regione di glifi; non occorre leggere o interpretare il testo |

`annotation_status` è separato dalla classe:

- `present`: oggetto individuato e delimitabile con quadrilatero; classe definita.
- `ambiguous`: presenza, separazione o identificazione incerta; spiega quale. Puoi
  conservare un quadrilatero provvisorio, ma non verrà usato nel matching.
- `not_localizable`: oggetto plausibile/visibile ma impossibile da delimitare senza
  inventare una regione; poligono `null`, motivo obbligatorio.
- `absent`: nota esplicita di un sospetto oggetto non confermato, con riferimento
  verbale alla zona cercata, poligono `null`. Non inventare righe di assenza per
  posizioni attese. Le assenze sono riportate separatamente: qui non esiste un
  universo di caselle negative né una misura di specificità.

Per stati incerti puoi lasciare `source_object_kind=null`. Non usare mai
`ambiguous` come classe. Non usare contenitore, indumento, orientamento o postura
come attributi: nessun attributo primario è selezionato.

`confidence` riguarda solo la delimitazione/presenza visiva, senza punteggi:

| Livello | Ancora osservabile |
|---|---|
| high | Regione interamente visibile e separabile; nessun tratto del contorno ricostruito |
| medium | Regione parzialmente occlusa o con bordo sbiadito, ma parti visibili sufficienti a delimitare un inviluppo; indica il bordo incerto |
| low | Occorrerebbe ricostruire parti non visibili o scegliere fra regioni alternative; usa ambiguous o not_localizable, mai present |

Per una nota `absent`, high/medium/low indica rispettivamente zona interamente
visibile, parzialmente visibile o non sufficientemente ispezionabile; spiega il caso.

## Consegna

Compila il modello JSON con ID assegnato dal custode, hash del protocollo e del
pacchetto forniti dal custode, quattro completamenti e il tuo inventario libero.
La lista vuota del modello non è una consegna completata. Annota eventuali dubbi
nelle note senza consultarne la soluzione con altri.

Consegna una sola versione definitiva al custode. Il custode ne registra UTC e
SHA-256 e chiude separatamente ogni revisore. Non comunicare con l'altro revisore
finché il custode non conferma che entrambe le consegne e le metriche sono chiuse.
L'eventuale aggiudicazione successiva produrrà un dataset distinto, non una
riscrittura dei tuoi dati originali o delle metriche di accordo.
