# EXP-INTERNAL-EDIT-POS-01 | Controllo avversariale sulle modifiche interne

**Data:** 12 novembre 2026. **Stato:** esplorativo, NON preregistrato, stessi 54 folii TEST già consultati in esperimenti precedenti. **RC1.4.2:** invariato, `CLOSED_PENDING_VALIDATION`.

## Domanda
Le varianti grafiche presenti in righe adiacenti dello stesso paragrafo mostrano una preferenza specifica per le modifiche nella parte interna della parola, distinta dalla normale concentrazione lessicale?

## Protocollo
- Corpus: 54 folii ZL3b e IT2a, snapshot originale del sottoinsieme EXP-COMP-01, 953 coppie di righe adiacenti per ciascuna trascrizione.
- Unita di conteggio: per ogni coppia consecutiva di righe dello stesso paragrafo, tutte le coppie **distinte** di parole a Levenshtein 1; ogni coppia di tipi conta una volta per coppia di righe.
- Inizio: primi 2 caratteri della forma piu lunga; fine: ultimi 2; interno: resto. Priorita inizio per parole corte e casi sovrapposti. Inserimento/cancellazione con posizione di cancellazione sinistra in caso di ambiguita.
- Controllo: 999 permutazioni di righe *dentro ciascun paragrafo*. Preserva contenuti, lunghezze, frequenze, folii e paragrafi; cambiano soltanto le adiacenze. PRNG NumPy PCG64 seed 20261112.
- I valori p sono unilaterali empirici, con correzione +1 su 999. Nessuna correzione per test multipli: analisi esplorativa.

## Risultati principali

| Misura | ZL3b osservato | ZL3b nullo | IT2a osservato | IT2a nullo |
|---|---:|---:|---:|---:|
| Coppie edit1 nelle righe adiacenti | 1.793 | 1.592,78 | 1.895 | 1.678,90 |
| Coppie identiche condivise nelle righe adiacenti | 460 | 403,82 | 491 | 430,05 |
| Quota modifiche interne fra le coppie edit1 | 18,46% | 17,63% | 19,00% | 18,09% |
| Quota modifiche nei primi due caratteri | 54,99% | 55,15% | 53,09% | 53,18% |

### Significativita
- Eccesso assoluto di coppie edit1: ZL3b +12,57%, IT2a +12,87%, p=0,001 in entrambe.
- Eccesso assoluto di ripetizioni identiche: ZL3b +13,91%, IT2a +14,17%, p=0,001 in entrambe.
- Eccesso percentuale di modifiche interne: p=0,106 ZL3b, p=0,089 IT2a (non convincenti).
- Frazione sostituzioni versus inserzioni/cancellazioni: nessuno scostamento significativo.
- Rapporto coppie edit1 / parole identiche condivise: ZL3b 3,898 vs nullo 3,949 (p_superiore=0,617); IT2a 3,859 vs nullo 3,908 (p_superiore=0,632). **Nessun arricchimento differenziale delle modifiche rispetto alle ripetizioni.**

## Decisione
L’ordinamento reale delle righe arricchisce sia la ricorrenza esatta sia la parentela edit1, in proporzioni simili. Non emerge una preferenza specifica per le modifiche interne o per una trasformazione rispetto a un riuso esatto. Questa evidenza e compatibile con una concentrazione locale delle famiglie lessicali, **non dimostra** copia-muta direzionale.

Il divario precedente fra generatore composizionale e Voynich sulla percentuale di modifiche interne **rimane descrittivo**: potrebbe derivare da un repertorio lessicale o distribuzione delle lunghezze differente, non da una regola di vicinanza tra righe.

## Limiti
- L’unità statistica qui e la coppia di tipi; non una singola parola, un singolo scriba o un evento storico.
- Preservare il contenuto delle righe controlla i margini lessicali, ma non ricrea gli effetti di larghezza e posizione del testo in manoscritti reali.
- Due trascrizioni dello stesso manoscritto non sono repliche indipendenti.
- I folii sono stati consultati durante sviluppi precedenti: nessun test cieco, nessuna preregistrazione.
- Il test esamina soltanto il sottoinsieme sperimentale di 54 folii e non la totalità del manoscritto.

## Riproduzione
Con Python 3 e NumPy installati: `python experiment.py` nella cartella estratta. Lo script usa unicamente `input_test_folios.json` e ricrea `results.json`, `statistics.csv` e `permutations.csv`.

La pipeline RC1.4.2 rimane congelata. Non effettuati builder, PCA, clustering o conditional coupling.
