EXP-INTERNAL-EDIT-POS-01: controlli delle varianti tra righe adiacenti, ZL3b e IT2a.

Leggi RAPPORTO.md.

Riproduci: python experiment.py (richiede NumPy).
Nessuna rete necessaria.
