#!/usr/bin/env python3
"""Exploratory adjacent-row edit position vs paragraph-internal random row order.
No tuning. Exact words + row inventories preserved. Same manuscript in two transcriptions.
"""
import sys, json, csv, math
from collections import defaultdict, Counter
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
SNAPSHOT=json.loads((HERE/'input_test_folios.json').read_text())['folios']


def edit(a,b):
 if a==b or abs(len(a)-len(b))>1:return None
 if len(a)==len(b):
  ix=[i for i,(x,y) in enumerate(zip(a,b)) if x!=y]
  return ('sub',ix[0],len(a)) if len(ix)==1 else None
 small,large=(a,b) if len(a)<len(b) else (b,a)
 for i in range(len(large)):
  if large[:i]+large[i+1:]==small:return ('indel',i,len(large))
 return None

def category(e):
 op,pos,L=e
 return 'first' if pos<2 else ('last' if pos>=L-2 else 'middle')

def rowpair(A,B):
 c=Counter()
 c['exact_shared']=len(set(A)&set(B))
 # Does not reuse Levenshtein caches: strict one edit computation, equal length and abs(diff)==1.
 b_by_len=defaultdict(list)
 for b in set(B):b_by_len[len(b)].append(b)
 for a in set(A):
  for n in (len(a)-1,len(a),len(a)+1):
   for b in b_by_len.get(n,[]):
    e=edit(a,b)
    if e:
     op,pos,L=e
     c['all']+=1;c[category(e)]+=1;c['op_'+op]+=1
     c['len_'+str(L)+'_all']+=1
     c['len_'+str(L)+'_'+category(e)]+=1
     c['op_'+op+'_'+category(e)]+=1
 return c

def precompute(tr):
 paragraph=[];total_rows=0
 for f in sorted(SNAPSHOT):
  for par in SNAPSHOT[f]:
   rows=[list(r) for r in par[tr]]
   if len(rows)<2:continue
   n=len(rows);total_rows+=n
   # ordered cache: row pair A->B used in permutation.
   pair={(i,j):rowpair(rows[i],rows[j]) for i in range(n) for j in range(n) if i!=j}
   paragraph.append((f,n,pair))
 return paragraph,total_rows

def pooled(paragraph,perms,rng):
 originals=Counter();nulls=[];filtered=Counter();n_pairs=0
 for f,n,pair in paragraph:
  for i in range(n-1):originals.update(pair[i,i+1]);n_pairs+=1
 for rep in range(perms):
  out=Counter()
  for f,n,pair in paragraph:
   order=rng.permutation(n)
   for i in range(n-1):out.update(pair[int(order[i]),int(order[i+1])])
  nulls.append(out)
 return originals,nulls,n_pairs

def analyze(obs, nulls, keys):
 totals=[]
 for n in nulls:totals.append({k:n.get(k,0)/max(n.get('all',0),1) if k not in ('all','exact_shared') else n.get(k,0) for k in keys})
 o={k:obs.get(k,0)/max(obs.get('all',0),1) if k not in ('all','exact_shared') else obs.get(k,0) for k in keys}
 rows=[]
 for k in keys:
  a=np.asarray([r[k] for r in totals]);v=o[k]
  rows.append({'metric':k,'observed':float(v),'null_mean':float(a.mean()),'null_sd':float(a.std(ddof=1)),'delta':float(v-a.mean()),'p_upper':float((np.count_nonzero(a>=v)+1)/(len(a)+1)),'p_lower':float((np.count_nonzero(a<=v)+1)/(len(a)+1)),'null_q025':float(np.quantile(a,.025)),'null_q975':float(np.quantile(a,.975))})
 return rows

def run():
 rng=np.random.default_rng(20261112)
 out={'experiment':'EXP-INTERNAL-EDIT-POS-01','status':'EXPLORATORY, PREVIOUSLY EXAMINED FOLIOS','permutations':999,'null':'uniform permutations of entire rows within same paragraph; row content and length retained; all ordered row-pair edit links counted', 'transcriptions':{}}
 all_rows=[];nullrows=[]
 for tr in ('zl','it'):
  print('PREP',tr,flush=True)
  pre,rows=precompute(tr)
  obs,nulls,pairs=pooled(pre,999,rng)
  keys=['all','exact_shared','first','middle','last','op_sub','op_indel','op_sub_middle','op_indel_middle']
  # keys indicate fraction of all edit pairs, except 'all' and 'exact_shared' which are raw counts
  tab=analyze(obs,nulls,keys)
  for r in tab:r['transcription']=tr;all_rows.append(r)
  out['transcriptions'][tr]={'paragraphs':len(pre),'rows':rows,'adjacent_pairs':pairs,'raw_count':dict(obs),'tests':tab}
  print('RESULT',tr,'n',obs['all'],'pairs',pairs,flush=True)
  for r in tab:print(r['metric'],f"obs={r['observed']:.6f} null={r['null_mean']:.6f} p_hi={r['p_upper']:.5f} p_lo={r['p_lower']:.5f}",flush=True)
  for i,n in enumerate(nulls):nullrows.append({'transcription':tr,'iteration':i,'all':n.get('all',0),'exact_shared':n.get('exact_shared',0),'middle_fraction':n.get('middle',0)/max(n.get('all',0),1),'first_fraction':n.get('first',0)/max(n.get('all',0),1),'middle_sub_fraction':n.get('op_sub_middle',0)/max(n.get('all',0),1)})
 (HERE/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True))
 with (HERE/'statistics.csv').open('w',newline='') as fh:
  w=csv.DictWriter(fh,fieldnames=list(all_rows[0]));w.writeheader();w.writerows(all_rows)
 with (HERE/'permutations.csv').open('w',newline='') as fh:
  w=csv.DictWriter(fh,fieldnames=list(nullrows[0]));w.writeheader();w.writerows(nullrows)
if __name__=='__main__':run()
