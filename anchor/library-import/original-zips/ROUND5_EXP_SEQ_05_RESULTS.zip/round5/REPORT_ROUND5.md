# EXP-SEQ-05 — ROUND 5, rapporto esplorativo conclusivo
**11 novembre 2026.** Nessun audit storico riaperto. Misure relative a paragrafi Currier omogenei di almeno 4 righe salvo dove specificato. Parser RC1.2 del precedente `analysis.py` in `/mnt/data/files`. Script `round5.py` in questo pacchetto. **Non si propone una decifrazione.**

## Origine dei dati
- `ZL3b-n.txt`: 411.671 byte, SHA-256 `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc`, 491 paragrafi eleggibili, 184 folii.
- `IT2a-n.txt`: 342.104 byte, SHA-256 `7f27a8b0feed8f6de0a99900df6bf912dd1d295c38e5f830bac8b41c3f536fb5`, 492 paragrafi eleggibili, 181 folii.
- Generatore Timm–Schinner: 30 JSON di testi rigenerati/byte-identici nel pacchetto precedente Round 4, 30 impronte del manifest storico verificate. 30 semi, 28.391 coppie consecutive entro paragrafo con lunghezza ≥4. La geometria sintetica e i raggruppamenti entro seme non sono quelli delle pagine manoscritte.

## 1. Re-flow (1.000 rispezzature per trascrizione)
Per ogni paragrafo, concatenazione completa dei token puliti e permutazione **senza reinserimento** del vettore originale delle lunghezze di riga in token; nuova suddivisione ai confini cumulativi. Le parole e il numero di righe di ciascun paragrafo sono conservati. Le colonne riportano O/E della ripetizione esatta entro folio a lag 1, e il confronto con il re-flow è empirico e distinto dal test di permutazione entro folio già calcolato.

| Colonna | ZL3b originale | ZL3b re-flow media [2,5%;97,5%] | IT2a originale | IT2a re-flow media [2,5%;97,5%] |
|---|---:|---|---:|---|
| 1 | 0,082 | 0,143 [0,090; 0,198] | 0,078 | 0,145 [0,090; 0,205] |
| 2 | 0,223 | 0,169 [0,115; 0,228] | 0,268 | 0,181 [0,123; 0,243] |
| 3 | 0,182 | 0,177 [0,120; 0,242] | 0,236 | 0,189 [0,133; 0,248] |
| 4 | 0,239 | 0,173 [0,112; 0,230] | 0,215 | 0,188 [0,128; 0,252] |
| 5 | 0,175 | 0,158 [0,099; 0,219] | 0,198 | 0,173 [0,111; 0,235] |

**Conclusione circoscritta:** per la colonna 1 il rapporto originale è inferiore a quasi tutti i re-flow (p inferiore empirico 0,0120 ZL3b, 0,0100 IT2a); **il deficit NON scompare integralmente**, perché anche il re-flow produce O/E intorno a 0,14. Per le colonne 2–5, il deficit osservato è generalmente compatibile con o meno estremo di quello re-flow. Questo indica un'importante componente di flusso/specificità lessicale entro paragrafo oltre a un contributo dei confini della prima colonna.

**qo nelle righe 3–4:** ZL3b originale 5/17,38 = 0,288, re-flow media 1,140, percentile [0,598;1,658], p inferiore 1/1001. IT2a originale 5/17,82=0,281, re-flow media 1,147, percentile [0,680;1,638], p inferiore 1/1001. Questo segnale dipende chiaramente dall'allineamento originale delle righe.

**Sensibilità di un effetto simulato.** Il pacchetto contiene due controlli esplorativi distinti: (a) inserimento diagnostico di ripetizioni esatte nel 5% delle coppie, rilevato 100/100 rispetto a una soglia di re-flow, **non valido come stima di potenza inferenziale calibrata**; (b) una simulazione sulla distribuzione empirica, riducendo artificialmente del 5% i rapporti O/E dei re-flow: sensibilità della soglia inferiore 2,5% pari a circa 2,9% (ZL3b colonna 1) e 3,9% (IT2a colonna 1), a fronte del 2,5% di coda nominale. Quindi un *piccolo* effetto simulato del 5% è scarsamente rilevabile con questa statistica/soglia. Non fare affermazioni di piena potenza.

## 2. Colonne spostate
O/E esatto con nullo di permutazione dei secondi termini entro folio e IC bootstrap per folio nei CSV.

| Prima colonna j → colonna j+1 | ZL3b | IT2a |
|---|---:|---:|
| 1→1 | 0,082 | 0,078 |
| 1→2 | 1,003 | 0,944 |
| 1→3 | 1,391 | 1,555 |
| 2→1 | 0,819 | 1,019 |
| 2→2 | 0,223 | 0,268 |
| 2→3 | 1,145 | 0,933 |
| 2→4 | 1,035 | 1,227 |
| 3→1 | 0,970 | 0,971 |
| 3→2 | 1,279 | 1,361 |
| 3→3 | 0,182 | 0,236 |
| 3→4 | 1,321 | 1,330 |
| 3→5 | 1,128 | 1,047 |

Le stesse-colonne sono nettamente depresse rispetto alle colonne ±1/±2. Questo è compatibile con un vincolo di **allineamento verticale**, non con il solo numero di token di separazione nel flusso. I denominatori cambiano tra spostamenti, perché sono necessarie entrambe le posizioni.

## 3. Replica della misura di Averyanov: informazione mutua dell'incipit
Unità di incipit implementata: `ch`/`sh` come unità EVA iniziali, altrimenti il primo carattere EVA. MI in **nat** delle coppie consecutive nella stessa pagina; nullo: 10.000 permutazioni degli incipit entro pagina. Per chiarezza si riporta sia la coorte eleggibile (L≥4) sia **tutti i loci P**, quest'ultima più vicina al protocollo di Averyanov. Le coppie e i denominatori differiscono tra ambiti.

| Ambito | Coppie | MI osservata | MI nulla media | z | Stessa apertura osservata / attesa |
|---|---:|---:|---:|---:|---|
| ZL3b, tutti P | 3.923 | 0,1131 | 0,0380 | +23,81 | 6,96% / 13,62% |
| IT2a, tutti P | 3.912 | 0,1192 | 0,0398 | +24,68 | 6,80% / 13,52% |
| ZL3b, eleggibili | 3.239 | 0,1236 | 0,0438 | +21,31 | 7,01% / 13,47% |
| IT2a, eleggibili | 3.211 | 0,1278 | 0,0462 | +21,71 | 6,88% / 13,45% |

Per tutte le analisi MI manoscritte, p superiore nel Monte Carlo = 1/10001. Averyanov riferisce 0,1683 contro 0,0599 e z +23,95; il **z è molto vicino**, ma le MI assolute sono diverse, quindi non è una riproduzione bit-per-bit della sua implementazione. I denominatori, la scelta delle unità e il trattamento di particolari loci potrebbero differire.

**Generatore (30 semi):** il test valido mantiene i confini di paragrafo, non conta transizioni artificiali tra paragrafi distinti e rimescola gli incipit entro ciascun seme. Su 28.391 coppie, MI 0,02585 nat contro 0,00315 del nullo, z +66,90, ripetizione della stessa apertura 18,72% contro 12,58%. p superiore 1/10001. I **z non sono confrontabili** con quelli dei manoscritti a causa della differente cardinalità e raggruppamento (30 semi contro ~200 pagine); il segno e il tasso assoluto mostrano che questa configurazione favorisce, non evita, gli incipit identici. La cifra **83% di Averyanov riguarda un'altra metrica** e non è direttamente riproducibile con questo confronto.

## 4. Ciclo direzionale d → q → y
L'apertura della prima parola è assegnata a una delle tre unità `d`, `q`, `y` quando pertinente; **si considerano soltanto coppie con due classi diverse appartenenti alla terna**. I passi in avanti sono `d→q`, `q→y`, `y→d`. La quota 0,5 è un riferimento di simmetria orientata fra coppie non ordinate, non un nullo che preservi la struttura delle posizioni; i test binomiali riportati in JSON sono descrittivi, non cluster-robust.

| Trascrizione | Ambito | Passi avanti / eleggibili | Quota |
|---|---|---:|---:|
| ZL3b | Tutti | 289/456 | 63,4% |
| ZL3b | 2→3 | 65/99 | 65,7% |
| ZL3b | 3→4 | 65/100 | 65,0% |
| ZL3b | 4→5 | 39/70 | 55,7% |
| IT2a | Tutti | 290/455 | 63,7% |
| IT2a | 2→3 | 66/100 | 66,0% |
| IT2a | 3→4 | 68/103 | 66,0% |
| IT2a | 4→5 | 37/69 | 53,6% |

**A/B:** ZL3b A 120/185=64,9%, B 169/271=62,4%; nella coppia 3→4, A 31/42=73,8%, B 34/58=58,6%. IT2a A 119/182=65,4%, B 171/273=62,6%; nella coppia 3→4, A 30/41=73,2%, B 38/62=61,3%. Le dimensioni sono modeste; ad esempio ZL3b A/B 3→4 dà test Fisher puramente descrittivo p≈0,14 e i contrasti fra le coppie condividono righe. **Non si dimostra che il ciclo sia concentrato esclusivamente in 3–4**: 2→3 ha quota praticamente uguale in entrambi i corpus, e la maggiore quota in A 3→4 richiede test dedicato. Il modello Timm–Schinner dà 361/707=51,1% con la stessa definizione sulle sue coppie entro paragrafo.

## 5. Curva completa dei lag della prima parola: ripetizioni esatte

| Lag | ZL3b osservate/attese (O/E) | IT2a osservate/attese (O/E) | Timm–Schinner osservate/attese (O/E) |
|---|---|---|---|
| 1 | 14/171,43 (0,082) | 13/167,55 (0,078) | 497/160,90 (3,089) |
| 2 | 20/112,58 (0,178) | 18/109,38 (0,165) | 354/105,27 (3,363) |
| 3 | 12/65,79 (0,182) | 11/62,70 (0,175) | 160/53,69 (2,980) |
| 4 | 18/42,74 (0,421) | 17/40,26 (0,422) | 69/24,48 (2,818) |
| 5 | 16/28,42 (0,563) | 17/26,99 (0,630) | 33/9,17 (3,597) |
| 6 | 12/19,68 (0,610) | 12/19,10 (0,628) | 7/3,30 (2,124) |

**Tassi assoluti lag 1:** manoscritto ZL3b 14/2932 = 0,48%, nullo 171,43/2932 = 5,85%; IT2a 13/2900=0,45%, nullo 167,55/2900=5,78%; generatore 497/28391=1,75%, nullo 160,90/28391=0,57%. Le attese e i denominatori radicalmente diversi vietano di interpretare i soli O/E come un confronto diretto di meccanismi.

## 6. Provenienza dei sette rapporti qo- e delle sottoclassi
Nel pacchetto si allegano immutati i CSV del Round 4 `qo_adjacent_pairs.csv` e `qo_subclasses_3_4.csv`: i rapporti O/E per le sette coppie sono rispettivamente per ZL3b [0, 0,123, 0,288, 0,272, 0,279, 0,601, 0,317] e IT2a [0, 0,240, 0,281, 0,267, 0,277, 0,576, 0,279]. Le celle rare delle sottoclassi qok/qot/altre qo non sono stime robuste autonome. Gli O/E qui indicati sono marginali, mentre in altre tabelle i nulli sono stratificati per folio.

## Precedente e limiti
Il 18 ottobre 2026 V. Averyanov ha pubblicato il rapporto `Lines remember each other: the cycle d → q → y` (https://voynich.site/en/findings/line-openers/), etichettato dall'autore «ESTABLISHED», **non attestazione di revisione paritaria**. Lavoro precedente su incipit e ciclo direzionale; le nostre analisi rappresentano una replica/esplorazione con estensioni su parole esatte, colonne, paragrafi e trascrizioni. I nostri risultati non sostengono una rivendicazione di originalità dell'evitamento degli incipit.

Limiti centrali: effetto di composizione e lunghezza dei paragrafi preservati solo parzialmente dal nullo entro folio; il re-flow permuta lunghezze **all'interno di ciascun paragrafo**, non ricostruisce i confini grafici effettivi; ZL3b e IT2a non sono campioni indipendenti; generatore raggruppato per seme, non per pagina; modelli e confronti scelti esplorativamente, test di potenza simulati non preregistrati. Non sono state eseguite nuove verifiche sugli artefatti storici.

## Conclusioni in dieci righe
1. Le aperture di riga del Voynich mostrano un forte evitamento, replicato con MI e tassi di identità su ZL3b/IT2a, concorde nel segno e nello z con Averyanov.
2. I re-flow eliminano l'anti-associazione specifica di `qo-` nelle righe 3–4 (O/E da circa 0,28 a circa 1,14).
3. La prima colonna conserva un deficit di ripetizione anche nei re-flow (O/E medio 0,14), segno che il fenomeno non è tutto attribuibile ai confini reali.
4. Le colonne 2–5 non mostrano un deficit originale sistematicamente più forte del re-flow.
5. Le colonne spostate ±1/±2 non presentano la stessa depressione: esiste una specificità dell'allineamento verticale.
6. La curva a lag 1–6 mostra attenuazione del deficit ma non distingue da sola un vincolo locale da uno lessicale di paragrafo.
7. Il ciclo d→q→y è presente descrittivamente (circa 63–64% dei passi eleggibili), con quota simile in 2→3 e 3→4.
8. La maggiore quota A 3→4 è promettente ma campionariamente fragile; non è dimostrata una concentrazione esclusiva in quella posizione.
9. La configurazione verificata Timm–Schinner non riproduce l'evitamento delle parole esatte né degli incipit con questi protocolli, senza che ciò falsifichi l'intera famiglia autocopia.
10. La fase sperimentale termina qui: scrivere una **replica ed estensione esplorativa**, con precedente Averyanov e limiti espliciti, senza attribuire un meccanismo storico.
