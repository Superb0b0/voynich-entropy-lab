import sys,json,numpy as np
from pathlib import Path
sys.path.insert(0,'/mnt/data/r5work')
from round5 import OUT,ROOT,opener,mi,SEED
from scipy.stats import binomtest
from statsmodels.stats.proportion import proportion_confint
results=json.loads((OUT/'RESULTS.json').read_text());rng=np.random.default_rng(SEED+501)
# synthetic opener MI, preserve paragraph boundaries in pairs; permutations within verified seed
samples=[];alphabet=set()
for s in range(1,31):
 d=json.loads((ROOT/'r5work'/'generator'/f'seed_{s:02d}.json').read_text());sub=[]
 for p in d['paragraphs']:
  if len(p)>=4:
   sub.append([opener(w[0]) for w in p])
   alphabet.update(sub[-1])
 samples.append(sub)
classes=sorted(alphabet);mapping={s:i for i,s in enumerate(classes)};G=len(classes)
S=[]
for ps in samples:
 vals=np.asarray([mapping[c] for p in ps for c in p],dtype=np.int16)
 starts=[];ends=[];i=0
 for p in ps:
  starts.extend(range(i,i+len(p)-1));ends.extend(range(i+1,i+len(p)));i+=len(p)
 S.append((vals,np.asarray(starts,int),np.asarray(ends,int)))
x=np.concatenate([a[i] for a,i,j in S]);y=np.concatenate([a[j] for a,i,j in S]);observed=mi(x,y,G);eq=np.mean(x==y)
sims=np.empty(10000);reps=np.empty(10000)
for k in range(10000):
 xx=[];yy=[]
 for a,i,j in S:
  perm=a[rng.permutation(len(a))];xx.append(perm[i]);yy.append(perm[j])
 xx=np.concatenate(xx);yy=np.concatenate(yy)
 sims[k]=mi(xx,yy,G);reps[k]=np.mean(xx==yy)
result=dict(n_pairs=len(x),n_seeds=30,MI_nats=observed,null_MI_mean=float(sims.mean()),null_MI_std=float(sims.std(ddof=1)),z_MI=float((observed-sims.mean())/sims.std(ddof=1)),p_upper=(np.count_nonzero(sims>=observed)+1)/10001,repeat_obs=eq,repeat_null=float(reps.mean()),z_repeat=float((eq-reps.mean())/reps.std(ddof=1)),method='shuffle openers within each seed while evaluating only within-paragraph adjacent pairs, excluding cross-paragraph joins')
results['Timm-Schinner-30']['mi_paragraph_boundaries_preserved']=result
for fn in ('ZL3b-n.txt','IT2a-n.txt'):
 d=results[fn];a=np.load(OUT/(fn+'_reflow_1000.npz'))['values'];
 # empirical one-sided alpha and sensitivity to 5% multiplicative decrease, using all baseline flows for the reference CDF.
 powers=[]
 for k in range(6):
  arr=a[:,k];threshold=float(np.quantile(arr,.025));power=float(np.mean(arr*.95 < threshold));falsepos=float(np.mean(arr < threshold))
  powers.append(dict(column=k+1 if k<5 else 'qo_3_4',relative_drop=.05,lower_2p5_threshold=threshold,empirical_false_positive=falsepos,simulated_power=power))
 d['reflow_simulated_power_relative_minus_5percent']=powers
 for row in d['cycle']:
  n=row['n_cross_class'];f=row['forward'];row['wilson95']=list(proportion_confint(f,n,alpha=.05,method='wilson')) if n else [None,None]
  row['binomial_reference_p_two']=float(binomtest(f,n,0.5).pvalue) if n else None
(OUT/'RESULTS.json').write_text(json.dumps(results,indent=2))
(OUT/'timm_mi_corrected.json').write_text(json.dumps(result,indent=2))
print('corrected',result)
for fn in ('ZL3b-n.txt','IT2a-n.txt'):
 print(fn,results[fn]['reflow_simulated_power_relative_minus_5percent'])
