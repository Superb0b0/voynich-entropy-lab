# Vincoli di ripetizione e allineamento verticale nel manoscritto Voynich: replica esplorativa ed estensione del controllo sugli incipit

**Bozza di lavoro, 11 novembre 2026. Non sottoposta a revisione paritaria.**

## Riassunto

Analizziamo la relazione fra parole collocate nella medesima posizione di righe successive del manoscritto Voynich, in due trascrizioni IVTFF (ZL3b-n e IT2a-n). Il risultato riprende la precedente osservazione di V. Averyanov (18 ottobre 2026) secondo cui i primi segni delle righe tendono a non ripetersi. Il nostro obiettivo non è rivendicare la scoperta dell'evitamento degli incipit, ma valutarne l'estensione a parole intere, colonne successive e posizioni nel paragrafo, con controlli di rispezzatura del testo (*re-flow*) e confronto con una configurazione verificata del generatore Timm–Schinner. Nei paragrafi omogenei Currier di almeno quattro righe, le ripetizioni esatte della prima parola tra righe consecutive sono 14 su 2.932 coppie ZL3b, contro 171,43 attese sotto permutazione entro folio (O/E 0,082), e 13 su 2.900 IT2a, contro 167,55 attese (O/E 0,078). Il deficit riguarda anche le colonne 2–5; tuttavia, quando il testo di ciascun paragrafo viene riconcatenato e rispezzato usando le lunghezze originali in ordine permutato, un deficit consistente permane in queste colonne, mostrando che una quota rilevante della non-ripetizione può dipendere dalla struttura del flusso o dal vocabolario del paragrafo. La colonna 1 è più estrema del re-flow (0,082 contro media 0,143 ZL3b), mentre l'anti-associazione degli incipit `qo-` alle righe 3–4 scompare nel controllo. La dipendenza tra incipit calcolata con informazione mutua replica in misura approssimata l'effetto pubblicato da Averyanov (z +23,81 e +24,68 su tutti i loci P). Descriviamo inoltre il ciclo direzionale `d→q→y`, presente sia nei passaggi 2→3 sia 3→4, senza evidenza che appartenga esclusivamente alla seconda coppia. I 30 output Timm–Schinner verificati presentano eccesso, anziché deficit, di ripetizioni verticali esatte nel protocollo usato, senza consentire un giudizio su tutte le varianti del generatore. Tutte le analisi sono esplorative.

**Parole chiave:** manoscritto Voynich, incipit di riga, dipendenza verticale, IVTFF, re-flow, Timm–Schinner, riproducibilità.

## 1. Introduzione

Le forme all'inizio delle righe del manoscritto Voynich seguono distribuzioni peculiari. V. Averyanov, nella pagina *Lines remember each other: the cycle d → q → y* del 18 ottobre 2026, riferisce una ripetizione della prima unità grafica nel 6,88% delle righe adiacenti contro il 13,54% atteso sotto riordinamento entro pagina, un'informazione mutua elevata e un ciclo preferenziale d→q→y, entrambi indeboliti dal re-flow. Lo stato «ESTABLISHED» sulla pagina è un'etichetta attribuita dall'autore e non prova di revisione paritaria. Il presente lavoro si propone come verifica computazionale e ampliamento di quelle osservazioni, non come scoperta originaria del principio di evitamento.

Gli interrogativi sono tre: (a) la stessa dipendenza emerge usando **parole intere** anziché unità glifiche? (b) è propria della prima parola oppure di tutte le colonne? (c) sopravvive quando i confini di riga originali sono sostituiti da confini alternativi che preservano l'ordine dei token?

## 2. Materiali e metodi

Sono utilizzate due trascrizioni testuali originali e verificate sui byte: ZL3b-n.txt (411.671 byte; SHA-256 `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc`) e IT2a-n.txt (342.104 byte; SHA-256 `7f27a8b0feed8f6de0a99900df6bf912dd1d295c38e5f830bac8b41c3f536fb5`). Il parser Python RC1.2 seleziona loci P, pulisce i marcatori editoriali e segmenta i paragrafi usando i delimitatori IVTFF; si analizzano i paragrafi Currier omogenei con almeno quattro righe (491 ZL3b e 492 IT2a). Non si applica il filtro storico di 6–10 token.

Per ogni colonna lessicale e lag si contano le ripetizioni esatte tra le parole comparate. L'atteso del nullo è ricavato permutando i secondi termini entro folio, preservandone i marginali, mentre gli intervalli sono ottenuti con bootstrap per folio. Si tratta di un nullo utile, ma non preserva tutte le dipendenze di posizione e di paragrafo. I rapporti O/E non sono percentuali di parole ripetute e non vanno equiparati ai tassi assoluti.

Nel controllo di *re-flow* (1.000 repliche per trascrizione) si concatenano i token di ciascun paragrafo nell'ordine originario e si rispezzano usando una permutazione senza sostituzione delle lunghezze originarie delle righe del medesimo paragrafo. Ciò preserva testo e numero di righe, ma non riproduce la geometria del supporto manoscritto. Le colonne spostate confrontano la posizione lessicale n della riga j con n±1/n±2 della riga j+1.

Per replicare la statistica di Averyanov si definisce l'unità di apertura come il primo elemento EVA, considerando `ch` e `sh` singole unità; si calcola informazione mutua tra incipit consecutivi entro pagina, contro 10.000 permutazioni per pagina. L'analisi è effettuata sia sull'insieme dei loci P sia sulla coorte di paragrafi L≥4. La definizione e il trattamento dei loci potrebbero non essere perfettamente identici all'implementazione di Averyanov.

Il ciclo `d→q→y` è stimato fra le coppie consecutive i cui incipit appartengono a due classi *differenti* della terna. Si riporta la frazione di `d→q`, `q→y`, `y→d` sul totale di tali transizioni. Questo condizionamento rende la quota descrittiva, non una probabilità di avanzamento fra tutte le righe. La stessa misura è riportata per Currier A e B.

Infine si riutilizzano 30 output del generatore Timm–Schinner rigenerati con i semi originali e verificati contro un registro storico di SHA-256. Gli output sono analizzati per paragrafi di almeno quattro righe; il nullo di informazione mutua permuta gli incipit entro seme ma valuta solo le coppie entro paragrafo. Un seme sintetico non equivale a un folio manoscritto. Non si esegue ottimizzazione dei parametri del generatore.

## 3. Risultati

### 3.1. Ripetizioni esatte, curve dei lag e colonne

Alla colonna 1 e lag 1 si osservano 14 ripetizioni su 2.932 confronti ZL3b, contro 171,43 attese (0,48% osservato, 5,85% atteso; O/E 0,082), e 13 su 2.900 IT2a contro 167,55 (0,45% osservato, 5,78% atteso; O/E 0,078). Il deficit diminuisce gradualmente con il lag: a lag 2 gli O/E sono 0,178 e 0,165; a lag 3 0,182 e 0,175; a lag 4 0,421 e 0,422; a lag 5 0,563 e 0,630; a lag 6 0,610 e 0,628. Questi risultati descrivono la relazione nelle sole finestre in cui i lag sono osservabili; i paragrafi più lunghi contribuiscono di più ai lag elevati.

Le colonne 2–5 mostrano anch'esse un deficit di identità esatta: in ZL3b O/E 0,223, 0,182, 0,239 e 0,175; in IT2a 0,268, 0,236, 0,215 e 0,198. Lo spostamento della colonna di confronto di una o due posizioni riduce sensibilmente il deficit: per esempio ZL3b colonna 1→2 O/E 1,003 contro 1→1 O/E 0,082; colonna 3→2 O/E 1,279 e 3→4 1,321 contro 3→3 0,182. IT2a fornisce risultati qualitativamente analoghi. Ciò suggerisce una specificità dell'allineamento verticale, pur con insiemi di coppie differenti per disponibilità dei token.

### 3.2. Re-flow

Dopo 1.000 rispezzature alternative, il rapporto medio O/E della prima colonna sale a 0,143 ZL3b e 0,145 IT2a, ma resta molto sotto 1; le frequenze originali sono inferiori alla maggioranza delle rispezzature (p empirici di coda 0,012 e 0,010). Il re-flow delle colonne 2–5 dà rapporti medi da 0,158 a 0,189, confrontabili con quelli osservati. Ne consegue che **il deficit verticale delle parole esatte non è integralmente eliminato dal re-flow**: non si può trattare ogni sua componente come dipendenza dai confini reali.

La specifica anti-associazione degli incipit `qo-` nelle righe 3 e 4 cambia invece radicalmente: rapporto osservato/atteso 0,288 in ZL3b e 0,281 in IT2a, contro medie dei re-flow 1,140 e 1,147 (p di coda inferiore 1/1001 per entrambi). Questo elemento, a differenza del deficit lessicale più generale, appare sensibile ai confini originari delle righe.

### 3.3. Informazione mutua degli incipit e relazione con il precedente

Sull'insieme dei loci P la nostra informazione mutua è 0,1131 nat contro 0,0380 nel nullo per ZL3b (z +23,81) e 0,1192 contro 0,0398 per IT2a (z +24,68); in ciascuna analisi il limite Monte Carlo superiore è 1/10001. Le ripetizioni della stessa unità iniziale si verificano rispettivamente nel 6,96% e nel 6,80% delle coppie, contro 13,62% e 13,52% attese. Il risultato è molto vicino a quello di Averyanov quanto a grandezza standardizzata (z +23,95 e +24,17), ma **non identico per informazione mutua assoluta**, per la quale Averyanov riporta 0,1683 contro 0,0599. Le due pipeline non sono pertanto equivalenti byte per byte.

### 3.4. Ciclo d→q→y e posizione nel paragrafo

Fra le transizioni in cui entrambi gli incipit sono classi distinte della terna, la quota di passaggi nel verso `d→q→y→d` è 289/456 = 63,4% in ZL3b e 290/455 = 63,7% in IT2a. Per le righe 2→3: 65/99=65,7% e 66/100=66,0%; per 3→4: 65/100=65,0% e 68/103=66,0%; per 4→5: 39/70=55,7% e 37/69=53,6%. Dunque **il ciclo non risulta confinato al passaggio 3→4** e in termini descrittivi il passaggio 2→3 è sostanzialmente equivalente. In ZL3b, per 3→4, A ha 31/42=73,8% e B 34/58=58,6%; la differenza è incerta in presenza di pochi eventi, e un test Fisher descrittivo dà p≈0,14. Non basta per sostenere che la fascia 3–4 sia *lo stesso fenomeno* del ciclo.

### 3.5. Confronto con Timm–Schinner

I 30 campioni verificati producono per la prima colonna a lag 1 497 ripetizioni esatte su 28.391 confronti, pari all'1,75%, contro 160,90 attese, pari allo 0,57% (O/E 3,089). Il tasso assoluto osservato è superiore a quello del manoscritto, ma le distribuzioni lessicali e i nulli attesi sono sensibilmente diversi, dunque l'O/E non misura da solo una distanza comune fra processi.

La quota di avanzamento del ciclo è 361/707=51,1%. Un test di informazione mutua costruito in modo da **non contare** falsi passaggi fra paragrafi contigui nel file generato dà 0,02585 nat contro 0,00315 del nullo entro seme, z +66,90, ma mostra *più* ripetizioni della stessa apertura (18,72% contro 12,58%) invece dell'evitamento manoscritto. Il valore z del generatore non si confronta direttamente con quello manoscritto perché i gruppi hanno struttura e dimensione diversa. Il valore dell'83% riferito da Averyanov per la capacità di autocopia di riprodurre l'evitamento riguarda un'altra statistica: **non è una contraddizione quantitativa dimostrata** senza allineare esattamente protocolli e denominatori.

## 4. Discussione

I dati confermano con una misura autonoma l'evitamento degli incipit già descritto da Averyanov, ma suggeriscono che l'estensione indiscriminata di tale conclusione all'intero reticolo verticale delle parole sarebbe eccessiva. Il re-flow distingue almeno due componenti: una sensibile ai veri confini delle righe, particolarmente evidente nell'arricchimento e nell'anti-associazione `qo-` nelle posizioni 3–4, e una dipendenza di non-ripetizione lessicale che sopravvive anche quando il testo è rispezzato.

La quasi totale assenza di ripetizioni esatte della prima parola in righe consecutive è una descrizione empirica solida **rispetto al nullo entro folio**, non una prova di una proibizione scribale o di un algoritmo specifico. Il confronto con Timm–Schinner indica che una particolare configurazione generativa verificata non riproduce gli stessi rapporti, senza falsificare ogni variante della famiglia di autocopia. Le due trascrizioni costituiscono test di sensibilità della rappresentazione del *medesimo manoscritto*, non repliche su campioni indipendenti.

Per l'interpretazione originale più promettente, la distribuzione del ciclo rispetto alla posizione nel paragrafo, i risultati attuali sono **negativi** per una concentrazione esclusiva in 3→4. Questo risultato va riportato, non nascosto: preserva la distinzione fra il ciclo generale degli incipit e il picco delle aperture `qo-` nelle righe centrali.

## 5. Conclusioni

La nostra analisi deve essere presentata come **replica computazionale esplorativa ed estensione** di un risultato già pubblicato online da Averyanov, con risultati nuovi sulle parole intere, sulle colonne spostate e sul re-flow. Il controllo di rispezzatura mostra che una parte della non-ripetizione verticale delle parole complete non è specifica degli originali confini di riga, mentre gli incipit `qo-` alle righe 3–4 lo sono maggiormente. Il ciclo `d→q→y` ricorre in più passaggi nel paragrafo e non appare limitato alla fascia 3–4. L'analisi non dimostra una regola di generazione né un significato linguistico. È opportuno sospendere ulteriori esplorazioni, rendere disponibili codice e log, e sottoporre queste conclusioni a replica indipendente prima di attribuire loro forza esplicativa.

## Riferimenti essenziali

- Averyanov, V. (2026, 18 ottobre), *Lines remember each other: the cycle d → q → y and a constraint on a whole class of explanations*. https://voynich.site/en/findings/line-openers/ (sito dell'autore; etichetta interna «ESTABLISHED», non peer review verificata).
- Timm, T. e Schinner, A., *SelfCitationTextgenerator*, implementazione pubblica e pacchetto di generazione utilizzato in EXP-SEQ-02B; fare riferimento al manifest e agli hash dei 30 campioni nel materiale supplementare.
- Zandbergen/Landini, trascrizione IVTFF ZL3b-n, e Takahashi IT2a-n, testi originali verificati con SHA-256 riportati nel materiale supplementare.

**Disponibilità dei materiali:** `ROUND5_EXP_SEQ_05_RESULTS.zip` contiene script, manifest, risultati numerici, log e tabelle; per gli output completi del generatore vedere anche `ROUND4_EXP_SEQ_05_RESULTS.zip`.
