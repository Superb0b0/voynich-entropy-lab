#!/usr/bin/env python3
"""EXP-SEQ-05 Round 5: exploratory; original RC1.2, same corpus and saved verified seed outputs.
Analytic within-group expectations and Monte Carlo reflow / opener MI. No original modified.
"""
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np,hashlib,json,csv,sys,time
sys.path.insert(0,'/mnt/data/r5work')
from round4 import get_paras
sys.path.insert(0,'/mnt/data/files')
from analysis import read,clean,PAGE,TAGS
ROOT=Path('/mnt/data'); OUT=ROOT/'round5'; OUT.mkdir(exist_ok=True)
HASH={'ZL3b-n.txt':'bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc','IT2a-n.txt':'7f27a8b0feed8f6de0a99900df6bf912dd1d295c38e5f830bac8b41c3f536fb5'}
NREFLOW=1000; NMI=10000; BOOT=2000; SEED=20261111
rng=np.random.default_rng(SEED)

def pair_vectors(paras,col=1,shift=0,lag=1):
    out=[]
    for p in paras:
        fs=p['folio']; w=p['words']
        for j in range(len(w)-lag):
            a,b=w[j],w[j+lag]
            i=col-1;k=i+shift
            if i>=0 and k>=0 and len(a)>i and len(b)>k:
                out.append((fs,a[i],b[k]))
    return out

def stat_exact(pairs):
    groups=defaultdict(list)
    for f,a,b in pairs:groups[f].append((a,b))
    ob=0;ex=0.; rows=[]
    for f,z in groups.items():
        A=Counter(a for a,b in z); B=Counter(b for a,b in z); o=sum(a==b for a,b in z);e=sum(v*B.get(a,0) for a,v in A.items())/len(z)
        ob+=o;ex+=e;rows.append([o,e])
    return dict(n=len(pairs),observed=int(ob),expected=float(ex),oe=float(ob/ex) if ex else None),np.asarray(rows,float)

def summarize(pairs,seed=0):
    res,rows=stat_exact(pairs)
    rng0=np.random.default_rng(SEED+seed)
    ix=rng0.integers(len(rows),size=(BOOT,len(rows)))
    t=rows[ix].sum(1)
    val=t[:,0]/np.maximum(t[:,1],1e-12)
    res['ci95_folio']=np.quantile(val,[.025,.975]).tolist()
    return res

def reflow_one(paras,rng):
    ans=[]
    for p in paras:
        words=p['words']; lengths=[len(w) for w in words]; order=rng.permutation(len(lengths));lens=np.asarray(lengths)[order]
        allwords=[t for row in words for t in row]
        starts=np.r_[0,np.cumsum(lens)[:-1]]
        nw=[allwords[int(i):int(i+n)] for i,n in zip(starts,lens)]
        ans.append(dict(folio=p['folio'],lang=p.get('lang'),words=nw))
    return ans

def reflow_stats(paras,n=1000):
    vocab=sorted(set(t for p in paras for w in p['words'] for t in w));code={w:i+1 for i,w in enumerate(vocab)};V=len(code)+1
    fols=sorted(set(p['folio'] for p in paras));fc={f:i for i,f in enumerate(fols)};F=len(fols)
    cols=[summarize(pair_vectors(paras,c),c) for c in range(1,6)]
    def qo34(ps):
        a=np.array([int(p['words'][2][0].startswith('qo')) for p in ps]); b=np.array([int(p['words'][3][0].startswith('qo')) for p in ps]);ob=int((a*b).sum());ex=a.sum()*b.sum()/len(ps)
        return dict(obs=ob,expected=float(ex),oe=float(ob/ex) if ex else None,n=len(ps))
    base=qo34(paras);result=np.full((n,6),np.nan)
    matrices=[{'x':[],'y':[],'g':[]} for _ in range(5)]
    isqo=np.zeros(V,dtype=np.uint8)
    for tok,idx in code.items():isqo[idx]=tok.startswith('qo')
    q3=np.zeros((n,len(paras)),dtype=np.uint8);q4=np.zeros((n,len(paras)),dtype=np.uint8)
    for pi,p in enumerate(paras):
        lens=np.asarray([len(w) for w in p['words']],dtype=np.int32);m=len(lens)
        stream=np.asarray([code[t] for w in p['words'] for t in w],dtype=np.int32)
        order=np.argsort(rng.random((n,m)),axis=1);ll=lens[order]
        starts=np.c_[np.zeros(n,dtype=np.int32),np.cumsum(ll[:,:-1],axis=1)]
        q3[:,pi]=isqo[stream[starts[:,2]]];q4[:,pi]=isqo[stream[starts[:,3]]]
        for c in range(5):
            valid=(ll[:,:-1]>c)&(ll[:,1:]>c)
            ix,jx=np.nonzero(valid)
            mats=matrices[c];mats['x'].append((ix,stream[starts[ix,jx]+c]));mats['y'].append(stream[starts[ix,jx+1]+c]);mats['g'].append(np.full(len(ix),fc[p['folio']],dtype=np.int16))
    for c,mats in enumerate(matrices):
        ii=np.concatenate([u[0] for u in mats['x']]).astype(np.int64)
        xx=np.concatenate([u[1] for u in mats['x']]).astype(np.int64)
        yy=np.concatenate(mats['y']).astype(np.int64)
        gg=np.concatenate(mats['g']).astype(np.int64)
        ob=np.bincount(ii,weights=(xx==yy),minlength=n)
        # high-cardinality encoded groups, count frequencies in each permutation & folio
        group=ii*F+gg
        keys_a=group*V+xx;keys_b=group*V+yy
        ua,ca=np.unique(keys_a,return_counts=True);ub,cb=np.unique(keys_b,return_counts=True)
        common,ia,ib=np.intersect1d(ua,ub,return_indices=True)
        gn,gnc=np.unique(group,return_counts=True)
        pos=np.searchsorted(gn,common//V)
        expect=np.bincount((common//V)//F,weights=ca[ia]*cb[ib]/gnc[pos],minlength=n)
        result[:,c]=ob/np.maximum(expect,1e-12)
        print('reflow col',c+1,'done',flush=True)
    exp=q3.sum(axis=1)*q4.sum(axis=1)/len(paras)
    result[:,5]=(q3*q4).sum(axis=1)/np.maximum(exp,1e-12)
    def info(obs,arr):
        q=np.quantile(arr,[.025,.5,.975]);return {'observed':obs,'reflow_mean':float(arr.mean()),'reflow_q025_median_q975':q.tolist(),'p_lower_vs_reflow':(1+int(np.sum(arr<=obs)))/(len(arr)+1),'p_upper_vs_reflow':(1+int(np.sum(arr>=obs)))/(len(arr)+1)}
    return {'n_reflow':n,'method':'concatenate tokens within paragraph, permute observed line token counts, split at new cumulative counts','columns':[{'col':c,'original':cols[c-1],**info(cols[c-1]['oe'],result[:,c-1])} for c in range(1,6)],'qo_3_4':{'original':base,**info(base['oe'],result[:,5])},'samples':result}

def shifted(paras):
    output=[]
    for c in range(1,6):
        for shift in [-2,-1,0,1,2]:
            ps=pair_vectors(paras,c,shift)
            if not ps:continue
            output.append({'column':c,'shift':shift,**summarize(ps,seed=100+c*7+shift)})
    return output

def lag_curve(paras):
    return [{'lag':lag,**summarize(pair_vectors(paras,1,0,lag),500+lag)} for lag in range(1,7)]

def opener(token):
    # EVA initial glyph unit: ch/sh treated as a single bench; otherwise first ASCII glyph.
    if token.startswith(('ch','sh')):return token[:2]
    return token[:1] if token else ''

def page_lines(path,eligible_only):
    if eligible_only:
        ps,_=get_paras(path);groups=defaultdict(list)
        for p in ps:
            for line in p['words']:
                if line:groups[p['folio']].append(opener(line[0]))
        return dict(groups)
    # all P lines but preserve actual page boundaries
    groups=defaultdict(list)
    current=None
    for line in path.read_bytes().decode('utf8').splitlines():
        m=PAGE.match(line)
        if not m or ',' not in m.group(1):continue
        loc,tag=m.group(1).split(',',1)
        if tag not in TAGS:continue
        words=clean(m.group(2))
        if words:groups[loc.split('.')[0]].append(opener(words[0]))
    return dict(groups)

def mi(x,y,n_categories):
    n=len(x);c=np.bincount(x*n_categories+y,minlength=n_categories*n_categories).reshape(n_categories,n_categories)
    p=c/n; px=p.sum(1);py=p.sum(0)
    i,j=np.nonzero(p)
    return float(np.sum(p[i,j]*np.log(p[i,j]/(px[i]*py[j]))))

def mi_test(groups,n=10000,seed=0):
    vals=[v for v in groups.values() if len(v)>=2]
    alphabet=sorted(set(x for v in vals for x in v)); mp={s:i for i,s in enumerate(alphabet)}
    arrays=[np.asarray([mp[s] for s in v],dtype=np.int16) for v in vals]
    X=np.concatenate([z[:-1] for z in arrays]); Y=np.concatenate([z[1:] for z in arrays]); C=len(alphabet)
    obs=mi(X,Y,C); eq=float(np.mean(X==Y));sim=np.empty(n,float);rep=np.empty(n,float)
    rnd=np.random.default_rng(SEED+seed)
    for i in range(n):
        a=[];b=[]
        for z in arrays:
            w=z[rnd.permutation(len(z))];a.append(w[:-1]);b.append(w[1:])
        xx=np.concatenate(a);yy=np.concatenate(b)
        sim[i]=mi(xx,yy,C);rep[i]=np.mean(xx==yy)
    return dict(n_pairs=len(X),n_groups=len(arrays),n_categories=C,categories=alphabet,MI_nats=obs,null_MI_mean=float(sim.mean()),null_MI_std=float(sim.std(ddof=1)),z_MI=float((obs-sim.mean())/sim.std(ddof=1)),p_upper_MI=(1+int(np.sum(sim>=obs)))/(n+1),p_lower_MI=(1+int(np.sum(sim<=obs)))/(n+1),repeat_rate=eq,null_repeat_mean=float(rep.mean()),z_repeat=float((eq-rep.mean())/rep.std(ddof=1)),n_permutations=n)

def cycle_stat(paras):
    def cls(word):
        # use first glyph 'q' consistent with Averyanov; note d, q and y only, not collapsed qo.
        u=opener(word)
        return u if u in ('d','q','y') else None
    out=[]
    for grp in ['ALL','A','B']:
        pp=paras if grp=='ALL' else [p for p in paras if p.get('lang')==grp]
        for window in ['all','2-3','3-4','4-5']:
            pairs=[]
            for p in pp:
                for i in range(len(p['words'])-1):
                    if window!='all' and i+1!=int(window.split('-')[0]):continue
                    a,b=cls(p['words'][i][0]),cls(p['words'][i+1][0]);
                    if a and b and a!=b:pairs.append((p['folio'],a,b))
            f=sum((a,b) in {('d','q'),('q','y'),('y','d')} for _,a,b in pairs)
            # expected forward fraction under swap of direction; for each pair conditional on two distinct classes, 0.5
            out.append(dict(group=grp,window=window,n_cross_class=len(pairs),forward=int(f),rate=f/len(pairs) if pairs else None,baseline=.5))
    return out

def test_power(paras,base,nsim=100,spike=0.05):
    # planting exact repeats in column 1 on 5% eligible pairs in a copy of original lines
    # check reflow separation relative to baseline original, not general statistical power for arbitrary effect.
    original=base['columns'][0]['observed']; threshold=base['columns'][0]['reflow_q025_median_q975'][0]
    detect=0
    for b in range(nsim):
        ps=[{'folio':p['folio'],'lang':p.get('lang'),'words':[w.copy() for w in p['words']]} for p in paras]
        for p in ps:
            for j in range(len(p['words'])-1):
                if rng.random()<spike and p['words'][j] and p['words'][j+1]:p['words'][j+1][0]=p['words'][j][0]
        st,_=stat_exact(pair_vectors(ps,1))
        detect+=(st['oe']>threshold)
    return {'plant_method':'with probability 0.05, replace next-line column-1 word with preceding line same-column word','n_sim':nsim,'detected_above_reflow_lower_2_5pct':detect,'warning':'This is only a positive-control diagnostic, not power of a calibrated p-value under arbitrary alternatives.'}

def model_paras():
    paras=[];n=0
    for k in range(1,31):
        source=ROOT/'r5work'/'generator'/f'seed_{k:02d}.json'
        d=json.loads(source.read_text()); assert d['seed']==k
        for idx,words in enumerate(d['paragraphs']):
            if len(words)>=4:
                paras.append(dict(folio=f'seed{k:02d}',lang='model',words=words))
        n+=1
    return paras

def dump_csv(file,rows):
    if not rows:return
    cols=list(rows[0]);
    with (OUT/file).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(rows)

def main():
    allres={}
    for ix,name in enumerate(HASH):
        previous=OUT/(name+'_results.json')
        if previous.exists():
            allres[name]=json.loads(previous.read_text());print('REUSE completed',name,flush=True);continue
        path=ROOT/name; dig=hashlib.sha256(path.read_bytes()).hexdigest();assert dig==HASH[name],(name,dig)
        print('corpus',name,dig,flush=True)
        ps,meta=get_paras(path)
        print('paras',len(ps),'folios',len(set(p['folio'] for p in ps)),flush=True)
        lag=lag_curve(ps);shift=shifted(ps);ref=reflow_stats(ps,NREFLOW)
        power=test_power(ps,ref,100)
        group=page_lines(path,True)
        print('MI',name,'eligible',flush=True)
        mi_elig=mi_test(group,NMI,ix*10)
        print('MI',name,'all P',flush=True)
        mi_full=mi_test(page_lines(path,False),NMI,ix*10+1)
        cyc=cycle_stat(ps)
        allres[name]=dict(hash=dig,n_paragraphs=len(ps),n_folios=len(group),lags=lag,shifted=shift,mi_eligible=mi_elig,mi_all_P=mi_full,cycle=cyc,reflow={k:v for k,v in ref.items() if k!='samples'},power_positive_control=power)
        np.savez_compressed(OUT/(name+'_reflow_1000.npz'),values=ref['samples'])
        dump_csv(name+'_lag.csv',lag);dump_csv(name+'_shifted.csv',shift);dump_csv(name+'_cycle.csv',cyc)
        (OUT/(name+'_results.json')).write_text(json.dumps(allres[name],indent=2))
        print('done',name,flush=True)
    print('generator',flush=True)
    ps=model_paras();lag=lag_curve(ps);shift=shifted(ps)
    mi=mi_test({f'seed{i:02d}':[opener(line[0]) for p in ps if p['folio']==f'seed{i:02d}' for line in p['words']] for i in range(1,31)},NMI,123)
    allres['Timm-Schinner-30']=dict(n_paragraphs=len(ps),n_seeds=30,lags=lag,shifted=shift,mi_eligible=mi,cycle=cycle_stat(ps))
    dump_csv('Timm_lag.csv',lag);dump_csv('Timm_shifted.csv',shift)
    (OUT/'RESULTS.json').write_text(json.dumps(allres,indent=2))
    print('FINISHED',flush=True)
if __name__=='__main__':main()
