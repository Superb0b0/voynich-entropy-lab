# Voynich: EXP-NAIBBE-01 / EXP-YO-02

**Data:** 12 novembre 2026  
**Stato:** risultati empirici ESPLORATIVI, non preregistrati; nessuna inferenza di decifrazione.  
**Vincolo:** pipeline immagini/testo RC1.4.2 invariata, gate `CLOSED_PENDING_VALIDATION`; non avviati builder, PCA, clustering o coupling.

## 1. Riproduzione del corpus di riferimento

Corpus `ZL3b-n.txt`: 411.671 byte, SHA-256 `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc`.

- **Pipeline delle quattro metriche:** 4.130 righe P, 34.323 token, 7.627 tipi (file `zl3b_P_ms408.tsv`). I valori sono densità **0,9556566**, Jaccard fra righe **0,0283863**, ripetizione media per riga **0,0580572**, hapax/tipi **0,7112888**. Riproducono i quattro riferimenti al quarto decimale.
- **Parser RC1.2 per il confronto posizionale:** 4.130 righe P, 35.492 token, 6.980 tipi, 207 folii; è un profilo di pulizia diverso e non va mischiato silenziosamente con quello delle quattro metriche.

## 2. EXP-NAIBBE-01: controllo positivo di cifratura con plaintext noto

Fonte originale: Michael A. Greshko, *The Naibbe cipher: a substitution cipher that encrypts Latin and Italian as Voynich Manuscript-like ciphertext*, Cryptologia (2025), DOI [10.1080/01611194.2025.2566408](https://doi.org/10.1080/01611194.2025.2566408).

Repository [`greshko/naibbe-cipher`](https://github.com/greshko/naibbe-cipher), **commit fissato** `5145f526b52741a6dca14201147f687e62c7162e`; ciphertext `encrypted/nathist_output_ciphertext.txt`, Git blob `fb5f1e7509773361ea1acf5b4019efdc83cd17e4` (217.307 byte). Il relativo plaintext pre-rispaziatura nello stesso repository conta 34.764 token, come il ciphertext: questo controllo riguarda l'allineamento dei file pubblicati, **non** una decifrazione eseguita autonomamente.

**Metodo:** per la prova primaria si conservano i primi 34.323 token del ciphertext nell'ordine originale, ma si ricostruiscono esattamente le 4.130 lunghezze di riga P del corpus Voynich. Questa trasformazione è dichiarata perché i 1.063 righi non vuoti originali di Greshko hanno un layout differente, che influenza Jaccard e ripetizione.

| Metrica | Bande preesistenti | Voynich | Naibbe appaiato | Naibbe layout originale |
|---|---:|---:|---:|---:|
| Densità | 0,91–0,96 | 0,9557 | **0,9987** | 0,9987 |
| Adiacenza (Jaccard medio righe) | 0,02–0,04 | 0,0284 | **0,0166** | 0,0503 |
| Ripetizione locale (media delle frazioni per riga) | 0,045–0,070 | 0,0581 | **0,0324** | 0,1115 |
| Hapax / tipi | 0,65–0,75 | 0,7113 | **0,4103** | 0,4091 |

**Risultato:** 0/4 in banda nel confronto primario, e 0/4 anche nel layout originale. Il risultato riguarda **un solo output preesistente del codice Naibbe**, non repliche indipendenti con semi diversi. Non esclude la famiglia dei cifrari verbose, né mette alla prova la sensibilità dei discriminanti su un insieme ampio di cifrari omofonici.

Sensibilità secondaria: la variante pubblica `nathist_output_ciphertext_respaced.txt` contiene solo 33.750 token, dunque non è identica per dimensioni al controllo primario. Nel layout originale la densità è 0,9742; adiacenza 0,0461; ripetizione 0,1022; hapax 0,5027 (0/4). Non chiamare questa variante una replica appaiata di 34.323 token.

**Limite procedurale:** i ciphertext sono stati letti e valutati direttamente tramite connettore GitHub; l'encoder/decoder dell'autore non è stato eseguito nella sessione. Lo script `test_naibbe_public_fixture.py` è una ricostruzione ripetibile della valutazione, che scarica e verifica il fixture originale pin-nato quando eseguito in un ambiente con Internet.

## 3. EXP-YO-02: robustezza della coppia yX/oX

Si applica **l'originale parser RC1.2** sul file dalla SHA sopra; nessun intervento sugli artefatti congelati.

- Reproduzione esatta della precedente analisi esplorativa con le 94 coppie informative: **OR Mantel–Haenszel 4,6625**, IC95% **3,711–5,857**.
- Folii divisi casualmente con `seed=20261112`, stratificati per Currier: 103 folii costruzione, 104 folii controllo. Coppie selezionate solo nel sottoinsieme costruzione, se entrambi i tipi hanno frequenza ≥2 e suffisso comune lungo almeno 3 caratteri. **69 suffissi** selezionati.
- Nel controllo: **OR CMH 2,8396**, IC95% **2,053–3,928**, p nominale **2,81×10⁻¹¹**, 55 strati informativi.
- CMH con strati aggiuntivi Currier: **OR 2,8487**, IC95% **2,018–4,020**, p nominale **1,24×10⁻¹⁰**.
- Regressione logistica con suffisso, Currier, log-lunghezza di riga, apertura paragrafo; errori cluster per folio: **OR corretto 3,1344**, IC95% **2,033–4,831**, p **2,28×10⁻⁷**.
- Aggiungendo la mano scribale alla regressione: **OR 3,3404**, IC95% **2,136–5,224**, p **1,24×10⁻⁷**.
- Per Currier A nei folii controllo: **OR 1,441**, IC95% **0,819–2,537**, p nominale 0,196. Per Currier B: **OR 4,730**, IC95% **3,004–7,448**, p **1,84×10⁻¹³**.
- In un modello con interazione, il coefficiente aggiuntivo `prima_posizione × Currier_B` è OR **3,65**, IC95% **1,57–8,47**, p **0,00259**. È un'interazione su scala di odds ratio, non una probabilità assoluta.

**Nullo a permutazione:** 1.000 assegnazioni casuali della parola iniziale dentro ogni riga originale dei folii controllo, preservando appartenenza al folio, lessico e lunghezza di tutte le righe. CMH per suffisso × Currier: OR osservato 2,8487, nullo mediano 1,010, percentili 2,5–97,5% 0,717–1,425, 0/1.000 repliche ≥ osservato, **p empirica unilaterale 0,000999**. La procedura è una verifica di rilevanza del segnale di inizio riga sotto questo nullo, non una replica indipendente.

**Cautela:** l'ipotesi y/o è stata selezionata in precedenti analisi dello stesso manoscritto; pertanto lo split interno non rende indipendente la scoperta né corregge gli altri confronti esplorati. L'effetto documenta una regolarità grafotattica posizionale, non l'identità semantica di `yX` e `oX` e non una prova di cifratura.

## 4. Prossimo test realmente discriminante

Ripetere EXP-NAIBBE-01 con **nuovi ciphertext generati**, versioni `naibbe.py` e `naibbe_v2.py` identificate, plaintext latino e italiano tracciati, semi registrati, controlli con cifrario omofonico ordinario, layout sia nativo sia appaiato, e misurare la frequenza dei quattro indicatori in banda. Per valutare il nesso con `yX/oX` applicare lo stesso filtro e le stesse statistiche al testo cifrato e a un insieme di generatori nulli. Nessun successo sul singolo output prova identificabilità; nessun insuccesso sul singolo output esclude la famiglia.

### File allegati al pacchetto

- `test_naibbe_public_fixture.py`: ricalcolo dei quattro discriminanti con fixture originale e pin Git.
- `test_yo_holdout.py`, `permutation_yo.py`: analisi posizionale, regression e permutazione.
- `EXP_NAIBBE_01_results.json`, `EXP_YO_02_results.json`, `EXP_YO_02_permutation.json`: risultati osservati.
- `ZL3b-n.txt`, `zl3b_P_ms408.tsv`, `ivtff_parser_rc1_2.py`: input di controllo provenienti dalla Library, non modificati.

### Riproduzione in locale

`python -m pip install -r requirements.txt`  
`python test_yo_holdout.py`  
`python permutation_yo.py`  
`python test_naibbe_public_fixture.py` (richiede connessione Internet per scaricare il fixture pinnato; altrimenti `--fixture <percorso_locale>`).
