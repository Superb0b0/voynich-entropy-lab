#!/usr/bin/env python3
"""Esplorazione di robustezza yX/oX su RC1.2. Non modifica gli input."""
import collections,hashlib,importlib.util,json,math,re,random
from pathlib import Path
import numpy as np
from statsmodels.stats.contingency_tables import StratifiedTable
from scipy.stats import fisher_exact
from statsmodels.formula.api import glm
from statsmodels.genmod.families import Binomial
import pandas as pd
BASE=Path(__file__).parent
SRC=BASE/'ZL3b-n.txt'
PAR=BASE/'ivtff_parser_rc1_2.py'
modspec=importlib.util.spec_from_file_location('ivtff_parser_rc1_2_readonly',PAR)
mod=importlib.util.module_from_spec(modspec);modspec.loader.exec_module(mod)
parsed=mod.parse_corpus(SRC)
raw=SRC.read_text().splitlines()
meta={}
for ln in raw:
 m=re.match(r'^<(f\d+[rv]\d*)>\s*<!',ln)
 if m:
  l=re.search(r'\$L=([^\s>]+)',ln);h=re.search(r'\$H=([^\s>]+)',ln)
  meta[m[1]]={'currier':l[1] if l else '?','hand':h[1] if h else '?'}
occ=[]
for row in parsed['records']:
 folio=row['folio'];md=meta.get(folio,{})
 line=raw[row['physical_line']-1]
 for i,w in enumerate(row['tokens']):
  occ.append({'folio':folio,'currier':md.get('currier','?'),'hand':md.get('hand','?'),'token':w,'stem':w[1:] if len(w)>=4 else None, 'first':int(i==0),'n':len(row['tokens']),'log_n':math.log(len(row['tokens'])),'para_start':int('<%>' in line),'physical_line':row['physical_line']})
ALL=set(x['token'] for x in occ)
FOLIOS=sorted({x['folio'] for x in occ})
rng=random.Random(20261112)
train_f,test_f=set(),set()
# Stratified 50:50 by Currier within folios to avoid a trivially imbalanced holdout.
for group in ['A','B','?']:
 fs=sorted(f for f in FOLIOS if meta.get(f,{}).get('currier','?')==group)
 rng.shuffle(fs);train_f.update(fs[:len(fs)//2]);test_f.update(fs[len(fs)//2:])
train=[x for x in occ if x['folio'] in train_f]
test=[x for x in occ if x['folio'] in test_f]

def choose_stems(data):
 c=collections.Counter(x['token'] for x in data)
 return sorted(s for w in c if w.startswith('y') and len(w)>=4 for s in [w[1:]] if c[w]>=2 and c['o'+s]>=2)

stems=choose_stems(train)
full_stems=choose_stems(occ)

def pooled(data,selected,by_currier=False,require_count=False):
 C=collections.Counter((x['stem'],x['currier'],x['token'][0],x['first']) for x in data if x['stem'] in selected and x['token'][0] in ('y','o'))
 strata=[];nforms=0
 for s in selected:
  for grp in (['A','B','?'] if by_currier else ['ALL']):
   def z(prefix,first):return C[(s,grp,prefix,first)] if by_currier else sum(C[(s,g,prefix,first)] for g in ['A','B','?'])
   a,b,c,d=z('y',1),z('y',0),z('o',1),z('o',0)
   if require_count and (a+b<2 or c+d<2):continue
   if a+c==0 or b+d==0 or a+b==0 or c+d==0:continue
   strata.append([[a,b],[c,d]])
   nforms+=a+b+c+d
 if not strata:return {'strata':0}
 t=StratifiedTable(strata)
 return {'strata':len(strata),'tokens_informative':nforms,'or':float(t.oddsratio_pooled),'ci95':[float(z) for z in t.oddsratio_pooled_confint()],'p':float(t.test_null_odds().pvalue)}

def simple_model(data,selected):
 a=[x for x in data if x['stem'] in selected and x['token'][0] in 'yo' and x['currier'] in 'AB']
 df=pd.DataFrame(a)
 if df.empty:return None
 df['y']=df.token.str.startswith('y').astype(int)
 # Regression controls: lexical stem, scribal hand, currier group, line length and paragraph opening; cluster folio.
 cols='y ~ first + log_n + para_start + C(currier) + C(stem)'
 try:
  m=glm(cols,data=df,family=Binomial()).fit(maxiter=70,cov_type='cluster',cov_kwds={'groups':df['folio']})
  b,se,p=m.params['first'],m.bse['first'],m.pvalues['first']
  return {'n_tokens':len(df),'n_folios':int(df.folio.nunique()),'or_adjusted':float(np.exp(b)),'ci95':[float(np.exp(b-1.96*se)),float(np.exp(b+1.96*se))],'p_cluster':float(p)}
 except Exception as e:return {'error':str(e)}

result={'input':{'sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'parser_sha256':hashlib.sha256(PAR.read_bytes()).hexdigest(),'n_records':len(parsed['records']),'n_tokens':parsed['counts']['token_count'],'n_folios':parsed['counts']['folio_count']},'candidate_stems_all':len(full_stems),'train_stems':len(stems),'train_folios':len(train_f),'test_folios':len(test_f)}
for name,dat,sel in [('full_historical',occ,full_stems),('train',train,stems),('heldout',test,stems)]:
 result[name]={'matched_suffix':pooled(dat,sel,by_currier=False,require_count=name=='full_historical'), 'matched_suffix_currier':pooled(dat,sel,by_currier=True), 'glm':simple_model(dat,sel)}
 for currier in ('A','B'):
  group=[x for x in dat if x['currier']==currier]
  result[name][f'currier_{currier}']=pooled(group,sel,False)
print(json.dumps(result,ensure_ascii=False,indent=2))
(BASE/'EXP_YO_02_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
