#!/usr/bin/env python3
from pathlib import Path
import contextlib, io, runpy, numpy as np, json
with contextlib.redirect_stdout(io.StringIO()):
    ns=runpy.run_path(str(Path(__file__).parent/'test_yo_holdout.py'))
sel=set(ns['stems']); test_f=ns['test_f']; records=ns['parsed']['records'];meta=ns['meta']; rows=[]
for rec in records:
    if rec['folio'] in test_f:
        rows.append((meta.get(rec['folio'],{}).get('currier','?'),rec['tokens']))
keys=sorted({(t[1:],cur) for cur,ww in rows for t in ww if len(t)>=4 and t[0] in 'yo' and t[1:] in sel})
index={k:i for i,k in enumerate(keys)}
ny=np.zeros(len(keys),dtype=np.int64);no=np.zeros(len(keys),dtype=np.int64);encoded=[]
for cur,ww in rows:
    row=np.full(len(ww),-1,dtype=np.int32)
    for j,t in enumerate(ww):
        if len(t)>=4 and t[0] in 'yo' and t[1:] in sel:
            i=index[(t[1:],cur)]
            row[j]=2*i+(t[0]=='o')
            if t[0]=='y':ny[i]+=1
            else:no[i]+=1
    encoded.append(row)
valid=(ny>0)&(no>0); n=ny+no

def mh(codes):
    ct=np.bincount(codes[codes>=0],minlength=2*len(keys));a=ct[::2];c=ct[1::2];b=ny-a;d=no-c
    included=valid&((a+c)>0)&((b+d)>0)
    num=np.sum(a[included]*d[included]/n[included]);den=np.sum(b[included]*c[included]/n[included])
    return float(num/den) if den>0 else float('inf')
obs=mh(np.array([r[0] for r in encoded],dtype=np.int32));rng=np.random.default_rng(20261112)
B=1000;sim=np.empty(B)
for k in range(B):
    cs=np.array([row[rng.integers(len(row))] for row in encoded],dtype=np.int32)
    sim[k]=mh(cs)
res={'seed':20261112,'repetitions':B,'observed_or':obs,'null_median':float(np.median(sim)),'null_ci95':[float(z) for z in np.quantile(sim,[.025,.975])],'null_exceed':int(np.sum(sim>=obs)),'p_one_sided':float((1+np.sum(sim>=obs))/(B+1)),'null_design':'uniform random choice of first token within each original heldout row'}
print(json.dumps(res,indent=2))
(Path(__file__).parent/'EXP_YO_02_permutation.json').write_text(json.dumps(res,indent=2)+'\n')
