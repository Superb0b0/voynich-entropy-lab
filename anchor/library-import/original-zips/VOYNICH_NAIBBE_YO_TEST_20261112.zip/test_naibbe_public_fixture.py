#!/usr/bin/env python3
"""EXP-NAIBBE-01 public fixture comparison.

Read-only experiment. Downloads the author's pinned public Naibbe fixture when
run with internet access (or accepts a local copy). Never modifies source files.

Credits: Greshko (2025), https://doi.org/10.1080/01611194.2025.2566408
Fixture: https://github.com/greshko/naibbe-cipher
"""
import argparse
from collections import Counter
from hashlib import sha1,sha256
import json
from pathlib import Path
from urllib.request import urlopen

BASE=Path(__file__).resolve().parent
PIN='5145f526b52741a6dca14201147f687e62c7162e'
FIXTURE='encrypted/nathist_output_ciphertext.txt'
BLOB='fb5f1e7509773361ea1acf5b4019efdc83cd17e4'
URL=f'https://raw.githubusercontent.com/greshko/naibbe-cipher/{PIN}/{FIXTURE}'
EXPECTED_VOY_SHA256='bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc'
BANDS={'density':(0.91,0.96),'adjacency':(0.02,0.04),'repetition':(0.045,0.070),'hapax':(0.65,0.75)}

def read_voynich(path):
    rows=[]
    for line in path.read_text(encoding='utf8').splitlines():
        folio,sep,text=line.partition('\t')
        if sep:rows.append(text.split())
    return rows

def reflow(tokens,lengths):
    """Align token-stream to exact Voynich P-line length vector; truncate overflow."""
    out=[];i=0
    for n in lengths:
        out.append(tokens[i:i+n]);i+=n
    assert i==len([x for row in out for x in row])
    return out

def d1_neighbours(types):
    # One substitution or insertion/deletion; deletion self-matches discarded.
    close=set();subst={}
    for word in types:
        for i in range(len(word)):
            shorter=word[:i]+word[i+1:]
            if shorter in types:
                close.add(word);close.add(shorter)
            pattern=word[:i]+'*'+word[i+1:]
            if pattern in subst and subst[pattern]!=word:
                close.add(word);close.add(subst[pattern])
            else:
                subst[pattern]=word
    return close

def metrics(rows):
    tokens=[t for line in rows for t in line]
    cnt=Counter(tokens)
    close=d1_neighbours(set(cnt))
    density=sum(n for w,n in cnt.items() if w in close)/len(tokens)
    adjacencies=[];repetitions=[]
    for before,after in zip(rows,rows[1:]):
        a,b=set(before),set(after)
        adjacencies.append(len(a&b)/len(a|b) if (a|b) else 0.0)
        repetitions.append(sum(t in a for t in after)/len(after) if after else 0.0)
    return {'rows':len(rows),'tokens':len(tokens),'types':len(cnt),
            'density':density,'adjacency':sum(adjacencies)/len(adjacencies),
            'repetition':sum(repetitions)/len(repetitions),
            'hapax':sum(n==1 for n in cnt.values())/len(cnt)}

def get_cipher(local_path=None):
    data=Path(local_path).read_bytes() if local_path else urlopen(URL,timeout=30).read()
    got=sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    if got!=BLOB:raise ValueError(f'Git blob SHA mismatch: {got} != {BLOB}')
    return data.decode('utf8')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--fixture',type=Path,help='Local copy of pinned Naibbe fixture');ap.add_argument('--verify-voynich-only',action='store_true');ap.add_argument('--output',type=Path)
    args=ap.parse_args()
    if sha256((BASE/'ZL3b-n.txt').read_bytes()).hexdigest()!=EXPECTED_VOY_SHA256:
        raise ValueError('Voynich source failed byte-level SHA-256 verification')
    voys=read_voynich(BASE/'zl3b_P_ms408.tsv')
    if (len(voys),sum(len(r) for r in voys))!=(4130,34323):raise ValueError('Unexpected Voynich size')
    results={'Voynich_ZL3b_P':metrics(voys),'naibbe_pin':PIN,'fixture_git_blob':BLOB}
    if not args.verify_voynich_only:
        cipher=get_cipher(args.fixture)
        orig=[line.split() for line in cipher.splitlines() if line.split()]
        seq=cipher.split()
        if len(seq)!=34764:raise ValueError('Unexpected original ciphertext token count')
        matched=reflow(seq,[len(row) for row in voys])
        results['Naibbe_original_layout']=metrics(orig)
        results['Naibbe_reflow_Voynich_lengths']=metrics(matched)
        results['Naibbe_in_band']={name:lo<=results['Naibbe_reflow_Voynich_lengths'][name]<=hi for name,(lo,hi) in BANDS.items()}
    print(json.dumps(results,indent=2))
    if args.output:args.output.write_text(json.dumps(results,indent=2)+'\n')
if __name__=='__main__':main()
