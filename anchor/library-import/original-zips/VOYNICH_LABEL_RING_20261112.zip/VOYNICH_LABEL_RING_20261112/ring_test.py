#!/usr/bin/env python3
"""Exploratory zodiac ring test: strict four half-sign medallions, two transcriptions.
Ring 0=ten labels, ring 1=five; classification is by @Lz delimiter.
Permutation exactly samples labels under fixed 10/5 counts within page; fixed features.
"""
from pathlib import Path
import re,csv,json,math,hashlib
import numpy as np
from collections import defaultdict
ROOT=Path(__file__).resolve().parent
D=ROOT/'input'; PAGES=['f70v1','f71r','f71v','f72r1']
PAT=re.compile(r'^<(f\d+[rv]\d?)\.(\d+),([@&]Lz)>\s*(?:<!([^>]+)>)?\s*(.*)$')
FEATURES=['starts_o','ends_y','length','starts_ot','ends_dy','has_gallows']
def parse(trans):
 out=[];rings=defaultdict(lambda:-1)
 for line in (D/(trans+'-n.txt')).read_text().splitlines():
  m=PAT.match(line)
  if not m:continue
  folio,locus,marker,clock,raw=m.groups()
  if folio not in PAGES:continue
  if marker=='@Lz':rings[folio]+=1
  raw=re.sub(r'<![^>]+>','',raw).split('<$>')[0].strip()
  chunks=re.split(r'[., ]',raw)
  word=chunks[0] if chunks and re.fullmatch('[a-z]+',chunks[0]) else None
  if rings[folio] not in (0,1):continue
  vals={k:None for k in FEATURES}
  if word:
   vals=dict(starts_o=int(word.startswith('o')),ends_y=int(word.endswith('y')),
      length=len(word), starts_ot=int(word.startswith('ot')),
      ends_dy=int(word.endswith('dy')),has_gallows=int(any(x in word for x in 'ktpf')))
  out.append(dict(transcription=trans,folio=folio,sign='Aries' if folio in PAGES[:2] else 'Taurus',
       ring=rings[folio],locus=int(locus),clock=clock,raw=raw,word=word or '',clean=bool(word),**vals))
 return out

def run(rows,B=9999,seed=74101):
 clean=[r for r in rows if r['clean']];by=defaultdict(list)
 for r in clean:by[r['folio']].append(r)
 n_by={k:{'inner':sum(r['ring']==0 for r in ls),'outer':sum(r['ring']==1 for r in ls)} for k,ls in by.items()}
 rng=np.random.default_rng(seed)
 result={}
 for feat in FEATURES:
  # Contrast is equal-weight mean of within-page differences, to avoid page length confounding.
  diffs=[]
  pages=[]
  for f in PAGES:
   xs=by[f];x=np.array([float(r[feat]) for r in xs]);m=np.array([r['ring']==0 for r in xs]);
   if (not m.any()) or m.all():continue
   diff=float(x[m].mean()-x[~m].mean());diffs.append(diff);pages.append((x,m))
  observed=float(np.mean(diffs))
  sims=np.empty(B)
  for b in range(B):
   sims[b]=np.mean([(lambda mm: x[mm].mean()-x[~mm].mean())(rng.permutation(m)) for x,m in pages])
  p=(1+np.count_nonzero(np.abs(sims)>=abs(observed)-1e-12))/(B+1)
  result[feat]=dict(contrast_inner_minus_outer=observed,p_two_sided=p,
       page_contrasts={PAGES[i]:v for i,v in enumerate(diffs)},null_sd=float(sims.std()))
 # maxT familywise correction using standardized contrasts, same permutations jointly.
 obs=np.array([result[k]['contrast_inner_minus_outer'] for k in FEATURES]);
 std=np.array([result[k]['null_sd'] for k in FEATURES]);std=np.maximum(std,1e-10)
 features=[]
 for f in PAGES:
  ls=by[f];m=np.array([r['ring']==0 for r in ls]);
  x=np.array([[float(r[k]) for k in FEATURES] for r in ls]);features.append((x,m))
 max_stat=[]
 for b in range(B):
  dif=[]
  for x,m in features:
   mm=rng.permutation(m);dif.append(x[mm].mean(axis=0)-x[~mm].mean(axis=0))
  t=np.abs(np.mean(dif,axis=0)/std);max_stat.append(t.max())
 max_stat=np.array(max_stat)
 for i,k in enumerate(FEATURES):result[k]['p_maxT_fwer']=(1+np.count_nonzero(max_stat>=abs(obs[i]/std[i])-1e-12))/(B+1)
 return dict(n=len(clean),by_folio=n_by,features=result,permutations=B,seed=seed)
allrows=[];results={}
for t in ['ZL3b','IT2a']:
 rows=parse(t);allrows.extend(rows);results[t]=run(rows)
with (ROOT/'labels_rings.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(allrows[0]));w.writeheader();w.writerows(allrows)
(ROOT/'results.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
with (ROOT/'summary.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['transcription','feature','inner_minus_outer','p_raw','p_maxT','page_diffs'])
 for t,d in results.items():
  for k,v in d['features'].items():w.writerow([t,k,round(v['contrast_inner_minus_outer'],5),v['p_two_sided'],v['p_maxT_fwer'],v['page_contrasts']])
print(json.dumps(results,ensure_ascii=False,indent=2)[:7000])
