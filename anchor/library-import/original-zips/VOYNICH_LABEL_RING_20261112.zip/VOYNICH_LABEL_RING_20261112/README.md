# EXP-FIRST-WORD-02: quattro mezze ruote zodiacali

Test esplorativo in sola lettura della diversa distribuzione grafica delle etichette nei gruppi 10 + 5 di Ariete e Toro. Nessuna decifrazione, nessuna prova figura-parola.

- `RAPPORTO.md`: fonti, metodo, risultati, limiti
- `ring_test.py`: parser e test di permutazione
- `input/`: trascrizioni originali ZL3b/IT2a
- `labels_rings.csv`: etichette e marcatori orari
- `summary.csv`, `results.json`: risultati con p nominali e corretti
- `SHA256SUMS.txt`: controllo integrità
