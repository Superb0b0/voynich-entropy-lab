# EXP-FIRST-WORD-02: differenze grafiche fra i due gruppi di etichette zodiacali

Data: 12 novembre 2026. Stato **ESPLORATIVO, NON CONFERMATO**. RC1.4.2 non modificata.

## Obiettivo e fonti

Si studiano le quattro mezze ruote `f70v1` (Ariete scuro), `f71r` (Ariete chiaro), `f71v` (Toro chiaro), `f72r1` (Toro scuro). Le descrizioni iconografiche riportano due gruppi di figure, 10 e 5 per pagina, con 15 etichette; la f72r1 presenta una piccola figura in più contestata nella conta. Fonti di riferimento: https://voynich.nu/q11/index.html , https://vib.tamagothi.de/index.php?id=f71v&show=page , https://vib.tamagothi.de/index.php?id=f72r1&show=page .

Le etichette sono assegnate ai gruppi mediante i delimitatori `@Lz` della trascrizione, non da una nuova ispezione visiva indipendente. In questo script `ring=0` designa il **primo gruppo di 10 etichette nel file**, `ring=1` il **secondo gruppo di 5**. I nomi interni `inner` e `outer` usati in due campi del codice descrivono soltanto l'ordine dei gruppi e **NON sono un'asserzione sulla posizione geometrica**. Nelle immagini gli anelli possono avere collocazioni differenti: non è metodologicamente corretto convertirli automaticamente in "anello interno" e "anello esterno".

Si impiegano due trascrizioni EVA, ZL3b e IT2a, dello stesso manoscritto. Le stringhe ambigue e le etichette prive di un primo token composto esclusivamente da lettere sono escluse solo dai test che richiedono la parola.

## Disegno

La prima parola EVA di ciascuna etichetta è misurata tramite sei proprietà dichiarate nel codice: iniziale `o`, finale `y`, lunghezza, iniziale `ot`, finale `dy`, presenza di un carattere del gruppo `k,t,p,f`. Si calcola, con uguale peso per ciascuna pagina, la differenza fra i due gruppi (10 meno 5). L'ipotesi nulla rimescola l'assegnazione delle etichette **entro la pagina**, preservando le dimensioni dei due gruppi; 9.999 riordinamenti a seme fissato. Correzione maxT sui sei test per trascrizione.

Non si tratta di una prova cieca, e la correzione non include tutti gli esperimenti esplorativi precedenti. La verifica su IT2a non è indipendente dal testo originale ZL3b.

## Risultati

ZL3b: 58/60 primi token non ambigui; IT2a: 60/60. Per l'iniziale `ot` il gruppo di 10 presenta una frequenza in media **30,4 punti percentuali inferiore** rispetto al gruppo di 5 (ZL3b, p nominale 0,0274, p maxT 0,1037); IT2a **30,0 punti percentuali inferiore** (p nominale 0,0399, p maxT 0,1128). La direzione è uniforme nelle quattro pagine. Nessuna delle sei proprietà supera la correzione maxT in nessuna trascrizione. Altri risultati in `summary.csv` e `results.json`.

## Interpretazione e limiti

1. Non emerge una prova di decifrazione né dell'identità di una figura.
2. Il segnale `ot` potrebbe riflettere una regola **posizionale dell'etichetta** anziché un nome o un oggetto. Le mezze ruote sono complementari, non repliche iconografiche di medesimi personaggi.
3. La presenza di fusti, stelle, abiti e contenitori non è stata annotata per singola figura a partire dalle immagini: non esiste qui una tabella affidabile figura↔etichetta per quei caratteri. Il marcatore orario presente nella trascrizione è una posizione approssimativa, non una verifica della figura.
4. La presenza della medesima tendenza in due trascrizioni non costituisce una replica su dati indipendenti; questi folii sono stati ripetutamente esaminati nella ricerca.
5. Le altre ruote dello zodiaco comprendono 30 figure in due o tre gruppi di dimensioni differenti: non sono un test diretto della separazione 10+5.

## Passo successivo valido

Ottenere per ogni etichetta una foto o un ritaglio, annotare **senza vedere le parole** anello, posizione e caratteristiche della figura, con almeno due revisioni indipendenti. Fissare poi un solo predittore e un controllo che confronti etichette di figure simili, considerando anche la struttura della pagina. Evitare l'associazione automatica `ot` = nome dell'oggetto.

## Riproduzione

```bash
python ring_test.py
```

Richiede `numpy`; gli input di trascrizione sono in `input/`. Il programma riscrive `labels_rings.csv`, `summary.csv` e `results.json` con un seme casuale fissato. Gli hash SHA256 di tutti i file sorgenti e risultati sono nel manifesto `SHA256SUMS.txt`.
