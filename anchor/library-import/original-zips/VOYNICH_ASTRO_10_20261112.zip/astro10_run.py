#!/usr/bin/env python3
import re, collections, pathlib, random, math, json, itertools, statistics, hashlib, zipfile
src=pathlib.Path('/mnt/data/files/ZL3b-n.txt')
raw=src.read_bytes(); d=collections.defaultdict(list)
for line in raw.decode().splitlines():
 m=re.match(r'^<([^<>]+)\.([0-9]+),([@+&=*])([A-Za-z0-9]+)>\s*(.*)',line)
 if not m:continue
 fol,n,marker,unit,txt=m.groups()
 if not unit.startswith('R'):continue
 txt=re.sub(r'<!.*?>|<\$>|<%>|<->','',txt)
 words=[x for x in re.split('[.,]',txt) if x.strip()]
 d[(fol,unit)].append((int(n),len(words),txt))
random_gen=random.Random(20261112)
results=[]
for (fol,kind),rows in sorted(d.items()):
 if len(rows)<4:continue
 rows=sorted(rows); vals=[x[1] for x in rows]; n=len(vals)
 observed=sum(abs(a-b)<=1 for a,b in zip(vals,vals[1:]))
 circular=observed+(abs(vals[-1]-vals[0])<=1)
 # Adjacent matches under random permutation of observed count multiset
 # exact expected: 2*sum_{i<j} 1(condition) / n, n-1 adjacent edges
 expected=sum(abs(a-b)<=1 for i,a in enumerate(vals) for b in vals[i+1:])*2/n
 reps=30000 if n>8 else 0
 if n<=8:
  sampled=list(set(itertools.permutations(vals)))
  counts=[sum(abs(a-b)<=1 for a,b in zip(t,t[1:])) for t in sampled]
  total=len(counts)
 else:
  counts=[]
  for _ in range(reps):
   x=vals[:];random_gen.shuffle(x)
   counts.append(sum(abs(a-b)<=1 for a,b in zip(x,x[1:])))
  total=reps
 higher=(sum(t>=observed for t in counts)+(0 if n<=8 else 1))/(total+(0 if n<=8 else 1))
 lower=(sum(t<=observed for t in counts)+(0 if n<=8 else 1))/(total+(0 if n<=8 else 1))
 res=dict(folio=fol,radial_type=kind,n=n,counts=dict(sorted(collections.Counter(vals).items())),observed_near_adjacency=observed,adjacencies=n-1,observed_circular=circular,expected_near_adjacency=round(expected,4),p_high=round(higher,6),p_low=round(lower,6),null_type='exact distinct multiset permutations' if n<=8 else 'Monte Carlo 30000', lengths=vals)
 results.append(res)
print('CORPUS',hashlib.sha256(raw).hexdigest())
for r in results:print(r['folio'],r['radial_type'],r['n'],r['observed_near_adjacency'],r['expected_near_adjacency'],r['p_high'],r['p_low'],r['lengths'])
print('total',len(results),'min p',min(min(x['p_high'],x['p_low']) for x in results))
out=pathlib.Path('/mnt/data/VOYNICH_ASTRO_10_20261112');out.mkdir(exist_ok=True)
(out/'RESULTS.json').write_text(json.dumps({'corpus_sha256':hashlib.sha256(raw).hexdigest(),'seed':20261112,'groups':results},indent=2,ensure_ascii=False)+'\n')
# Combined, within-diagram fixed-histogram randomisation.
rng=random.Random(20261112)
repetitions=50000
observed=sum(x['observed_near_adjacency'] for x in results)
distribution=[]
for i in range(repetitions):
 total=0
 for x in results:
  seq=x['lengths'][:];rng.shuffle(seq)
  total+=sum(abs(a-b)<=1 for a,b in zip(seq,seq[1:]))
 distribution.append(total)
summary={'panels':len(results),'adjacency_pairs':sum(x['adjacencies'] for x in results),'observed_similar_pairs':observed,'observed_fraction':observed/sum(x['adjacencies'] for x in results),'expected_similar_pairs_exact':sum(x['expected_near_adjacency'] for x in results),'null_mean':statistics.mean(distribution),'null_stdev':statistics.stdev(distribution),'p_upper_plus1':(1+sum(v>=observed for v in distribution))/(1+len(distribution)),'null_95pct_interval': [sorted(distribution)[int(len(distribution)*.025)],sorted(distribution)[int(len(distribution)*.975)]],'randomisations':repetitions,'selection':'All (folio,radial_type) groups with >=4 radial loci; ordering by locus number; not necessarily independently verified physical clockwise order.','posthoc':True,'f68v3_note':'Minimum one-sided panel p=0.026786 from 12 examined groups, uncorrected and post-selection; not a surviving familywise finding.'}
(out/'POOLED.json').write_text(json.dumps(summary,indent=2)+'\n')
print('SUMMARY',json.dumps(summary,indent=2))
