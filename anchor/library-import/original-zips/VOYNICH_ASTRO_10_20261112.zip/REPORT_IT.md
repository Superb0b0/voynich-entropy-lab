# ASTRO-10 — La regola apparente delle lunghezze radiali

**Data:** 12 novembre 2026. Ricerca esplorativa, non decifrazione. La pipeline RC1.4.2 rimane intatta e congelata.

## Domanda

I testi radiali vicini dei diagrammi astronomici/cosmologici hanno lunghezze simili per una regola locale, o perché ciascun diagramma contiene già etichette di lunghezza quasi uniforme?

## Fonti e unità

Corpus in sola lettura: `ZL3b-n.txt`, SHA-256 `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc`. Inclusi tutti i gruppi `(folio,unità R...)` con almeno 4 loci radiali nel corpus, **12 gruppi**, per complessive 130 coppie consecutive. Unità di misura: numero dei segmenti separati da `.` o `,` nella trascrizione, dopo rimozione delle note inline; non equivale necessariamente a numero morfologico di parole. Ordine = numero di locus; l'effettiva sequenza spaziale va confermata in facsimile per ogni pagina. I due lati del foglio f69 non costituiscono due manoscritti indipendenti.

La fonte di contesto `https://voynich.nu/q10/index.html` descrive f69r e f69v, compresi i 22 testi radiali sul recto e le 28 scritte sul verso. Un'altra analisi pubblicata online (https://www.dmh.dev/voynich/library?doc=plain-english-visual-readers-guide&subtab=docs) segnala un'elevata frequenza di lunghezze radiali simili, ma con perimetro e controlli diversi: non è una replica del suo calcolo.

## Test specificato

Definizione di somiglianza: due loci consecutivi differiscono al massimo di 1 parola. Null: **rimescolare in modo indipendente e uniforme le lunghezze all'interno dello stesso gruppo**; preservare numero di loci e multinsieme delle loro lunghezze. 50.000 repliche random (seed 20261112), confronto unilaterale verso un eccesso di coppie simili. La previsione nulla esatta si calcola dalle coppie del multinsieme.

## Risultati

- **118/130 = 90,77%** delle coppie hanno lunghezze simili.
- Sotto il null condizionato alla composizione di ogni gruppo: **116,41/130 = 89,55%** coppie attese.
- Simulazioni: media **116,42**, deviazione standard **2,55**; intervallo centrale simulato 95% **111–121**.
- **p unilaterale = 0,3385** (50.000 rimescolamenti, correzione +1): nessuna evidenza robusta di una regola addizionale che attragga lunghezze simili in posizione adiacente.
- f69r: **19/21** coppie simili; atteso **18,73** conservando 5 scritte di 2 parole, 12 di 3 e 5 di 4; p circa **0,595**.
- f69v: **27/27** coppie simili; è **matematicamente inevitabile** per la misura scelta, perché tutte le iscrizioni hanno 1 o 2 parole.
- f68v3: **0/7** coppie simili con lunghezze `[8,5,8,4,7,4,6,4]` contro **2,75** attese; p esatto unilaterale **0,02679**, calcolato su tutte le permutazioni distinte dello stesso multinsieme. È il gruppo più anomalo visto *a posteriori*: con **12** gruppi esaminati non supera una correzione conservativa per ricerche multiple (Bonferroni 0,3214); non è una scoperta confermata.

## Interpretazione

Il contrasto f69r/f69v resta reale sul piano della **distribuzione delle lunghezze**. Non si può trasformarlo nella prova di una regola locale di successione, perché la forte omogeneità all'interno dei due diagrammi spiega quasi interamente la vicinanza delle lunghezze.

Il caso f68v3 è un'indicazione esplorativa di possibile alternanza strutturale, ma richiede **una previsione esterna predefinita** su una nuova pagina prima di essere considerato significativo.

## Decisione scientifica

**STOP** all'ipotesi di una legge generale di «livellamento locale» delle lunghezze radiali con questi dati. Proseguire con vincoli iconografici e semantici specifici, ad esempio le **28 iscrizioni** di f69v rispetto alla tradizione delle **28 dimore lunari**, che è un'identificazione già proposta nella letteratura; la corrispondenza numerica da sola non basta a nominare o tradurre le 28 iscrizioni. Nessuna parola è stata decifrata.
