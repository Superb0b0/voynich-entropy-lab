# Release candidata v1.1.0

Solo ANC-0001, ANCHOR-02, PENDING/RIPORTATO/ESPLORATIVO. Il digest del rapporto e la validazione rev3 sono stati verificati. Nessuna riproduzione scientifica, nessuna modifica al gate, nessun aggiornamento della v1.0.0.

La release NON è congelata. Verificare il manifest e i file originali prima di qualsiasi attestazione ulteriore.
