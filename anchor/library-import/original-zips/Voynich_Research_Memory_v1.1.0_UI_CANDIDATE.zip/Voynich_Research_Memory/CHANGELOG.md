# CHANGELOG

## 1.0.0 — 2026-11-12 (CONGELATA_NON_VERIFICATA)
- Prima release: separazione tra dati (`releases/v1.0.0/data.json`) e codice (`site/index.html`).
- Dati derivati dal cruscotto RC1.4.2/V7.1 senza modifiche scientifiche (round-trip verificato sulle cinque tabelle).
- Stato invariato: CLOSED_PENDING_VALIDATION, RP-01 e PROVENANCE-GAP-01 aperti, f085v irrisolto, popolazioni 146 e 9 distinte.
- Nessuna autorizzazione a builder, PCA, clustering, conditional coupling.
- Risultati ANCHOR: classificati come esplorativi, nessuna voce presente.
- Verifiche ancora PENDING: hash dei file nella Library, test nel browser (filtri, navigazione, export JSON), apertura dell'URL pubblicato.
