Cartella per le evidenze (file originali con hash). Vuota in release 1.0.0.
