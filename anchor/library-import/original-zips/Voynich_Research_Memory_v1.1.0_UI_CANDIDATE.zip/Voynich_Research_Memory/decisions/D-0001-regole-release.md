# D-0001 — Regole di release (2026-11-12)
1. Il sito legge dati solo da release immutabili con versione e hash.
2. Nuova evidenza = nuova release; nessuna modifica retroattiva.
3. Le note locali restano separate dai dati e non diventano registro.
4. Il sito mostra l'hash della release visualizzata, confrontabile con la Library.
5. Nessun dato passa da PENDING a PASS solo perché inserito in una nuova release: servono evidenza identificabile e verifica documentata.

Il digest è calcolato sui byte definitivi di `data.json` e riportato solo nel manifest.
La Library è la fonte documentale; il sito presenta una release specifica.
