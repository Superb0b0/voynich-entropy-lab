#!/usr/bin/env python3
import pathlib,sys,json,hashlib,datetime
ROOT=pathlib.Path(__file__).resolve().parent.parent
if len(sys.argv)<2 or sys.argv[1] not in ('stato','verifica','nuova-nota'):
 print('Uso: memoria.py stato | verifica | nuova-nota "testo"');sys.exit(2)
cmd=sys.argv[1]
if cmd=='stato':
 print((ROOT/'registri/stato.json').read_text());sys.exit(0)
if cmd=='verifica':
 m=json.loads((ROOT/'MANIFEST.json').read_text());bad=[]
 for name,h in m['files_sha256'].items():
  path=ROOT/name
  if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest()!=h:bad.append(name)
 print('PASS: snapshot integro' if not bad else 'FAIL: '+', '.join(bad));sys.exit(bool(bad))
if len(sys.argv)!=3 or not sys.argv[2].strip():sys.exit('Fornire una nota non vuota')
path=ROOT/'annotazioni_append_only.jsonl'
entry={'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'type':'USER_NOTE_UNVERIFIED','text':sys.argv[2]}
with path.open('a',encoding='utf8') as f:f.write(json.dumps(entry,ensure_ascii=False)+'\n')
print('Annotazione aggiunta; nessuno stato scientifico modificato')
