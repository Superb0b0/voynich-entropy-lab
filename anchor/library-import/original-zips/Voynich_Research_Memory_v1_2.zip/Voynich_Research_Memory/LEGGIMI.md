# Voynich Research Memory 1.0

**Snapshot:** 12 novembre 2026. **Gate:** `CLOSED_PENDING_VALIDATION`. **Regime:** fail-closed.

## Ripresa in 60 secondi
1. Leggere `registri/stato.json` e `registri/rilievi.json`.
2. Leggere `registri/attivita.json`: lavorare solo su attività consentite.
3. Controllare `registri/esperimenti.json` per evitare duplicazioni.
4. Consultare `registri/artefatti.json`: hash troncati NON verificano l'integrità; non presumere che i file originali siano inclusi.
5. Ogni nuova osservazione deve citare un file preciso, versione, digest completo (se disponibile), metodo, data, e distinguere fatto/attestazione/ipotesi.

## Regole inderogabili
- Nessun builder, PCA, clustering, conditional coupling o promozione dei profili.
- `f085v` resta irrisolto; RP-01 e PROVENANCE-GAP-01 aperti.
- PASS locali non aprono il gate.
- Gli esperimenti ANCHOR sono esplorativi, non una decifrazione.
- Non modificare retroattivamente snapshot e registri: creare una nuova versione, conservando quella vecchia.
- Il database è un indice derivato: i JSON sono la sorgente canonica di questo pacchetto.

## Aggiornamenti nel tempo
Eseguire solo `python strumenti/memoria.py verifica` per controllare l'integrità dei file del pacchetto. `python strumenti/memoria.py stato` mostra lo stato. `python strumenti/memoria.py nuova-nota "testo"` aggiunge un'annotazione append-only senza modificare i registri scientifici. Nessuno di questi comandi esegue analisi Voynich.

## Cosa manca
Il pacchetto contiene riferimenti e attestazioni, non tutti gli artefatti originali. La verifica crittografica di sorgenti non presenti resta pendente. La persistenza tra sessioni richiede conservare questo ZIP in Library o in un repository versionato; una copia scaricata localmente non si sincronizza automaticamente con ChatGPT.
