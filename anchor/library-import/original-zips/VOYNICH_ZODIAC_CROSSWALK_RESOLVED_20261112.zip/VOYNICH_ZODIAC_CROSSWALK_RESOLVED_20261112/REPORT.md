# Voynich: Zodiac crosswalk exceptions resolved (2026-11-12)

## Result
The earlier 299-figure/299-label numerical total masked two counterbalancing local exceptions. Using independent pre-existing image annotation sources, we have now **identified the referent type and locus** in both cases:

1. **Pisces f70v2:** 29 nymphs, 30 labels. The extra label is **`f70v2.C.1`**, explicitly identified as **Central star** by the historical Voynich Information Browser (VIB). ZL3b: `otolal` (our extracted local locus 33); Takahashi/IT2a: `otylal`; Currier and Kluge: `otral`; Stolfi: `otalal`. Zandbergen's Quire 10 independent description confirms the central star as the extra referent. Importantly the attribution is based on the VIB's explicit `C.1` unit, **not** on assuming the last extracted label must be the central label.
2. **Gemini f72r2:** 30 nymphs, 29 labels. Zandbergen identifies the unlabeled nymph **on the outer ring, left side**, distinct from the **starless** outer-ring nymph **lower right**. They must never be merged or treated as the same exception.

## What this does not establish
- The **meaning** of `otolal`, `otylal`, or any other Voynich token is **unknown**. They refer to a central star in this one context, but are not necessarily a word for 'star'.
- No one-to-one coordinate crosswalk has been confirmed for the remaining 297 nymph labels in this study. Page-level equality of counts does not certify individual pairing.
- VIB and Zandbergen provide human descriptions; fine-grained spatial co-registration with high-resolution scans was not independently recomputed here.
- The two transcription readings refer to the same physical inscription and do not constitute independent semantic replication.

## Source URLs
- https://vib.tamagothi.de/index.php?id=f70v2&show=page (unit `f70v2.C.1`, Central star)
- https://www.ic.unicamp.br/~stolfi/EXPORT/projects/voynich/00-EXPORT/98-02-01-lotsa-labels/labels-t.html (`f70v2.C.1`)
- https://www.voynich.nu/q10/index.html (Pisces: 29 nymphs, 30 labels)
- https://www.voynich.nu/q11/index.html (Gemini: unlabeled outer-left, starless lower-right)

## Workflow and provenance
This is an **audit correction**, not a new decipherment or a new semantic test. Source `source_labels.csv` copied without modification from the previously frozen dossier. `build.py` checks record counts and expected transcriptions, and creates `resolved_exceptions.csv` and `resolved.json`. RC1.4.2 remains **CLOSED_PENDING_VALIDATION**, untouched.
