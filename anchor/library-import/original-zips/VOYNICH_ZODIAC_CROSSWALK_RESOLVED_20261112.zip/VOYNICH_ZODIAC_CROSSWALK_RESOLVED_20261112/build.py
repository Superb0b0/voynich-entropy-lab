#!/usr/bin/env python3
"""Read-only audit revision from previously frozen source_labels.csv.
Does not assume last locus of zodiac ring is an nymph.
"""
from pathlib import Path
import csv,json,hashlib
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'source_labels.csv'
rows=list(csv.DictReader(SRC.open(newline='',encoding='utf-8')))
assert len(rows)==598, len(rows)
items=[]
for tr,expected in [('ZL3b','otolal'),('IT2a','otylal')]:
    r=[x for x in rows if x['folio']=='f70v2' and x['transcription']==tr and x['raw']==expected]
    assert len(r)==1 and r[0]['locus']=='33',(tr,r)
    items.append({'transcription':tr,'folio':'f70v2','source_locus_in_earlier_extract':r[0]['locus'],
                  'full_original_locus':'f70v2.C.1','raw':r[0]['raw'],'referent':'CENTRAL_STAR',
                  'mapping_basis':'Independent Voynich Information Browser unit Central star, not inferred from sequence',
                  'source_url':'https://vib.tamagothi.de/index.php?id=f70v2&show=page',
                  'status':'LOCUS_REFERENT_IDENTIFIED','translation':'UNKNOWN'})
for tr in ['ZL3b','IT2a']:
    r=[x for x in rows if x['folio']=='f72r2' and x['transcription']==tr]
    assert len(r)==29,(tr,len(r))
    items.append({'transcription':tr,'folio':'f72r2','source_locus_in_earlier_extract':'ABSENT',
                  'full_original_locus':'ABSENT','raw':'ABSENT','referent':'NYMPH_OUTER_RING_LEFT',
                  'mapping_basis':'René Zandbergen quire 11: missing label outer ring left; distinct from starless nymph lower right',
                  'source_url':'https://www.voynich.nu/q11/index.html','status':'UNLABELED_NYMPH_IDENTIFIED',
                  'translation':'NOT_APPLICABLE'})
fields=['transcription','folio','source_locus_in_earlier_extract','full_original_locus','raw','referent','mapping_basis','source_url','status','translation']
with (ROOT/'resolved_exceptions.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(items)
report={'source_rows':len(rows),'n_transcriptions':2,'exception_count_physical':2,
       'exception_count_by_transcription':4,
       'pisces':{'labels':30,'nymphs':29,'central_star_labels':1,'central_star_locus':'f70v2.C.1',
       'ZL3b':'otolal','IT2a':'otylal',
       'alternate_readings':{'Currier':'otral','Kluge':'otral','Stolfi':'otalal'}},
       'gemini':{'labels':29,'nymphs':30,'unlabeled':'outer ring left','starless':'outer ring lower right'},
       'mapping_scope':'Specific exception loci/types established using independent historical sources. No other individual figure-label crosswalk validated.',
       'semantic_status':'NO_TRANSLATION'}
(ROOT/'resolved.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
