# ANCHOR-01 | audit di pre-distribuzione del kit zodiacale

Data: 2026-11-12. **Decisione: `DISTRIBUTION_BLOCKED`.** La precedente frase «5/5 test superati» era una verifica limitata della struttura del kit, non della sua usabilità scientifica.

| Verifica | Esito documentabile | Blocco residuo |
|---|---|---|
| 1. Mapping pannello→canvas | Snapshot Yale del 18/10/2026 corrobora `1006203 = 71v and 72r`, `1006204/5 = 72v (part)`. Non è un errore di copia ovvio: si tratta di immagini composite. | Manifest Yale non recuperato direttamente; localizzazione delle 12 ROI non ancora verificata visivamente. |
| 2. Fallback immagini | Ora definiti Yale IIIF, mirror con SHA-256 di terze parti e importazione manuale. Lo script non sostituisce immagini in silenzio. | Otto scansioni integrali assenti; nessuna acquisizione reale verificata. |
| 3. Provenienza | Distingue hash dei JPEG mirror, hash della snapshot manifest Yale e attestazione del custode. Il pack richiede approvazioni separate. | Nessun SHA-256 di JPEG Yale attestato dal manifest; confronto diretto con Yale ancora necessario. |
| 4. Annotatore | Nel kit precedente `bbox_px` era effettivamente in coordinate naturali del JPEG visualizzato, ma mancavano SHA-256 del JPEG visto, timestamp per regione, ordine vincolato, lock, conversione da ritagli a coordinate native della sorgente. Nel kit nuovo sono implementati e testati a livello unitario. | E2E browser su computer reale ancora da eseguire; ROI reali da confermare. |
| 5. Fatica / blocchi | Ora 12 ritagli separati, 4 blocchi da 3, pausa obbligata fra blocchi, log eventi e sessioni. | Nessuna pausa o sessione reale registrata; revisori non reclutati. |
| Demo / indipendenza | Due anteprime solo in `custodian/pilot_reference_only`, mai nel reviewer ZIP; test sintetico copre due pannelli dalla stessa immagine sorgente. Modulo d'indipendenza e verifica custodiale presenti. | Zero dichiarazioni firmate; nessuna coppia di revisori eleggibili verificata. |

**Nota di integrità:** una snapshot che *riporta* SHA-256 del manifest Yale non equivale a ricalcolare quell'hash sui byte originali Yale in questa sessione. Un file JPEG corrispondente all'hash del mirror non è automaticamente un master Yale. Un'approvazione umana della corrispondenza visiva è un controllo dichiarativo, non una firma dell'istituzione Yale.

**Non eseguire il gate statistico.** L'obiettivo immediato è acquisire e controllare le 8 scansioni, verificare le 12 ROI, reclutare due revisori, quindi raccogliere nuove annotazioni cieche. Nessun collegamento figura–etichetta è stato validato.
