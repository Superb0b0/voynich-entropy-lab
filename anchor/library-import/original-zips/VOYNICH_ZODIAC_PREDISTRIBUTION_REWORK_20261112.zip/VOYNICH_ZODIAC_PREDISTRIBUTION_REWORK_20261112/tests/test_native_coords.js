const fs=require('fs'),assert=require('assert'),vm=require('vm'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../reviewer_template/annotate_offline.html'),'utf8');
const code=html.split('<script>')[1].split('</script>')[0];
new vm.Script(code); // full script syntax
function extract(name){
 const prefix='function '+name+'(';let start=code.indexOf(prefix);assert(start>=0,name);
 let brace=code.indexOf('{',start),depth=0,end=-1;
 for(let i=brace;i<code.length;i++){if(code[i]==='{')depth++;else if(code[i]==='}'){depth--;if(depth===0){end=i+1;break}}}
 return code.slice(start,end);
}
const context={Math,Number,Set,Error,RegExp,Array,console,canvas:{getBoundingClientRect:()=>({left:20,top:30,width:500,height:400})},activeImage:{naturalWidth:1000,naturalHeight:800}};
vm.createContext(context);
vm.runInContext(extract('localPoint')+'\n'+extract('nativeBox')+'\n'+extract('validateManifest'),context);
assert.deepEqual(Array.from(context.nativeBox([10,20,30,40],{source_native_offset_px:[100,200]})),[110,220,130,240]);
let p=context.localPoint({clientX:270,clientY:230});assert.equal(p.x,500);assert.equal(p.y,400);
const panels=Array.from({length:12},(_,i)=>({panel_alias:`PANEL_${String(i+1).padStart(2,'0')}.jpg`,panel_order:i+1,block:Math.floor(i/3)+1,source_native_offset_px:[50+i,80+i],source_native_dimensions_px:[500,500],source_image_sha256:i===4||i===5?'a'.repeat(64):'b'.repeat(64),crop_sha256:'c'.repeat(64),crop_bytes:100,crop_width:200,crop_height:200}));
const m={schema_version:'ZODIAC-12P-BLIND-MANIFEST-2.0',block_size:3,panels};
context.validateManifest(m);
assert.equal(panels[4].source_image_sha256,panels[5].source_image_sha256); // two panels from one canvas
panels[5].panel_alias=panels[4].panel_alias;
assert.throws(()=>context.validateManifest(m),/Manifest/);
console.log('NODE_UNIT_PASS: source-native transforms, display scaling, 12 panel manifest, shared source, duplicate alias blocked');
