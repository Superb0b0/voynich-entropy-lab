#!/usr/bin/env python3
"""Compare actual verso lexical similarity to same-code alternative versos of comparable token length.
Oracle length selection for fair matched contrasts, not a practical retrieval algorithm.
"""
from pathlib import Path
import re,json,csv
from collections import Counter
import numpy as np
F=Path(__file__).with_name('exp_next_token.py');ns={'__name__':'leaf_matched','__file__':str(F)}
exec(compile(F.read_text().split("for tr in ('zl','it'):")[0],str(F),'exec'),ns)
folios=ns['folios'];header={}
for line in (ns['INPUT']/'ZL3b-n.txt').read_text().splitlines():
 m=re.match(r'^<([^>,.]+)>\s*<!',line)
 if m:header[m[1]]=dict(re.findall(r'\$(\w+)=([^\s>]+)',line))
res={}
for trans in ['zl','it']:
 words={f:Counter(t for p in folios[f] for row in p for t in row[trans]) for f in folios}
 sets={f:set(w) for f,w in words.items()}
 n={f:sum(w.values()) for f,w in words.items()}
 for tol in [.10,.20,.35,.50,1.]:
  sample=[]
  for r in folios:
   m=re.fullmatch(r'f(\d+)r',r)
   if not m:continue
   v=f'f{m[1]}v'
   if v not in folios:continue
   alternatives=[x for x in folios if x.endswith('v') and x!=v and all(header[r].get(k)==header[x].get(k) for k in ['L','Q','I'])]
   matched=[x for x in alternatives if abs(np.log((n[x]+1)/(n[v]+1)))<=tol]
   if not matched:continue
   def jac(a,b):return len(sets[a]&sets[b])/max(1,len(sets[a]|sets[b]))
   true=jac(r,v)
   comp=np.mean([jac(r,x) for x in matched]);sample.append((r,v,true,comp,len(matched),n[v]))
  obs=np.array([x[2]-x[3] for x in sample]);rng=np.random.default_rng(20261112+round(tol*100)+(trans=='it'))
  B=4999;boot=np.zeros(B);nll=np.zeros(B)
  for j in range(B):
   ids=rng.integers(len(obs),size=len(obs));boot[j]=obs[ids].mean()
   nll[j]=(obs*rng.choice([-1,1],size=len(obs))).mean()
  res.setdefault(str(tol),{})[trans]={'n':len(sample),'mean_alternatives':np.mean([x[4] for x in sample]),
    'observed':float(np.mean([x[2] for x in sample])), 'matched_expected':float(np.mean([x[3] for x in sample])),
    'delta':float(obs.mean()),'p_one_sided_signflip':float((1+sum(nll>=obs.mean()))/(B+1)),
    'ci95_bootstrap':[float(x) for x in np.quantile(boot,[.025,.975])]}
output={'status':'EXPLORATORY_POST_HOC_LENGTH_MATCHED','parameters':{'tol':'maximum absolute log-ratio between actual and alternate verso token counts','strata':['Currier L','quire Q','illustration code I']},'results':res}
F.with_name('LEAF_LENGTH_MATCHED_RESULTS.json').write_text(json.dumps(output,indent=2))
with F.with_name('LEAF_LENGTH_MATCHED_SUMMARY.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['tolerance','trans','n_pairs','true_jaccard','match_mean','difference','p'])
 for tolerance,d in res.items():
  for tr,val in d.items():w.writerow([tolerance,tr,val['n'],val['observed'],val['matched_expected'],val['delta'],val['p_one_sided_signflip']])
print(json.dumps(output,indent=2))
