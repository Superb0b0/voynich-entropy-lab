#!/usr/bin/env python3
"""Robustness to globally frequent words of within-leaf overlap; post hoc.
Matched controls same Currier, quire, illustration. Includes exact adjacent-page contrast.
"""
from pathlib import Path
import numpy as np,re,json,csv
from collections import Counter
F=Path(__file__).with_name('exp_next_token.py')
ns={'__name__':'leaf_rare','__file__':str(F)}
exec(compile(F.read_text().split("for tr in ('zl','it'):")[0],str(F),'exec'),ns)
folios=ns['folios'];raw=(ns['INPUT']/'ZL3b-n.txt').read_text().splitlines();head={}
for line in raw:
 m=re.match(r'^<([^>,.]+)>\s*<!',line)
 if m:head[m[1]]=dict(re.findall(r'\$(\w+)=([^\s>]+)',line))
rows=[]
for f in folios:
 m=re.fullmatch(r'f(\d+)r',f)
 if not m:continue
 n=int(m[1]);v=f'f{n}v';x=f'f{n+1}r'
 if v in folios and x in folios and all(head[f].get(k)==head[v].get(k)==head[x].get(k) for k in ['L','Q','I']):
  rows.append((f,v,x))
res={}
for trans in ['zl','it']:
 counts={f:Counter(x for para in folios[f] for row in para for x in row[trans]) for f in folios}
 globalfreq=Counter();
 for c in counts.values():globalfreq.update(c)
 allfreq=globalfreq.most_common()
 for cut in [0,10,25,50,100,200]:
  stop={w for w,n in allfreq[:cut]}
  sets={f:set(c)-stop for f,c in counts.items()}
  def jac(f,g):
   a=sets[f];b=sets[g];return len(a&b)/(len(a|b) or 1)
  # Same leaf vs consecutive next leaf, equal control vars.
  actual=np.array([jac(r,v) for r,v,x in rows]);control=np.array([jac(v,x) for r,v,x in rows]);delta=actual-control
  B=3999;rng=np.random.default_rng(20261112+cut+(trans=='it'))
  bootstrap=np.zeros(B);null=np.zeros(B)
  for i in range(B):
   ix=rng.integers(len(delta),size=len(delta));bootstrap[i]=delta[ix].mean()
   null[i]=(delta*rng.choice([-1,1],size=len(delta))).mean()
  res.setdefault(cut,{})[trans]={'N':len(rows),'actual':float(actual.mean()),'control':float(control.mean()),
      'delta':float(delta.mean()),'ratio':float(actual.mean()/control.mean()),
      'p_flip_one_sided':float((1+np.count_nonzero(null>=delta.mean()))/(B+1)),
      'CI95':[float(z) for z in np.quantile(bootstrap,[.025,.975])],
      'pairs_with_overlap':int(sum(jac(r,v)>0 for r,v,x in rows)),
      'freq_discarded_token_share':float(sum(globalfreq[w] for w in stop)/sum(globalfreq.values()))}
output={'status':'EXPLORATORY_POST_HOC_FREQUENCY_ABLATION','results':res,
 'warning':'Top K removal parameters explored after seeing main leaf association; no multiplicity-adjusted p or claim of semantic topic.'}
F.with_name('LEAF_RARE_RESULTS.json').write_text(json.dumps(output,indent=2))
with F.with_name('LEAF_RARE_SUMMARY.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['top_n_removed','trans','n','obs','control','ratio','p_one_sided'])
 for cut,v in res.items():
  for trans,x in v.items():w.writerow([cut,trans,x['N'],x['actual'],x['control'],x['ratio'],x['p_flip_one_sided']])
print(json.dumps(output,indent=2))
