#!/usr/bin/env python3
"""Text-only test of metadata-linked bifolio members (`$Q`, `$B`).
Exploratory replication/contrast to recent codicology work; folio-side text only, no image processing.
"""
from pathlib import Path
import json,re,csv
import numpy as np
from collections import Counter,defaultdict
F=Path(__file__).with_name('exp_next_token.py')
ns={'__name__':'bifolium_test','__file__':str(F)}
exec(compile(F.read_text().split("for tr in ('zl','it'):")[0],str(F),'exec'),ns)
folios=ns['folios']
header={}
for line in (ns['INPUT']/'ZL3b-n.txt').read_text().splitlines():
 m=re.match(r'^<([^>,.]+)>\s*<!',line)
 if m:header[m[1]]=dict(re.findall(r'\$(\w+)=([^\s>]+)',line))
# Each leaf is a recto/verso pair. Select leaves with both sides and a consistent Q+B assignment.
leaves={}
for f in folios:
 m=re.fullmatch(r'f(\d+)r',f)
 if not m:continue
 n=int(m[1]);v=f'f{n}v';
 if v not in folios:continue
 if header[f].get('Q')!=header[v].get('Q') or header[f].get('B')!=header[v].get('B'):continue
 if header[f].get('L')!=header[v].get('L'):continue
 leaves[n]={'ids':[f,v], 'Q':header[f].get('Q'), 'B':header[f].get('B'), 'L':header[f].get('L'), 'I':header[v].get('I') if header[f].get('I')!=header[v].get('I') else header[f].get('I')}
byqb=defaultdict(list)
for n,info in leaves.items():byqb[(info['Q'],info['B'])].append(n)
mates={}
for k,numbers in byqb.items():
 if len(numbers)==2:
  a,b=numbers;mates[a]=b;mates[b]=a
print('leaf count',len(leaves),'paired',len(mates),'bifolio groups',len(mates)//2)

rng=np.random.default_rng(20261112+962)
res={}
for tr in ['zl','it']:
 counts={n:Counter(t for f in d['ids'] for p in folios[f] for row in p for t in row[tr]) for n,d in leaves.items()}
 freq=Counter()
 for c in counts.values():freq.update(c)
 for skip in [0,50]:
  stop={w for w,c in freq.most_common(skip)}
  sets={n:set(counts[n])-stop for n in leaves}
  def jac(a,b):
   x=sets[a];y=sets[b];return len(x&y)/(len(x|y) or 1)
  for match in ['Q+L','Q+L+I']:
   pair=[]
   for a,b in mates.items():
    row=leaves[a]
    options=[c for c,cc in leaves.items() if c!=a and c!=b and cc['Q']==row['Q'] and cc['L']==row['L'] and (match=='Q+L' or cc['I']==row['I'])]
    if options:pair.append((a,b,options))
   x=np.array([jac(a,b) for a,b,other in pair]);y=np.array([np.mean([jac(a,c) for c in other]) for a,b,other in pair]);delta=x-y
   # Pairs a->b and b->a correlated; group bootstrap by bifolium unit
   groups=defaultdict(list)
   for i,(a,b,other) in enumerate(pair):groups[(min(a,b),max(a,b))].append(i)
   IDs=list(groups);B=3999;bs=np.zeros(B);fl=np.zeros(B)
   for k in range(B):
    sampled=rng.choice(len(IDs),len(IDs),replace=True);ix=np.concatenate([groups[IDs[i]] for i in sampled]);bs[k]=np.mean(delta[ix])
    sign=rng.choice([-1,1],size=len(IDs));d=delta.copy()
    for j,id in enumerate(IDs):d[groups[id]]*=sign[j]
    fl[k]=np.mean(d)
   item={'n_anchor_leaves':len(pair),'n_bifolia':len(IDs),'actual_mean_J':float(x.mean()),'other_mean_J':float(y.mean()),
    'delta':float(delta.mean()),'p_cluster_flip':float((1+np.count_nonzero(fl>=delta.mean()))/(B+1)),
    'CI95_bifolio_bootstrap':[float(q) for q in np.quantile(bs,[.025,.975])],
    'ratio':float(x.mean()/y.mean())}
   # check whether consecutive-number leaves are stronger than physically same-bifolio mate (if mate is non-adjacent)
   q=[]
   for a,b,o in pair:
    if abs(a-b)<=1:continue
    near=[k for k in [a-1,a+1] if k in leaves and leaves[k]['Q']==leaves[a]['Q'] and leaves[k]['L']==leaves[a]['L'] and (match=='Q+L' or leaves[k]['I']==leaves[a]['I'])]
    if near:q.append((a,b,np.mean([jac(a,j) for j in near])))
   if q:item['nonadjacent_mates_vs_adjacent_leaves']={'n':len(q),'same_sheet_mean':float(np.mean([jac(a,b) for a,b,n in q])), 'adjacent_leaf_mean':float(np.mean([n for a,b,n in q])), 'delta':float(np.mean([jac(a,b)-n for a,b,n in q]))}
   res.setdefault(str(skip),{}).setdefault(match,{})[tr]=item

output={'status':'EXPLORATORY_POST_HOC_BIFOLIO','design':'Aggregate r+v for each numbered leaf with both sides, identify paired bifolio by matching metadata Q and B; compare same bifolio vs other leaves within quire and Currier, optionally illustration matched; no visual-text pipeline; ties bootstrapped by bifolio.',
 'inputs':ns['HASH'],'results':res,'cautions':['Manuscript quire/bifolio metadata is existing editorial markup, not newly inferred structural binding.','Existing 2026 bifolio-coherence research means these observations are not necessarily novel.','Retrospective hypothesis and repeated testing, exploratory.']}
F.with_name('BIFOLIO_RESULTS.json').write_text(json.dumps(output,indent=2))
with F.with_name('BIFOLIO_SUMMARY.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['remove_top_n','match','trans','n_bifolia','same_bifolio','control','difference','p'])
 for skip, rr in res.items():
  for match,dd in rr.items():
   for tr,x in dd.items():w.writerow([skip,match,tr,x['n_bifolia'],x['actual_mean_J'],x['other_mean_J'],x['delta'],x['p_cluster_flip']])
print(json.dumps(output,indent=2))
