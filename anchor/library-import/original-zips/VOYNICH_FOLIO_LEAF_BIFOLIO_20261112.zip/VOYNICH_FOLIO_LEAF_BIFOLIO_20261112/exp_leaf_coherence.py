#!/usr/bin/env python3
"""Same physical leaf recto/verso lexical association, controlling quire/Currier/illustration.
Secondary hypothesis chosen after page-memory results. This is exploratory.
"""
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np, json, csv, re
F=Path(__file__).with_name('exp_next_token.py')
ns={'__name__':'leaf_test','__file__':str(F)}
exec(compile(F.read_text().split("for tr in ('zl','it'):")[0],str(F),'exec'),ns)
folios=ns['folios'];test=ns['test'];raw=(ns['INPUT']/'ZL3b-n.txt').read_text().splitlines()
head={}
for ln in raw:
 m=re.match(r'^<([^>,.]+)>\s*<!',ln)
 if m:
  info=dict(re.findall(r'\$(\w+)=([^\s>]+)',ln))
  head[m[1]]=info
allKeys=set(folios)
# recto->verso within the same physical numbered leaf, provided both sides in P corpus.
true_pairs=[]
for f in folios:
 mt=re.fullmatch(r'f(\d+)r',f)
 if mt and 'f'+mt[1]+'v' in allKeys:
  v='f'+mt[1]+'v'
  if head[f].get('L')==head[v].get('L') and head[f].get('Q')==head[v].get('Q'):
   true_pairs.append((f,v))
print('n true recto verso same currier+quire',len(true_pairs))
for constraints in [['L','Q','I'],['L','Q'],['L','I'],['L']]:
 eligible=[]
 for r,v in true_pairs:
  null=[x for x in folios if x.endswith('v') and x!=v and x!='f'+r.split('r')[0].replace('f','')+'v' and all(head[x].get(z)==head[r].get(z) for z in constraints)]
  if null:eligible.append((r,v,null))
 print('strata',constraints,'eligible',len(eligible),'candidate-median',np.median([len(t[2]) for t in eligible]) if eligible else None)

rng=np.random.default_rng(20261112+5618)
result={}
# Full corpus candidates and quire/Currier/illustration matched controls.
for constr in [['L','Q','I'],['L','Q']]:
 obsdata={};
 for trans in ['zl','it']:
  profiles={f:Counter(t for para in folios[f] for row in para for t in row[trans]) for f in folios}
  sets={f:set(p) for f,p in profiles.items()}
  eligible=[]
  for r,v in true_pairs:
   null=[x for x in folios if x.endswith('v') and x!=v and all(head[x].get(z)==head[r].get(z) for z in constr)]
   if not null:continue
   # compare same-length-band null candidates to real verso, allows limited drift
   target=len(profiles[v]);null2=[x for x in null if abs(np.log((len(profiles[x])+1)/(target+1)))<=.7]
   if null2:null=null2
   eligible.append((r,v,null))
  def jac(a,b):
   x=sets[a];y=sets[b];return len(x&y)/(len(x|y) or 1)
  true=np.array([jac(r,v) for r,v,opts in eligible]);
  # Match null candidate per recto in same class; null must be another leaf.
  M=4999;null=np.empty(M)
  for i in range(M):
   vals=[jac(r,opts[rng.integers(len(opts))]) for r,v,opts in eligible]
   null[i]=np.mean(vals)
  obs=float(np.mean(true));avg=float(np.mean(null));
  # Per-pair expected vs random candidate mean; group bootstrap by leaf.
  means=np.array([np.mean([jac(r,x) for x in opts]) for r,v,opts in eligible]);
  delta=true-means
  B=3999;b=np.empty(B)
  for k in range(B):
   ss=rng.integers(len(delta),size=len(delta));b[k]=np.mean(delta[ss])
  obsdata[trans]={'pairs':len(eligible),'observed_mean_jaccard':obs,'null_mean_jaccard':avg,'delta':obs-avg,
     'ratio':obs/avg,'p_above':(1+np.count_nonzero(null>=obs))/(M+1),
     'difference_bootstrap_CI':[float(x) for x in np.quantile(b,[.025,.975])],
     'words_per_page_median':float(np.median([sum(profiles[r].values()) for r,_,_ in eligible]))}
 result['+'.join(constr)]=obsdata
output={'status':'EXPLORATORY_POST_HOC_LEAF_TEST',
  'reference':'recto/verso of same numbered folio vs recto and alternative verso, matched in annotated quire, Currier and illustration code; matched candidate lengths when available.',
  'results':result}
F.with_name('LEAF_COHERENCE_RESULTS.json').write_text(json.dumps(output,indent=2))
with F.with_name('LEAF_COHERENCE_SUMMARY.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['stratum','transcription','n_pairs','observed','null_mean','ratio','p'])
 for k,d in result.items():
  for tr,v in d.items():w.writerow([k,tr,v['pairs'],v['observed_mean_jaccard'],v['null_mean_jaccard'],v['ratio'],v['p_above']])
print(json.dumps(output,indent=2))
