#!/usr/bin/env python3
"""Retrospective directionality/folio specificity controls.
Parameters/folio splits frozen from validation of context-scale models.
Data examined repeatedly: these are exploratory diagnostics, not confirmatory p-values.
"""
from pathlib import Path
import numpy as np, json, csv
from collections import Counter
F=Path(__file__).with_name('exp_next_token.py')
ns={'__name__':'time_arrow','__file__':str(F)}
exec(compile(F.read_text().split("for tr in ('zl','it'):")[0],str(F),'exec'),ns)
R=json.loads(F.with_name('CONTEXT_SCALE_RESULTS.json').read_text())['results']
folios=ns['folios'];base=ns['base'];test=ns['test'];meta=ns['meta'];Gfunc=ns['global_prob'];seed=ns['seed']

out={}
for tr in ('zl','it'):
    G,V=Gfunc(tr)
    th=R[tr]['models']['folio']['w'][0]
    assert th>0
    # Distinct Currier-matched decoy folio, selected deterministically without word contents.
    fx={c:sorted([f for f in test if meta[f]==c]) for c in ['A','B','?']}
    records=[]
    for f in test:
        data=[row[tr] for para in folios[f] for row in para]
        other=[k for k in fx[meta[f]] if k!=f]
        if not other:continue
        other_f=other[sum(map(ord,f))%len(other)]
        foil_all=Counter(t for p in folios[other_f] for row in p for t in row[tr]); foil_total=sum(foil_all.values())
        entire=Counter(t for row in data for t in row); past=Counter();n_past=0
        j=0
        for para in folios[f]:
            for pi,row in enumerate(para):
                tokens=row[tr];entire.subtract(tokens)
                n_future=sum(entire.values())
                if pi>0 and n_past>0 and n_future>0 and tokens:
                    for token in tokens:
                        g=G[meta[f]][token]
                        a=np.log(g)
                        p=np.log((1-th)*g+th*past[token]/n_past)
                        future=np.log((1-th)*g+th*entire[token]/n_future)
                        decoy=np.log((1-th)*g+th*foil_all[token]/foil_total)
                        records.append((f,token,a,p,future,decoy,j,len(data)))
                past.update(tokens);n_past+=len(tokens);j+=1
    x=np.array([[q[2],q[3],q[4],q[5]] for q in records])
    ids=np.array([r[0] for r in records]);fs=sorted(set(ids))
    rng=np.random.default_rng(seed+7000+(tr=='it'))
    boot=3999
    scores={'past_minus_global':x[:,1]-x[:,0],
            'future_minus_global':x[:,2]-x[:,0],
            'crossfolio_minus_global':x[:,3]-x[:,0],
            'past_minus_future':x[:,1]-x[:,2],
            'past_minus_crossfolio':x[:,1]-x[:,3]}
    results={}
    groups={f:np.where(ids==f)[0] for f in fs}
    for name,d in scores.items():
        b=np.zeros(boot)
        for k in range(boot):
            samp=rng.choice(fs,len(fs),replace=True)
            ii=np.concatenate([groups[f] for f in samp]);b[k]=d[ii].mean()
        results[name]={'gain_nats':float(np.mean(d)), 'CI95_folio_bootstrap':[float(t) for t in np.quantile(b,[.025,.975])]}
    # Middle folio rows only 20%-80% by token count: comparable past/future mass.
    pos=np.array([q[6]/q[7] for q in records]);mask=(pos>=.2)&(pos<=.8)
    middle={name:float(d[mask].mean()) for name,d in scores.items()}
    out[tr]={'n_test_tokens_interior':len(records),'n_folios':len(fs),'test_theta_folio':th,
             'results':results,'middle_20_80_fraction':float(mask.mean()),'middle_20_80_results':middle}

payload={'status':'EXPLORATORY_POST_HOC_DIRECTIONALITY','description':'Holdout comparison of past folio, future folio (oracle explanatory, not a predictor), different folio same Currier, versus G. Parameters fixed by prior validation. Reused test folios so not confirmatory.','results':out}
F.with_name('TIME_ARROW_RESULTS.json').write_text(json.dumps(payload,indent=2))
with F.with_name('TIME_ARROW_SUMMARY.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['transcription','comparison','gain_nats','CI_low','CI_high'])
    for tr,val in out.items():
        for name,metric in val['results'].items():w.writerow([tr,name,metric['gain_nats'],*metric['CI95_folio_bootstrap']])
print(json.dumps(payload,indent=2))
