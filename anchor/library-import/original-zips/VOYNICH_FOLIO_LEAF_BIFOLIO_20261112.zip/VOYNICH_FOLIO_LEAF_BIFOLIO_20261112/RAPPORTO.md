# Voynich · EXP-FOLIO-LEAF-BIFOLIO-01

**Data:** 12 novembre 2026. **Stato:** esplorativo / ipotesi sviluppate iterativamente, non preregistrato. **Non è una decifrazione.**

## La risposta che abbiamo ottenuto

Nel campione di trascrizioni ZL3b e IT2a, la distribuzione delle parole è associata alla **pagina fisica (folio-side)** in misura superiore alla sola memoria di paragrafo. La conoscenza delle parole che *seguiranno* su quella pagina fornisce un contributo comparabile a quello delle parole già lette: l'effetto è dunque più coerente con un campo lessicale di pagina che con una copia direzionale semplice. A scala materiale, recto e verso dello stesso foglio e le coppie di fogli assegnate allo stesso bifoglio sono spesso più simili dei controlli. I controlli di lunghezza e di adiacenza ridimensionano queste associazioni; non consentono di concludere che siano effetti puramente semantici o puramente fisici.

## Perimetro dei dati e audit

- Fonti locali **in sola lettura** ZL3b, IT2a, TSV P-only, parser RC1.2; SHA-256 negli input e in `SHA256SUMS.txt`.
- Riconciliazione: **4.118 loci P comuni**, confini di paragrafo spezzati se differiscono tra trascrizioni.
- Folii divisi con stratificazione Currier e seed `20265619`: 112 fonti del modello globale, 40 di validazione, 54 di controllo; nessuna sovrapposizione.
- Target test: 7758 token ZL3b, 7777 token IT2a. Vocabolario dei tipi noto *transduttivamente* sul corpus completo, ma le frequenze globali sono stimate esclusivamente sui folii base. Unigrammi Currier con smoothing additivo 0,10.
- `RC1.4.2` resta **CLOSED_PENDING_VALIDATION**; nessun builder, clustering, PCA o accoppiamento immagini/testo.

## 1. Previsione: frequenze globali, storia del paragrafo e storia del folio

La probabilità prevista per un token è la miscela di unigrammi globali **G**, distribuzione delle parole già osservate nell'intero folio **F**, nel paragrafo corrente **P**, e nella/e ultima/e riga/righe **R**. I pesi sono selezionati con una griglia finita sui soli folii di validazione e poi valutati sui folii di controllo. Il log score è **per token**; il guadagno è la diminuzione della cross-entropy in nat/token.

| Contrasto di modelli (miglioramento sul controllo) | ZL3b | IT2a |
|---|---:|---:|
| P vs G | +0.01705 | +0.01783 |
| F vs G | +0.03379 | +0.03694 |
| F+P vs F | +0.00169 | +0.00065 |
| F+P+R₂ vs F+P | +0.00080 | +0.00069 |

La memoria di pagina riduce la perplessità **3,32%** (ZL3b) e **3,63%** (IT2a) rispetto alle frequenze generali. L'aggiunta della memoria di paragrafo dopo F non produce intervalli bootstrap per folio interamente positivi. Un piccolo contributo delle due ultime righe compare nel modello esteso dopo selezione dei parametri, ma è stato esaminato *post hoc* sullo stesso test set; non è una verifica indipendente.

![Confronto modelli](context_perplexity.png)

### La direzione del tempo: un controllo negativo

Nei 7527 token ZL3b (7553 IT2a) con un contesto precedente e successivo, mantenendo fisso il peso del modello F, il log-score guadagna:

| Sorgente di vocabolario (vs G) | ZL3b | IT2a |
|---|---:|---:|
| Precedente nello stesso folio | +0,03277 | +0,03627 |
| **Successivo nello stesso folio** (oracolo, non predittore) | **+0,03861** | **+0,04310** |
| Folio diverso, stessa varietà Currier | −0,01382 | −0,02390 |

La differenza **passato meno futuro** è negativa in media, con intervalli bootstrap per folio comprendenti zero. Il folio alternativo, viceversa, peggiora la previsione. Conclusione: forte coerenza lessicale specifica di pagina, senza prova di causa sequenziale da passato a futuro. L'uso del vocabolario futuro serve *solo* a diagnosticare questa simmetria e non costituisce un metodo di previsione in tempo reale.

## 2. Recto e verso del medesimo foglio

Sono disponibili **79 coppie recto/verso** con alternative della stessa quire, lingua Currier e tipo illustrativo. Il Jaccard medio del recto con il suo verso è **0,11837 contro 0,10473** (ZL3b); **0,12137 contro 0,10932** (IT2a). L'eccesso compare anche con un candidato di lunghezza simile: con vincolo |ln(token_alt/token_verso)| ≤ 0,20, gli eccessi sono +0.01642 ZL3b su 69 coppie e +0.01290 IT2a su 68 coppie.

Nei **49** casi in cui possiamo confrontare tre pagine consecutive dello stesso ambito (`fNr`→`fNv` e `fNv`→`f(N+1)r`), il vantaggio del passaggio **entro lo stesso foglio** è +0,00952 (ZL3b) e +0,01144 (IT2a), con significatività esplorativa modesta (test sign-flip appaiato p circa 0,032 e 0,011). Dopo aver tolto le 50 forme più frequenti l'associazione rimane visibile, ma questi test sono stati scelti dopo osservazioni precedenti: non aggiungere p-value come fossero prove indipendenti.

### Identificazione mascherata del verso: controllo sulla lunghezza

Dato un recto e soltanto i versi compatibili per quire/Currier/illustrazione, Jaccard identifica il vero verso come primo **38.6% ZL3b** e **32.3% IT2a** delle volte (credito frazionale ai pari merito) contro un caso **18,7%**. Tuttavia, il modello che sceglie solo la pagina con il numero più simile di token ottiene **31.6%** e **36.7%**, rispettivamente. Il confronto lessicale, preso come compito di *top-1*, **non dimostra un guadagno affidabile sulla geometria della pagina**: in IT2a il semplice conteggio dei token è perfino superiore.

Il compito maschera artificialmente l'identità ma non la metadata: i folii nel manoscritto sono ovviamente numerati, quindi non è un sistema pratico per ricostruire l'ordine. È un test di contenuto relativo ai gruppi compatibili.

## 3. Bifogli: coppie di fogli legati dal medesimo supporto

La metadata `$Q` (quire) e `$B` (bifolio) nel corpus IVTFF permettono di identificare **39** coppie con due fogli presenti integralmente, **36** valutabili entro le quire con controlli compatibili. Ogni foglio è rappresentato dal testo combinato di recto e verso.

| Media Jaccard fra fogli di medesimo bifoglio vs altri fogli della stessa quire/Currier | ZL3b | IT2a |
|---|---:|---:|
| Stesso bifoglio | 0.14032 | 0.14671 |
| Controlli | 0.12949 | 0.13768 |
| Eccesso | +0.01083 | +0.00903 |

Il confronto ampio è positivo in entrambe le trascrizioni e dopo aver rimosso le 50 parole più frequenti. Nel controllo più selettivo (solo bifogli non adiacenti vs foglio **vicino ma non membro del bifoglio**), restano **23 unità materiali indipendenti** e la differenza positiva non dà intervalli bootstrap che escludano zero: p=0,0437 ZL3b e 0,0682 IT2a prima dell'esclusione delle 50 forme; dopo l'esclusione p=0,1574 e 0,1175. Non è prova robusta di una proprietà fisica distinta dalla vicinanza testuale.

![Struttura fisica](physical_structure.png)

## Cosa vale la pena sostenere

- **Associazione della distribuzione delle parole con la pagina**, robusta fra due trascrizioni dello stesso manoscritto in questo benchmark. Il modello che usa l'intera storia del folio prevede i token meglio di quello che usa solo la storia del paragrafo.
- **Mancanza di una freccia temporale dimostrata:** la distribuzione delle parole nelle pagine future del medesimo folio funziona altrettanto bene, quindi “memoria” è un'etichetta matematica, non una prova di copiatura causale.
- **Segnali fra due facciate e bifogli:** positivi contro controlli di quire, ma parzialmente spiegabili da geometria, contiguità e lunghezza; non si inferisce per questo un argomento, una lingua o una legatura originale.

## Limiti metodologici inderogabili

1. Tutti i test sono **esplorativi** e varie ipotesi sono state proposte *dopo* osservazioni su dati già esaminati. Lo stesso test set è stato riutilizzato per estensioni. Gli intervalli statistici descrivono la variabilità nel campione osservato, non sostituiscono un nuovo test veramente cieco.
2. ZL3b e IT2a sono due letture dello stesso manoscritto e non due corpus indipendenti. L'accordo riduce la dipendenza dalla trascrizione, non raddoppia il supporto statistico.
3. Il vocabolario globale è conosciuto trasduttivamente; le frequenze sono stimate solo sulle pagine base. Il modello probabilistico non impone la grammatica delle parole né genera un testo Voynich completo.
4. I metadati quire, bifolio e tipo illustrativo sono **informazioni preesistenti** del corpus, non inferenze nuove dall'immagine originale. Non abbiamo aperto la pipeline visivo-testuale congelata.
5. Nessuno di questi esperimenti fornisce una traduzione, una chiave o identifica il meccanismo storico.

## Letteratura, precedenti non trascurabili

- S. Reddy e K. Knight, *What We Know About The Voynich Manuscript* (2011): analisi delle parole-tema di pagina e somiglianza fra pagine adiacenti. https://aclanthology.org/W11-1511/
- Tobias Franke, *A Generative Folio Grammar of the Voynich Manuscript* (14 ottobre 2026): modello con campo lessicale di folio e confronto fra ZL3b e IT2a; risultati già analoghi sull'utilità predittiva del campo di pagina. https://celler-presse.de/forschung/dokument/a-generative-folio-grammar-of-the-voynich-manuscript/
- Colin Layfield e Lisa Fagin Davis, *Singulion Structure and the Voynich Manuscript* (2026): test sulla struttura materiale e sui bifogli. https://doi.org/10.4000/16k0a

I nostri test non vanno presentati come scoperta originale della dipendenza di folio, già documentata. La distinzione empirica **passato/futuro/altro folio** e i controlli lessicali/di lunghezza/retrieval/bifolio qui riportati sono estensioni esplorative con queste specifiche misure, non una verifica di novità nella letteratura completa.

## Esecuzione

Richiede Python 3.11+, NumPy e Matplotlib per i grafici. Eseguire nell'ordine:

```bash
python exp_next_token.py
python exp_context_scale.py
python exp_time_arrow.py
python exp_leaf_coherence.py
python exp_leaf_adjacency.py
python exp_leaf_rare.py
python exp_leaf_retrieval.py
python exp_leaf_retrieval_lengths.py
python exp_leaf_length_matched.py
python exp_bifolium.py
python exp_bifolium_strict.py
python create_dossier.py
```

Il codice utilizza per scelta la stessa separazione di folii nelle estensioni, e non deve essere scambiato per un test preregistrato. Tutti i file utilizzati sono inclusi e controllati con SHA-256.
