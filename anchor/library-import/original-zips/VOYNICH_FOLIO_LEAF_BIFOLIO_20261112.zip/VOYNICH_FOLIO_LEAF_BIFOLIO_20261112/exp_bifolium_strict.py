#!/usr/bin/env python3
"""Strict bifolio test: non-neighbor sheet mates vs immediate non-sheet neighbor leaves.
Posthoc and lower-power than broad within-quire control.
"""
from pathlib import Path
import re,json,csv
from collections import Counter,defaultdict
import numpy as np
F=Path(__file__).with_name('exp_next_token.py');ns={'__name__':'bifolio_strict','__file__':str(F)}
exec(compile(F.read_text().split("for tr in ('zl','it'):")[0],str(F),'exec'),ns)
folios=ns['folios'];header={}
for line in (ns['INPUT']/'ZL3b-n.txt').read_text().splitlines():
 m=re.match(r'^<([^>,.]+)>\s*<!',line)
 if m:header[m[1]]=dict(re.findall(r'\$(\w+)=([^\s>]+)',line))
leaf={}
for f in folios:
 m=re.fullmatch(r'f(\d+)r',f)
 if not m:continue
 n=int(m[1]);v=f'f{n}v'
 if v in folios and all(header[f].get(k)==header[v].get(k) for k in ['L','Q','B']):
  leaf[n]={'Q':header[f].get('Q'),'B':header[f].get('B'),'L':header[f].get('L'),'ids':(f,v)}
by=defaultdict(list)
for n,x in leaf.items():by[x['Q'],x['B']].append(n)
mates={n:bs[1-i] for bs in by.values() if len(bs)==2 for i,n in enumerate(bs)}

out={}
for tr in ['zl','it']:
 freq={n:Counter(w for f in x['ids'] for p in folios[f] for row in p for w in row[tr]) for n,x in leaf.items()}
 allf=Counter();[allf.update(c) for c in freq.values()]
 for cut in [0,50]:
  stop={w for w,k in allf.most_common(cut)}
  sets={n:set(c)-stop for n,c in freq.items()}
  def J(a,b):
   x=sets[a];y=sets[b];return len(x&y)/(len(x|y) or 1)
  obs=[]
  for a,b in mates.items():
   if abs(a-b)<=1:continue
   near=[n for n in (a-1,a+1) if n in leaf and leaf[n]['Q']==leaf[a]['Q'] and leaf[n]['L']==leaf[a]['L']]
   if near:obs.append((min(a,b),max(a,b),J(a,b)-np.mean([J(a,x) for x in near])))
  grouped=defaultdict(list)
  for a,b,d in obs:grouped[a,b].append(d)
  groupmean=np.array([np.mean(ds) for ds in grouped.values()]);G=len(groupmean)
  rng=np.random.default_rng(20261112+1200+cut+int(tr=='it'));B=9999
  boost=np.empty(B);null=np.empty(B)
  for i in range(B):
   s=rng.integers(0,G,size=G);boost[i]=groupmean[s].mean();null[i]=(groupmean*rng.choice([-1,1],size=G)).mean()
  out.setdefault(cut,{})[tr]={'n_oriented':len(obs),'n_bifolia_independent':G,'mean_excess':float(groupmean.mean()),
   'ci95':[float(q) for q in np.quantile(boost,[.025,.975])],
   'p_one_sided_signflip':float((1+(null>=groupmean.mean()).sum())/(B+1))}
P={'status':'EXPLORATORY_POST_HOC','result':out,'caution':'Treat independent units as bifolia, not oriented leaf comparisons. Nonadjacent mate vs adjacent other leaf may differ in distance and page content; this strict test may be underpowered.'}
F.with_name('BIFOLIO_STRICT_RESULTS.json').write_text(json.dumps(P,indent=2))
print(json.dumps(P,indent=2))
