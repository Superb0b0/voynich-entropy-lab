#!/usr/bin/env python3
"""Check whether physical recto-verso signal is only consecutive page adjacency.
Post-hoc exploratory, per-leaf paired comparison: fNr->fNv versus fNv->f(N+1)r,
with same quire, Currier, and illustration where possible.
"""
from pathlib import Path
from collections import Counter
import re,json,csv
import numpy as np
F=Path(__file__).with_name('exp_next_token.py')
ns={'__name__':'leaf_adj','__file__':str(F)}
exec(compile(F.read_text().split("for tr in ('zl','it'):")[0],str(F),'exec'),ns)
folios=ns['folios'];raw=(ns['INPUT']/'ZL3b-n.txt').read_text().splitlines();header={}
for line in raw:
 m=re.match(r'^<([^>,.]+)>\s*<!',line)
 if m:header[m[1]]=dict(re.findall(r'\$(\w+)=([^\s>]+)',line))
fs=set(folios)
D={}
for tr in ['zl','it']:
 words={f:Counter(x for p in paragraphs for row in p for x in row[tr]) for f,paragraphs in folios.items()}
 sets={f:set(c) for f,c in words.items()}
 def jaccard(f1,f2):
  a=sets[f1];b=sets[f2];return len(a&b)/len(a|b) if a or b else 0.
 def rate(f1,f2):
  a=words[f1];b=words[f2];return sum(min(a[t],b[t]) for t in a.keys()&b.keys())/max(1,sum(b.values()))
 for constraints in [('L','Q','I'),('L','Q')]:
  pairs=[]
  for f in folios:
   m=re.fullmatch(r'f(\d+)r',f)
   if not m:continue
   n=int(m[1]);v='f'+str(n)+'v';nextr='f'+str(n+1)+'r'
   if v not in fs or nextr not in fs:continue
   if not all(header[f].get(x)==header[v].get(x)==header[nextr].get(x) for x in constraints):continue
   pairs.append((f,v,nextr))
  a=np.array([jaccard(r,v) for r,v,k in pairs]);b=np.array([jaccard(v,k) for r,v,k in pairs]);delta=a-b
  a2=np.array([rate(r,v) for r,v,k in pairs]);b2=np.array([rate(v,k) for r,v,k in pairs]);
  rng=np.random.default_rng(20261112+800+int(tr=='it'));B=4999
  bootstrap=np.empty(B)
  for k in range(B):
   s=rng.integers(len(delta),size=len(delta));bootstrap[k]=delta[s].mean()
  signflip=np.empty(B)
  for k in range(B):signflip[k]=np.mean(delta*rng.choice([-1,1],size=len(delta)))
  D.setdefault('+'.join(constraints),{})[tr]={'pairs':len(pairs),'recto_verso_mean':float(a.mean()),'verso_nextrecto_mean':float(b.mean()),
   'difference':float(delta.mean()),'bootstrap_CI95':[float(x) for x in np.quantile(bootstrap,[.025,.975])],
   'signflip_p_one_sided':float((1+np.sum(signflip>=delta.mean()))/(B+1)),
   'rate_r2v':float(a2.mean()),'rate_v2next_r':float(b2.mean()),
   'median_tokens_r':float(np.median([sum(words[r].values()) for r,v,k in pairs])),
   'median_tokens_v':float(np.median([sum(words[v].values()) for r,v,k in pairs])),
   'median_tokens_next_r':float(np.median([sum(words[k].values()) for r,v,k in pairs]))}
output={'status':'EXPLORATORY_POST_HOC','design':'Compare same-leaf adjacent pages to next-leaf adjacent pages; all pages required same Currier, quire and optional illustration; n groups of 3 pages.','results':D}
F.with_name('LEAF_ADJACENCY_RESULTS.json').write_text(json.dumps(output,indent=2))
with F.with_name('LEAF_ADJACENCY_SUMMARY.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['controls','trans','n','same_leaf','cross_leaf','delta','p'])
 for k,x in D.items():
  for tr,z in x.items():w.writerow([k,tr,z['pairs'],z['recto_verso_mean'],z['verso_nextrecto_mean'],z['difference'],z['signflip_p_one_sided']])
print(json.dumps(output,indent=2))
