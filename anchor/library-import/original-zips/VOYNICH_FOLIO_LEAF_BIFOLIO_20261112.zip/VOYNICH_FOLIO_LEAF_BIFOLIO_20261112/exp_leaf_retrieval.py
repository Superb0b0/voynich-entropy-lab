#!/usr/bin/env python3
"""Blind verso retrieval from a recto text using Jaccard, matched quire Currier illustration.
No trained parameters; post-hoc retrieval benchmark, independent folio pairs but same manuscript.
"""
from pathlib import Path
import re,csv,json
from collections import Counter
import numpy as np
F=Path(__file__).with_name('exp_next_token.py');ns={'__name__':'retrieval','__file__':str(F)}
exec(compile(F.read_text().split("for tr in ('zl','it'):")[0],str(F),'exec'),ns)
folios=ns['folios'];raw=(ns['INPUT']/'ZL3b-n.txt').read_text().splitlines();meta={}
for line in raw:
 m=re.match(r'^<([^>,.]+)>\s*<!',line)
 if m:meta[m[1]]=dict(re.findall(r'\$(\w+)=([^\s>]+)',line))
allf=set(folios)
res={};detail=[]
for tr in ['zl','it']:
 allcnt=Counter()
 counts={f:Counter(t for para in folios[f] for row in para for t in row[tr]) for f in folios}
 for c in counts.values():allcnt.update(c)
 for cut in [0,50]:
  stop={t for t,n in allcnt.most_common(cut)}
  sets={f:set(c)-stop for f,c in counts.items()}
  sample=[]
  for r in folios:
   m=re.fullmatch(r'f(\d+)r',r)
   if not m:continue
   v=f'f{m[1]}v'
   if v not in allf:continue
   group=[x for x in folios if x.endswith('v') and all(meta[r].get(k)==meta[x].get(k) for k in ['L','Q','I'])]
   if v not in group or len(group)<2:continue
   sr=sets[r]
   def jac(t):return len(sr&sets[t])/len(sr|sets[t]) if sr or sets[t] else 0
   scores={t:jac(t) for t in group};sc=scores[v]
   greater=sum(score>sc+1e-12 for score in scores.values())
   ties=sum(abs(score-sc)<=1e-12 for score in scores.values())
   rr=1.0/(greater+(ties+1)/2)
   topcredit=1.0/ties if greater==0 else 0
   sample.append({'folio':r,'verso':v,'choices':len(group),'greater':greater,'ties':ties,'rank_percentile':(greater+(ties+1)/2)/len(group),
                  'MRR':rr,'top_credit':topcredit,'chance':1/len(group), 'true_J':sc,'max_J':max(scores.values()), 'score_margin_vs_other_mean':sc-np.mean([sc0 for t,sc0 in scores.items() if t!=v])})
  # Uniform label permutation, draws score-compatible true assignments within candidate groups.
  M=9999;rng=np.random.default_rng(20261112+cut+(tr=='it'));null=np.zeros(M)
  for j in range(M):
   acc=0
   for s in sample:
    # with tied ranks under global null, random truth success probability 1/n
    acc+=float(rng.random()<1/s['choices'])
   null[j]=acc/len(sample)
  acc=float(np.mean([s['top_credit'] for s in sample]));baseline=float(np.mean([s['chance'] for s in sample]))
  # Fraction of true-verso scores higher than OTHER group mean, more stable with ties.
  win=float(np.mean([s['score_margin_vs_other_mean']>0 for s in sample]))
  B=4999;boot=np.zeros(B)
  for j in range(B):
   inds=rng.integers(0,len(sample),size=len(sample));boot[j]=np.mean([sample[t]['top_credit']-sample[t]['chance'] for t in inds])
  res.setdefault(str(cut),{})[tr]={'n_pairs':len(sample),'mean_alternatives':float(np.mean([s['choices'] for s in sample])),
      'top1_fractional':acc,'chance_mean':baseline,'top1_lift':acc/baseline,'p_top1_approx_null':float((1+sum(null>=acc))/(M+1)),
      'top1_minus_chance_bootstrap_CI95':[float(x) for x in np.quantile(boot,[.025,.975])],
      'mean_reciprocal_rank':float(np.mean([s['MRR'] for s in sample])),
      'mean_margin_vs_other_mean':float(np.mean([s['score_margin_vs_other_mean'] for s in sample])),
      'fraction_true_score_above_other_mean':win}
  if cut==50 and tr=='zl':detail=sample
payload={'status':'EXPLORATORY_POST_HOC_LEAF_RETRIEVAL','design':'Recto given; choose associated verso from same quire, Currier and illustration by maximum word-set Jaccard (ties receive fractional credit). No model trained; random rank baseline 1/N.','results':res,
 'cautions':['Same side manuscript (not independent transcription replication)','Manual selection of comparisons after hypothesis exploration.','Candidate sets of variable sizes; top1 null Bernoulli is approximate, not exact label-permutation conditional on mutual matching.']}
F.with_name('LEAF_RETRIEVAL_RESULTS.json').write_text(json.dumps(payload,indent=2))
with F.with_name('LEAF_RETRIEVAL_DETAILS.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(detail[0].keys()));w.writeheader();w.writerows(detail)
print(json.dumps(payload,indent=2))
