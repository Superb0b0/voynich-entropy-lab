# Voynich · EXP-FOLIO-LEAF-BIFOLIO-01

Leggere `RAPPORTO.md` per risultati, limiti, citazioni e percorso di riproduzione.

Il pacchetto include gli input ZL3b/IT2a e il parser RC1.2 in sola lettura; nessuna operazione sulla pipeline RC1.4.2 congelata.

**Stato: ricerca esplorativa, NON decifrazione e NON validazione indipendente.**
