#!/usr/bin/env python3
"""Preliminary extension: separate folio-level history from paragraph history.
The source setup/split/immutable SHA checks are reused from exp_next_token.py;
new hypotheses developed after the original run, exploratory, evaluated on SAME test folios.
"""
from pathlib import Path
import json,csv
import numpy as np
from collections import Counter
file=Path(__file__).with_name('exp_next_token.py')
source=file.read_text()
# Freeze existing data preparation, reuse original split, no rerun of costly original shuffles.
ns={'__name__':'context_scale','__file__':str(file)}
exec(compile(source[:source.index("for tr in ('zl','it'):")],str(file),'exec'),ns)
meta=ns['meta'];folios=ns['folios'];Gfunc=ns['global_prob'];base=ns['base'];validation=ns['validation'];test=ns['test'];seed=ns['seed'];ROOT=file.parent


def features(trans,fs,G):
    out=[]
    for f in fs:
        g=G[meta[f]]
        folio=Counter(); nf=0
        for para in folios[f]:
            par=Counter(); npast=0
            hist=[]
            for j,row in enumerate(para):
                tokens=row[trans]
                if j and tokens:
                    one=Counter(hist[-1]) if hist else Counter()
                    two=Counter(hist[-1]) if hist else Counter()
                    if len(hist)>1:two.update(hist[-2])
                    n1=sum(one.values());n2=sum(two.values())
                    for token in tokens:
                        out.append((f,g[token],folio[token]/nf if nf else 0,
                                    par[token]/npast if npast else 0,
                                    one[token]/n1 if n1 else 0,
                                    two[token]/n2 if n2 else 0))
                par.update(tokens);folio.update(tokens);npast+=len(tokens);nf+=len(tokens);hist.append(tokens)
    return out

def logp(x,weights):
    assert len(weights)==4
    wg=1-sum(weights)
    if wg<0:raise ValueError(weights)
    ss=wg*x[:,0]+x[:,1:]@np.asarray(weights)
    assert np.all(ss>0)
    return np.log(ss)

GRID=[0,.01,.02,.04,.06,.08,.10,.15,.20,.30,.40,.55]
M={
 'global':[[0,0,0,0]],
 'folio':[[f,0,0,0] for f in GRID],
 'paragraph':[[0,p,0,0] for p in GRID],
 'folio_plus_para':[[f,p,0,0] for f in GRID for p in GRID if f+p<=.9],
 'folio_plus_para_last1':[[f,p,r,0] for f in GRID for p in GRID for r in GRID if f+p+r<=.9],
 'folio_plus_para_last2':[[f,p,0,r] for f in GRID for p in GRID for r in GRID if f+p+r<=.9],
}
results={}
for trans in ['zl','it']:
    G,V=Gfunc(trans)
    val=features(trans,validation,G); te=features(trans,test,G)
    X=np.asarray([x[1:] for x in val]);Y=np.asarray([x[1:] for x in te]);ff=np.asarray([x[0] for x in te])
    models={}
    for k,options in M.items():
        best=(-np.inf,None)
        for w in options:
            m=float(logp(X,w).mean())
            if m>best[0]:best=(m,w)
        probs=logp(Y,best[1]);models[k]={'w':best[1],'validation_lp':best[0],'test_nll':float(-probs.mean()),'test_ppl':float(np.exp(-probs.mean()))}
    comparisons={}; test_fs=np.unique(ff)
    groups={f:np.nonzero(ff==f)[0] for f in test_fs}
    rng=np.random.default_rng(seed+123+(0 if trans=='zl' else 1))
    B=2999
    for left,right in [('folio','global'),('paragraph','global'),('folio_plus_para','folio'),('folio_plus_para','paragraph'),('folio_plus_para_last2','folio_plus_para'),('folio_plus_para_last1','folio_plus_para'),('folio_plus_para_last2','folio_plus_para_last1')]:
        d=logp(Y,models[left]['w'])-logp(Y,models[right]['w'])
        out=np.zeros(B)
        for j in range(B):
            sample=rng.choice(test_fs,len(test_fs),replace=True)
            ids=np.concatenate([groups[f] for f in sample]);out[j]=d[ids].mean()
        comparisons[left+' - '+right]={'gain_nats':float(d.mean()),'ci95':[float(t) for t in np.quantile(out,[.025,.975])],
                                      'percent_perplexity_gain':float((1-np.exp(-d.mean()))*100)}
    results[trans]={'n_val':len(X),'n_test':len(Y),'models':models,'comparisons':comparisons}

(ROOT/'CONTEXT_SCALE_RESULTS.json').write_text(json.dumps({'status':'EXPLORATORY_POST_HOC_EXTENSION',
'description':'Folio history vs paragraph history vs 1- and 2-line history on same folio-disjoint test split of previous experiment.',
'input_hashes':ns['HASH'],'seed':seed,'results':results},indent=2))
with (ROOT/'CONTEXT_SCALE_SUMMARY.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['transcription','model','weights_[folio,paragraph,last1,last2]','test_nll'])
    for trans,v in results.items():
        for name,m in v['models'].items():w.writerow([trans,name,str(m['w']),m['test_nll']])
print(json.dumps(results,indent=2))
