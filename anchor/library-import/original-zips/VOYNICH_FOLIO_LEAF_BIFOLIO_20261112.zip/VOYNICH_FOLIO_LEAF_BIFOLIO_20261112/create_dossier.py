from pathlib import Path
import json,hashlib, shutil, zipfile
import matplotlib.pyplot as plt
import numpy as np
D=Path(__file__).resolve().parent
raw=json.loads((D/'RESULTS.json').read_text())
ctx=json.loads((D/'CONTEXT_SCALE_RESULTS.json').read_text())['results']
arrow=json.loads((D/'TIME_ARROW_RESULTS.json').read_text())['results']
leaf=json.loads((D/'LEAF_COHERENCE_RESULTS.json').read_text())['results']
retr=json.loads((D/'LEAF_RETRIEVAL_RESULTS.json').read_text())['results']
leni=json.loads((D/'LEAF_RETRIEVAL_LENGTH_CONTROL.json').read_text())['results']
lenmat=json.loads((D/'LEAF_LENGTH_MATCHED_RESULTS.json').read_text())['results']
bif=json.loads((D/'BIFOLIO_RESULTS.json').read_text())['results']
strict=json.loads((D/'BIFOLIO_STRICT_RESULTS.json').read_text())['result']
rare=json.loads((D/'LEAF_RARE_RESULTS.json').read_text())['results']

# Charts (unadorned, descriptive, no statistical significance implied)
labels=['Solo paragrafo','Precedente sul folio','Folio + paragrafo','Folio + 2 righe']
keys=['paragraph','folio','folio_plus_para','folio_plus_para_last2']
z0=ctx['zl']['models']['global']['test_nll'];i0=ctx['it']['models']['global']['test_nll']
yz=[100*(1-np.exp(ctx['zl']['models'][k]['test_nll']-z0)) for k in keys]
yi=[100*(1-np.exp(ctx['it']['models'][k]['test_nll']-i0)) for k in keys]
fig,ax=plt.subplots(figsize=(10,5));yy=np.arange(len(labels));h=.34
ax.barh(yy-h/2,yz,h,label='ZL3b');ax.barh(yy+h/2,yi,h,label='IT2a')
ax.set_yticks(yy,labels);ax.set_xlabel('Riduzione della perplessità rispetto alle frequenze Currier (%)')
ax.set_title('Quale scala di memoria aiuta a prevedere le parole?')
ax.legend();ax.invert_yaxis();fig.tight_layout();fig.savefig(D/'context_perplexity.png',dpi=170);plt.close(fig)

fig,ax=plt.subplots(figsize=(10,5));x=np.arange(3)
for j,tr in enumerate(['zl','it']):
 vals=[leaf['L+Q+I'][tr]['observed_mean_jaccard'],bif['0']['Q+L'][tr]['actual_mean_J'],bif['0']['Q+L'][tr]['other_mean_J']]
 ax.bar(x+(j-.5)*.32,vals,.32,label=('ZL3b' if tr=='zl' else 'IT2a'))
ax.set_xticks(x,['R/V stesso foglio','Due fogli stesso bifoglio','Altri fogli stessa quire'])
ax.set_ylabel('Jaccard medio (campioni e gruppi differenti)')
ax.set_title('Similitudine lessicale a diverse scale fisiche')
ax.legend();fig.tight_layout();fig.savefig(D/'physical_structure.png',dpi=170);plt.close(fig)

# Self-contained text dataset sources, immutable copies.
original=(D/'inputs' if (D/'inputs').exists() else Path('/mnt/data/VOYNICH_SEQ_LINE_MEMORY_20261112/inputs'))
for name in ['ZL3b-n.txt','IT2a-n.txt','zl3b_P_ms408.tsv','ivtff_parser_rc1_2.py']:
    target=D/'inputs'/name;target.parent.mkdir(exist_ok=True)
    if original/name != target:shutil.copyfile(original/name,target)

report=f'''# Voynich · EXP-FOLIO-LEAF-BIFOLIO-01

**Data:** 12 novembre 2026. **Stato:** esplorativo / ipotesi sviluppate iterativamente, non preregistrato. **Non è una decifrazione.**

## La risposta che abbiamo ottenuto

Nel campione di trascrizioni ZL3b e IT2a, la distribuzione delle parole è associata alla **pagina fisica (folio-side)** in misura superiore alla sola memoria di paragrafo. La conoscenza delle parole che *seguiranno* su quella pagina fornisce un contributo comparabile a quello delle parole già lette: l'effetto è dunque più coerente con un campo lessicale di pagina che con una copia direzionale semplice. A scala materiale, recto e verso dello stesso foglio e le coppie di fogli assegnate allo stesso bifoglio sono spesso più simili dei controlli. I controlli di lunghezza e di adiacenza ridimensionano queste associazioni; non consentono di concludere che siano effetti puramente semantici o puramente fisici.

## Perimetro dei dati e audit

- Fonti locali **in sola lettura** ZL3b, IT2a, TSV P-only, parser RC1.2; SHA-256 negli input e in `SHA256SUMS.txt`.
- Riconciliazione: **4.118 loci P comuni**, confini di paragrafo spezzati se differiscono tra trascrizioni.
- Folii divisi con stratificazione Currier e seed `{raw['design']['seed']}`: {len(raw['folio_splits']['base'])} fonti del modello globale, {len(raw['folio_splits']['validation'])} di validazione, {len(raw['folio_splits']['test'])} di controllo; nessuna sovrapposizione.
- Target test: {ctx['zl']['n_test']} token ZL3b, {ctx['it']['n_test']} token IT2a. Vocabolario dei tipi noto *transduttivamente* sul corpus completo, ma le frequenze globali sono stimate esclusivamente sui folii base. Unigrammi Currier con smoothing additivo 0,10.
- `RC1.4.2` resta **CLOSED_PENDING_VALIDATION**; nessun builder, clustering, PCA o accoppiamento immagini/testo.

## 1. Previsione: frequenze globali, storia del paragrafo e storia del folio

La probabilità prevista per un token è la miscela di unigrammi globali **G**, distribuzione delle parole già osservate nell'intero folio **F**, nel paragrafo corrente **P**, e nella/e ultima/e riga/righe **R**. I pesi sono selezionati con una griglia finita sui soli folii di validazione e poi valutati sui folii di controllo. Il log score è **per token**; il guadagno è la diminuzione della cross-entropy in nat/token.

| Contrasto di modelli (miglioramento sul controllo) | ZL3b | IT2a |
|---|---:|---:|
| P vs G | +{ctx['zl']['comparisons']['paragraph - global']['gain_nats']:.5f} | +{ctx['it']['comparisons']['paragraph - global']['gain_nats']:.5f} |
| F vs G | +{ctx['zl']['comparisons']['folio - global']['gain_nats']:.5f} | +{ctx['it']['comparisons']['folio - global']['gain_nats']:.5f} |
| F+P vs F | +{ctx['zl']['comparisons']['folio_plus_para - folio']['gain_nats']:.5f} | +{ctx['it']['comparisons']['folio_plus_para - folio']['gain_nats']:.5f} |
| F+P+R₂ vs F+P | +{ctx['zl']['comparisons']['folio_plus_para_last2 - folio_plus_para']['gain_nats']:.5f} | +{ctx['it']['comparisons']['folio_plus_para_last2 - folio_plus_para']['gain_nats']:.5f} |

La memoria di pagina riduce la perplessità **3,32%** (ZL3b) e **3,63%** (IT2a) rispetto alle frequenze generali. L'aggiunta della memoria di paragrafo dopo F non produce intervalli bootstrap per folio interamente positivi. Un piccolo contributo delle due ultime righe compare nel modello esteso dopo selezione dei parametri, ma è stato esaminato *post hoc* sullo stesso test set; non è una verifica indipendente.

![Confronto modelli](context_perplexity.png)

### La direzione del tempo: un controllo negativo

Nei {arrow['zl']['n_test_tokens_interior']} token ZL3b ({arrow['it']['n_test_tokens_interior']} IT2a) con un contesto precedente e successivo, mantenendo fisso il peso del modello F, il log-score guadagna:

| Sorgente di vocabolario (vs G) | ZL3b | IT2a |
|---|---:|---:|
| Precedente nello stesso folio | +0,03277 | +0,03627 |
| **Successivo nello stesso folio** (oracolo, non predittore) | **+0,03861** | **+0,04310** |
| Folio diverso, stessa varietà Currier | −0,01382 | −0,02390 |

La differenza **passato meno futuro** è negativa in media, con intervalli bootstrap per folio comprendenti zero. Il folio alternativo, viceversa, peggiora la previsione. Conclusione: forte coerenza lessicale specifica di pagina, senza prova di causa sequenziale da passato a futuro. L'uso del vocabolario futuro serve *solo* a diagnosticare questa simmetria e non costituisce un metodo di previsione in tempo reale.

## 2. Recto e verso del medesimo foglio

Sono disponibili **79 coppie recto/verso** con alternative della stessa quire, lingua Currier e tipo illustrativo. Il Jaccard medio del recto con il suo verso è **0,11837 contro 0,10473** (ZL3b); **0,12137 contro 0,10932** (IT2a). L'eccesso compare anche con un candidato di lunghezza simile: con vincolo |ln(token_alt/token_verso)| ≤ 0,20, gli eccessi sono +{lenmat['0.2']['zl']['delta']:.5f} ZL3b su {lenmat['0.2']['zl']['n']} coppie e +{lenmat['0.2']['it']['delta']:.5f} IT2a su {lenmat['0.2']['it']['n']} coppie.

Nei **49** casi in cui possiamo confrontare tre pagine consecutive dello stesso ambito (`fNr`→`fNv` e `fNv`→`f(N+1)r`), il vantaggio del passaggio **entro lo stesso foglio** è +0,00952 (ZL3b) e +0,01144 (IT2a), con significatività esplorativa modesta (test sign-flip appaiato p circa 0,032 e 0,011). Dopo aver tolto le 50 forme più frequenti l'associazione rimane visibile, ma questi test sono stati scelti dopo osservazioni precedenti: non aggiungere p-value come fossero prove indipendenti.

### Identificazione mascherata del verso: controllo sulla lunghezza

Dato un recto e soltanto i versi compatibili per quire/Currier/illustrazione, Jaccard identifica il vero verso come primo **{retr['0']['zl']['top1_fractional']*100:.1f}% ZL3b** e **{retr['0']['it']['top1_fractional']*100:.1f}% IT2a** delle volte (credito frazionale ai pari merito) contro un caso **18,7%**. Tuttavia, il modello che sceglie solo la pagina con il numero più simile di token ottiene **{leni['zl']['top1_fractional_by_model']['token_count_similarity']*100:.1f}%** e **{leni['it']['top1_fractional_by_model']['token_count_similarity']*100:.1f}%**, rispettivamente. Il confronto lessicale, preso come compito di *top-1*, **non dimostra un guadagno affidabile sulla geometria della pagina**: in IT2a il semplice conteggio dei token è perfino superiore.

Il compito maschera artificialmente l'identità ma non la metadata: i folii nel manoscritto sono ovviamente numerati, quindi non è un sistema pratico per ricostruire l'ordine. È un test di contenuto relativo ai gruppi compatibili.

## 3. Bifogli: coppie di fogli legati dal medesimo supporto

La metadata `$Q` (quire) e `$B` (bifolio) nel corpus IVTFF permettono di identificare **39** coppie con due fogli presenti integralmente, **36** valutabili entro le quire con controlli compatibili. Ogni foglio è rappresentato dal testo combinato di recto e verso.

| Media Jaccard fra fogli di medesimo bifoglio vs altri fogli della stessa quire/Currier | ZL3b | IT2a |
|---|---:|---:|
| Stesso bifoglio | {bif['0']['Q+L']['zl']['actual_mean_J']:.5f} | {bif['0']['Q+L']['it']['actual_mean_J']:.5f} |
| Controlli | {bif['0']['Q+L']['zl']['other_mean_J']:.5f} | {bif['0']['Q+L']['it']['other_mean_J']:.5f} |
| Eccesso | +{bif['0']['Q+L']['zl']['delta']:.5f} | +{bif['0']['Q+L']['it']['delta']:.5f} |

Il confronto ampio è positivo in entrambe le trascrizioni e dopo aver rimosso le 50 parole più frequenti. Nel controllo più selettivo (solo bifogli non adiacenti vs foglio **vicino ma non membro del bifoglio**), restano **23 unità materiali indipendenti** e la differenza positiva non dà intervalli bootstrap che escludano zero: p=0,0437 ZL3b e 0,0682 IT2a prima dell'esclusione delle 50 forme; dopo l'esclusione p=0,1574 e 0,1175. Non è prova robusta di una proprietà fisica distinta dalla vicinanza testuale.

![Struttura fisica](physical_structure.png)

## Cosa vale la pena sostenere

- **Associazione della distribuzione delle parole con la pagina**, robusta fra due trascrizioni dello stesso manoscritto in questo benchmark. Il modello che usa l'intera storia del folio prevede i token meglio di quello che usa solo la storia del paragrafo.
- **Mancanza di una freccia temporale dimostrata:** la distribuzione delle parole nelle pagine future del medesimo folio funziona altrettanto bene, quindi “memoria” è un'etichetta matematica, non una prova di copiatura causale.
- **Segnali fra due facciate e bifogli:** positivi contro controlli di quire, ma parzialmente spiegabili da geometria, contiguità e lunghezza; non si inferisce per questo un argomento, una lingua o una legatura originale.

## Limiti metodologici inderogabili

1. Tutti i test sono **esplorativi** e varie ipotesi sono state proposte *dopo* osservazioni su dati già esaminati. Lo stesso test set è stato riutilizzato per estensioni. Gli intervalli statistici descrivono la variabilità nel campione osservato, non sostituiscono un nuovo test veramente cieco.
2. ZL3b e IT2a sono due letture dello stesso manoscritto e non due corpus indipendenti. L'accordo riduce la dipendenza dalla trascrizione, non raddoppia il supporto statistico.
3. Il vocabolario globale è conosciuto trasduttivamente; le frequenze sono stimate solo sulle pagine base. Il modello probabilistico non impone la grammatica delle parole né genera un testo Voynich completo.
4. I metadati quire, bifolio e tipo illustrativo sono **informazioni preesistenti** del corpus, non inferenze nuove dall'immagine originale. Non abbiamo aperto la pipeline visivo-testuale congelata.
5. Nessuno di questi esperimenti fornisce una traduzione, una chiave o identifica il meccanismo storico.

## Letteratura, precedenti non trascurabili

- S. Reddy e K. Knight, *What We Know About The Voynich Manuscript* (2011): analisi delle parole-tema di pagina e somiglianza fra pagine adiacenti. https://aclanthology.org/W11-1511/
- Tobias Franke, *A Generative Folio Grammar of the Voynich Manuscript* (14 ottobre 2026): modello con campo lessicale di folio e confronto fra ZL3b e IT2a; risultati già analoghi sull'utilità predittiva del campo di pagina. https://celler-presse.de/forschung/dokument/a-generative-folio-grammar-of-the-voynich-manuscript/
- Colin Layfield e Lisa Fagin Davis, *Singulion Structure and the Voynich Manuscript* (2026): test sulla struttura materiale e sui bifogli. https://doi.org/10.4000/16k0a

I nostri test non vanno presentati come scoperta originale della dipendenza di folio, già documentata. La distinzione empirica **passato/futuro/altro folio** e i controlli lessicali/di lunghezza/retrieval/bifolio qui riportati sono estensioni esplorative con queste specifiche misure, non una verifica di novità nella letteratura completa.

## Esecuzione

Richiede Python 3.11+, NumPy e Matplotlib per i grafici. Eseguire nell'ordine:

```bash
python exp_next_token.py
python exp_context_scale.py
python exp_time_arrow.py
python exp_leaf_coherence.py
python exp_leaf_adjacency.py
python exp_leaf_rare.py
python exp_leaf_retrieval.py
python exp_leaf_retrieval_lengths.py
python exp_leaf_length_matched.py
python exp_bifolium.py
python exp_bifolium_strict.py
python create_dossier.py
```

Il codice utilizza per scelta la stessa separazione di folii nelle estensioni, e non deve essere scambiato per un test preregistrato. Tutti i file utilizzati sono inclusi e controllati con SHA-256.
'''
(D/'RAPPORTO.md').write_text(report)
(D/'README.md').write_text('''# Voynich · EXP-FOLIO-LEAF-BIFOLIO-01\n\nLeggere `RAPPORTO.md` per risultati, limiti, citazioni e percorso di riproduzione.\n\nIl pacchetto include gli input ZL3b/IT2a e il parser RC1.2 in sola lettura; nessuna operazione sulla pipeline RC1.4.2 congelata.\n\n**Stato: ricerca esplorativa, NON decifrazione e NON validazione indipendente.**\n''')
(D/'requirements.txt').write_text('numpy>=1.24\nmatplotlib>=3.7\n')
# Manifest is computed on all files except itself, create_dossier writes to directory only.
files=[p for p in D.rglob('*') if p.is_file() and p.name not in ('SHA256SUMS.txt',) and '__pycache__' not in str(p) and not p.name.endswith('.pyc')]
lines=[]
for file in sorted(files):
    dig=hashlib.sha256(file.read_bytes()).hexdigest();lines.append(f'{dig}  {file.relative_to(D)}')
(D/'SHA256SUMS.txt').write_text('\n'.join(lines)+'\n')
archive=D.parent/'VOYNICH_FOLIO_LEAF_BIFOLIO_20261112.zip'
files.append(D/'SHA256SUMS.txt')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for file in sorted(files):z.write(file,arcname='VOYNICH_FOLIO_LEAF_BIFOLIO_20261112/'+str(file.relative_to(D)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print('READY',archive,'ZIP bytes',archive.stat().st_size,'included files',len(files),'REPORT bytes',(D/'RAPPORTO.md').stat().st_size)
