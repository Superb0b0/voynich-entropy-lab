#!/usr/bin/env python3
"""Does page length and type count alone explain masked verso retrieval?"""
from pathlib import Path
import re,json,csv
from collections import Counter
import numpy as np
F=Path(__file__).with_name('exp_next_token.py');ns={'__name__':'leaf_length','__file__':str(F)}
exec(compile(F.read_text().split("for tr in ('zl','it'):")[0],str(F),'exec'),ns)
folios=ns['folios'];header={}
for line in (ns['INPUT']/'ZL3b-n.txt').read_text().splitlines():
 m=re.match(r'^<([^>,.]+)>\s*<!',line)
 if m:header[m[1]]=dict(re.findall(r'\$(\w+)=([^\s>]+)',line))
report={}
for trans in ['zl','it']:
 counts={f:Counter(t for p in folios[f] for row in p for t in row[trans]) for f in folios}
 pairs=[]
 for r in folios:
  m=re.fullmatch(r'f(\d+)r',r)
  if not m:continue
  v=f'f{m[1]}v'
  if v not in folios:continue
  options=[x for x in folios if x.endswith('v') and all(header[r].get(k)==header[x].get(k) for k in ['L','Q','I'])]
  if v in options and len(options)>=2:pairs.append((r,v,options))
 models=['jaccard','token_count_similarity','type_count_similarity','length_5gram_signature','random']
 acc={m:0 for m in models};score_details=[]
 for r,v,opts in pairs:
  query=counts[r]
  def score(x,kind):
   y=counts[x]
   if kind=='jaccard':return len(query.keys()&y.keys())/(len(query.keys()|y.keys()) or 1)
   if kind=='token_count_similarity':return -abs(np.log((sum(query.values())+1)/(sum(y.values())+1)))
   if kind=='type_count_similarity':return -abs(np.log((len(query)+1)/(len(y)+1)))
   if kind=='length_5gram_signature':
    # Similarity between empirical word-length histograms, not actual vocabulary.
    ca=Counter(min(len(w),15) for w,n in query.items() for _ in range(n));cb=Counter(min(len(w),15) for w,n in y.items() for _ in range(n))
    na=sum(ca.values());nb=sum(cb.values())
    return -sum(abs(ca[k]/na-cb[k]/nb) for k in set(ca)|set(cb))
   return 0
  for model in models:
   s=[score(o,model) for o in opts];best=max(s);tied=[o for o,z in zip(opts,s) if abs(z-best)<1e-12]
   acc[model]+=1/len(tied) if v in tied else 0
 report[trans]={'n_pairs':len(pairs),'top1_fractional_by_model':{m:acc[m]/len(pairs) for m in models}}
P=F.with_name('LEAF_RETRIEVAL_LENGTH_CONTROL.json');P.write_text(json.dumps({'status':'EXPLORATORY','results':report,'warning':'Word length signature count is from text but not its lexical identities; posthoc null.'},indent=2))
print(json.dumps(report,indent=2))
