#!/usr/bin/env python3
"""Face f72v labels across 3 independent zodiac diagram panels. Structural ONLY."""
from pathlib import Path
import numpy as np, re, hashlib, json
ROOT=Path(__file__).resolve().parent
PINS={'ZL3b':'bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc','IT2a':'7f27a8b0feed8f6de0a99900df6bf912dd1d295c38e5f830bac8b41c3f536fb5'}
SIGNS=[('Leo','f72v3'),('Virgo','f72v2'),('Libra','f72v1')]
SEED=2026111207;B=20000

def data(src):
 p=ROOT/'inputs'/('ZL3b-n.txt' if src=='ZL3b' else 'IT2a-n.txt')
 assert hashlib.sha256(p.read_bytes()).hexdigest()==PINS[src]
 by={v:[] for _,v in SIGNS}
 for ln in p.read_text(encoding='utf-8').splitlines():
  m=re.match(r'^<([^>,]+),([@&]Lz)>\s*(.*)$',ln)
  if not m:continue
  page=m.group(1).split('.')[0]
  if page not in by:continue
  raw=re.sub(r'<!.*?>','',m.group(3)).lower()
  a=re.findall('[a-z]+',raw)
  if not a:raise RuntimeError('empty label '+m.group(1))
  by[page].append(a[0])
 assert all(len(by[p])==30 for _,p in SIGNS),{k:len(v) for k,v in by.items()}
 return [by[p] for _,p in SIGNS]

def calc(v):
 # v.shape = (2 halves, 3 signs, 15 labels, ngrams)
 A=v.sum(axis=2);A=A/np.maximum(np.linalg.norm(A,axis=2,keepdims=True),1e-15)
 M=A[0]@A[1].T
 return (np.trace(M)/3 - (M.sum()-np.trace(M))/6),M

def main():
 result={}
 for src in PINS:
  raw=data(src)
  grams=sorted(set(g for group in raw for w in group for n in (2,3) for i in range(len(w)-n+1) for g in (w[i:i+n],)))
  vocab={g:i for i,g in enumerate(grams)}
  V=np.zeros((2,3,15,len(vocab)),dtype=np.float32)
  for i,rows in enumerate(raw):
   for j,w in enumerate(rows):
    for n in (2,3):
     for k in range(len(w)-n+1):V[j//15,i,j%15,vocab[w[k:k+n]]]+=1.
  obs,M=calc(V)
  rng=np.random.default_rng(SEED)
  fine=np.empty(B);block=np.empty(B)
  F=V.reshape(2,45,len(vocab));K=V.reshape(2,9,5,len(vocab)).sum(axis=2)
  for b in range(B):
   a=np.stack([F[hh,rng.permutation(45)].reshape(3,15,-1) for hh in (0,1)])
   fine[b],_=calc(a)
   c=np.stack([K[hh,rng.permutation(9)].reshape(3,3,-1).sum(axis=1) for hh in (0,1)])
   # mimic dimension expected by calc; treat 3 blocks as 3 labels for group histogram
   block[b],_=calc(c.reshape(2,3,1,-1))
  result[src]={'n_labels':90,'source_sha256':PINS[src],'feature_dim':len(vocab),'matched_vs_mismatched_cosine_difference':float(obs),'matrix_3x3':M.tolist(),'nulls':{
   'fine_label_shuffle':{'B':B,'mean':float(fine.mean()),'sd':float(fine.std()),'one_sided_p':float((1+np.count_nonzero(fine>=obs-1.e-10))/(B+1)),'null_q95':float(np.quantile(fine,0.95))},
   'five_label_block_shuffle':{'B':B,'mean':float(block.mean()),'sd':float(block.std()),'one_sided_p':float((1+np.count_nonzero(block>=obs-1.e-10))/(B+1)),'null_q95':float(np.quantile(block,0.95))}
  }}
 out={'experiment':'ANCHOR-07','status':'EXPLORATORY_NOT_SEMANTIC','side':'f72v','signs':[x[0] for x in SIGNS],'seed':SEED,'protocol_sha256':hashlib.sha256((ROOT/'PROTOCOL_LOCAL_PRETEST.md').read_bytes()).hexdigest(),'results':result,'caveat':'Panel identity cannot be separated from sign semantics on a single folio face; no decipherment'}
 (ROOT/'result.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:{'observed':v['matched_vs_mismatched_cosine_difference'],'fine_p':v['nulls']['fine_label_shuffle']['one_sided_p'],'block5_p':v['nulls']['five_label_block_shuffle']['one_sided_p']} for k,v in result.items()},indent=2))
if __name__=='__main__':main()
