ANCHOR-07 | Restricted within-page zodiac panel grouping
Date 2026-11-12. Exploratory. Written before ANCHOR-07 results. This experiment comes after seeing the positive ANCHOR-06 and its f72v 3! face-level sensitivity. No strict blind status.

Question: If all 90 labels from three 30-label zodiac panels sharing one physical face f72v (Leo=f72v3, Virgo=f72v2, Libra=f72v1) are considered, is the morphology of the two 15-label halves of the *same diagram* more similar than that of different diagrams? Does the result survive nulls preserving local five-label lexical dependencies?

Data: exact Lz loci from ZL3b-n.txt (sha256 bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc). Transcription sensitivity: IT2a-n.txt (sha256 7f27a8b0feed8f6de0a99900df6bf912dd1d295c38e5f830bac8b41c3f536fb5). Use first ASCII alphabetical group for each label, same feature as ANCHOR-06: pooled overlapping 2+3 character gram histogram, L2-normalize half-group vector, cosine similarity. Primary statistic: average 3 matched cosines minus average 6 mismatched cosines, within the same face. Exact loci order; no per-panel orientation correction.

Fixed nulls, each 20,000 permutations seeded 2026111207:
FINE: shuffle 45 individual labels within first 15-position halves of the three diagrams, separately shuffle the corresponding 45 labels of the second halves; repartition each to three groups of 15.
BLOCK: preserve each run of 5 consecutive labels within its original half (9 blocks per half), shuffle all 9 blocks per half and repartition into three groups of 3 blocks (15 labels), independently between halves. This retains five-label local morphology. No shuffle between first and second half (page position preserved).
P upper-tail with plus one, no hyperparameter tuning. Need both nulls under 0.01 *and* transcription sensitivity for any structural claim; even so cannot infer zodiac sign meanings because labels and panels co-vary, and the face-level source has 3 diagrams only. The test does not certify graphical mapping to nymphs.
