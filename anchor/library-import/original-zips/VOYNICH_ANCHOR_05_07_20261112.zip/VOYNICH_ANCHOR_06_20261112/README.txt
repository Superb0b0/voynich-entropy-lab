VOYNICH | ANCHOR-05/06 | 2026-11-12

Exploratory text-only controls. NO SEMANTIC DECIPHERMENT.

Reproduce with Python 3 (standard library only):
  python run_anchor05.py
  python run_anchor06.py
  python run_it2a.py
  python page_control.py

Inputs in inputs/: ZL3b-n.txt, IT2a-n.txt, slot_inventory.csv.
Both transcription bytes are SHA-256 pinned in methods and the script.
Result files contain the complete exact 7!/9! permutation calculations.
This report and its package are distinct from the frozen RC1.4.2 pipeline.

CAUTION: the first seven signs were encountered in previous tests. No independent blind or external preregistration. Same page effects and local writing style cannot be removed by the current design. The manuscript is NOT decoded.
