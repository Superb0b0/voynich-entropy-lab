#!/usr/bin/env python3
"""Exploratory same-sign half lexical structure, purely textual.
No interpretation of manuscript text. See PROTOCOL_LOCAL_PRETEST.md
"""
import csv, hashlib, itertools, collections, json, math, re
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PIN='bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc'
CORPUS=ROOT/'inputs'/'ZL3b-n.txt'
SIGNS={'Pisces':('f70v2',),'Aries':('f70v1','f71r'),'Taurus':('f71v','f72r1'),'Cancer':('f72r3',),'Leo':('f72v3',),'Virgo':('f72v2',),'Libra':('f72v1',),'Scorpio':('f73r',),'Sagittarius':('f73v',)}

def load_corpus(path):
    assert hashlib.sha256(path.read_bytes()).hexdigest()==PIN, 'SHA256 mismatch'
    pages=collections.defaultdict(list)
    for line in path.read_text(encoding='utf-8').splitlines():
        m=re.match(r'^<([^>,]+),([@&]Lz)>\s*(.*)$',line)
        if not m: continue
        loc=m.group(1);page=loc.split('.')[0]
        raw=re.sub(r'<!.*?>','',m.group(3)).strip().lower()
        chunks=re.findall('[a-z]+',raw)
        if not chunks:raise ValueError(f'Empty Lz {loc}')
        pages[page].append({'loc':loc,'first':chunks[0],'raw':raw})
    words={k:[s for p in parts for s in pages[p]] for k,parts in SIGNS.items()}
    assert all(len(rows)==30 for rows in words.values()),{k:len(v) for k,v in words.items()}
    return words

def grams(w):
    return [w[i:i+n] for n in (2,3) for i in range(len(w)-n+1)]

def vector(rows):
    c=collections.Counter(g for row in rows for g in grams(row['first']))
    norm=math.sqrt(sum(v*v for v in c.values()))
    return {k:v/norm for k,v in c.items()} if norm else {}

def cos(x,y):
    if len(x)>len(y):x,y=y,x
    return sum(v*y.get(k,0) for k,v in x.items())

def analyze(signs, words):
    A=[vector(words[name][:15]) for name in signs]
    B=[vector(words[name][15:]) for name in signs]
    M=[[cos(a,b) for b in B] for a in A]
    n=len(signs);diag=sum(M[i][i] for i in range(n))/n
    off=sum(M[i][j] for i in range(n) for j in range(n) if i!=j)/(n*(n-1))
    obs_sum=n*diag
    # all n! permutations, feasible n<=9
    upper=0;total=0;total_sum=0.; total_sq=0.
    for perm in itertools.permutations(range(n)):
        val=sum(M[i][perm[i]] for i in range(n))
        total+=1;upper+=val>=obs_sum-1.e-12; total_sum+=val;total_sq+=val*val
    mu=total_sum/total;sd=math.sqrt(max(0.,total_sq/total-mu*mu))
    top1=sum(M[i][i]>=max(M[i])-1.e-12 for i in range(n))
    margins={signs[i]:round(M[i][i]-sum(M[i][j] for j in range(n) if j!=i)/(n-1),8) for i in range(n)}
    return dict(n_signs=n,signs=signs,n_labels=n*30,n_exact_permutations=total,mean_matched_cosine=diag,mean_unmatched_cosine=off,difference=diag-off,observed_diagonal_sum=obs_sum,null_sum_mean=mu,null_sum_sd=sd,z=(obs_sum-mu)/sd if sd else None,one_sided_exact_p=upper/total,top1_count=top1,top1_total=n,top1_fraction=top1/n,per_sign_margin=margins,similarity_matrix=M)

def main():
    words=load_corpus(CORPUS)
    result={'study':'ANCHOR-06 sign-specific half-label structure','status':'EXPLORATORY_NOT_SEMANTIC','corpus_sha256':PIN,'protocol_sha256':hashlib.sha256((ROOT/'PROTOCOL_LOCAL_PRETEST.md').read_bytes()).hexdigest(),'input':'inputs/ZL3b-n.txt','primary':analyze(list(SIGNS)[:7],words),'challenge_plus_holdouts':analyze(list(SIGNS),words),'notes':['Unannotated IVTFF order, not independently validated geometry','Within-sign same-folio for 5 of 7 signs; page effect cannot be ruled out','Aries and Taurus split cross-folio','A positive value is not proof of sign meanings, no translation','Not a genuinely blind holdout or external preregistration']}
    (ROOT/'result.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    with (ROOT/'similarity_matrix_9.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['half1/half2']+list(SIGNS));
        for name,row in zip(SIGNS,result['challenge_plus_holdouts']['similarity_matrix']):w.writerow([name]+row)
    with (ROOT/'input_inventory.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['sign','half','label_pos','locus','first','raw'])
        for name,rows in words.items():
            for i,r in enumerate(rows):w.writerow([name,1 if i<15 else 2,i+1,r['loc'],r['first'],r['raw']])
    print(json.dumps({s:{k:v for k,v in result[s].items() if k!='similarity_matrix'} for s in ('primary','challenge_plus_holdouts')},indent=2))
if __name__=='__main__':main()
