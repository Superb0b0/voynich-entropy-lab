import csv,random,statistics,json,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent/'inputs'/'slot_inventory.csv'
rows=list(csv.DictReader(p.open()))
by={}
for r in rows:by.setdefault(r['sign'],[]).append(r)
assert len(by)==7 and all(len(x)==30 for x in by.values())
def sim(a,b):
 a,b=a['first'],b['first'];return int(len(a)>=2 and len(b)>=2 and a[:2]==b[:2])
def stat(groups):
 # adjacent within 15-label half, vs all within half: statistic direct adjacency probability
 pairs=[]
 for x in groups.values():
  for st in (0,15):
   h=x[st:st+15];pairs.extend(sim(h[i],h[i+1]) for i in range(14))
 return sum(pairs)/len(pairs)
obs=stat(by)
rng=random.Random(2026111206); B=20000;null=[]
for _ in range(B):
 z={}
 for name,x in by.items():
  h1=x[:15].copy();h2=x[15:].copy();rng.shuffle(h1);rng.shuffle(h2);z[name]=h1+h2
 null.append(stat(z))
pvalue=(1+sum(v>=obs for v in null))/(B+1)
out={'name':'ANCHOR-05 adjacent prefix within zodiac half','source':'ANCHOR-04 slot_inventory.csv','source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'hypothesis':'adjacent labels share first 2 EVA characters more often than shuffled within half of sign','n_signs':7,'n_labels':210,'n_adjacent_pairs':196,'observed':obs,'null_mean':statistics.mean(null),'null_sd':statistics.pstdev(null),'p_one_sided':pvalue,'B':B,'seed':2026111206,'exploratory':True,'no_semantic_claim':True}
(Path(__file__).resolve().parent/'anchor05_result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
