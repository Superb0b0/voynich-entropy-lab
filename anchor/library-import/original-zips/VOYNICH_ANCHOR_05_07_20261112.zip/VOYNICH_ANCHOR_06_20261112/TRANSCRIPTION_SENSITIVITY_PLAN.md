# ANCHOR-06 sensitivity to independent EVA transcription: plan
2026-11-12. Written before calculating IT2a results, after seeing ZL3b result.

The original exploratory effect used ZL3b. Rerun *identical* 2-3gram features, half assignment, exact permutation test and 9-sign sign definitions on IT2a (Takahashi), pinned SHA-256 7f27a8b0feed8f6de0a99900df6bf912dd1d295c38e5f830bac8b41c3f536fb5. Use no tuning, same parsing regex; note locus set and number of changed first groups. Report 7-sign and 9-sign p, mean diagonal vs off-diagonal and sign-specific margins. This is transcription robustness, not independent semantic validation because both are transcriptions of same manuscript.
