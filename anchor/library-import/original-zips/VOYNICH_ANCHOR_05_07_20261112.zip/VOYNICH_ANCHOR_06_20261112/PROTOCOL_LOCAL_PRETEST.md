# ANCHOR-06 | Same-sign half-label specificity (local pretest)
Date: 2026-11-12. Exploratory. Written before reading ANCHOR-06 results.

Question: Do the first 15 and second 15 zodiac labels of a sign share *character n-gram composition* beyond what would be obtained by arbitrarily pairing halves from different zodiac signs?

Input: original ZL3b-n.txt, pinned SHA256 bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc. Parse only @Lz and &Lz loci; remove IVTFF inline comments <!...>; lowercase; use first contiguous ASCII [a-z]+ group (no semantic inference). List order: Pisces=f70v2; Aries=f70v1+f71r; Taurus=f71v+f72r1; Cancer=f72r3; Leo=f72v3; Virgo=f72v2; Libra=f72v1; reserved Scorpio=f73r and Sagittarius=f73v. Each has 30 labels, first 15 and second 15 according to literal IVTFF order. Label-to-nymph relation not assumed.

Locked feature: histogram of all overlapping character bigrams and trigrams of the first label group, pooling counts across 15 labels; normalize each half vector with L2; dot product = cosine similarity. No IDF, hyperparameters, vocabulary filtering, feature cherry picking, label-weighting or post-hoc rotations.

Primary statistic: mean diagonal pair cosine minus mean off-diagonal pair cosine among seven initial signs (matrix 7x7). Exact one-sided null: all 7! permutations of second-half assignment, same first halves; p proportion of permutations with diagonal sum >= observed, with tolerance 1e-12 (no +1 necessary for exact test).

Descriptive: top-1 fraction by nearest half2 for each half1, no separate inferential testing, report raw and randomized expectation. Secondary challenge: 9-sign exact 9! test with Scorpio & Sagittarius added using identical fixed feature and protocol; report sign-specific margins for the two additional signs separately. This is not a strictly untouched sample, previous work inspected other zodiac sign data.

Sensitivity control specified ex ante: *cross-folio pair subset* Aries and Taurus vs all signs, report cosine within vs across other signs, descriptive only. A positive full-sign result may merely reflect page-specific handwriting/text-generation or local register, NOT names/sign semantics; splits for five signs are on the same page, while Aries and Taurus are cross folio.

Any positive p below 0.01 remains structural/exploratory, not a decipherment. No change to frozen RC1.4.2, no claims about plaintext. No access to excluded holdout labels before the protocol is saved.
