#!/usr/bin/env python3
"""Additional post-hoc page/adjacency controls (NOT PRE-REGISTERED)."""
from pathlib import Path
import json,itertools
root=Path(__file__).resolve().parent
result={}
for source,fn in [('ZL3b','result.json'),('IT2a','it2a_result.json')]:
    v=json.loads((root/fn).read_text())['challenge_plus_holdouts']; M=v['similarity_matrix']; S=v['signs'];n=len(S)
    neighbor_deltas={}
    for i,name in enumerate(S):
        indices=[j for j in (i-1,i+1) if 0<=j<n]
        neighbor_deltas[name]=M[i][i]-sum(M[i][j] for j in indices)/len(indices)
    # Three signs on same f72v side: Leo = f72v3, Virgo=f72v2, Libra=f72v1.
    idx=[S.index(s) for s in ['Leo','Virgo','Libra']]
    X=[[M[i][j] for j in idx] for i in idx]
    all_scores=[sum(X[i][pi[i]] for i in range(3)) for pi in itertools.permutations(range(3))]
    observed=all_scores[0]
    result[source]={
        'order_used':S,
        'neighbor_half_similarity_advantage':neighbor_deltas,
        'neighbor_positives':sum(x>0 for x in neighbor_deltas.values()),
        'mean_neighbor_advantage':sum(neighbor_deltas.values())/len(neighbor_deltas),
        'same_folio_side_three_signs':{'face':'f72v','signs':['Leo','Virgo','Libra'],'observed_sum':observed,'permutation_sums':all_scores,'exact_upper_p':sum(z>=observed-1e-12 for z in all_scores)/len(all_scores)},
        'cautions':['Local controls are POST-HOC and exploratory','Adjacent zodiac order skips Gemini; not exact geometrical distance','One 3-sign face yields only six permutations, low power','These sign labels are not independently tied to visual targets']}
(root/'page_control_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:{'adjacent_positives':v['neighbor_positives'],'adjacent_mean_advantage':v['mean_neighbor_advantage'],'f72v_3_sign_p':v['same_folio_side_three_signs']['exact_upper_p']} for k,v in result.items()},indent=2))
