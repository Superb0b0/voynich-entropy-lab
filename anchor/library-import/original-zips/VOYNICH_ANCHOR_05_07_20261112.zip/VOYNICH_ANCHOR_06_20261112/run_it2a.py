from pathlib import Path
import hashlib,importlib.util,json
root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('a06',root/'run_anchor06.py')
a06=importlib.util.module_from_spec(spec); spec.loader.exec_module(a06)
a06.PIN='7f27a8b0feed8f6de0a99900df6bf912dd1d295c38e5f830bac8b41c3f536fb5'
it=root/'inputs'/'IT2a-n.txt'
assert hashlib.sha256(it.read_bytes()).hexdigest()==a06.PIN
w_it=a06.load_corpus(it)
r={'study':'ANCHOR-06 IT2a transcription robustness','status':'EXPLORATORY_TRANSCRIPTION_SENSITIVITY','source_sha256':a06.PIN,'protocol_sha256':hashlib.sha256((root/'TRANSCRIPTION_SENSITIVITY_PLAN.md').read_bytes()).hexdigest(),'primary':a06.analyze(list(a06.SIGNS)[:7],w_it),'challenge_plus_holdouts':a06.analyze(list(a06.SIGNS),w_it)}
(root/'it2a_result.json').write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
# Cross-transcription first-label agreement by exact IVTFF locus
# mod.PIN changed, temporarily restore for original
pin_it=a06.PIN;a06.PIN='bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc'
w_z=a06.load_corpus(root/'inputs'/'ZL3b-n.txt');a06.PIN=pin_it
pairs=[(r['loc'],r['first'],d['first']) for name in a06.SIGNS for r,d in zip(w_z[name],w_it[name])]
assert all([a['loc'] for a in w_z[name]]==[b['loc'] for b in w_it[name]] for name in a06.SIGNS)
rep={'n_labels':len(pairs),'n_identical':sum(z==it for _,z,it in pairs),'different_first_groups':[(loc,z,it) for loc,z,it in pairs if z!=it]}
(root/'first_groups_comparison.json').write_text(json.dumps(rep,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'ZL3b_vs_IT2a':{'n_labels':rep['n_labels'],'n_identical':rep['n_identical'],'n_different':len(rep['different_first_groups'])},'IT2a_primary':{k:v for k,v in r['primary'].items() if k in ('mean_matched_cosine','mean_unmatched_cosine','difference','one_sided_exact_p','top1_count')},'IT2a_all':{k:v for k,v in r['challenge_plus_holdouts'].items() if k in ('mean_matched_cosine','mean_unmatched_cosine','difference','one_sided_exact_p','top1_count')}},indent=2))
