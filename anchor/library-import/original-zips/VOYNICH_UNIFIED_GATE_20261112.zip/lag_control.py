#!/usr/bin/env python3
"""Post-hoc matched lag control for edit1 neighbor mechanism.
Score same tokens with edit1 context from prior rows [1,2], [3,4], [5,6].
Uses fixed validation-selected model weight from edit1_results.json; no retuning.
"""
from pathlib import Path
from collections import Counter
import numpy as np,json
ROOT=Path(__file__).resolve().parent
script=ROOT/'edit_neighborhood.py'; ns={'__file__':str(script),'__name__':'load_functions_only'}
txt=script.read_text();exec(compile(txt[:txt.index('out={')],str(script),'exec'),ns)
folios,meta,test=ns['folios'],ns['meta'],ns['test'];Gfunc=ns['Gfunc'];idx=ns['index_vocab'];score=ns['score']
W=json.loads((ROOT/'edit1_results.json').read_text())

def lagged(t,fs,G,neighbors,lag):
    out=[];ids=[]
    for f in fs:
        g=G[meta[f]];gy=sum(v for w,v in g.items() if w.startswith('y'))
        fol=Counter();nf=0
        for par in folios[f]:
            hist=[]
            for row in par:
                words=row[t]
                if len(hist)>=6 and words:
                    ctx=hist[-(lag+1):-(lag-1)] if lag>1 else hist[-2:]
                    # lag = 1 -> hist[-2:], lag = 3 -> hist[-4:-2], lag=5 -> hist[-6:-4]
                    R=Counter(w for line in ctx for w in line);nr=sum(R.values())
                    Q=Counter();valid=0
                    for w,c in R.items():
                        near=neighbors.get(w,())
                        if not near:continue
                        valid+=c
                        for nw in near:Q[nw]+=c/len(near)
                    if valid:
                        for w in Q:Q[w]/=valid
                    fy=sum(c for w,c in fol.items() if w.startswith('y'))/nf if nf else 0
                    ry=sum(c for w,c in R.items() if w.startswith('y'))/nr if nr else 0
                    qy=sum(v for w,v in Q.items() if w.startswith('y'))
                    for col,w in enumerate(words):
                        out.append([g[w],fol[w]/nf if nf else 0,R[w]/nr if nr else 0,Q[w],gy,fy,ry,qy,float(col==0),float(w.startswith('y'))]);ids.append(f)
                fol.update(words);nf+=len(words);hist.append(words)
    return np.asarray(out,float),np.asarray(ids,dtype=object)

output={'status':'EXPLORATORY_POSTHOC','design':'Matched-token heldout rows j>=7, no model refit; compare edit1 sources from preceding 1-2, 3-4, 5-6 lines within same paragraph','results':{}}
for t in ['zl','it']:
    G,vocab=Gfunc(t);neighbors=idx(set(next(iter(G.values()))))
    weights=W['models'][t]['fits']['folio_plus_edit1']['params_folio_exact_edit_beta']
    measured={};fs0=None
    for lag in [1,3,5]:
        x,fs=lagged(t,test,G,neighbors,lag)
        if fs0 is None:fs0=fs
        assert list(fs)==list(fs0)
        measured[lag]=score(x,*weights)
    differences={}
    rng=np.random.default_rng(20261112+14600+(t=='it'))
    fids=np.unique(fs0);groups={f:np.flatnonzero(fs0==f) for f in fids}
    boots=[np.concatenate([groups[f] for f in rng.choice(fids,len(fids),replace=True)]) for _ in range(1999)]
    for lag in [3,5]:
        d=measured[1]-measured[lag]
        ci=np.quantile([d[indices].mean() for indices in boots],[.025,.975]).tolist()
        differences[f'lag1_2_minus_lag{lag}_{lag+1}']={'delta_logprob':float(d.mean()),'bootstrap_folio_ci95':ci}
    output['results'][t]={'n_tokens':len(fs0),'folios':len(fids),'prior_fitted_parameters':weights,
        'logprob_means':{f'lag{lag}':float(v.mean()) for lag,v in measured.items()},'differences':differences}
(ROOT/'lag_control_results.json').write_text(json.dumps(output,indent=2))
print(json.dumps(output,indent=2))
