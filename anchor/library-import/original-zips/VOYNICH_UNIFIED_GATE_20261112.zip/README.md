# Voynich: unified three-factor predictive gate + edit-1 extension

Date: 2026-11-12. **EXPLORATORY, NOT INDEPENDENT CONFIRMATION.** Existing Voynich folios have already been inspected in the project's previous experiments. Even though these scripts choose parameters exclusively on a validation split and evaluate a separate test split, the *hypotheses and the broad model family* were selected using prior experience with this same manuscript. A genuinely independent confirmation would require future preregistration, independent evidence or a separate blinded corpus.

## Research question

Can a **single proper probability distribution over Voynich token types** combine (i) a folio-specific lexical field, (ii) short-distance local dependence and (iii) first-position token preference? We separate local exact-token repetition from the ability to draw **edit-distance-one variants of words in preceding lines**.

## Actual results

The initial model uses a convex mixture of Currier-stratified global token frequencies, past-folio frequencies and exact-token counts in the preceding two lines. It additionally multiplies initial-`y` words at **the first position of every line** by `exp(beta)` and correctly normalizes the full token distribution. This is an **unmatched y/o proxy**, **not** the previously studied suffix-matched `yX/oX` odds ratio. Global vocabulary is known transductively, but all global frequency counts are fit on base folios only.

The data split is fixed, Currier-stratified, folio-disjoint (55% / 20% / 25%), inherited from prior `exp_next_token.py`. Approximately 9,967 ZL3b and 10,003 IT2a words are scored on 54 test folios (the source counts include *all* paragraph rows in this newer model rather than only non-initial paragraph rows in prior studies). Fitted hyperparameters are selected **only** on validation folios.

| Test comparison | ZL3b gain (nat/token) | IT2a gain (nat/token) |
|---|---:|---:|
| Folio versus global | +0.02374 | +0.02537 |
| Initial-y rule on top of folio | +0.00707 | +0.00623 |
| Exact-token preceding-two-lines on top of folio + initial-y | 0.00000 | 0.00000 |
| Edit-distance-one preceding-two-lines on top of folio + initial-y | **+0.01471** | **+0.01332** |

The initial-y parameter `beta=1.0` is selected at **the upper edge of the predeclared grid**, so we cannot claim adequate calibration or a close fit to any matched `yX/oX` odds ratio. Additional work must test whether positional distributions are reproduced rather than merely improved in log-score.

The edit-one neighbor mechanism assigns each token in the preceding two lines equal mass across **all vocabulary types exactly one insertion, deletion or substitution away**, and mixes that normalized lexical distribution at 2% into the next-token distribution. It **excludes the unchanged source word**. A 0.02 edit-one weight is chosen on validation in both transcriptions. The 95% folio-cluster bootstrap confidence intervals for incremental test log-score are `[+0.00975, +0.02066]` (ZL3b) and `[+0.00806, +0.01969]` (IT2a). The original exact-token mechanism does not provide convincing additional gain.

### Lagged control

On exactly matched evaluation words in paragraphs with at least six preceding lines (1,681 / 1,697 words over 26 folios), we keep the learned model weight fixed and swap the edit-one context source: preceding rows 1-2 versus 3-4 or 5-6. The 1-2 versus 3-4 contrasts are inconclusive (CIs include zero). The 1-2 versus 5-6 contrasts are positive for both transcriptions: `+0.01191` (95% CI `[+0.00227,+0.02416]`) and `+0.01099` (`[+0.00320,+0.02133]`). These lag comparisons are post-hoc exploratory, and **IT2a and ZL3b share one physical manuscript**.

## Outstanding failure points

1. **NOT a complete text generator**. These scripts evaluate probabilities of real Voynich tokens, conditioned on their real preceding folio history. They neither generate a full artificial manuscript nor simulate the four standard benchmark metrics, positional matched odds ratios or realistic line layouts.
2. **Not a historical explanation or decipherment**. A correlation among edit-one variants cannot establish whether the scribe copied, transformed, dictated or encoded tokens.
3. **Reused test corpus**. Past project branches have already examined these folios. Hence even correctly separated validation/test within this run does *not* make this a genuinely fresh blind test.
4. **Vocabulary transductive** and a simple flat edit-one operator; script intentionally does not optimize for section, illustration, paragraph boundary or physical foliation.
5. **The fit for initial-y preference is boundary-constrained**. The model might underfit the actual positional effect; the study reports it as a predictive improvement only.
6. All processing is in *read-only* mode with respect to sources and RC1.4.2; project RC1.4.2 remains **CLOSED_PENDING_VALIDATION**.

## Reproduce

Requirements: Python 3.11+, NumPy. The `inputs/` directory contains the original fixed ZL3b and IT2a transcripts, P-only TSV and parser. SHA-256 locks are verified by `exp_next_token.py` setup. From this directory:

```bash
python unified_gate.py       # outputs results.json and scores.csv
python edit_neighborhood.py # outputs edit1_results.json
python lag_control.py       # outputs lag_control_results.json
```

The three scripts do not execute the old `exp_next_token.py` experiment; they import only its verified corpus parsing and split construction. They do not alter original files. `exp_next_token.py` is bundled solely to provide the exact parser/splits/baselines as in prior work.

## Next non-negotiable gate

Implement genuine full-manuscript generation with **locked** model parameters and a novel evaluation corpus, and evaluate all four previously fixed statistical measures and suffix-matched `yX/oX`, including Currier- and paragraph-stratified controls. Reject a model that gets local edit-one likelihood improvement but fails the global distribution, the matched positional endpoint or independent heldout reproduction.
