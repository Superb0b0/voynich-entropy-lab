from playwright.sync_api import sync_playwright
import json,threading,http.server,socketserver,hashlib
PORT=18765
class Handler(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
import os
os.chdir('/mnt/data/voynich_browser_test')
srv=socketserver.TCPServer(('127.0.0.1',PORT),Handler)
threading.Thread(target=srv.serve_forever,daemon=True).start()
results={}
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 context=browser.new_context(accept_downloads=True)
 page=context.new_page()
 try:
  page.goto(f'http://127.0.0.1:{PORT}/index.html',wait_until='load',timeout=10000)
  page.wait_for_timeout(900)
  results['base_hash']={'status':'PASS' if 'Hash dati verificato nel browser ✔' in page.locator('body').inner_text() else 'FAIL','detail':page.locator('body').inner_text()[-400:]}
  print('nav',page.locator('#nav').inner_text())
  page.locator('[data-tab="anchor"]').click();page.wait_for_timeout(500)
  results['anchor_navigation']={'status':'PASS' if 'ANC-0001' in page.locator('#app').inner_text() else 'FAIL'}
  results['anchor_hash']={'status':'PASS' if 'Hash voce ANCHOR verificato nel browser ✔' in page.locator('#app').inner_text() else 'FAIL'}
  page.locator('[data-tab="files"]').click()
  fields=[x for x in ['query','status','version','kind','cls'] if page.locator('#'+x).count()]
  print('fields',fields)
  if len(fields)>=2:
   selects=[x for x in fields if x!='query' and page.locator('#'+x+' option').count()>1]
   if len(selects)>=2:
    a,b=selects[:2]
    page.locator('#'+a).select_option(index=1);page.locator('#'+b).select_option(index=1)
    results['combined_filters']={'status':'PASS' if page.locator('#'+a).input_value() and page.locator('#'+b).input_value() else 'FAIL','fields':[a,b]}
   else:results['combined_filters']={'status':'PENDING','reason':'No two populated selects'}
  page.locator('[data-tab="notes"]').click() if page.locator('[data-tab="notes"]').count() else page.locator('#nav button').last.click()
  page.locator('#ntitle').fill('TEST AUTOMATICO');page.locator('#nbody').fill('Persistenza controllata')
  page.locator('#save').click();page.reload();page.wait_for_timeout(300)
  if page.locator('#ntitle').count()==0:page.locator('#nav button').last.click()
  results['notes_persistence']={'status':'PASS' if 'TEST AUTOMATICO' in page.locator('#app').inner_text() else 'FAIL'}
  with page.expect_download(timeout=5000) as dl:page.locator('#export').click()
  download=dl.value
  path=download.path();content=open(path,'rb').read();obj=json.loads(content)
  results['export_json']={'status':'PASS' if isinstance(obj,list) and any(x.get('title')=='TEST AUTOMATICO' for x in obj) else 'FAIL','filename':download.suggested_filename,'bytes':len(content)}
 except Exception as e:results['error']={'status':'FAIL','message':str(e)[:500]}
 finally:browser.close();srv.shutdown()
print(json.dumps(results,indent=2,ensure_ascii=False))
open('/mnt/data/voynich_browser_test/results.json','w').write(json.dumps(results,indent=2,ensure_ascii=False))
