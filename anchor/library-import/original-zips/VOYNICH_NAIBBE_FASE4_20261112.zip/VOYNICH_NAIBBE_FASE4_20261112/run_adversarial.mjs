#!/usr/bin/env node
/*
 EXP-NAIBBE-04. Independent reproducer of four public-data analyses.
 1) Count all codebook readings of merged tokens, without language.
 2) Evaluate a fixed uniform-character prior and external-Latin trigram model.
 3) Compare against a character-shuffled training control.
 4) Vary removal of token boundaries and compare matched-size VMS text.

 Source: Greshko (2025), The Naibbe cipher, Cryptologia,
 https://doi.org/10.1080/01611194.2025.2566408
 Repository: https://github.com/greshko/naibbe-cipher
 Library corpus: user-owned ZL3b-n.txt, accessed via unchanged P-only export.
 No Voynich decipherment is claimed. No original Greshko Python is executed here.
*/
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const ROOT = path.dirname(new URL(import.meta.url).pathname);
const PIN = '5145f526b52741a6dca14201147f687e62c7162e';
const OBS = {
 'references/naibbe_tables.csv':'5cd34fb81d80faf3b4d57dbf1719c05ffde25302',
 'encrypted/nathist_output_ciphertext.txt':'fb5f1e7509773361ea1acf5b4019efdc83cd17e4',
 'encrypted/nathist_output_ciphertext_respaced.txt':'c95b95507e603ca9a7b0dadba2d13eb314e9b7ea',
 'respaced_plaintext/nathist_pre_encryption_respaced_plaintext.txt':'e1cca30c06fb5f99aff480e1e128245529b63a35',
};
const EXT = {
 'BrunoDeMagia':'79310c6515f9c28711ca558d7b58e257c2173c5d',
 'Secreta_Secretorum_LAT':'836e7880f494c293bfc7e07359cc332eac8e1ecf',
 'Latin_Aix':'6cead0c577c77c46f808431e2884e23195941b95',
 'Steganographia':'1a507eab4258953bbe5c7b30293ab74121c24fbd',
 'Rettorica':'376d611e483669f367bd61da39fd70fe497c987f',
};
const argv = process.argv.slice(2);
const flag = s => argv.includes(s);
const srcIdx = argv.indexOf('--source-dir');
const sourceDir = srcIdx<0?path.join(ROOT,'original_source_cache'):path.resolve(argv[srcIdx+1]);
const outDir = ROOT;
function blobsha(buf){return crypto.createHash('sha1').update(`blob ${buf.length}\0`).update(buf).digest('hex');}
async function acquire(repo,file,expected){const dst=path.join(sourceDir,repo==='greshko'?'greshko':'historical',file);if(!fs.existsSync(dst)){
 if(!flag('--fetch'))throw Error(`Missing ${dst}; run with --fetch when internet access is available`);
 const url=repo==='greshko'?`https://raw.githubusercontent.com/greshko/naibbe-cipher/${PIN}/${file}`:`https://raw.githubusercontent.com/chirila/Voynich-public/master/${file}`;
 const res=await fetch(url);if(!res.ok)throw Error(`${res.status} for ${url}`);
 fs.mkdirSync(path.dirname(dst),{recursive:true});fs.writeFileSync(dst,Buffer.from(await res.arrayBuffer()));
 }
 const bytes=fs.readFileSync(dst),actual=blobsha(bytes);if(actual!==expected)throw Error(`PIN mismatch ${file}: ${actual} != ${expected}`);
 return bytes.toString('utf8');}
function rows(text){return text.split(/\r?\n/).map(x=>x.trim().split(/\s+/).filter(Boolean));}
function readGlyphs(csv){const E=csv.replace(/^\uFEFF/,'').trim().split(/\r?\n/).slice(1).map(line=>{let i=line.indexOf(','),k=line.slice(0,i).split('_');return {kind:k[0],letter:k.at(-1),glyph:line.slice(i+1)};});
 const D=new Map(),U=new Set(),P=[],S=[];
 for(const e of E){if(e.kind==='unigram'){U.add(e.glyph);D.set(e.glyph,new Set([e.letter]));}else if(e.kind==='prefix')P.push(e);else if(e.kind==='suffix')S.push(e);}
 for(const a of P)for(const b of S){const glyph=a.glyph+b.glyph;if(U.has(glyph))continue;const s=D.get(glyph)||new Set();s.add(a.letter+b.letter);D.set(glyph,s);}
 return {D,maxLen:Math.max(...[...D.keys()].map(x=>x.length))};}
function candidateFactory(D,maxLen){const cache=new Map();return word=>{if(cache.has(word))return cache.get(word);const memo=new Map();function scan(i){if(i===word.length)return [{text:'',parts:0}];if(memo.has(i))return memo.get(i);const out=[];
 for(let j=i+1;j<=Math.min(word.length,i+maxLen);j++){const forms=D.get(word.slice(i,j));if(!forms)continue;for(const form of forms)for(const rest of scan(j))out.push({text:form+rest.text,parts:rest.parts+1});}
 memo.set(i,out);return out;}
 const seen=new Set();const ret=scan(0).filter(x=>x.parts>=2).filter(x=>{const key=x.text+'|'+x.parts;if(seen.has(key))return false;seen.add(key);return true;});cache.set(word,ret);return ret;};}
function normalizeLatin(s){return s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[æÆ]/g,'ae').replace(/[œŒ]/g,'oe').replace(/[ðÐ]/g,'d').replace(/[þÞ]/g,'th').replace(/[łŁ]/g,'l').replace(/ß/g,'ss').replace(/[øØ]/g,'o').replace(/[^A-Za-z]/g,'').toLowerCase();}
function model(s,n=3){let hist=new Map(),base=new Map(),pref='^'.repeat(n-1);for(let ch of s){const g=(pref+ch).slice(-n);hist.set(g,(hist.get(g)||0)+1);base.set(g.slice(0,-1),(base.get(g.slice(0,-1))||0)+1);pref=g.slice(-n+1);}return {hist,base,n};}
function lmScore(str,m){let val=0,pref='^'.repeat(m.n-1);for(let ch of str){const g=(pref+ch).slice(-m.n);val+=Math.log(((m.hist.get(g)||0)+.01)/((m.base.get(g.slice(0,-1))||0)+.26));pref=g.slice(-m.n+1);}return val;}
function mulberry(seed){return ()=>{seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return ((t^t>>>14)>>>0)/4294967296;};}
function shuffle(text,seed){const a=[...text],rng=mulberry(seed);for(let i=a.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a.join('');}
function evaluate(pair,D,candidates,corpora){const M=new Map(Object.entries(corpora).map(([k,s])=>[k,model(s)])),stats=Object.fromEntries([...M.keys(),'uniform_letters','shortest'].map(x=>[x,{correct:0,total:0}]));
 const merged=[],r=rows(pair.raw),rr=rows(pair.resp),p=rows(pair.plain);
 if(r.length!==rr.length||r.length!==p.length)throw Error('Source line count differs');
 for(let i=0;i<r.length;i++){let idx=0,parts=[];
 if(r[i].length!==p[i].length)throw Error('Plaintext mismatch '+i);
 if(r[i].join('')!==rr[i].join(''))throw Error('Changes beyond space removal '+i);
 for(const w of rr[i]){let acc='',origin=[];while(acc.length<w.length){acc+=r[i][idx];origin.push(p[i][idx]);idx++;}if(acc!==w)throw Error('Alignment mismatch '+i);parts.push({glyph:w,truth:origin.join(''),k:origin.length});}
 for(let j=0;j<parts.length;j++){const q=parts[j];if(q.k<2)continue;const L=j>0?D.get(parts[j-1].glyph):null,R=j+1<parts.length?D.get(parts[j+1].glyph):null,left=L?.size===1?[...L][0].slice(-6):'',right=R?.size===1?[...R][0].slice(0,6):'';
 const opts=candidates(q.glyph);if(!opts.some(x=>x.text===q.truth))throw Error('Ground truth excluded '+i);
 const base={line:i,glyph:q.glyph,truth:q.truth,origin_parts:q.k,alternatives:opts.length,distinct_readings:new Set(opts.map(x=>x.text)).size};
 for(const [name,mod] of [...M,['uniform_letters',null],['shortest',null]]){let best=-Infinity,choice=null;
 for(const x of opts){const val=name==='shortest'?-x.parts:(name==='uniform_letters'?-x.text.length*Math.log(26):lmScore(left+x.text+right,mod))+(x.parts-2)*Math.log(.03);
 if(val>best){best=val;choice=x;}}
 const match=choice?.text===q.truth;stats[name].total++;if(match)stats[name].correct++;base[name+'_correct']=match;base[name+'_predicted']=choice?.text??'';
 }
 merged.push(base);
 }
 if(idx!==r[i].length)throw Error('Unaligned tail '+i);
 }
 for(const name of Object.keys(stats))stats[name].accuracy=stats[name].correct/stats[name].total;
 return {stats,merged};}
function lengthMatchedVms(text,cap=22000){let rows=text.split(/\r?\n/).filter(x=>x.includes('\t')).map(x=>x.split('\t').slice(1).join('\t').trim().split(/\s+/).filter(Boolean));let total=0,out=[];for(let r of rows){if(total+r.length>cap)break;out.push(r);total+=r.length;}return {out,total,lengths:out.map(x=>x.length)};}
function metrics(rows){const ts=rows.flat(),f=new Map();for(let t of ts)f.set(t,(f.get(t)||0)+1);
 const good=new Set(),sigs=new Map();for(let w of f.keys())for(let j=0;j<w.length;j++){const sh=w.slice(0,j)+w.slice(j+1);if(f.has(sh)){good.add(w);good.add(sh);}const k=w.slice(0,j)+'*'+w.slice(j+1);if(sigs.has(k)){const v=sigs.get(k);if(v!==w){good.add(w);good.add(v);}}else sigs.set(k,w);}
 let density=0,hapax=0;for(let [w,n] of f){if(good.has(w))density+=n;if(n===1)hapax++;}
 let adj=0,repeat=0;for(let i=1;i<rows.length;i++){const old=new Set(rows[i-1]),current=new Set(rows[i]);let intersect=0;for(const x of current)if(old.has(x))intersect++;adj+=(intersect/(old.size+current.size-intersect))||0;let k=0;for(const t of rows[i])if(old.has(t))k++;repeat+=rows[i].length?k/rows[i].length:0;}
 return{density:density/ts.length,adjacency:adj/(rows.length-1),repetition:repeat/(rows.length-1),hapax:hapax/f.size,types:f.size};}
function fromLengths(token,lengths){let i=0;return lengths.map(n=>{const row=token.slice(i,i+n);i+=n;return row;});}
function respaceNative(native,p,seed){const rng=mulberry(seed),out=[];for(const line of native){if(!line.length)continue;let t=line[0];for(let j=1;j<line.length;j++){if(rng()<p)t+=line[j];else{out.push(t);t=line[j];}}out.push(t);}return out;}
function sweep(raw,vms){const native=rows(raw).filter(x=>x.length),{out,lengths,total}=lengthMatchedVms(vms),real=metrics(out),grid=[];
 for(let p of [0,.03,.06,.09,.12,.15,.18,.21,.24,.27,.30]){let measurements=[];for(let seed=1001;seed<=1010;seed++){const t=respaceNative(native,p,seed);if(t.length<total)throw Error('Too short after merging');const m=metrics(fromLengths(t,lengths));measurements.push({seed,...m});}
 const means={};for(let k of ['density','adjacency','repetition','hapax'])means[k]=measurements.reduce((s,x)=>s+x[k],0)/measurements.length;
 grid.push({p,mean:means,trials:measurements});}
 return {matching:{tokens:total,lines:lengths.length,real},grid};}
function selfTest(){const a=readGlyphs('code,glyphs\nunigram_alpha_a,ol\nunigram_alpha_b,ar\nprefix_alpha_a,ch\nsuffix_alpha_b,dy\n');const ca=candidateFactory(a.D,a.maxLen);if(a.D.get('ol')?.has('a')!==true||a.D.get('chdy')?.has('ab')!==true||!ca('olar').some(x=>x.text==='ab'&&x.parts===2))throw Error('Self test failed');
 const trial=evaluate({raw:'ol ar\n',resp:'olar\n',plain:'a b\n'},a.D,ca,{sample:'abababab'});
 if(trial.merged.length!==1||trial.stats.uniform_letters.correct!==1||trial.stats.sample.correct!==1)throw Error('Full decode self-test failed');
 const met=metrics([['ab','ac'],['ab','ad']]);
 if(Math.abs(met.density-1)>1e-12||Math.abs(met.adjacency-1/3)>1e-12||Math.abs(met.repetition-.5)>1e-12||Math.abs(met.hapax-2/3)>1e-12)throw Error('Metric definitions self-test failed');
 console.log('Self test PASS');}
if(flag('--self-test')){selfTest();process.exit(0);}
const source={};for(let [file,sha] of Object.entries(OBS))source[file]=await acquire('greshko',file,sha);
const ext={};for(let [name,sha] of Object.entries(EXT))ext[name]=normalizeLatin(await acquire('chirila',`Corpora/Historical_texts/${name}`,sha)).slice(0,90000);
const {D,maxLen}=readGlyphs(source['references/naibbe_tables.csv']);const cand=candidateFactory(D,maxLen);
const corpora={...ext};corpora['Latin_Aix_shuffled_1001']=shuffle(ext.Latin_Aix,1001);
const out=evaluate({raw:source['encrypted/nathist_output_ciphertext.txt'],resp:source['encrypted/nathist_output_ciphertext_respaced.txt'],plain:source['respaced_plaintext/nathist_pre_encryption_respaced_plaintext.txt']},D,cand,corpora);
const vms=fs.readFileSync(path.join(ROOT,'zl3b_P_ms408.tsv'),'utf8');const boundaries=sweep(source['encrypted/nathist_output_ciphertext.txt'],vms);
fs.writeFileSync(path.join(outDir,'recomputed.json'),JSON.stringify({status:'executed_from_pinned_public_sources',run_date:new Date().toISOString(),version:'EXP-NAIBBE-04',decoder:{stat:out.stats,n:out.merged.length},boundaries},null,2));
fs.writeFileSync(path.join(outDir,'per_merged_token.json'),JSON.stringify(out.merged));
console.log(JSON.stringify({decoder:out.stats,boundary_means:boundaries.grid.map(({p,mean})=>({p,mean})),vms:boundaries.matching},null,2));
