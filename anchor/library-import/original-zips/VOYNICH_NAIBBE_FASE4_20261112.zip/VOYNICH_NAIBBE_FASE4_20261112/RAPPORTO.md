# EXP-NAIBBE-04 | Audit avversariale: ambiguità, priors e confini

**Data:** 12 novembre 2026.  
**Classificazione:** esplorativo, non preregistrato. **Nessuna decifrazione.**  
**Gates precedenti:** la pipeline RC1.4.2 resta `CLOSED_PENDING_VALIDATION`, senza esecuzione builder, PCA o clustering.

## Sintesi

L'ipotesi che l'eliminazione di spazi renda Naibbe altamente ambiguo è vera **senza ulteriori vincoli**, ma il recupero dei plaintext migliora drasticamente non appena il decoder dispone delle regole generative note del cifrario e della frequenza di fusione degli spazi. Il contributo propriamente linguistico risulta molto inferiore a quello apparentemente suggerito dall'uso del decoder pubblicato da Greshko. Viceversa, aumentando la frequenza di fusione degli spazi, alcune metriche lessicali di Naibbe si avvicinano al Voynich, ma **le dipendenze tra righe si allontanano**.

## 1. Dati originali e integrità

Dataset Greshko: [greshko/naibbe-cipher](https://github.com/greshko/naibbe-cipher), commit `5145f526b52741a6dca14201147f687e62c7162e`. Quattro file autentici: mappa dei glifi, ciphertext latino della *Naturalis Historia*, ciphertext rispaziato e corrispondente plaintext n-grammato. Identità dei blob Git in `OBSERVED_RESULTS.json`. Gli input originali non sono stati alterati.

Corpus Voynich: export P-only dalla Library (`zl3b_P_ms408.tsv`, SHA-256 `41c3ea40b7f71ea612fbee49a65ebd253231a209ce2d5096131126c957bcd1f2`), ricondotto al parent ZL3b-n.txt di SHA-256 `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc`. Per il confronto a parità di dimensione sono stati usati **22.000 token e 2.903 righe** iniziali. Si tratta di un campione ridotto: **non** usare le bande RC1.4 definite per il campione 34.323-token.

## 2. Recuperabilità del ciphertext Naibbe con confini incerti

Le eliminazioni di 1.014 confini originali generano **985 blocchi fusi**, di cui 957 composti da due e 28 da almeno tre token di partenza. Per tutti i 985, la lettura corretta è contenuta tra le possibilità enumerate. Senza modello contestuale, solo **56/985 (5,7%)** hanno una lettura univoca. La mediana è 6 stringhe latine distinte, il 95° percentile 25, massimo 120.

Il decoder originale, con la sua procedura locale e verifica di compound, restituisce la lettura corretta in forma non ambigua per **219/985 (22,2%)**. Ciò misura i limiti del decoder, non l'irrecuperabilità della lingua cifrata.

| Meccanismo di scelta | Correct | Percentuale |
|---|---:|---:|
| Lettura grammaticalmente univoca, senza scelta | 56/985 | 5,7% |
| Preferire meno token cifrati | 756/985 | 76,8% |
| Prior uniforme sulle lettere e fusione nota al 3% | 937/985 | **95,1%** |
| Trigrammi di latino indipendente, *De magia* | 962/985 | 97,7% |
| Trigrammi latini indipendenti, *Historia Hierosolymitana* | 971/985 | **98,6%** |
| Trigrammi di italiano, *Rettorica* | 907/985 | 92,1% |
| Trigrammi con lettere d'addestramento mescolate, seed 1001 | 946/985 | 96,0% |
| Trigrammi con lettere d'addestramento mescolate, seed 1002 | 949/985 | 96,3% |

**Interpretazione corretta:** la maggioranza del guadagno rispetto al 22,2% non richiede conoscere il latino. Il prior strutturale, inclusa la frequenza di fusione **nota in anticipo nel codice Greshko**, basta per arrivare al 95,1%. Il trigramma latino migliora di **34 gruppi / 985, cioè 3,45 punti percentuali** rispetto al prior uniforme. Il controllo con lettere rimescolate raggiunge 96,0–96,3%: quindi le frequenze e la penalizzazione della lunghezza contribuiscono a una parte della prestazione. Non si sostiene che un modello linguistico cieco possa decifrare il Voynich.

### Ablazione: quanto valgono davvero lingua, contesto e prior?

Per il modello esterno *Historia Hierosolymitana* ho confrontato bigrammi, trigrammi e tetragrammi, con e senza il contesto immediato dei token adiacenti e con e senza il prior di fusione al 3%.

- **Trigrammi senza vicini + prior 3%:** 962/985 (97,7%).
- **Trigrammi con vicini + prior 3%:** 971/985 (98,6%).
- **Trigrammi con vicini senza prior 3%:** 945/985 (95,9%).
- **Bigrammi con vicini + prior 3%:** 973/985 (98,8%), appena sopra il trigramma.
- **4-grammi con vicini + prior 3%:** 953/985 (96,8%), inferiore al trigramma.

Il miglioramento non cresce monotonamente con l'ordine del modello. La differenza fra 971/985 e 973/985 è irrilevante come evidenza di superiorità: **queste scelte sono state confrontate sullo stesso set di controllo**, perciò la selezione del migliore sarebbe una forma di ottimizzazione ex post. I dati completi figurano in `decoder_ablation.csv`.

**Contaminazione e model selection:** i corpora latini indipendenti non contengono il plaintext Greshko. Tuttavia la famiglia dei modelli e i parametri sono stati esplorati su questo stesso dataset pubblico. Il risultato è esplorativo, non una validazione preregistrata né una replica indipendente del Voynich. L'analisi sul 70%/30% interno produce 308/313 (98,4%) nel segmento riservato, ma il dato non va sommato ai 985 e non costituisce ulteriore campione indipendente.

## 3. La perdita degli spazi può riprodurre le quattro metriche?

**No, non in questo modello a sola fusione e layout controllato.** Per rispettare la comparabilità dimensionale, sono stati presi i primi 22.000 token del corpus Voynich P-only, mantenendo esattamente le lunghezze delle 2.903 righe e reimpaginando ciascuna versione Naibbe con quello stesso vettore. Sono state esplorate probabilità di fusione dal 0 al 30%, con 10 repliche per valore. Le medie sono in `boundary_sweep_10seeds.csv`.

| Metrica | Voynich 22k | Naibbe senza fusioni | Fusioni 6% | Fusioni 18% |
|---|---:|---:|---:|---:|
| Densità | 0,9440 | 0,9972 | 0,9483 | 0,8594 |
| Adiacenza | 0,0295 | 0,0150 | 0,0132 | 0,0105 |
| Ripetizione locale | 0,0599 | 0,0287 | 0,0257 | 0,0202 |
| Hapax | 0,7178 | 0,4681 | 0,5909 | 0,7254 |

L'aumento delle fusioni fa salire gli hapax, ma riduce l'adiacenza e la ripetizione. Quando gli hapax sono vicini al Voynich (intorno al 18% di fusioni), la densità è già molto inferiore al valore reale e le dipendenze fra righe sono ulteriormente indebolite. Quando la densità coincide quasi (intorno al 6%), gli hapax restano lontani. **Non è stato trovato un valore del parametro che recuperi il profilo simultaneo.**

Questa è una **sweep esplorativa e condizionata** al ciphertext pubblicato, alla randomizzazione adottata, al riempimento delle righe e al prefix size 22k. Non è una prova contro tutte le procedure di rispaziatura, né contro tutti i cifrari omofonici.

## 4. Conclusioni falsificabili

1. **Confermato:** la rimozione degli spazi crea ambiguità combinatoria se si dimenticano le regole di generazione dei simboli.
2. **Ridimensionato:** il contesto linguistico recupera molto meno di quanto sembrasse confrontandolo con il decoder originale; la conoscenza del cifrario e del 3% di fusioni spiega già la maggioranza della recuperabilità.
3. **Non sostenuta:** la sola fusione casuale dei confini spiega simultaneamente densità, hapax e dipendenza fra righe del Voynich. Nel campione verificato i tradeoff vanno nella direzione opposta.
4. **Non concluso:** la verifica di esecuzione del codice Python originale Naibbe v1 e v2 resta aperta per mancanza delle copie native dei sorgenti nell'ambiente locale senza rete. `run_original_python_PENDING.py` è un runner pronto, non una prova di avvenuta esecuzione.
5. **Non alterato:** nessun accesso in scrittura alla pipeline immagini/testo RC1.4.2.

## 5. Riproducibilità

- `run_adversarial.mjs` contiene la procedura completa (Node 20+); `node run_adversarial.mjs --self-test` verifica la logica minima senza rete.
- Con Internet, `node run_adversarial.mjs --fetch` acquisisce file pubblici e ne verifica i Git blob SHA prima di ripetere gli esperimenti. Usa `--source-dir` per riutilizzare file originali già scaricati.
- `run_original_python_PENDING.py`, con `pandas`, permette un audit successivo del vero Python di Greshko. L'output non è stato prodotto durante questa sessione.
- `OBSERVED_RESULTS.json` e i CSV registrano i **risultati numerici osservati** tramite strumenti di analisi in questa conversazione, distinti da `recomputed.json`, che nasce solo se il runner viene eseguito con tutti i sorgenti pubblici disponibili.

**Nota etica/scientifica:** Greshko, M. A. (2025), *The Naibbe cipher: a substitution cipher that encrypts Latin and Italian as Voynich Manuscript-like ciphertext*, *Cryptologia*, DOI: 10.1080/01611194.2025.2566408. Il presente esperimento valuta compatibilità statistica, non autenticità del manoscritto, letture semantiche o decifrazioni.
