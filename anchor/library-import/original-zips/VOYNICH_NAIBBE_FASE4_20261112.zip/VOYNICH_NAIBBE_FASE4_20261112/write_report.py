from __future__ import annotations
from pathlib import Path
import csv,json,hashlib,zipfile
BASE=Path(__file__).resolve().parent
source={
 'greshko_commit':'5145f526b52741a6dca14201147f687e62c7162e',
 'greshko_blobs':{
 'references/naibbe_tables.csv':'5cd34fb81d80faf3b4d57dbf1719c05ffde25302',
 'encrypted/nathist_output_ciphertext.txt':'fb5f1e7509773361ea1acf5b4019efdc83cd17e4',
 'encrypted/nathist_output_ciphertext_respaced.txt':'c95b95507e603ca9a7b0dadba2d13eb314e9b7ea',
 'respaced_plaintext/nathist_pre_encryption_respaced_plaintext.txt':'e1cca30c06fb5f99aff480e1e128245529b63a35',
 'naibbe.py':'910b7a99532f4630cb59917f9df3de8e98808598',
 'naibbe_v2.py':'b566ad82e4b6ff0782ecdddebf77718dac44f292',
 },
 'historical_blobs':{
  'BrunoDeMagia':'79310c6515f9c28711ca558d7b58e257c2173c5d',
  'Secreta_Secretorum_LAT':'836e7880f494c293bfc7e07359cc332eac8e1ecf',
  'Latin_Aix':'6cead0c577c77c46f808431e2884e23195941b95',
  'Steganographia':'1a507eab4258953bbe5c7b30293ab74121c24fbd',
  'Rettorica':'376d611e483669f367bd61da39fd70fe497c987f',
 },
 'vms_p_only_tsv_sha256':'41c3ea40b7f71ea612fbee49a65ebd253231a209ce2d5096131126c957bcd1f2',
 'vms_parent_sha256':'bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc'
}
recover=[
 ('Pubblicato, senza ricerca alternative',219,985),
 ('Lettura unica nella grammatica completa',56,985),
 ('Preferenza per numero minimo di token',756,985),
 ('Prior uniforme + probabilità 3% fusione',937,985),
 ('Trigramma latino De magia',962,985),
 ('Trigramma latino Secreta Secretorum',956,985),
 ('Trigramma latino Historia Hierosolymitana',971,985),
 ('Trigramma latino Steganographia',971,985),
 ('Trigramma italiano Rettorica',907,985),
 ('Trigramma, lettere mescolate seed 1001',946,985),
 ('Trigramma, lettere mescolate seed 1002',949,985),
 ('Trigramma latino Naibbe primo 70%, prova su ultimo 30%',308,313)
]
with (BASE/'decoder_comparison.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.writer(f);w.writerow(['method','correct','total','pct']);w.writerows((name,k,n,round(k/n*100,4)) for name,k,n in recover)
real={'density':.944,'adjacency':.029513858575030163,'repetition':.05993932850233788,'hapax':.7178280542986425}
sweep=[
 (0,.9971818181818184,.014977240275217149,.028658571921585406,.46813186813186813),
 (.03,.9719045454545453,.0136851414838354,.02670883355494893,.5365090456851482),
 (.06,.9483227272727273,.013210875301250364,.025671546258793514,.5908584797598181),
 (.09,.9253227272727272,.012274206917975131,.02392344928329252,.6346263844919474),
 (.12,.9031181818181817,.011790178094159453,.02291117491851278,.6698253566624904),
 (.15,.8812909090909091,.010813060774214286,.020975986470118415,.6992628875163792),
 (.18,.8594090909090909,.010462733773652748,.02019657509297018,.7253519313265226),
 (.21,.8369090909090909,.00934890005775196,.018195136620157985,.7466124860262953),
 (.24,.813640909090909,.00897757772246503,.017308409235908595,.765961268722826),
 (.27,.7897363636363636,.008081801714118986,.015602908640190288,.7847937456792082),
 (.30,.7654545454545454,.007630812389157767,.014709042320273966,.801118991600282),
]
with (BASE/'boundary_sweep_10seeds.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.writer(f);w.writerow(['merge_probability','n_trials','density_mean','adjacency_mean','repetition_mean','hapax_mean']);w.writerows((p,10,d,a,r,h) for p,d,a,r,h in sweep)
observed={
 'status':'OBSERVED_IN_THIS_CHAT_VIA_GITHUB_CONNECTOR_AND_LOCAL_LIBRARY_ACCESS',
 'date':'2026-11-12',
 'sources':source,
 'decoder':{
  'total_merged_groups':985,'original_token_boundaries_removed':1014,
  'one_unambiguous_reading':56,'multiple_readings':929,
  'median_candidate_plaintexts':6,'p95_candidate_plaintexts':25,'max_candidate_plaintexts':120,
  'true_plaintext_is_candidate':985,
  'unique_if_true_part_count_known':685,
  'raw_cipher_tokens':34764,'raw_unambiguous_correct':34517,'raw_explicitly_ambiguous':247,
  'published_decoder_unique_correct_merged':219,
  'comparisons':[{"model":name,'correct':k,'n':n,'pct':k/n*100} for name,k,n in recover],
  'trigram':'add-0.01 smoothed character trigrams; 6-letter adjacent context only if cipher neighbor has a unique codebook reading',
  'prior':'(number_of_cipher_tokens-2)*ln(0.03); uniform letters ln(1/26)',
  'external_source_text_preprocessing':'first 90000 lowercase normalized letters',
  'limitation':'The codebook, the author-specified 3% merging rate and a known plaintext ground truth are all available; no such ground truth is available for Voynich.'
 },
 'boundary_sweep':{
  'n_reference_tokens':22000,'n_reference_lines':2903,
  'reference_real_VMS':real,'n_random_seeds_per_p':10,
  'seeds':[1001,1010],
  'p_grid':[p for p,*_ in sweep],
  'means':[{"p":p,'density':d,'adjacency':a,'repetition':r,'hapax':h}for p,d,a,r,h in sweep],
  'note':'Exploratory truncated equal-sized corpus, not subject to pre-established 34323-token acceptance bands.'
 },
 'original_python_execution':'NOT_COMPLETED; pending native-source acquisition in offline container',
 'rc1_4_2_state':'CLOSED_PENDING_VALIDATION; unchanged'
}
(BASE/'OBSERVED_RESULTS.json').write_text(json.dumps(observed,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=f'''# EXP-NAIBBE-04 | Audit avversariale: ambiguità, priors e confini

**Data:** 12 novembre 2026.  
**Classificazione:** esplorativo, non preregistrato. **Nessuna decifrazione.**  
**Gates precedenti:** la pipeline RC1.4.2 resta `CLOSED_PENDING_VALIDATION`, senza esecuzione builder, PCA o clustering.

## Sintesi

L'ipotesi che l'eliminazione di spazi renda Naibbe altamente ambiguo è vera **senza ulteriori vincoli**, ma il recupero dei plaintext migliora drasticamente non appena il decoder dispone delle regole generative note del cifrario e della frequenza di fusione degli spazi. Il contributo propriamente linguistico risulta molto inferiore a quello apparentemente suggerito dall'uso del decoder pubblicato da Greshko. Viceversa, aumentando la frequenza di fusione degli spazi, alcune metriche lessicali di Naibbe si avvicinano al Voynich, ma **le dipendenze tra righe si allontanano**.

## 1. Dati originali e integrità

Dataset Greshko: [greshko/naibbe-cipher](https://github.com/greshko/naibbe-cipher), commit `{source['greshko_commit']}`. Quattro file autentici: mappa dei glifi, ciphertext latino della *Naturalis Historia*, ciphertext rispaziato e corrispondente plaintext n-grammato. Identità dei blob Git in `OBSERVED_RESULTS.json`. Gli input originali non sono stati alterati.

Corpus Voynich: export P-only dalla Library (`zl3b_P_ms408.tsv`, SHA-256 `{source['vms_p_only_tsv_sha256']}`), ricondotto al parent ZL3b-n.txt di SHA-256 `{source['vms_parent_sha256']}`. Per il confronto a parità di dimensione sono stati usati **22.000 token e 2.903 righe** iniziali. Si tratta di un campione ridotto: **non** usare le bande RC1.4 definite per il campione 34.323-token.

## 2. Recuperabilità del ciphertext Naibbe con confini incerti

Le eliminazioni di 1.014 confini originali generano **985 blocchi fusi**, di cui 957 composti da due e 28 da almeno tre token di partenza. Per tutti i 985, la lettura corretta è contenuta tra le possibilità enumerate. Senza modello contestuale, solo **56/985 (5,7%)** hanno una lettura univoca. La mediana è 6 stringhe latine distinte, il 95° percentile 25, massimo 120.

Il decoder originale, con la sua procedura locale e verifica di compound, restituisce la lettura corretta in forma non ambigua per **219/985 (22,2%)**. Ciò misura i limiti del decoder, non l'irrecuperabilità della lingua cifrata.

| Meccanismo di scelta | Correct | Percentuale |
|---|---:|---:|
| Lettura grammaticalmente univoca, senza scelta | 56/985 | 5,7% |
| Preferire meno token cifrati | 756/985 | 76,8% |
| Prior uniforme sulle lettere e fusione nota al 3% | 937/985 | **95,1%** |
| Trigrammi di latino indipendente, *De magia* | 962/985 | 97,7% |
| Trigrammi latini indipendenti, *Historia Hierosolymitana* | 971/985 | **98,6%** |
| Trigrammi di italiano, *Rettorica* | 907/985 | 92,1% |
| Trigrammi con lettere d'addestramento mescolate, seed 1001 | 946/985 | 96,0% |
| Trigrammi con lettere d'addestramento mescolate, seed 1002 | 949/985 | 96,3% |

**Interpretazione corretta:** la maggioranza del guadagno rispetto al 22,2% non richiede conoscere il latino. Il prior strutturale, inclusa la frequenza di fusione **nota in anticipo nel codice Greshko**, basta per arrivare al 95,1%. Il trigramma latino migliora di **34 gruppi / 985, cioè 3,45 punti percentuali** rispetto al prior uniforme. Il controllo con lettere rimescolate raggiunge 96,0–96,3%: quindi le frequenze e la penalizzazione della lunghezza contribuiscono a una parte della prestazione. Non si sostiene che un modello linguistico cieco possa decifrare il Voynich.

**Contaminazione e model selection:** i corpora latini indipendenti non contengono il plaintext Greshko. Tuttavia la famiglia dei modelli e i parametri sono stati esplorati su questo stesso dataset pubblico. Il risultato è esplorativo, non una validazione preregistrata né una replica indipendente del Voynich. L'analisi sul 70%/30% interno produce 308/313 (98,4%) nel segmento riservato, ma il dato non va sommato ai 985 e non costituisce ulteriore campione indipendente.

## 3. La perdita degli spazi può riprodurre le quattro metriche?

**No, non in questo modello a sola fusione e layout controllato.** Per rispettare la comparabilità dimensionale, sono stati presi i primi 22.000 token del corpus Voynich P-only, mantenendo esattamente le lunghezze delle 2.903 righe e reimpaginando ciascuna versione Naibbe con quello stesso vettore. Sono state esplorate probabilità di fusione dal 0 al 30%, con 10 repliche per valore. Le medie sono in `boundary_sweep_10seeds.csv`.

| Metrica | Voynich 22k | Naibbe senza fusioni | Fusioni 6% | Fusioni 18% |
|---|---:|---:|---:|---:|
| Densità | 0,9440 | 0,9972 | 0,9483 | 0,8594 |
| Adiacenza | 0,0295 | 0,0150 | 0,0132 | 0,0105 |
| Ripetizione locale | 0,0599 | 0,0287 | 0,0257 | 0,0202 |
| Hapax | 0,7178 | 0,4681 | 0,5909 | 0,7254 |

L'aumento delle fusioni fa salire gli hapax, ma riduce l'adiacenza e la ripetizione. Quando gli hapax sono vicini al Voynich (intorno al 18% di fusioni), la densità è già molto inferiore al valore reale e le dipendenze fra righe sono ulteriormente indebolite. Quando la densità coincide quasi (intorno al 6%), gli hapax restano lontani. **Non è stato trovato un valore del parametro che recuperi il profilo simultaneo.**

Questa è una **sweep esplorativa e condizionata** al ciphertext pubblicato, alla randomizzazione adottata, al riempimento delle righe e al prefix size 22k. Non è una prova contro tutte le procedure di rispaziatura, né contro tutti i cifrari omofonici.

## 4. Conclusioni falsificabili

1. **Confermato:** la rimozione degli spazi crea ambiguità combinatoria se si dimenticano le regole di generazione dei simboli.
2. **Ridimensionato:** il contesto linguistico recupera molto meno di quanto sembrasse confrontandolo con il decoder originale; la conoscenza del cifrario e del 3% di fusioni spiega già la maggioranza della recuperabilità.
3. **Non sostenuta:** la sola fusione casuale dei confini spiega simultaneamente densità, hapax e dipendenza fra righe del Voynich. Nel campione verificato i tradeoff vanno nella direzione opposta.
4. **Non concluso:** la verifica di esecuzione del codice Python originale Naibbe v1 e v2 resta aperta per mancanza delle copie native dei sorgenti nell'ambiente locale senza rete. `run_original_python_PENDING.py` è un runner pronto, non una prova di avvenuta esecuzione.
5. **Non alterato:** nessun accesso in scrittura alla pipeline immagini/testo RC1.4.2.

## 5. Riproducibilità

- `run_adversarial.mjs` contiene la procedura completa (Node 20+); `node run_adversarial.mjs --self-test` verifica la logica minima senza rete.
- Con Internet, `node run_adversarial.mjs --fetch` acquisisce file pubblici e ne verifica i Git blob SHA prima di ripetere gli esperimenti. Usa `--source-dir` per riutilizzare file originali già scaricati.
- `run_original_python_PENDING.py`, con `pandas`, permette un audit successivo del vero Python di Greshko. L'output non è stato prodotto durante questa sessione.
- `OBSERVED_RESULTS.json` e i CSV registrano i **risultati numerici osservati** tramite strumenti di analisi in questa conversazione, distinti da `recomputed.json`, che nasce solo se il runner viene eseguito con tutti i sorgenti pubblici disponibili.

**Nota etica/scientifica:** Greshko, M. A. (2025), *The Naibbe cipher: a substitution cipher that encrypts Latin and Italian as Voynich Manuscript-like ciphertext*, *Cryptologia*, DOI: 10.1080/01611194.2025.2566408. Il presente esperimento valuta compatibilità statistica, non autenticità del manoscritto, letture semantiche o decifrazioni.
'''
(BASE/'RAPPORTO.md').write_text(report,encoding='utf8')
print('Wrote',len(report),'chars')
