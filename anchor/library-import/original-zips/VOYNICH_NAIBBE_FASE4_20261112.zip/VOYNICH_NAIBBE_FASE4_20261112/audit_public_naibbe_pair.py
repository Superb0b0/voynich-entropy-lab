#!/usr/bin/env python3
"""Naibbe published-pair reversibility audit, pinned original public files.

This is an independent implementation of the PUBLISHED decoder's semantics,
NOT execution of the original Python source. No manuscript meanings inferred.

Greshko, Michael A. (2025), Cryptologia,
https://doi.org/10.1080/01611194.2025.2566408

Usage:
  python audit_public_naibbe_pair.py --source-dir SOURCE_CACHE --output observed.json
  python audit_public_naibbe_pair.py --download --source-dir SOURCE_CACHE
  python audit_public_naibbe_pair.py --self-test

Caches are immutable when validated, verified against git blob SHA-1.
"""
from __future__ import annotations
import argparse, csv, hashlib, io, json
from collections import defaultdict
from functools import lru_cache
from pathlib import Path
from urllib.request import urlopen

PIN='5145f526b52741a6dca14201147f687e62c7162e'
ROOT='https://raw.githubusercontent.com/greshko/naibbe-cipher/'+PIN+'/'
FILES={
'references/naibbe_tables.csv':'5cd34fb81d80faf3b4d57dbf1719c05ffde25302',
'encrypted/nathist_output_ciphertext.txt':'fb5f1e7509773361ea1acf5b4019efdc83cd17e4',
'encrypted/nathist_output_ciphertext_respaced.txt':'c95b95507e603ca9a7b0dadba2d13eb314e9b7ea',
'respaced_plaintext/nathist_pre_encryption_respaced_plaintext.txt':'e1cca30c06fb5f99aff480e1e128245529b63a35',
}

def blob_hash(data:bytes)->str:
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def get_file(path:Path,name:str,download:bool)->str:
    dest=path/name
    if not dest.is_file():
        if not download: raise FileNotFoundError(f'Missing {dest}; use --download or supply the original file locally')
        dest.parent.mkdir(parents=True,exist_ok=True)
        with urlopen(ROOT+name,timeout=60) as response:dest.write_bytes(response.read())
    data=dest.read_bytes()
    found=blob_hash(data)
    if found!=FILES[name]:
        raise ValueError(f'Git blob integrity mismatch for {name}: {found} != {FILES[name]}')
    return data.decode('utf-8-sig')


def build_maps(csv_text):
    rows=list(csv.DictReader(io.StringIO(csv_text)))
    U,P,S={},{},{}
    word_types=set()
    unigram_strings=set()
    for x in rows:
        code,glyph=x['code'],x['glyphs']
        word_types.add(glyph)
        if code.startswith('unigram_'):
            U[glyph]=code.split('_')[-1];unigram_strings.add(glyph)
        elif code.startswith('prefix_'):P[glyph]=code.split('_')[-1]
        elif code.startswith('suffix_'):S[glyph]=code.split('_')[-1]
    # Enumerate the cipher's generative vocabulary, not just the CSV cells.
    grammar=defaultdict(set)
    for glyph,letter in U.items():grammar[glyph].add(letter)
    for a,letter1 in P.items():
        for b,letter2 in S.items():
            token=a+b
            if token not in unigram_strings:grammar[token].add(letter1+letter2)
    return U,P,S,word_types,grammar


def decrypt_one(token,U,P,S,word_types,compound=True):
    # BASIC=True, MARK_COMPOUND=True: same preference as original script.
    u=U.get(token)
    if u:return u
    opts=list(dict.fromkeys((P[token[:i]]+S[token[i:]] for i in range(1,len(token))
                            if token[:i] in P and token[i:] in S)))
    if len(opts)==1:return opts[0]
    if len(opts)>1:return '('+'|'.join(opts)+')'
    if not compound:return '[?]'
    cand=[]
    for i in range(1,len(token)):
        left,right=token[:i],token[i:]
        l=decrypt_one(left,U,P,S,word_types,False) if left in word_types else '[?]'
        r=decrypt_one(right,U,P,S,word_types,False) if right in word_types else '[?]'
        if l!='[?]' and r!='[?]':cand.append((l+' '+r,abs(len(left)-len(right))))
    if not cand:return '[?]'
    cand.sort(key=lambda x:x[1])
    first=cand[0][0]+'*'
    return first if len(cand)==1 else '('+'|'.join([first]+[a for a,d in cand[1:]])+')'


def segmentation_count(text:str,grammar,exact_n=None,cap=1000000):
    length_max=max(map(len,grammar))
    @lru_cache(None)
    def sub(index,count):
        if index==len(text):return int(count>=2 and (exact_n is None or count==exact_n))
        if exact_n is not None and count>=exact_n:return 0
        total=0
        for j in range(index+1,min(len(text),index+length_max)+1):
            forms=grammar.get(text[index:j])
            if forms:total+=len(forms)*sub(j,count+1)
            if total>cap:return cap+1
        return total
    return sub(0,0)


def audit(tables,raw,respaced,plaintext):
    U,P,S,word_types,grammar=build_maps(tables)
    raw_lines=raw.splitlines();merged_lines=respaced.splitlines();plain_lines=plaintext.splitlines()
    if len(raw_lines)!=len(merged_lines) or len(raw_lines)!=len(plain_lines):
        raise ValueError('Line count mismatch')
    counts={'lines_with_text':0,'raw_tokens':0,'raw_exact':0,'raw_explicitly_ambiguous':0,
        'raw_unknown':0,'raw_wrong_single':0,'respaced_tokens':0,'merged_groups':0,
        'removed_boundaries':0,'original_tokens_inside_merged':0,
        'published_decoder_merged_exact_unambiguous':0,
        'published_decoder_merged_unknown':0,
        'published_decoder_merged_other':0,
        'grammar_unique_segmentations':0,'grammar_multiple_segmentations':0,
        'grammar_no_segmentations':0,'true_reading_in_grammar':0,
        'grammar_unique_matches_truth':0,'two_ngram_merges':0,
        'three_or_more_ngram_merges':0,'two_ngram_uniquely_decodable_if_count_known':0}
    examples=[]
    for i,(raw_line,resp_line,plain_line) in enumerate(zip(raw_lines,merged_lines,plain_lines)):
        a,b,c=raw_line.split(),resp_line.split(),plain_line.split()
        if not a and not b and not c:continue
        counts['lines_with_text']+=1
        if len(a)!=len(c):raise ValueError(f'Plaintext mismatch on source line {i+1}')
        if ''.join(a)!=''.join(b):raise ValueError(f'Respacing changed ciphertext letters on source line {i+1}')
        counts['raw_tokens']+=len(a);counts['respaced_tokens']+=len(b)
        for g,p in zip(a,c):
            d=decrypt_one(g,U,P,S,word_types)
            if d==p:counts['raw_exact']+=1
            elif d=='[?]':counts['raw_unknown']+=1
            elif d.startswith('('):counts['raw_explicitly_ambiguous']+=1
            else:counts['raw_wrong_single']+=1
        pos=0
        for merged in b:
            seq=[];glyph=''
            while len(glyph)<len(merged):
                if pos>=len(a):raise ValueError(f'Respacing overread on source line {i+1}')
                glyph+=a[pos];seq.append((a[pos],c[pos]));pos+=1
            if glyph!=merged:raise ValueError(f'Boundary mapping failed on line {i+1}')
            if len(seq)==1:continue
            counts['merged_groups']+=1
            counts['removed_boundaries']+=len(seq)-1
            counts['original_tokens_inside_merged']+=len(seq)
            if len(seq)==2:counts['two_ngram_merges']+=1
            else:counts['three_or_more_ngram_merges']+=1
            d=decrypt_one(merged,U,P,S,word_types)
            plain_expected=''.join(part for _,part in seq)
            # A single unambiguous reading with optional space and compound marker:
            if '|' not in d and '[?]' not in d and d.replace(' ','').replace('*','').replace('(','').replace(')','')==plain_expected:
                counts['published_decoder_merged_exact_unambiguous']+=1
            elif d=='[?]':counts['published_decoder_merged_unknown']+=1
            else:counts['published_decoder_merged_other']+=1
            num=segmentation_count(merged,grammar)
            if num==1:counts['grammar_unique_segmentations']+=1
            elif num>1:counts['grammar_multiple_segmentations']+=1
            else:counts['grammar_no_segmentations']+=1
            exists=all(expected in grammar.get(g,set()) for g,expected in seq)
            if exists:counts['true_reading_in_grammar']+=1
            if num==1 and exists:counts['grammar_unique_matches_truth']+=1
            if len(seq)==2 and segmentation_count(merged,grammar,exact_n=2)==1:
                counts['two_ngram_uniquely_decodable_if_count_known']+=1
            if len(examples)<8 and num>1:examples.append({'cipher':merged,'expected_plain_letters':plain_expected,'generated_parts':len(seq),'possible_readings':num})
        if pos!=len(a):raise ValueError(f'Trailing unmatched raw tokens, line {i+1}')
    assert counts['raw_tokens']-counts['respaced_tokens']==counts['removed_boundaries']
    return {'status':'REPRODUCIBLE_IF_PINNED_SOURCES_PRESENT',
      'method':'Mirror of basic original decoder + exhaustive grammar segmentation (no deck-state/language prior)',
      'pin':PIN,'source_blobs':FILES,'counts':counts,'example_ambiguous_merges':examples}


def self_test():
    fake='code,glyphs\nunigram_alpha_a,ol\nunigram_alpha_b,ar\nprefix_alpha_a,ch\nsuffix_alpha_b,dy\n'
    U,P,S,types,grammar=build_maps(fake)
    assert decrypt_one('ol',U,P,S,types)=='a'
    assert decrypt_one('chdy',U,P,S,types)=='ab'
    assert segmentation_count('olar',grammar)==1
    test=audit(fake,'ol ar\n','olar\n','a b\n')
    assert test['counts']['merged_groups']==1
    assert test['counts']['grammar_unique_segmentations']==1
    print('Self-test PASS')


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--source-dir',type=Path,default=Path(__file__).parent/'source_cache')
    parser.add_argument('--download',action='store_true')
    parser.add_argument('--self-test',action='store_true')
    parser.add_argument('--output',type=Path,default=Path(__file__).parent/'recomputed.json')
    args=parser.parse_args()
    if args.self_test:self_test();return
    fields=[get_file(args.source_dir,key,args.download) for key in FILES]
    result=audit(*fields)
    args.output.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(result['counts'],indent=2))

if __name__=='__main__':main()
