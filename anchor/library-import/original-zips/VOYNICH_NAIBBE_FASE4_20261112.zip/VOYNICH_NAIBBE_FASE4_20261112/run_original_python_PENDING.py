#!/usr/bin/env python3
"""Download and run Greshko's exact pinned Python source with deterministic seeds.

THIS SCRIPT IS A FUTURE VERIFICATION RUNNER, NOT AN EXECUTION REPORT.
Citation: Greshko, M. A. (2025), Cryptologia, doi:10.1080/01611194.2025.2566408

Requires Python 3.11+ and pandas. Network for first invocation only.
Original source and tables remain unmodified. Generates a new output directory.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import runpy
import shutil
from urllib.request import urlopen

BASE=Path(__file__).resolve().parent
PIN='5145f526b52741a6dca14201147f687e62c7162e'
FILES={
 'naibbe.py':'910b7a99532f4630cb59917f9df3de8e98808598',
 'naibbe_v2.py':'b566ad82e4b6ff0782ecdddebf77718dac44f292',
 'references/naibbe_tables.csv':'5cd34fb81d80faf3b4d57dbf1719c05ffde25302',
 'input/examples/nathist_book16.txt':'453d8e1cb7a6626c02bb53467c329ab127d89006'
}
BANDS={'density':(.91,.96),'adjacency':(.02,.04),'repetition':(.045,.07),'hapax':(.65,.75)}
STEMS=set('aiin air chedy chey chol ckhey daiin dam dar kaiin kain kair kal kam kar kchdy kchedy kchey kchol kchor kchy kedy keear keedy keeedy keeey keeo keeody keeol keeor keey keody keol keor key kody koiin kol kor pair par pchdy pchedy pchol shey taiin tain tair tal tam tar tchedy tchey tcho tchol tchor tchy tedy teedy teeey teeo teey teody teol teor tey tody tol tor'.split())


def blob_hash(data):
 return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()


def obtain(cache):
 for name,expect in FILES.items():
  p=cache/name
  if not p.exists():
   p.parent.mkdir(parents=True,exist_ok=True)
   url=f'https://raw.githubusercontent.com/greshko/naibbe-cipher/{PIN}/{name}'
   with urlopen(url,timeout=60) as f:p.write_bytes(f.read())
  actual=blob_hash(p.read_bytes())
  if actual!=expect:raise ValueError(f'Git blob mismatch for {name}: {actual} != {expect}')


def d1_close(types):
 close=set(); seen={}
 for w in types:
  for i in range(len(w)):
   shorter=w[:i]+w[i+1:]
   if shorter in types:close.add(w);close.add(shorter)
   pattern=w[:i]+'*'+w[i+1:]
   if pattern in seen and seen[pattern]!=w:close.add(w);close.add(seen[pattern])
   else:seen.setdefault(pattern,w)
 return close


def metrics(tokens,rows):
 c=Counter(tokens)
 good=d1_close(set(c));close=sum(c[w] for w in good)
 hapax=sum(1 for q in c.values() if q==1)
 adj=rep=0.0
 for a,b in zip(rows,rows[1:]):
  A,B=set(a),set(b)
  adj+=len(A&B)/len(A|B) if (A|B) else 0
  rep+=sum(w in A for w in b)/len(b) if b else 0
 return {'density':close/len(tokens),'adjacency':adj/(len(rows)-1),'repetition':rep/(len(rows)-1),'hapax':hapax/len(c),'types':len(c)}


def yo(rows,stems=None):
 d={}
 for line in rows:
  for pos,w in enumerate(line):
   if len(w)<4 or w[0] not in ('y','o'):continue
   suffix=w[1:]
   if stems is not None and suffix not in stems:continue
   z=d.setdefault(suffix,[0,0,0,0]);z[(0 if w[0]=='y' else 2)+(0 if pos==0 else 1)]+=1
 num=den=0.0;ns=0
 for a,b,c,d0 in d.values():
  if a+b<2 or c+d0<2 or a+c==0 or b+d0==0:continue
  n=a+b+c+d0;num+=a*d0/n;den+=b*c/n;ns+=1
 return (num/den if den else None),ns


def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('--cache',type=Path,default=BASE/'greshko_pinned_sources')
 ap.add_argument('--output',type=Path,default=BASE/'python_native_results.csv')
 ap.add_argument('--min-seed',type=int,default=1001)
 ap.add_argument('--max-seed',type=int,default=1030)
 args=ap.parse_args()
 obtain(args.cache)
 import pandas  # noqa: F401: original source requires pandas
 test=BASE/'zl3b_P_ms408.tsv'
 lens=[]
 with test.open(encoding='utf8') as f:
  for line in f:
   k,sep,data=line.partition('\t')
   if sep:lens.append(len(data.split()))
 N=sum(lens)
 assert (len(lens),N)==(4130,34323)
 workspace=BASE/'python_native_workspace'
 for sub in ['references','input/examples','encrypted','respaced_plaintext']:(workspace/sub).mkdir(parents=True,exist_ok=True)
 shutil.copy2(args.cache/'references/naibbe_tables.csv',workspace/'references/naibbe_tables.csv')
 for path in ['nathist_book16.txt','divina_commedia.txt']:
  shutil.copy2(args.cache/'input/examples/nathist_book16.txt',workspace/'input/examples'/path)
 # Both versions encrypt EXACTLY the same Latin source; v1's hard-coded filename is relabelled.
 old_cwd=Path.cwd()
 cols=['version','seed','generated','types','density','adjacency','repetition','hapax','axes_in_band','yo_or','yo_n','yo_fixed_or','yo_fixed_n']
 args.output.parent.mkdir(parents=True,exist_ok=True)
 try:
  os.chdir(workspace)
  with args.output.open('w',encoding='utf8',newline='') as fout:
   writer=csv.DictWriter(fout,fieldnames=cols);writer.writeheader()
   for version in (1,2):
    src=(args.cache/('naibbe.py' if version==1 else 'naibbe_v2.py')).resolve()
    output=workspace/'encrypted'/('divcom_output_ciphertext.txt' if version==1 else 'nathist_output_ciphertext_bigram_unambig.txt')
    for seed in range(args.min_seed,args.max_seed+1):
     random.seed(seed)
     runpy.run_path(str(src),run_name='__main__')
     tokens=output.read_text(encoding='utf8').split()
     if len(tokens)<N:raise ValueError(f'Version {version} seed {seed} short: {len(tokens)}')
     pointer=0;rows=[]
     for n in lens:rows.append(tokens[pointer:pointer+n]);pointer+=n
     m=metrics(tokens[:N],rows);y,ny=yo(rows);yfix,nfix=yo(rows,STEMS)
     flags=[k for k,(a,b) in BANDS.items() if a<=m[k]<=b]
     row={'version':version,'seed':seed,'generated':len(tokens),**m,'axes_in_band':'|'.join(flags),'yo_or':y,'yo_n':ny,'yo_fixed_or':yfix,'yo_fixed_n':nfix}
     writer.writerow({k:row[k] for k in cols});fout.flush()
     print('Original-Python:',version,seed,'in band',len(flags),'/4','y/o',y)
 finally:
  os.chdir(old_cwd)
 print('Completed output:',args.output)

if __name__=='__main__':main()
