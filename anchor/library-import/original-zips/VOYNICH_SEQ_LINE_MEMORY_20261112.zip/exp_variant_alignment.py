#!/usr/bin/env python3
"""EXP-SEQ-HORIZONTAL-01: Is a same-stem near-variant horizontally aligned across rows?
Analytic random-position null conditional on row lengths and number of edit1 matches.
Caveat: naive position null does NOT control the form-specific positional grammar.
"""
import json,math,csv
from pathlib import Path
from functools import lru_cache
from collections import defaultdict
import numpy as np
p=Path(__file__).with_name('exp_line_memory.py')
script=p.read_text();ns={'__file__':str(p),'__name__':'__module__'}
exec(compile(script[:script.index('rng=np.random.default_rng(SEED)')],str(p),'exec'),ns)
F=ns['folio_data'];words=ns['words']; edit1=ns['edit1']
seed=20261112
@lru_cache(maxsize=None)
def expectation(nprev,ncur,k):
 if k>nprev:raise ValueError()
 norm=lambda i,n: .5 if n==1 else i/(n-1)
 denominator=math.comb(nprev,k)
 total=0
 for j in range(ncur):
  distances=sorted(abs(norm(i,nprev)-norm(j,ncur)) for i in range(nprev))
  value=sum(distances[ix]*math.comb(nprev-ix-1,k-1)/denominator for ix in range(nprev-k+1))
  total+=value/ncur
 return total
rec=[]
for f in F:
 ids=[i for i,(fol,_) in enumerate(ns['rows']) if fol==f['folio']]
 for pp in f['paragraphs']:
  for lag in [1,2,3,4]:
   if len(pp)<=lag:continue
   for j in range(len(pp)-lag):
    prev=words[ids[int(pp[j])]];cur=words[ids[int(pp[j+lag])]]
    prevset=set(prev)
    for c,w in enumerate(cur):
     if w in prevset:continue
     matching=[i for i,v in enumerate(prev) if edit1(w,v)]
     if not matching:continue
     pos=lambda ix,n: .5 if n==1 else ix/(n-1)
     actual=min(abs(pos(c,len(cur))-pos(i,len(prev))) for i in matching)
     exp=expectation(len(prev),len(cur),len(matching))
     rec.append({'folio':f['folio'],'currier':f['currier'],'lag':lag,'actual':actual,'expected':exp,'diff':actual-exp,
                 'prev_len':len(prev),'cur_len':len(cur),'match_count':len(matching)})

out={'metadata':{'status':'EXPLORATORY','seed':seed,'measure':'minimum absolute normalized word-index displacement for unseen edit1 variant in previous row','null':'expected displacement for uniform random independent word ordering conditional on row lengths and edit1 match count; no form-specific position conditioning'}}
for group in ['ALL','A','B']:
 out[group]={}
 for lag in [1,2,3,4]:
  arr=[z for z in rec if z['lag']==lag and (group=='ALL' or z['currier']==group)]
  if not arr:continue
  d=np.array([z['diff'] for z in arr]);A=np.array([z['actual'] for z in arr]);E=np.array([z['expected'] for z in arr]);
  folios=sorted(set(z['folio'] for z in arr));byF={f:[z['diff'] for z in arr if z['folio']==f] for f in folios}
  rng=np.random.default_rng(seed+lag+(0 if group=='ALL' else 10 if group=='A' else 20));B=2999;boot=np.empty(B)
  for b in range(B):
   sample=rng.choice(folios,size=len(folios),replace=True)
   boot[b]=sum(sum(byF[f]) for f in sample)/sum(len(byF[f]) for f in sample)
  out[group][f'lag{lag}']={'n_matched_tokens':len(arr),'folios':len(folios),'observed_abs_displacement':float(A.mean()),
                'random_position_expected':float(E.mean()),'difference':float(d.mean()),'ratio':float(A.mean()/E.mean()),
                'bootstrap_diff_ci95':[float(np.quantile(boot,x)) for x in [.025,.975]],'mean_match_count':float(np.mean([z['match_count'] for z in arr]))}
( p.parent/'alignment_results.json').write_text(json.dumps(out,indent=2))
with (p.parent/'alignment_tokenlevel.csv').open('w',newline='') as o:
 w=csv.DictWriter(o,fieldnames=list(rec[0]));w.writeheader();w.writerows(rec)
for group in out:
 if group=='metadata':continue
 print(group)
 for k,z in out[group].items():
  print(' ',k,z['n_matched_tokens'],'actual',round(z['observed_abs_displacement'],4),'null',round(z['random_position_expected'],4),'ratio',round(z['ratio'],3),'boot CI',list(map(lambda q:round(q,4),z['bootstrap_diff_ci95'])))
