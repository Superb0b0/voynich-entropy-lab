# VOYNICH | EXP-SEQ-LINE-MEMORY-01

**Data:** 12 novembre 2026. **Stato: esplorativo, non preregistrato, nessuna decifrazione.**  
**Oggetto:** dipendenze lessicali fra righe e verifica di previsioni alternative basate su geometria, ordine del paragrafo e posizione orizzontale.  
**Perimetro:** esclusivamente il corpus testuale P-only e il parser RC1.2 in sola lettura. La pipeline RC1.4.2 rimane `CLOSED_PENDING_VALIDATION`.

## Sintesi dei risultati

Il testo Voynich è più simile lungo righe contigue di quanto previsto da rimescolamenti che preservano **integralmente le parole di ogni paragrafo**. L'effetto ricorre in Currier A e B. Per le somiglianze fra parole esatte e quasi identiche è concentrato nelle prime due distanze fra righe, mentre la terza e le successive non mostrano un eccesso Jaccard convincente nel benchmark usato.

**Limite determinante:** questa dipendenza statistica *non si traduce* in buona capacità di scegliere la vera riga successiva quando due candidate hanno identica lunghezza e non sono linee terminali. Inoltre il vantaggio di allineamento orizzontale delle varianti non sopravvive al rimescolamento dell'ordine delle righe. Un modello di copiatura verticale letterale non è quindi dimostrato.

## Input e integrità

- `inputs/ZL3b-n.txt`: SHA-256 `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc`.
- `inputs/zl3b_P_ms408.tsv`: SHA-256 `41c3ea40b7f71ea612fbee49a65ebd253231a209ce2d5096131126c957bcd1f2`.
- `inputs/ivtff_parser_rc1_2.py`: SHA-256 `8a614436a2d5dc3cb30c282743929aaa21a379d9da7e691b4277c670ce2a91c5`.
- 207 folii, 4.130 righe P-only, 34.323 token, **740 paragrafi** identificati dai marcatori `<%>` del parser, con 3.390 coppie interne di righe adiacenti.
- Il confronto esclude transizioni tra folii, a differenza della metrica storica aggregata su tutto il corpus.

## Protocollo principale: ordine delle righe

Per ogni coppia diretta di righe \(R_i, R_j\), tre misure sono state fissate prima dell'esame dei risultati: **Jaccard fra insiemi di parole**; **frazione delle occorrenze della seconda riga presenti nella precedente**; **frazione delle occorrenze con almeno un vicino a distanza di Levenshtein 1 nella precedente, esclusa la parola identica come coppia**. Le ultime due sono medie di rapporti per riga. Per i controlli sono state prodotte 1.999 permutazioni deterministiche, seed `20261112`, più intervalli bootstrap per folio con 2.499 ricampionamenti.

| Misura | Osservato nello stesso paragrafo | Media nulla | Eccesso | p unilaterale |
|---|---:|---:|---:|---:|
| Jaccard | 0.03159 | 0.02742 | +15.2% | 0.0005 |
| Ripetizione esatta | 0.06555 | 0.05457 | +20.1% | 0.0005 |
| Varianti a un edit | 0.20218 | 0.17325 | +16.7% | 0.0005 |

- **Nullo F:** permutazione di tutte le righe all'interno del folio, conservando il vocabolario della pagina e le righe stesse.
- **Nullo P (principale):** permutazione limitata all'interno di ciascun paragrafo, conservando lessico, lunghezze delle singole righe e folio.
- **Nullo EP:** prima e ultima riga di ogni paragrafo bloccate; permutazione soltanto delle righe intermedie, con paragrafi di almeno quattro righe.

### Controllo EP, primi e ultimi righi fissi

| Misura | Osservato | Media nulla | Eccesso | p unilaterale |
|---|---:|---:|---:|---:|
| Jaccard | 0.03203 | 0.03033 | +5.6% | 0.0025 |
| Ripetizione esatta | 0.06558 | 0.06172 | +6.3% | 0.0010 |
| Varianti a un edit | 0.20438 | 0.19296 | +5.9% | 0.0005 |

### Controllo sulle lunghezze

In un ulteriore nullo esplorativo sono state scambiate soltanto righe **interne** appartenenti allo stesso paragrafo e alla stessa fascia di lunghezza (1–3, 4–6, 7–9, 10–12, ≥13 token); anche apertura e chiusura del paragrafo sono fisse. Questo è più severo perché una grande quota delle righe resta immobile. Si sono potute permutare 2.164 posizioni in 440 paragrafi.

| Misura | Eccesso rispetto al nullo | p unilaterale |
|---|---:|---:|
| Jaccard | +3.5% | 0.0260 |
| Ripetizione esatta | +4.6% | 0.0090 |
| Varianti a un edit | +4.6% | 0.0010 |
| Varianti a un edit, parole assenti nella riga precedente | +4.4% | 0.0010 |

Il p=0,026 di Jaccard in questo test **non** resta sotto 0,05 applicando una correzione conservativa per più metriche; l'analisi resta esplorativa. Gli altri valori non conferiscono di per sé un'interpretazione semantica.

## Profilo delle distanze (paragrafi ≥6 righe)

| Distanza | Coppie | Jaccard reale | Jaccard nullo | p unilaterale |
|---|---:|---:|---:|---:|
| 1 | 2164 | 0.03301 | 0.02869 | 0.0010 |
| 2 | 1905 | 0.03313 | 0.02885 | 0.0010 |
| 3 | 1646 | 0.02924 | 0.02901 | 0.3970 |
| 4 | 1387 | 0.02944 | 0.02924 | 0.4380 |
| 5 | 1128 | 0.02815 | 0.02948 | 0.8670 |

![Profilo delle distanze](lag_jaccard.png)

**Interpretazione:** un eccesso locale di somiglianza alle distanze 1 e 2, senza eccesso Jaccard convincente dalle distanze 3 a 5, nel campione dei paragrafi lunghi. Non deduce una finestra generativa con memoria esattamente due.

## Replicazione fra le trascrizioni ZL3b e IT2a (Takahashi)

Il corpus IT2a, disponibile nella Library, è stato acquisito nei suoi **342.104 byte originali**, SHA-256 `7f27a8b0feed8f6de0a99900df6bf912dd1d295c38e5f830bac8b41c3f536fb5`. Il parser RC1.2 è stato utilizzato in sola lettura con disattivazione della *sola* verifica che l'input sia il file ZL: l'hash IT2a è controllato separatamente. Per la comparazione sono stati usati **4.118 loci P comuni**, ignorando i 12 presenti soltanto in ZL; eventuali interruzioni nella sequenza o marcatori nuovi di paragrafo in una delle due trascrizioni spezzano il gruppo. Restano **3.333 coppie adiacenti** sullo stesso locus, con uguali confini nei due test.

Soltanto il **37,3%** delle righe ha esattamente la stessa sequenza di token nelle due trascrizioni; nel **62,6%** è uguale il conteggio dei token. Quindi il risultato non deriva da dati testuali identici.

| Misura | Eccesso ZL3b rispetto a nulla interna al paragrafo | Eccesso IT2a | p per ciascuna trascrizione |
|---|---:|---:|---:|
| Jaccard | +14.6% | +15.0% | 0.00067 |
| Ripetizione esatta | +19.3% | +18.6% | 0.00067 |
| Varianti a un edit | +16.2% | +15.9% | 0.00067 |
| Varianti nuove a un edit | +15.1% | +14.5% | 0.00067 |

I valori sono stati verificati anche separatamente in Currier A e Currier B. In un bootstrap appaiato per folio con 3.999 campioni, le differenze negli eccessi relativi IT2a meno ZL3b sono compatibili con zero. Per Jaccard, ad esempio, l'IC 95% della differenza nel **rapporto** osservato/nullo è da −0,020 a +0,029.

**Portata:** è una robustezza *fra letture dello stesso manoscritto*, non una seconda scoperta indipendente. La significatività è condizionale alla specifica ipotesi nulla scelta, e le stesse righe Voynich sono già state studiate in altri esperimenti. Un test su un secondo manoscritto o una decifrazione richiederebbero criteri completamente diversi.

![Confronto trascrizioni](transcription_replication.png)

## Una prova predittiva deliberatamente severa

Compito: dati una riga precedente e due candidate successive **dello stesso paragrafo**, identificare la vera riga immediatamente successiva rispetto a una riga più lontana. Separazione per folio fra addestramento (137 folii) e controllo (60). Per non rivelare la risposta, il modello usa soltanto le misure lessicali di coppia e/o le lunghezze delle righe, mai l'indice della candidata o la sua distanza.

| Modello | Confronti di controllo | Accuratezza | IC 95% bootstrap per folio |
|---|---:|---:|---:|
| Solo lunghezze | 818 | 73.0% | 68.5%–77.3% |
| Solo similarità lessicale | 818 | 59.4% | 55.9%–62.7% |
| Combinato | 818 | 74.3% | 70.0%–78.1% |

Il modello combinato supera il solo modello geometrico di **1.3 punti percentuali**, ma l'intervallo bootstrap per questa differenza comprende lo zero: -0.48 a 3.02 punti. Per questo non interpretiamo il 74.3% come capacità di lettura del Voynich.

### Controllo post hoc: stessa lunghezza, nessuna riga finale

La vera candidata e quella alternativa hanno la **stessa lunghezza esatta** in token; entrambe sono righe *non finali* del paragrafo. Il modello può vedere soltanto Jaccard, ripetizione e distanza di un edit.

- 760 confronti di addestramento, **292 confronti su 56 folii riservati**.
- Accuratezza **52.2%**, IC 95% per folio 46.7%–57.5%, p per sign-flip dei folii **0.238**.
- Nessuna prova affidabile di predizione oltre il caso nel sottocampione strettamente appaiato. La riduzione di campione rende il test meno potente, non prova che una dipendenza lessicale sia assente.

## Posizione orizzontale: un falso indizio di copiatura?

Le parole mai viste nella riga precedente ma distanti **un edit** da almeno una parola in essa appaiono più vicine orizzontalmente di quanto atteso se le parole fossero distribuite uniformemente sulla lunghezza della riga. Questo apparente allineamento si osserva tuttavia anche a distanza 3 e 4, non soltanto tra righe contigue.

Con un nullo che conserva **ogni parola nella sua posizione** e permuta soltanto le righe interne allo stesso paragrafo, l'allineamento non risulta speciale per coppie originariamente consecutive:

- Edit-varianti esaminate: **5359**.
- Scarto osservato rispetto a posizioni uniformi: **-0.0281**.
- Media nulla con ordine delle righe permutato: **-0.0295**; p inferiore = **0.696**.

Questo è un **risultato contrario** alla versione semplice dell'ipotesi che le forme siano copiate da una riga alla successiva mantenendo la stessa posizione orizzontale. Una grammatica con preferenze di posizione può produrre l'allineamento di base anche senza copiatura.

## Confronto con la letteratura

Queste osservazioni non sono dichiarate una scoperta inedita. Silvio de Carvalho, in uno studio online del **27 settembre 2026**, ha già riportato un arricchimento delle quasi-copie nella riga superiore e una diminuzione dell'effetto con la distanza. Il suo controllo usa una riga casuale esterna alla pagina e la trascrizione Takahashi, mentre questo dossier condiziona per paragrafo e usa il corpus ZL3b P-only. **Gli odds ratio e i rapporti non sono direttamente confrontabili.**  
Fonte: https://silviodc.de/ai-projects/voynich/

Anche l'analisi su voynich.site (stato autoriale aggiornato al 18 ottobre 2026) riporta effetti specifici degli inizi di riga, con controlli tramite reflow. È una classe di evidenza distinta dal nostro confronto lessicale:  
Fonte: https://voynich.site/en/findings/line-openers/

Le fonti sono studi pubblicati online, non automaticamente prove con revisione paritaria; i rispettivi campioni, strumenti e nulli differiscono.

## Conclusione e ipotesi da falsificare

I dati richiedono di tenere distinte **tre componenti**:

1. **Coerenza lessicale di paragrafo e breve portata:** adiacenza, riuso e vicinanza grafica eccedono il nullo per i paragrafi originali.
2. **Geometria delle righe:** molte previsioni sulla successione derivano dalle lunghezze, non dal lessico.
3. **Vincoli posizionali sulle forme:** l'allineamento delle quasi-copie non richiede che quelle righe si succedano in ordine reale.

Una prossima ipotesi *non calibrata sui risultati* dovrà specificare un meccanismo che genera congiuntamente le tre proprietà, non limitarsi a riprodurre il 0,0284 storico di Jaccard. Prima di qualsiasi interpretazione semantica serviranno controlli incrociati su Takahashi e dati con diversa segmentazione, positivi sintetici e negativi testuali, non soltanto la stessa trascrizione ricampionata.

## Riproduzione offline

Requisiti: Python 3.11+ con `numpy`, `scipy`, `scikit-learn`, `matplotlib` (solo per grafici).

I file di input verificati e il parser RC1.2 sono inclusi in `inputs/`; gli script **non** scrivono sui file originali.

```bash
python exp_line_memory.py
python exp_it2a_replication.py
python exp_lag_and_currier.py
python exp_next_line_prediction.py
python exp_predict_length_matched.py
python exp_variant_alignment.py
python exp_alignment_paragraph_null.py
python build_dossier.py
```

Tutti gli output originari sono presenti in JSON/CSV. Ripetere il codice può richiedere più tempo, soprattutto per gli esperimenti di allineamento; se non è disponibile il calcolo, i dati osservati restano consultabili direttamente. Il corpus non viene modificato. La pipeline visivo-testuale RC1.4.2 non viene avviata.

**Avvertenza metodologica:** ogni p empirica misura la deviazione rispetto al nullo specifico; non tiene conto di tutte le scelte e le analisi della ricerca pregressa. L'analisi è esplorativa e non è preregistrazione né decifrazione.
