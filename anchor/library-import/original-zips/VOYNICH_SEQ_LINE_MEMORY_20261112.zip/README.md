# Voynich · EXP-SEQ-LINE-MEMORY-01

Leggi `RAPPORTO.md` per il contesto completo.

Codice, risultati e input verificati inclusi. Analisi esplorativa, nessuna decifrazione.

Avvio:

```bash
pip install -r requirements.txt
python exp_line_memory.py
python exp_it2a_replication.py
python exp_lag_and_currier.py
python exp_next_line_prediction.py
python exp_predict_length_matched.py
python exp_variant_alignment.py
python exp_alignment_paragraph_null.py
```

Il codice carica i dati dalla cartella `inputs/` e scrive soltanto nella directory dei risultati.
