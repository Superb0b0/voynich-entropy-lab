#!/usr/bin/env python3
"""Control for horizontal-alignment confounding via randomizing whole row order within paragraphs.
This preserves every word's original horizontal location and paragraph vocabulary.
"""
from pathlib import Path
import json,math,csv
from functools import lru_cache
from collections import defaultdict
import numpy as np
P=Path(__file__).with_name('exp_line_memory.py');T=P.read_text()
ns={'__file__':str(P),'__name__':'__module__'}
exec(compile(T[:T.index('rng=np.random.default_rng(SEED)')],str(P),'exec'),ns)
F=ns['folio_data'];W=ns['words']; edit1=ns['edit1']
@lru_cache(maxsize=None)
def expected(nprev,ncur,k):
 N=math.comb(nprev,k);s=0
 for v in range(ncur):
  y=.5 if ncur==1 else v/(ncur-1)
  d=sorted(abs((.5 if nprev==1 else j/(nprev-1))-y) for j in range(nprev))
  s+=sum(d[i]*math.comb(nprev-i-1,k-1)/N for i in range(nprev-k+1))/ncur
 return s

def pair(prev,cur):
 a=W[prev];b=W[cur]; aset=set(a);sum_o=0.;sum_e=0.;count=0
 for j,w in enumerate(b):
  if w in aset:continue
  ix=[i for i,x in enumerate(a) if edit1(w,x)]
  if not ix:continue
  pos=lambda k,n: .5 if n==1 else k/(n-1)
  sum_o+=min(abs(pos(i,len(a))-pos(j,len(b))) for i in ix)
  sum_e+=expected(len(a),len(b),len(ix))
  count+=1
 return np.array([sum_o,sum_e,count],dtype=float)

panels=[];obs=np.zeros(3)
for f in F:
 global_ids=[i for i,(ff,_) in enumerate(ns['rows']) if ff==f['folio']]
 for p in f['paragraphs']:
  if len(p)<2:continue
  n=len(p);mat=np.zeros((3,n,n))
  for i in range(n):
   for j in range(n):
    if i!=j:mat[:,i,j]=pair(global_ids[int(p[i])],global_ids[int(p[j])])
  order=np.arange(n)
  obs+=mat[:,order[:-1],order[1:]].sum(axis=1)
  panels.append((f['currier'],mat))
B=1999;rng=np.random.default_rng(20261112+999)
null=np.zeros((B,3));obsBy={q:np.zeros(3) for q in 'AB?'};nullBy={q:np.zeros((B,3)) for q in 'AB?'}
for group,M in panels:
 n=M.shape[1];z=np.arange(n)
 obsBy[group]+=M[:,z[:-1],z[1:]].sum(axis=1)
for k in range(B):
 for group,M in panels:
  n=M.shape[1];order=rng.permutation(n)
  s=M[:,order[:-1],order[1:]].sum(axis=1)
  null[k]+=s;nullBy[group][k]+=s

def describe(obs,ref):
 o=obs[0]/obs[2];e=obs[1]/obs[2];v=(ref[:,0]-ref[:,1])/ref[:,2]
 d=o-e
 return {'matching_words_observed':int(obs[2]),'observed_abs_distance':float(o),'observed_random_position_expected':float(e),
         'observed_distance_excess':float(d),'null_mean_distance_excess':float(v.mean()),
         'null_q025_q975':[float(a) for a in np.quantile(v,[.025,.975])],
         'p_below':float((1+(v<=d).sum())/(B+1)), 'p_above':float((1+(v>=d).sum())/(B+1))}
result={'date':'2026-11-12','status':'EXPLORATORY','description':'All paragraph lines in original place; compare horizontal closeness of nonidentical edit1 variants to a null of permuted lines within same paragraph, preserving every word and position','n_permutations':B,'ALL':describe(obs,null)}
for cl in 'AB?':result[cl]=describe(obsBy[cl],nullBy[cl]) if obsBy[cl][2]>0 else None
(P.parent/'alignment_paragraph_shuffle.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
