#!/usr/bin/env python3
"""Secondary exploratory stress tests: Currier-specific, lag profiles and length-constrained null.
Read-only. Shares verified source/metric code with exp_line_memory.py.
"""
from pathlib import Path
import json, csv
import numpy as np
p=Path(__file__).with_name('exp_line_memory.py')
src=p.read_text(); split=src.index('rng=np.random.default_rng(SEED)')
ns={'__file__':str(p),'__name__':'__module__'}
exec(compile(src[:split],str(p),'exec'),ns)
F=ns['folio_data']; W=ns['words']; S=ns['sets']; edit1=ns['edit1']; SEED=ns['SEED']
OUT=p.parent
B=999
rng=np.random.default_rng(SEED+10)
classes=['A','B','?']
metrics=['jaccard','exact_reuse','edit1_nonidentical','edit1_on_unseen_token']
# Add an explicitly distinct lexical-variant metric: current token NOT in previous row.
for f in F:
 M=f['matrix'];n=f['n'];gids=[]
 # Folio's global rows are consecutive in our P-only corpus; recover by first row of folio.
 # map via source parser same folio order
 inds=[i for i,(fol,_) in enumerate(ns['rows']) if fol==f['folio']]
 Q=np.zeros((n,n),float)
 for i in range(n):
  pre=S[inds[i]]
  for j in range(n):
   if i==j:continue
   cur=W[inds[j]]
   Q[i,j]=sum((w not in pre) and any(edit1(w,x) for x in pre) for w in cur)/len(cur)
 f['matrix4']=np.concatenate([M,Q[None,:,:]],axis=0)
 f['global_ids']=inds
 f['bin_groups']=[]
 for pp in f['paragraphs']:
  bins={}
  for localpos in range(1,len(pp)-1):
   count=len(W[inds[int(pp[localpos])]])
   bucket=0 if count<=3 else 1 if count<=6 else 2 if count<=9 else 3 if count<=12 else 4
   bins.setdefault(bucket,[]).append(localpos)
  f['bin_groups'].append([np.array(ix,dtype=np.int32) for ix in bins.values() if len(ix)>=2])

obs={cl:np.zeros(4) for cl in classes}
obs_n={cl:0 for cl in classes}
null={cl:np.zeros((B,4)) for cl in classes}
# length-bin constrained, 1st and last lines always fixed.
length_null=np.zeros((B,4));obs_len=np.zeros(4);count_len=0
moved_pars=0;moved_rows=0
for f in F:
 M=f['matrix4']; cl=f['currier'];
 for para in f['paragraphs']:
  if len(para)<2:continue
  obs[cl]+=M[:,para[:-1],para[1:]].sum(axis=1);obs_n[cl]+=len(para)-1
  if len(para)<4:continue
  obs_len+=M[:,para[:-1],para[1:]].sum(axis=1);count_len+=len(para)-1

# lag stats for paragraph len>=6 with fixed population each lag 1..5.
lag_sum=np.zeros((5,4));lag_count=np.zeros(5,dtype=int)
lag_null=np.zeros((B,5,4))
for f in F:
 M=f['matrix4']
 for p in f['paragraphs']:
  if len(p)<6:continue
  for lag in range(1,6):
   lag_sum[lag-1]+=M[:,p[:-lag],p[lag:]].sum(axis=1)
   lag_count[lag-1]+=len(p)-lag

# Null P and length-conditioned null simultaneously in a single randomized stream.
for t in range(B):
 for f in F:
  M=f['matrix4'];cl=f['currier']
  for p,groups in zip(f['paragraphs'],f['bin_groups']):
   if len(p)<2:continue
   sh=rng.permutation(p)
   null[cl][t]+=M[:,sh[:-1],sh[1:]].sum(axis=1)
   if len(p)>=6:
    for lag in range(1,6):lag_null[t,lag-1]+=M[:,sh[:-lag],sh[lag:]].sum(axis=1)
   if len(p)>=4:
    q=p.copy()
    for poss in groups:
     q[poss]=rng.permutation(q[poss])
    length_null[t]+=M[:,q[:-1],q[1:]].sum(axis=1)

rows=[]
moved_pars=sum(bool(groups) for f in F for groups in f['bin_groups'])
moved_rows=sum(sum(len(q) for q in groups) for f in F for groups in f['bin_groups'])
result={'metadata':{'n_permutations':B,'seed':SEED+10,'statistics':metrics,'length_bins':'<=3, 4-6, 7-9, 10-12, >=13',
                    'endpoints_fixed':True,'movable_paragraphs':moved_pars,'movable_rows':moved_rows,
                    'lag_population':'paragraphs of >=6 P-only rows'}}
for cl in classes:
 result[cl]={'n_edges':obs_n[cl],'statistics':{}}
 for j,key in enumerate(metrics):
  real=obs[cl][j]/obs_n[cl] if obs_n[cl] else 0
  ref=null[cl][:,j]/obs_n[cl] if obs_n[cl] else np.zeros(B)
  d={'observed':float(real),'null_mean':float(ref.mean()),'excess':float(real-ref.mean()),
     'ratio':float(real/ref.mean()) if ref.mean()>0 else None,'p_above':float((1+(ref>=real).sum())/(B+1))}
  result[cl]['statistics'][key]=d;rows.append(['currier_'+cl,key,*d.values()])
result['length_constrained']={'n_edges':count_len,'statistics':{}}
for j,key in enumerate(metrics):
 real=obs_len[j]/count_len;ref=length_null[:,j]/count_len
 d={'observed':float(real),'null_mean':float(ref.mean()),'excess':float(real-ref.mean()),
    'ratio':float(real/ref.mean()) if ref.mean()>0 else None,'p_above':float((1+(ref>=real).sum())/(B+1))}
 result['length_constrained']['statistics'][key]=d;rows.append(['len_conditioned',key,*d.values()])
result['lag']={}
for k in range(5):
 key='lag_'+str(k+1)
 z={'n_pairs':int(lag_count[k]),'stats':{}}
 for j,m in enumerate(metrics):
  real=lag_sum[k,j]/lag_count[k];ref=lag_null[:,k,j]/lag_count[k]
  z['stats'][m]={'observed':float(real),'null_mean':float(ref.mean()),'excess':float(real-ref.mean()),
                 'ratio':float(real/ref.mean()) if ref.mean()>0 else None,'p_above':float((1+(ref>=real).sum())/(B+1))}
 result['lag'][key]=z
(OUT/'stress_results.json').write_text(json.dumps(result,indent=2))
with (OUT/'stress_table.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['group','metric','observed','null_mean','excess','ratio','p_above']);w.writerows(rows)
for cl in classes+['length_constrained']:
 z=result[cl];print(cl,'edges',z['n_edges']);
 for m in metrics:
  s=z['statistics'][m];print(' ',m,round(s['observed'],5),round(s['null_mean'],5),'ratio',round(s['ratio'],3),'p',s['p_above'])
print('lag behavior')
for lag,x in result['lag'].items():
 print(lag,'pairs',x['n_pairs'], 'jaccard',[(k,round(x['stats']['jaccard'][k],5)) for k in ['observed','null_mean','excess','p_above']], 'novel_edit1',round(x['stats']['edit1_on_unseen_token']['observed'],4),round(x['stats']['edit1_on_unseen_token']['null_mean'],4))
print('movable_paragraphs',moved_pars,'movable_rows',moved_rows)
