#!/usr/bin/env python3
"""Exploratory cross-transcription replication of line-memory tests on locus-matched ZL3b P-only and IT2a P lines.
Same exact loci, paragraph boundaries, and null design. Parser RC1.2 applied to IT2a with source lock explicitly off:
IT2a input SHA is separately locked here; the original ZL source parser and code are unmodified.
"""
from pathlib import Path
import csv,re,json,hashlib,importlib.util
from collections import defaultdict
from functools import lru_cache
import numpy as np
D=Path(__file__).resolve().parent
SRC=D/'inputs/ZL3b-n.txt';IT=D/'inputs/IT2a-n.txt';ZL=D/'inputs/zl3b_P_ms408.tsv';PAR=D/'inputs/ivtff_parser_rc1_2.py'
SHA={'IT2a-n.txt':'7f27a8b0feed8f6de0a99900df6bf912dd1d295c38e5f830bac8b41c3f536fb5',
'ZL3b-n.txt':'bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc',
'zl3b_P_ms408.tsv':'41c3ea40b7f71ea612fbee49a65ebd253231a209ce2d5096131126c957bcd1f2'}
for filename,dig in SHA.items():
 assert hashlib.sha256((D/'inputs'/filename).read_bytes()).hexdigest()==dig
spec=importlib.util.spec_from_file_location('orig_rc12_readonly',PAR)
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
zrec=p.parse_corpus(SRC)['records']
itr=p.parse_corpus(IT,verify_source=False)['records']
assert len(zrec)==4130 and len(itr)==4118
it_by={r['locus_id']:r for r in itr}
zbody=[]
for line in ZL.read_text().splitlines():
 fol,txt=line.split('\t');zbody.append((fol,txt.split()))
assert len(zbody)==len(zrec) and all(r['folio']==z[0] for r,z in zip(zrec,zbody))
rawZ=SRC.read_text().splitlines();rawI=IT.read_text().splitlines()
header={};group=[];par=[];current=[];n_it_extra_boundaries=0
for ln in rawZ:
 m=re.match(r'^<([^>,.]+)>\s*<!',ln)
 if m:
  g=re.search(r'\$L=([^\s>]+)',ln)
  header[m[1]]=g[1] if g else '?'
# Preserve corpus order; each paragraph is bounded by ZL and IT start markers, or a missing locus.
previous_folio=None
for z,(f,toks) in zip(zrec,zbody):
 ref=it_by.get(z['locus_id'])
 startZ='<%>' in rawZ[z['physical_line']-1]
 startI=ref is not None and '<%>' in rawI[ref['physical_line']-1]
 if startI and not startZ:n_it_extra_boundaries+=1
 if f!=previous_folio or startZ or startI or ref is None:
  if current:group.append(current);current=[]
 if ref is not None:
  current.append({'id':z['locus_id'],'folio':f,'currier':header.get(f,'?'),'zl':toks,'it':ref['tokens']})
 previous_folio=f
if current:group.append(current)
assert len([r for g in group for r in g])==len(itr)

def dist1(a,b):
 if a==b:return False
 if len(a)==len(b):return sum(x!=y for x,y in zip(a,b))==1
 if len(a)+1==len(b):return any(b[:j]+b[j+1:]==a for j in range(len(b)))
 if len(b)+1==len(a):return any(a[:j]+a[j+1:]==b for j in range(len(a)))
 return False

@lru_cache(maxsize=400000)
def metric(a,b):
 x=set(a);y=set(b);q=len(x&y);u=len(x)+len(y)-q
 jac=q/u if u else 0
 rep=sum(t in x for t in b)/len(b)
 near=sum(any(dist1(t,s) for s in x) for t in b)/len(b)
 novel=sum(t not in x and any(dist1(t,s) for s in x) for t in b)/len(b)
 return np.array([jac,rep,near,novel])

panels=[];obs=np.zeros((2,4));raw_by_folio=defaultdict(lambda:np.zeros((2,4)));expect_by_folio=defaultdict(lambda:np.zeros((2,4)));edges_by_folio=defaultdict(int)
nedges=0
for groupP in group:
 if len(groupP)<2:continue
 f=groupP[0]['folio'];M=np.zeros((2,4,len(groupP),len(groupP)),float)
 for i in range(len(groupP)):
  for j in range(len(groupP)):
   if i!=j:
    M[0,:,i,j]=metric(tuple(groupP[i]['zl']),tuple(groupP[j]['zl']))
    M[1,:,i,j]=metric(tuple(groupP[i]['it']),tuple(groupP[j]['it']))
 ids=np.arange(len(groupP));vals=sum((M[:,:,int(i),int(j)] for i,j in zip(ids[:-1],ids[1:])),np.zeros((2,4)))
 obs+=vals;raw_by_folio[f]+=vals;nedges+=len(groupP)-1
 expect_by_folio[f]+=M.sum(axis=(2,3))/len(groupP)
 edges_by_folio[f]+=len(groupP)-1
 panels.append((f,groupP[0]['currier'],M))

B=1499;rng=np.random.default_rng(20261112+1300)
null=np.zeros((B,2,4));mean_by_folio=defaultdict(lambda:np.zeros((2,4)))
currier_obs={c:np.zeros((2,4)) for c in 'AB?'}
currier_null={c:np.zeros((B,2,4)) for c in 'AB?'}
currier_edges={c:0 for c in 'AB?'}
for f,c,M in panels:
 n=M.shape[-1];idx=np.arange(n);currier_obs[c]+=sum((M[:,:,int(i),int(j)] for i,j in zip(idx[:-1],idx[1:])),np.zeros((2,4)));currier_edges[c]+=n-1
for b in range(B):
 for f,c,M in panels:
  idx=rng.permutation(M.shape[-1]); v=sum((M[:,:,int(i),int(j)] for i,j in zip(idx[:-1],idx[1:])),np.zeros((2,4)))
  null[b]+=v;currier_null[c][b]+=v;mean_by_folio[f]+=v

metrics=['jaccard','exact_reuse','edit1_nonidentical','novel_edit1']
def stats(x,y,nn):
 result={}
 for ver,vername in enumerate(['ZL3b','IT2a']):
  rr={}
  for k,m in enumerate(metrics):
   real=float(x[ver,k]/nn);nul=y[:,ver,k]/nn;mean=float(nul.mean())
   rr[m]={'observed':real,'null_mean':mean,'excess':real-mean,
          'ratio':real/mean if mean else None,'p_above':float((1+np.count_nonzero(nul>=real))/(B+1))}
  result[vername]=rr
 return result
output={'experiment':'EXP_SEQ_IT2A_REPLICATION_01','status':'EXPLORATORY_CROSS_TRANSCRIPTION','sha256':SHA,
        'parser_sha256':hashlib.sha256(PAR.read_bytes()).hexdigest(),
        'counts':{'ZL_P':len(zrec),'IT_P':len(itr),'matched_loci':len(itr),'missing_from_IT':len(zrec)-len(itr),
                  'matched_paragraph_segments':len(group),'adjacent_pairs':nedges,'extra_IT_breaks':n_it_extra_boundaries,
                  'total_matched_tokens_ZL':sum(len(r['zl']) for g in group for r in g),
                  'total_matched_tokens_IT':sum(len(r['it']) for g in group for r in g)},
        'null':{'permutations':B,'seed':20261112+1300,'within_matched_paragraph_segments':True,
                'same_locus_pairings':True,'only_shared_loci':True},
        'ALL':stats(obs,null,nedges),'currier':{c:stats(currier_obs[c],currier_null[c],currier_edges[c]) for c in 'AB' if currier_edges[c]},
        'warnings':['Transcriptions are two readings of the same manuscript, not an independent manuscript/control text.',
                    'The IT2a source lock was independently verified; parser was applied with verify_source=False and must be treated as adaptation not original validated IT-specific parser.',
                    'Only common P loci in both texts are included; gaps start new paragraph segments.',
                    'P-values conditional on manuscript-specific within-paragraph permutation null and exploratory statistic selection.']}
# Paired folio cluster bootstrap: how much do the two relative excesses differ?
BF=3999;rb=np.random.default_rng(20261112+1301)
all_f=sorted(edges_by_folio);boot_ratio=np.zeros((BF,2,4));bootstrap_difference=np.zeros((BF,4))
for jj in range(BF):
 chosen=rb.choice(all_f,size=len(all_f),replace=True)
 O=sum((raw_by_folio[f] for f in chosen),np.zeros((2,4)))
 E=sum((expect_by_folio[f] for f in chosen),np.zeros((2,4)))
 ratio=O/E
 boot_ratio[jj]=ratio
 bootstrap_difference[jj]=ratio[1]-ratio[0]
output['paired_transcription_cluster_bootstrap']={
 'n_folios':len(all_f),'resamples':BF,
 'excess_ratio_ci95':{tr:{metrics[k]:[float(v) for v in np.quantile(boot_ratio[:,t,k],[.025,.975])] for k in range(4)} for t,tr in enumerate(['ZL3b','IT2a'])},
 'IT_minus_ZL_ratio_difference_ci95':{metrics[k]:[float(v) for v in np.quantile(bootstrap_difference[:,k],[.025,.975])] for k in range(4)}
}
# Contrast token counts and strict exact matches on aligned positions.

matched=[r for gg in group for r in gg]
eq_len=sum(len(x['zl'])==len(x['it']) for x in matched)
eq_forms=sum(x['zl']==x['it'] for x in matched)
output['transcription_comparison']={'same_token_count_per_locus':eq_len,'same_full_token_sequence_per_locus':eq_forms,
                                    'fraction_same_token_count':eq_len/len(matched),'fraction_same_sequence':eq_forms/len(matched)}
(D/'IT2a_replication.json').write_text(json.dumps(output,indent=2))
with (D/'IT2a_replication_table.csv').open('w',newline='') as io:
 w=csv.writer(io);w.writerow(['stratum','transcription','metric','observed','null_mean','ratio','p_above'])
 for group_name,entry in [('ALL',output['ALL'])]+[(name,x) for name,x in output['currier'].items()]:
  for trans,measure in entry.items():
   for m,s in measure.items():w.writerow([group_name,trans,m,s['observed'],s['null_mean'],s['ratio'],s['p_above']])
print('counts',output['counts'],'matching',output['transcription_comparison'])
for tran in ['ZL3b','IT2a']:
 print('\n'+tran)
 for m,d in output['ALL'][tran].items():print(m,'obs',round(d['observed'],5),'null',round(d['null_mean'],5),'ratio',round(d['ratio'],4),'p',d['p_above'])
for currier,entries in output['currier'].items():
 print(currier,{tr:{k:(round(d['ratio'],3),d['p_above']) for k,d in metrics.items()} for tr,metrics in entries.items()})
