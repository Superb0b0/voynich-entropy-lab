#!/usr/bin/env python3
"""EXP-SEQ-NEXT-LINE-01. Held-out by folio; one later-line decoy per anchor.
Exploratory, NOT a semantic decipherment. Data and parser unchanged.
"""
from pathlib import Path
import json, csv
from collections import defaultdict
import numpy as np
from scipy.stats import binomtest
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

P=Path(__file__).with_name('exp_line_memory.py')
T=P.read_text();ns={'__file__':str(P),'__name__':'__module__'}
exec(compile(T[:T.index('rng=np.random.default_rng(SEED)')],str(P),'exec'),ns)
F=ns['folio_data'];words=ns['words'];seed=20261112
trainfolios,testfolios=set(),set()
rng=np.random.default_rng(seed+100)
for cl in ['A','B']:
 ids=[f['folio'] for f in F if f['currier']==cl]
 rng.shuffle(ids);cut=int(.7*len(ids))
 trainfolios.update(ids[:cut]);testfolios.update(ids[cut:])

# Paired comparison: given previous line, distinguish true next from a random
# later line of SAME paragraph; decoy not sampled from other topics/pages.
# Fixed one decoy per anchor, one such comparison per anchor.
examples=[]
for f in F:
 if f['currier'] not in ('A','B'):continue
 M=f['matrix'];ids=f['original'];lengths=np.array([len(words[i]) for i,(fol,_) in enumerate(ns['rows']) if fol==f['folio']])
 for paragraph in f['paragraphs']:
  if len(paragraph)<3:continue
  for pos in range(len(paragraph)-2):
   prev=int(paragraph[pos]);true=int(paragraph[pos+1]);other=int(paragraph[pos+2+rng.integers(0,len(paragraph)-pos-2)])
   def fe(t):
    return np.array([M[0,prev,t],M[1,prev,t],M[2,prev,t],
                     abs(int(lengths[prev])-int(lengths[t])),int(lengths[t])],dtype=float)
   delta=fe(true)-fe(other)
   examples.append({'folio':f['folio'],'currier':f['currier'],'n_paragraph':len(paragraph),
                    'anchor_pos':pos,'prev_len':int(lengths[prev]),'true_len':int(lengths[true]),'decoy_len':int(lengths[other]),
                    'features':delta})

train=[x for x in examples if x['folio'] in trainfolios]
test=[x for x in examples if x['folio'] in testfolios]
assert not (trainfolios & testfolios)
assert len(train)>100 and len(test)>100
Xtr=np.array([x['features'] for x in train]);Xte=np.array([x['features'] for x in test])
# Randomly orient training candidate order; 50/50 balance, no position leakage.
rng2=np.random.default_rng(seed+101)
signs=np.where(rng2.integers(0,2,len(train))==1,1,-1)
y=(signs==1).astype(int)

def score_model(name,ix):
 scaler=StandardScaler(with_mean=False)
 tr=scaler.fit_transform(Xtr[:,ix]);te=scaler.transform(Xte[:,ix])
 model=LogisticRegression(fit_intercept=False, C=1,solver='lbfgs',max_iter=300,random_state=seed)
 model.fit(tr*signs[:,None],y)
 z=model.decision_function(te)
 # label 'true next' is candidate 1 in held-out. Tie gets chance credit.
 correct=(z>0).astype(float)+.5*(z==0)
 return correct,{'variables':ix,'coefficients':model.coef_[0].tolist(), 'accuracy':float(correct.mean()),
                 'hard_correct':int((z>0).sum()),'ties':int((z==0).sum()),'hard_wrong':int((z<0).sum())}
models={}
for name,ix in [('length_only',[3,4]),('lexical_only',[0,1,2]),('combined',[0,1,2,3,4])]:
 c,info=score_model(name,ix);models[name]=info
 # cluster bootstrap folio, identical sampled folios for all models later
 models[name]['_scores']=c
 models[name]['currier_accuracy']={cl:float(c[[i for i,x in enumerate(test) if x['currier']==cl]].mean())
                                     for cl in ['A','B']}

# Additional non-fitted baselines, ties contribute 0.5.
for name,idx in [('jaccard_greedy',0),('reuse_greedy',1),('edit1_greedy',2),('length_match',3)]:
 z=Xte[:,idx]
 if name=='length_match':z=-z
 c=(z>0).astype(float)+.5*(z==0)
 models[name]={'variables':[idx],'accuracy':float(c.mean()),'hard_correct':int((z>0).sum()),
               'ties':int((z==0).sum()),'hard_wrong':int((z<0).sum()),'_scores':c}

# Cluster inference by held-out folio: percentages correlated within folio.
Ftest=sorted(testfolios)
S={name:np.array([np.mean([score for score,x in zip(info['_scores'],test) if x['folio']==f]) if any(x['folio']==f for x in test) else np.nan for f in Ftest])
   for name,info in models.items()}
I={f:np.array([i for i,x in enumerate(test) if x['folio']==f],dtype=int) for f in Ftest}
I={f:ii for f,ii in I.items() if len(ii)}
Ftest=list(I)
B=4999;bt=np.random.default_rng(seed+102)
boot={k:np.zeros(B) for k in models}
for b in range(B):
 fs=bt.choice(Ftest,len(Ftest),replace=True)
 ix=np.concatenate([I[f] for f in fs])
 for k,v in models.items():boot[k][b]=v['_scores'][ix].mean()
for k,info in models.items():
 info['folio_cluster_bootstrap_95ci']=[float(np.quantile(boot[k],q)) for q in [.025,.975]]
 del info['_scores']

# Predeclare combined as primary; cluster-sign-flip test (folio as unit).
# Probability of positive test score after held-out label symmetry, conditional on fitted model.
acc_by_folio=np.array([np.mean((score_model('combined',[0,1,2,3,4])[0])[I[f]]) for f in Ftest]) if False else None
# Recompute primary predictions for sign-flips without refitting.
primary, _=score_model('combined',[0,1,2,3,4]);d=np.array([primary[I[f]].sum()-.5*len(I[f]) for f in Ftest])
T=19999;st=np.random.default_rng(seed+103);obs=float(d.sum())
null=np.zeros(T)
for t in range(T):null[t]=(d*st.choice([-1,1],size=len(d))).sum()
p_cluster=float((1+np.count_nonzero(null>=obs))/(T+1))
models['combined']['cluster_signflip_p_one_sided']=p_cluster
models['combined']['cluster_signflip_observed_excess_correct']=obs
models['combined']['difference_vs_length_only_95ci']=[float(np.quantile(boot['combined']-boot['length_only'],q)) for q in [.025,.975]]

payload={'experiment':'EXP_SEQ_NEXT_LINE_01','status':'EXPLORATORY_NOT_PREREGISTERED','seed':seed,
         'task':'Given anchor row and two candidate later rows in the same paragraph, choose true immediate successor vs one further-later decoy.',
         'features':['Jaccard(prev,candidate)','reuse_rate(prev,candidate)','edit1_rate(prev,candidate)','abs_delta_row_length','candidate_row_length'],
         'train_folio_count':len(trainfolios),'test_folio_count':len(testfolios),
         'training_pairs':len(train),'heldout_pairs':len(test),'heldout_currier_counts':{cl:sum(x['currier']==cl for x in test) for cl in ['A','B']},
         'test_folios':Ftest,'results':models,
         'warnings':['This is an ordering test of known rows, NOT next-word or text generation.',
                     'Random decoys sampled once per paragraph anchor; alternative decoy policies may change accuracy.',
                     'Held-out by folio, but research question itself was selected on an already explored corpus.',
                     'Cluster sign-flip p is a descriptive test conditional on trained model; multiplicity from prior research is not accounted for.']}
OUT=P.parent
(OUT/'prediction_results.json').write_text(json.dumps(payload,indent=2,ensure_ascii=False))
with (OUT/'prediction_holdout_pairs.csv').open('w',newline='') as o:
 w=csv.writer(o);w.writerow(['folio','currier','paragraph_length','position','len_previous','len_true','len_decoy',*payload['features']]);
 for x in test:w.writerow([x['folio'],x['currier'],x['n_paragraph'],x['anchor_pos'],x['prev_len'],x['true_len'],x['decoy_len'],*x['features'].tolist()])
print('train',len(train),'test',len(test),'train folios',len(trainfolios),'test folios',len(testfolios),'test features shape',Xte.shape)
for name,x in models.items():print(name,'accuracy',round(x['accuracy'],4),'ci',list(map(lambda t:round(t,4),x['folio_cluster_bootstrap_95ci'])),'correct',x['hard_correct'],'ties',x['ties'],'wrong',x['hard_wrong'])
print('combined coefs',models['combined']['coefficients'],'cluster_p',p_cluster,'diff_vs_length',models['combined']['difference_vs_length_only_95ci'])
