from pathlib import Path
import json, hashlib, zipfile, datetime, subprocess, csv, os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
D=Path(__file__).resolve().parent
R=json.loads((D/'results.json').read_text())
S=json.loads((D/'stress_results.json').read_text())
P=json.loads((D/'prediction_results.json').read_text())
M=json.loads((D/'length_matched_prediction.json').read_text())
A=json.loads((D/'alignment_paragraph_shuffle.json').read_text())
G=json.loads((D/'alignment_results.json').read_text())
IT=json.loads((D/'IT2a_replication.json').read_text())

def f(x,n=4):return f'{x:.{n}f}'

def pc(x):return f'{x*100:.1f}%'

lags=list(S['lag'].values())
xs=list(range(1,6))
fig,ax=plt.subplots(figsize=(8.5,4.6))
ax.plot(xs,[x['stats']['jaccard']['observed'] for x in lags],'-o',label='Ordine originale')
ax.plot(xs,[x['stats']['jaccard']['null_mean'] for x in lags],'-s',label='Media ordine casuale nel paragrafo')
ax.set_xlabel('Distanza fra righe nello stesso paragrafo')
ax.set_ylabel('Somiglianza media, Jaccard')
ax.set_xticks(xs)
ax.legend()
ax.grid(alpha=.2)
fig.tight_layout();fig.savefig(D/'lag_jaccard.png',dpi=185);plt.close(fig)

fig,ax=plt.subplots(figsize=(8.5,4.6))
observed=[R['results']['para']['observed'][k] for k in ['jaccard','exact_reuse','edit1_nonidentical']]
null=[R['results']['para']['null'][k]['mean'] for k in ['jaccard','exact_reuse','edit1_nonidentical']]
labels=['Jaccard','Ripetizione esatta','Varianti a un edit']
ratio=[o/n for o,n in zip(observed,null)]
ax.bar(labels,[(x-1)*100 for x in ratio])
ax.axhline(0,linewidth=1)
ax.set_ylabel('Eccesso rispetto al nullo interno al paragrafo (%)')
ax.set_ylim(0,26)
for i,x in enumerate(ratio):ax.text(i,(x-1)*100+.8,f'+{(x-1)*100:.1f}%',ha='center',fontsize=11)
fig.tight_layout();fig.savefig(D/'paragraph_excess.png',dpi=185);plt.close(fig)

text=f'''# VOYNICH | EXP-SEQ-LINE-MEMORY-01

**Data:** 12 novembre 2026. **Stato: esplorativo, non preregistrato, nessuna decifrazione.**  
**Oggetto:** dipendenze lessicali fra righe e verifica di previsioni alternative basate su geometria, ordine del paragrafo e posizione orizzontale.  
**Perimetro:** esclusivamente il corpus testuale P-only e il parser RC1.2 in sola lettura. La pipeline RC1.4.2 rimane `CLOSED_PENDING_VALIDATION`.

## Sintesi dei risultati

Il testo Voynich è più simile lungo righe contigue di quanto previsto da rimescolamenti che preservano **integralmente le parole di ogni paragrafo**. L'effetto ricorre in Currier A e B. Per le somiglianze fra parole esatte e quasi identiche è concentrato nelle prime due distanze fra righe, mentre la terza e le successive non mostrano un eccesso Jaccard convincente nel benchmark usato.

**Limite determinante:** questa dipendenza statistica *non si traduce* in buona capacità di scegliere la vera riga successiva quando due candidate hanno identica lunghezza e non sono linee terminali. Inoltre il vantaggio di allineamento orizzontale delle varianti non sopravvive al rimescolamento dell'ordine delle righe. Un modello di copiatura verticale letterale non è quindi dimostrato.

## Input e integrità

- `inputs/ZL3b-n.txt`: SHA-256 `{R['input_sha256']['ZL3b-n.txt']}`.
- `inputs/zl3b_P_ms408.tsv`: SHA-256 `{R['input_sha256']['zl3b_P_ms408.tsv']}`.
- `inputs/ivtff_parser_rc1_2.py`: SHA-256 `{R['parser_sha256']}`.
- 207 folii, 4.130 righe P-only, 34.323 token, **740 paragrafi** identificati dai marcatori `<%>` del parser, con 3.390 coppie interne di righe adiacenti.
- Il confronto esclude transizioni tra folii, a differenza della metrica storica aggregata su tutto il corpus.

## Protocollo principale: ordine delle righe

Per ogni coppia diretta di righe \(R_i, R_j\), tre misure sono state fissate prima dell'esame dei risultati: **Jaccard fra insiemi di parole**; **frazione delle occorrenze della seconda riga presenti nella precedente**; **frazione delle occorrenze con almeno un vicino a distanza di Levenshtein 1 nella precedente, esclusa la parola identica come coppia**. Le ultime due sono medie di rapporti per riga. Per i controlli sono state prodotte 1.999 permutazioni deterministiche, seed `{R['config']['seed']}`, più intervalli bootstrap per folio con 2.499 ricampionamenti.

| Misura | Osservato nello stesso paragrafo | Media nulla | Eccesso | p unilaterale |
|---|---:|---:|---:|---:|
'''
for key,label in [('jaccard','Jaccard'),('exact_reuse','Ripetizione esatta'),('edit1_nonidentical','Varianti a un edit')]:
 x=R['results']['para'];text+=f"| {label} | {f(x['observed'][key],5)} | {f(x['null'][key]['mean'],5)} | +{(x['test'][key]['ratio']-1)*100:.1f}% | {f(x['test'][key]['p_one_sided_above'],4)} |\n"
text+='''
- **Nullo F:** permutazione di tutte le righe all'interno del folio, conservando il vocabolario della pagina e le righe stesse.
- **Nullo P (principale):** permutazione limitata all'interno di ciascun paragrafo, conservando lessico, lunghezze delle singole righe e folio.
- **Nullo EP:** prima e ultima riga di ogni paragrafo bloccate; permutazione soltanto delle righe intermedie, con paragrafi di almeno quattro righe.

### Controllo EP, primi e ultimi righi fissi

| Misura | Osservato | Media nulla | Eccesso | p unilaterale |
|---|---:|---:|---:|---:|
'''
for key,label in [('jaccard','Jaccard'),('exact_reuse','Ripetizione esatta'),('edit1_nonidentical','Varianti a un edit')]:
 x=R['results']['para_endpoints'];text+=f"| {label} | {f(x['observed'][key],5)} | {f(x['null'][key]['mean'],5)} | +{(x['test'][key]['ratio']-1)*100:.1f}% | {f(x['test'][key]['p_one_sided_above'],4)} |\n"
text+='''
### Controllo sulle lunghezze

In un ulteriore nullo esplorativo sono state scambiate soltanto righe **interne** appartenenti allo stesso paragrafo e alla stessa fascia di lunghezza (1–3, 4–6, 7–9, 10–12, ≥13 token); anche apertura e chiusura del paragrafo sono fisse. Questo è più severo perché una grande quota delle righe resta immobile. Si sono potute permutare 2.164 posizioni in 440 paragrafi.

| Misura | Eccesso rispetto al nullo | p unilaterale |
|---|---:|---:|
'''
for key,label in [('jaccard','Jaccard'),('exact_reuse','Ripetizione esatta'),('edit1_nonidentical','Varianti a un edit'),('edit1_on_unseen_token','Varianti a un edit, parole assenti nella riga precedente')]:
 x=S['length_constrained']['statistics'][key];text+=f"| {label} | +{(x['ratio']-1)*100:.1f}% | {f(x['p_above'],4)} |\n"
text+='''
Il p=0,026 di Jaccard in questo test **non** resta sotto 0,05 applicando una correzione conservativa per più metriche; l'analisi resta esplorativa. Gli altri valori non conferiscono di per sé un'interpretazione semantica.

## Profilo delle distanze (paragrafi ≥6 righe)

| Distanza | Coppie | Jaccard reale | Jaccard nullo | p unilaterale |
|---|---:|---:|---:|---:|
'''
for lag,x in S['lag'].items():
 j=x['stats']['jaccard'];text+=f"| {lag.replace('lag_','')} | {x['n_pairs']} | {f(j['observed'],5)} | {f(j['null_mean'],5)} | {f(j['p_above'],4)} |\n"
text+='''
![Profilo delle distanze](lag_jaccard.png)

**Interpretazione:** un eccesso locale di somiglianza alle distanze 1 e 2, senza eccesso Jaccard convincente dalle distanze 3 a 5, nel campione dei paragrafi lunghi. Non deduce una finestra generativa con memoria esattamente due.

## Una prova predittiva deliberatamente severa

Compito: dati una riga precedente e due candidate successive **dello stesso paragrafo**, identificare la vera riga immediatamente successiva rispetto a una riga più lontana. Separazione per folio fra addestramento (137 folii) e controllo (60). Per non rivelare la risposta, il modello usa soltanto le misure lessicali di coppia e/o le lunghezze delle righe, mai l'indice della candidata o la sua distanza.

| Modello | Confronti di controllo | Accuratezza | IC 95% bootstrap per folio |
|---|---:|---:|---:|
'''
for key,label in [('length_only','Solo lunghezze'),('lexical_only','Solo similarità lessicale'),('combined','Combinato')]:
 m=P['results'][key];text+=f"| {label} | {P['heldout_pairs']} | {pc(m['accuracy'])} | {pc(m['folio_cluster_bootstrap_95ci'][0])}–{pc(m['folio_cluster_bootstrap_95ci'][1])} |\n"
text+=f'''
Il modello combinato supera il solo modello geometrico di **{(P['results']['combined']['accuracy']-P['results']['length_only']['accuracy'])*100:.1f} punti percentuali**, ma l'intervallo bootstrap per questa differenza comprende lo zero: {100*P['results']['combined']['difference_vs_length_only_95ci'][0]:.2f} a {100*P['results']['combined']['difference_vs_length_only_95ci'][1]:.2f} punti. Per questo non interpretiamo il {pc(P['results']['combined']['accuracy'])} come capacità di lettura del Voynich.

### Controllo post hoc: stessa lunghezza, nessuna riga finale

La vera candidata e quella alternativa hanno la **stessa lunghezza esatta** in token; entrambe sono righe *non finali* del paragrafo. Il modello può vedere soltanto Jaccard, ripetizione e distanza di un edit.

'''
m=M['results']['tolerance_0']
text+=f"- {m['n_train']} confronti di addestramento, **{m['n_test']} confronti su {m['test_folios']} folii riservati**.\n"
text+=f"- Accuratezza **{pc(m['accuracy'])}**, IC 95% per folio {pc(m['CI95_folio_bootstrap'][0])}–{pc(m['CI95_folio_bootstrap'][1])}, p per sign-flip dei folii **{f(m['p_one_sided_cluster_signflip'],3)}**.\n"
text+='''- Nessuna prova affidabile di predizione oltre il caso nel sottocampione strettamente appaiato. La riduzione di campione rende il test meno potente, non prova che una dipendenza lessicale sia assente.

## Posizione orizzontale: un falso indizio di copiatura?

Le parole mai viste nella riga precedente ma distanti **un edit** da almeno una parola in essa appaiono più vicine orizzontalmente di quanto atteso se le parole fossero distribuite uniformemente sulla lunghezza della riga. Questo apparente allineamento si osserva tuttavia anche a distanza 3 e 4, non soltanto tra righe contigue.

Con un nullo che conserva **ogni parola nella sua posizione** e permuta soltanto le righe interne allo stesso paragrafo, l'allineamento non risulta speciale per coppie originariamente consecutive:

'''
a=A['ALL']
text+=f"- Edit-varianti esaminate: **{a['matching_words_observed']}**.\n"
text+=f"- Scarto osservato rispetto a posizioni uniformi: **{f(a['observed_distance_excess'],4)}**.\n"
text+=f"- Media nulla con ordine delle righe permutato: **{f(a['null_mean_distance_excess'],4)}**; p inferiore = **{f(a['p_below'],3)}**.\n"
text+='''
Questo è un **risultato contrario** alla versione semplice dell'ipotesi che le forme siano copiate da una riga alla successiva mantenendo la stessa posizione orizzontale. Una grammatica con preferenze di posizione può produrre l'allineamento di base anche senza copiatura.

## Confronto con la letteratura

Queste osservazioni non sono dichiarate una scoperta inedita. Silvio de Carvalho, in uno studio online del **27 settembre 2026**, ha già riportato un arricchimento delle quasi-copie nella riga superiore e una diminuzione dell'effetto con la distanza. Il suo controllo usa una riga casuale esterna alla pagina e la trascrizione Takahashi, mentre questo dossier condiziona per paragrafo e usa il corpus ZL3b P-only. **Gli odds ratio e i rapporti non sono direttamente confrontabili.**  
Fonte: https://silviodc.de/ai-projects/voynich/

Anche l'analisi su voynich.site (stato autoriale aggiornato al 18 ottobre 2026) riporta effetti specifici degli inizi di riga, con controlli tramite reflow. È una classe di evidenza distinta dal nostro confronto lessicale:  
Fonte: https://voynich.site/en/findings/line-openers/

Le fonti sono studi pubblicati online, non automaticamente prove con revisione paritaria; i rispettivi campioni, strumenti e nulli differiscono.

## Conclusione e ipotesi da falsificare

I dati richiedono di tenere distinte **tre componenti**:

1. **Coerenza lessicale di paragrafo e breve portata:** adiacenza, riuso e vicinanza grafica eccedono il nullo per i paragrafi originali.
2. **Geometria delle righe:** molte previsioni sulla successione derivano dalle lunghezze, non dal lessico.
3. **Vincoli posizionali sulle forme:** l'allineamento delle quasi-copie non richiede che quelle righe si succedano in ordine reale.

Una prossima ipotesi *non calibrata sui risultati* dovrà specificare un meccanismo che genera congiuntamente le tre proprietà, non limitarsi a riprodurre il 0,0284 storico di Jaccard. Prima di qualsiasi interpretazione semantica serviranno controlli incrociati su Takahashi e dati con diversa segmentazione, positivi sintetici e negativi testuali, non soltanto la stessa trascrizione ricampionata.

## Riproduzione offline

Requisiti: Python 3.11+ con `numpy`, `scipy`, `scikit-learn`, `matplotlib` (solo per grafici).

I file di input verificati e il parser RC1.2 sono inclusi in `inputs/`; gli script **non** scrivono sui file originali.

```bash
python exp_line_memory.py
python exp_lag_and_currier.py
python exp_next_line_prediction.py
python exp_predict_length_matched.py
python exp_variant_alignment.py
python exp_alignment_paragraph_null.py
python build_dossier.py
```

Tutti gli output originari sono presenti in JSON/CSV. Ripetere il codice può richiedere più tempo, soprattutto per gli esperimenti di allineamento; se non è disponibile il calcolo, i dati osservati restano consultabili direttamente. Il corpus non viene modificato. La pipeline visivo-testuale RC1.4.2 non viene avviata.

**Avvertenza metodologica:** ogni p empirica misura la deviazione rispetto al nullo specifico; non tiene conto di tutte le scelte e le analisi della ricerca pregressa. L'analisi è esplorativa e non è preregistrazione né decifrazione.
'''

# Cross-transcription replication, inserted before predictive limits.
rep = """## Replicazione fra le trascrizioni ZL3b e IT2a (Takahashi)

Il corpus IT2a, disponibile nella Library, è stato acquisito nei suoi **342.104 byte originali**, SHA-256 `7f27a8b0feed8f6de0a99900df6bf912dd1d295c38e5f830bac8b41c3f536fb5`. Il parser RC1.2 è stato utilizzato in sola lettura con disattivazione della *sola* verifica che l'input sia il file ZL: l'hash IT2a è controllato separatamente. Per la comparazione sono stati usati **4.118 loci P comuni**, ignorando i 12 presenti soltanto in ZL; eventuali interruzioni nella sequenza o marcatori nuovi di paragrafo in una delle due trascrizioni spezzano il gruppo. Restano **3.333 coppie adiacenti** sullo stesso locus, con uguali confini nei due test.

Soltanto il **37,3%** delle righe ha esattamente la stessa sequenza di token nelle due trascrizioni; nel **62,6%** è uguale il conteggio dei token. Quindi il risultato non deriva da dati testuali identici.

| Misura | Eccesso ZL3b rispetto a nulla interna al paragrafo | Eccesso IT2a | p per ciascuna trascrizione |
|---|---:|---:|---:|
"""
for key,label in [('jaccard','Jaccard'),('exact_reuse','Ripetizione esatta'),('edit1_nonidentical','Varianti a un edit'),('novel_edit1','Varianti nuove a un edit')]:
 z=IT['ALL']['ZL3b'][key];t=IT['ALL']['IT2a'][key]
 rep+=f"| {label} | +{(z['ratio']-1)*100:.1f}% | +{(t['ratio']-1)*100:.1f}% | {t['p_above']:.5f} |\n"
rep+="""
I valori sono stati verificati anche separatamente in Currier A e Currier B. In un bootstrap appaiato per folio con 3.999 campioni, le differenze negli eccessi relativi IT2a meno ZL3b sono compatibili con zero. Per Jaccard, ad esempio, l'IC 95% della differenza nel **rapporto** osservato/nullo è da −0,020 a +0,029.

**Portata:** è una robustezza *fra letture dello stesso manoscritto*, non una seconda scoperta indipendente. La significatività è condizionale alla specifica ipotesi nulla scelta, e le stesse righe Voynich sono già state studiate in altri esperimenti. Un test su un secondo manoscritto o una decifrazione richiederebbero criteri completamente diversi.

![Confronto trascrizioni](transcription_replication.png)

"""
text=text.replace('## Una prova predittiva deliberatamente severa',rep+'## Una prova predittiva deliberatamente severa')
text=text.replace('python exp_line_memory.py\n','python exp_line_memory.py\npython exp_it2a_replication.py\n')

# Visualization cross-transcription: ratio excess in matched loci.
fig,ax=plt.subplots(figsize=(8.6,4.7))
keys=['jaccard','exact_reuse','edit1_nonidentical','novel_edit1'];names=['Jaccard','Riusi esatti','Varianti a un edit','Varianti nuove']
x=np.arange(4);w=.36
zl=[(IT['ALL']['ZL3b'][q]['ratio']-1)*100 for q in keys]
it=[(IT['ALL']['IT2a'][q]['ratio']-1)*100 for q in keys]
ax.bar(x-w/2,zl,width=w,label='ZL3b');ax.bar(x+w/2,it,width=w,label='IT2a')
ax.set_xticks(x,names,rotation=12,ha='right');ax.set_ylabel('Eccesso rispetto al nullo (%)')
ax.legend();ax.grid(axis='y',alpha=.2)
fig.tight_layout();fig.savefig(D/'transcription_replication.png',dpi=185);plt.close(fig)

(D/'RAPPORTO.md').write_text(text,encoding='utf-8')
(D/'requirements.txt').write_text('numpy\nscipy\nscikit-learn\nmatplotlib\n')
(D/'README.md').write_text('# Voynich · EXP-SEQ-LINE-MEMORY-01\n\nLeggi `RAPPORTO.md` per il contesto completo.\n\nCodice, risultati e input verificati inclusi. Analisi esplorativa, nessuna decifrazione.\n\nAvvio:\n\n```bash\npip install -r requirements.txt\npython exp_line_memory.py\npython exp_it2a_replication.py\npython exp_lag_and_currier.py\npython exp_next_line_prediction.py\npython exp_predict_length_matched.py\npython exp_variant_alignment.py\npython exp_alignment_paragraph_null.py\n```\n\nIl codice carica i dati dalla cartella `inputs/` e scrive soltanto nella directory dei risultati.\n')
files_to_include=[p for p in D.iterdir() if p.is_file() and p.name not in {'probe.py'}]+[p for p in (D/'inputs').iterdir() if p.is_file()]
manifest={str(q.relative_to(D)):hashlib.sha256(q.read_bytes()).hexdigest() for q in files_to_include if q.name!='SHA256SUMS.txt'}
(D/'SHA256SUMS.txt').write_text(''.join(f'{v}  {k}\n' for k,v in sorted(manifest.items())))
files_to_include=[p for p in D.iterdir() if p.is_file() and p.name not in {'probe.py'}]+[p for p in (D/'inputs').iterdir() if p.is_file()]
zip_path=D.parent/'VOYNICH_SEQ_LINE_MEMORY_20261112.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as zz:
    for q in files_to_include:zz.write(q,arcname=str(q.relative_to(D)))
with zipfile.ZipFile(zip_path) as zz:
    assert zz.testzip() is None
    assert len(zz.namelist())==len(files_to_include)
print(json.dumps({'zip':str(zip_path),'bytes':zip_path.stat().st_size,'files':len(files_to_include),
                  'report_bytes':(D/'RAPPORTO.md').stat().st_size,'images':[p.name for p in D.glob('*.png')]}))
