#!/usr/bin/env python3
"""Post-hoc adversarial correction: equal-length, nonterminal next-row choices.
No claim of pre-registration. Fixed split by Currier-stratified folio from previous model.
"""
import json,csv
from pathlib import Path
from collections import defaultdict
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from scipy.stats import binomtest
P=Path(__file__).with_name('exp_line_memory.py')
T=P.read_text();ns={'__file__':str(P),'__name__':'__module__'}
exec(compile(T[:T.index('rng=np.random.default_rng(SEED)')],str(P),'exec'),ns)
folios=ns['folio_data'];words=ns['words'];seed=20261112
rng=np.random.default_rng(seed+100)
trF=set();teF=set()
for currier in ['A','B']:
 a=[f['folio'] for f in folios if f['currier']==currier];rng.shuffle(a);cut=int(.7*len(a));trF.update(a[:cut]);teF.update(a[cut:])

# For each previous row, true successor must NOT be paragraph-final.
# A decoy must be a later NON-final row from SAME paragraph and identical token count.
# Separate relaxed ±1 length benchmark (same setup, not primary).
all_rows=[]
for f in folios:
 if f['currier'] not in ('A','B'):continue
 mm=f['matrix'];lens=np.array([len(z) for ff,z in ns['rows'] if ff==f['folio']]);currier=f['currier']
 for p in f['paragraphs']:
  if len(p)<4:continue
  for i in range(len(p)-3):
   prev,next=int(p[i]),int(p[i+1]);candidates=[int(j) for j in p[i+2:-1]]
   if not candidates:continue
   for tol in [0,1,2]:
    admissible=[j for j in candidates if abs(lens[j]-lens[next])<=tol]
    if not admissible:continue
    # Select closest possible later row, breaking ties by reproducible random choice.
    dist=min(abs(lens[j]-lens[next]) for j in admissible)
    short=[j for j in admissible if abs(lens[j]-lens[next])==dist]
    dec=short[int(rng.integers(len(short)))]
    q=mm[:,prev,next]-mm[:,prev,dec]
    all_rows.append({'folio':f['folio'],'currier':currier,'tol':tol,'len_next':int(lens[next]),'len_decoy':int(lens[dec]),
                     'n_paragraph':len(p),'pos':i, 'features':q,'same_len':int(lens[next]==lens[dec])})

nperm=19999;B=2999
results={}
for tol in [0,1,2]:
 tr=[z for z in all_rows if z['tol']==tol and z['folio'] in trF];te=[z for z in all_rows if z['tol']==tol and z['folio'] in teF]
 Xtr=np.array([z['features'] for z in tr]);Xte=np.array([z['features'] for z in te]);testF=sorted(set(z['folio'] for z in te))
 sc=StandardScaler(with_mean=False);trn=sc.fit_transform(Xtr);tst=sc.transform(Xte)
 rng2=np.random.default_rng(seed+tol+201);sign=np.where(rng2.integers(0,2,len(tr))==1,1,-1);y=(sign==1).astype(int)
 clf=LogisticRegression(fit_intercept=False,C=1,solver='lbfgs',max_iter=300,random_state=seed).fit(trn*sign[:,None],y)
 zs=clf.decision_function(tst);scores=(zs>0).astype(float)+.5*(zs==0)
 nonzero=np.where(np.abs(zs)>1e-9)[0]
 baseline={}
 for lab,j in [('jaccard_greedy',0),('reuse_greedy',1),('edit1_greedy',2)]:
  d=Xte[:,j];baseline[lab]=float(((d>0).astype(float)+.5*(d==0)).mean())
 groups={folio:np.array([i for i,z in enumerate(te) if z['folio']==folio]) for folio in testF}
 rb=np.random.default_rng(seed+tol+301);boot=np.zeros(B)
 for k in range(B):
  sample=rb.choice(testF,len(testF),replace=True);ii=np.concatenate([groups[g] for g in sample]);boot[k]=scores[ii].mean()
 ds=np.array([scores[groups[g]].sum()-.5*len(groups[g]) for g in testF]);observed=ds.sum()
 flip=np.random.default_rng(seed+tol+401);null=np.empty(nperm)
 for k in range(nperm):null[k]=(ds*flip.choice([-1,1],size=len(ds))).sum()
 p=float((1+np.count_nonzero(null>=observed))/(nperm+1))
 results[f'tolerance_{tol}']={'n_train':len(tr),'n_test':len(te),'test_folios':len(testF),'accuracy':float(scores.mean()),
          'CI95_folio_bootstrap':[float(np.quantile(boot,q)) for q in [.025,.975]],
          'p_one_sided_cluster_signflip':p,'coefficients':clf.coef_[0].tolist(),'normalization_sd':sc.scale_.tolist(),
          'hard_correct':int((zs>0).sum()),'wrong':int((zs<0).sum()),'ties':int((zs==0).sum()),
          'baselines':baseline,'test_currier':{cl:{'n':int(sum(z['currier']==cl for z in te)),
                 'accuracy':float(scores[[i for i,z in enumerate(te) if z['currier']==cl]].mean())} for cl in ['A','B']},
          'exact_length_fraction_test':float(np.mean([z['same_len'] for z in te]))}
( P.parent/'length_matched_prediction.json').write_text(json.dumps({'status':'EXPLORATORY_POST_HOC','design':'Within same paragraph, true and decoy never final line; decoy matches exact or within 1-2 tokens in length; later nonterminal only; model fit only on separate folios','results':results},indent=2))
print(json.dumps(results,indent=2))
