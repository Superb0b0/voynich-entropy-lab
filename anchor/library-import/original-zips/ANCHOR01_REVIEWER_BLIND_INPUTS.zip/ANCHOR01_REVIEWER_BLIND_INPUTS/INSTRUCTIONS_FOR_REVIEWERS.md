# Revisione indipendente delle immagini · ANCHOR-01

Annotare indipendentemente **tutti** i corpi visibili e tutti i gruppi di glifi distinti in page_A.jpg e page_B.jpg. Non è richiesto né consentito un abbinamento figura–etichetta. Delimitare ogni oggetto con un poligono in pixel immagine e riportare una riga per oggetto nella scheda CSV. Classi ammesse: body, glyph_cluster, star, container, other. Anello: inner, outer, uncertain. Annotare le incertezze senza consultare altri revisori.

Non sono forniti trascrizioni, precedenti coordinate, candidati, distanze, esiti o warning. I glifi originali restano visibili nelle immagini; la cecità riguarda i dati e le ipotesi precedenti, non l'aspetto della pagina.

Consegna: un file CSV compilato per ciascun revisore, con identificativo del revisore, senza consultare gli output altrui. La scheda iniziale è volutamente vuota: il numero degli oggetti non viene suggerito.
