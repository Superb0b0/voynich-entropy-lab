# Provenienza delle immagini e limiti della raccolta

Le immagini sono scansioni del manoscritto Voynich (Beinecke MS 408). Durante la preparazione l’accesso diretto al manifest Yale ha restituito HTTP 403 oppure non era disponibile dalla rete di esecuzione. La prima mappatura dei canvas deriva da una snapshot terza che **riporta** il SHA-256 del manifest Yale `317d58fd9ea90392a83d9858a91eada3d0b41416a3c835857dc0154bd123a309`; tale dichiarazione non è una verifica diretta dei byte Yale.

**La distribuzione reale è consentita soltanto dopo che il custode abbia acquisito i byte del manifest primario o di una copia autenticata, verificato il loro hash rispetto al valore fissato e registrato la provenienza e il controllo visivo delle immagini.** La ricevuta custodiale deve documentare metodo, data UTC e verificatore. Le immagini possono provenire da un mirror, ma l'hash del mirror da solo non certifica l'origine Yale.

Il vostro compito riguarda esclusivamente **regioni e tipi di oggetto**, senza trascrizioni, attributi visivi o associazioni figura–testo. Le coordinate sono espresse nei pixel nativi del canvas sorgente e riportano l'offset del pannello. Il dataset è una nuova estensione indipendente e non modifica il pilota ANCHOR-01, che conserva 30 collegamenti ambigui e zero validati. Nessun dato sintetico o dimostrativo è un'annotazione reale.
