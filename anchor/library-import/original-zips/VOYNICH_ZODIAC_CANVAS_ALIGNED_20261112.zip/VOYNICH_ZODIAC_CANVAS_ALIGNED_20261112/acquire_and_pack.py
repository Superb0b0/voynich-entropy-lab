#!/usr/bin/env python3
"""Pre-distribution fail-closed acquisition, provenance, panel crops, and custody.

This is a tool, NOT evidence that a Yale image was fetched or reviewed independently.
"""
from __future__ import annotations
import argparse, csv, datetime as dt, hashlib, json, shutil, sys, time, urllib.request, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
CUST=ROOT/'custodian'
MANIFEST=CUST/'ACQUISITION_MANIFEST.json'
YALE=CUST/'YALE_CANVAS_SNAPSHOT_EVIDENCE.json'
APPROVALS=CUST/'CANVAS_APPROVALS_PRIVATE.json'
ROIS=CUST/'PANEL_ROIS_PRIVATE.csv'
ELIGIBILITY=CUST/'REVIEWER_ELIGIBILITY_PRIVATE.json'
ORIGINALS=CUST/'downloaded_originals'
OUTPUT=CUST/'completed_packets'
REVIEWER=ROOT/'reviewer_template'
PACKET='VOYNICH_12_PANEL_REVIEWER_BLIND_IDENTICAL.zip'
BLOCK_SIZES=(3,4,3,2)
BLOCK_BY_ORDER=(1,1,1,2,2,2,2,3,3,3,4,4)
FROZEN_YALE_MANIFEST_SHA='317d58fd9ea90392a83d9858a91eada3d0b41416a3c835857dc0154bd123a309'

def sha256(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()

def dimensions(path):
 from PIL import Image
 with Image.open(path) as im: im.verify()
 with Image.open(path) as im:return im.size,im.format

def load(path):return json.loads(path.read_text(encoding='utf8'))

def get_manifest():
 items=load(MANIFEST)['items']
 assert len(items)==8 and len({x['canvas_oid'] for x in items})==8
 return items

def yale_evidence(items):
 snap=load(YALE)
 assert snap['reported_manifest_sha256']=='317d58fd9ea90392a83d9858a91eada3d0b41416a3c835857dc0154bd123a309'
 assert snap['live_yale_fetch_this_session']=='FAILED_NOT_ACCESSIBLE'
 by={x['canvas_oid']:x for x in snap['canvas_level_evidence']}
 assert set(by)=={x['canvas_oid'] for x in items}
 for x in items:
  e=by[x['canvas_oid']]
  assert e['index']==x['mirror_seq']
  assert e['image_service']==f"https://collections.library.yale.edu/iiif/2/{x['canvas_oid']}"
 return by

def manifest_authority_check(approvals):
 """Fail closed: reported snapshot hash alone cannot establish Yale provenance."""
 a=approvals.get('manifest_authority') or {}
 if a.get('verification_method') not in ('live_yale','authenticated_yale_manifest_mirror'):
  return False,'YALE_MANIFEST_AUTHORITY_METHOD_PENDING'
 if a.get('authentic_provenance_checked') is not True or not all(a.get(k) for k in ('original_manifest_binary_path','original_manifest_source_url','retrieval_or_authenticated_mirror_evidence','verified_utc','verifier_id')):
  return False,'YALE_MANIFEST_CHAIN_OF_CUSTODY_PENDING'
 path=Path(a['original_manifest_binary_path'])
 if not path.is_absolute():path=ROOT/path
 if not path.is_file():return False,'YALE_MANIFEST_BINARY_MISSING'
 actual=sha256(path)
 if actual!=FROZEN_YALE_MANIFEST_SHA or a.get('original_manifest_sha256')!=actual:
  return False,'YALE_MANIFEST_BINARY_HASH_MISMATCH'
 try:
  timestamp=dt.datetime.fromisoformat(a['verified_utc'].replace('Z','+00:00'))
  if timestamp.tzinfo is None or timestamp.utcoffset()!=dt.timedelta(0):return False,'AUTHORITY_TIMESTAMP_NOT_UTC'
 except ValueError:return False,'AUTHORITY_TIMESTAMP_INVALID'
 return True,'YALE_MANIFEST_BYTES_AND_PROVENANCE_ATTESTED'

def strict_mirror_check(path,rec):
 if not path.is_file():return False,'MISSING'
 if path.stat().st_size!=rec['expected_bytes']:return False,'MIRROR_BYTE_MISMATCH'
 if sha256(path)!=rec['expected_sha256']:return False,'MIRROR_SHA_MISMATCH'
 try: (w,h),fmt=dimensions(path)
 except Exception as e:return False,'IMAGE_INVALID:'+str(e)
 if (w,h)!=(rec['expected_width'],rec['expected_height']) or fmt!='JPEG':return False,'DIMENSIONS_OR_FORMAT_MISMATCH'
 return True,'MIRROR_BYTES_VERIFIED_ONLY'

def validate(path,rec):
 # For backward compatibility with local fixture tests, no Yale claims.
 return strict_mirror_check(path,rec)

def approved_check(path,rec,approval):
 if not path.is_file():return False,'MISSING'
 try: (w,h),fmt=dimensions(path)
 except Exception as e:return False,'IMAGE_INVALID:'+str(e)
 if (w,h)!=(rec['expected_width'],rec['expected_height']) or fmt!='JPEG':return False,'NATIVE_DIMENSIONS_OR_FORMAT_MISMATCH'
 observed=sha256(path)
 if not approval:return False,'CUSTODIAN_APPROVAL_MISSING'
 if approval.get('observed_sha256')!=observed:return False,'CUSTODIAN_SHA_MISMATCH'
 if approval.get('source_mode') not in ('mirror_exact','yale_iiif','manual_yale_verified'):return False,'SOURCE_MODE_INVALID'
 if approval['source_mode']=='mirror_exact' and not strict_mirror_check(path,rec)[0]:return False,'MIRROR_HASH_MISMATCH'
 if not all(approval.get(k) for k in ('yale_canvas_verified','visual_correspondence_verified','approver_id','approved_utc','evidence_note','source_url')):
  return False,'YALE_PROVENANCE_APPROVAL_PENDING'
 try:dt.datetime.fromisoformat(approval['approved_utc'].replace('Z','+00:00'))
 except ValueError:return False,'INVALID_APPROVAL_UTC'
 return True,'SOURCE_APPROVED_WITH_HUMAN_ATTESTATION'

def report(items):
 approvals={x['canvas_oid']:x for x in load(APPROVALS)['canvases']}
 out=[]
 for x in items:
  path=ORIGINALS/(x['canvas_oid']+'.jpg')
  ok,reason=approved_check(path,x,approvals.get(x['canvas_oid']))
  print(f"{x['image_alias']} / {x['canvas_oid']}: {reason}")
  out.append((ok,reason))
 return out

def download(items,source):
 ORIGINALS.mkdir(parents=True,exist_ok=True)
 for x in items:
  target=ORIGINALS/(x['canvas_oid']+'.jpg')
  if target.exists():
   print(f"{target.name}: already exists; no overwrite. Check provenance and approval.")
   continue
  if source=='mirror':url=x['mirror_url']
  else:url=f"https://collections.library.yale.edu/iiif/2/{x['canvas_oid']}/full/full/0/default.jpg"
  temp=target.with_suffix('.part')
  if temp.exists():raise RuntimeError(f'Stale partial file: {temp}')
  print('Downloading',url)
  try:
   req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (archival research)'})
   with urllib.request.urlopen(req,timeout=120) as r,open(temp,'wb') as out:
    while True:
     chunk=r.read(1024*1024)
     if not chunk:break
     out.write(chunk)
     if out.tell()>150_000_000:raise RuntimeError('Oversized image')
   if source=='mirror':
    ok,why=strict_mirror_check(temp,x)
    if not ok:raise RuntimeError(f'Mirror download rejected: {why}')
   else:
    (w,h),fmt=dimensions(temp)
    if (w,h)!=(x['expected_width'],x['expected_height']) or fmt!='JPEG':raise RuntimeError('Yale download dimensions differ from snapshot: manual review required')
   temp.rename(target)
  except Exception:
   temp.unlink(missing_ok=True)
   raise
  time.sleep(1)
 print('DOWNLOAD COMPLETE. Still requires independent Yale source/visual approval by custodian.')

def validated_rois(items):
 with ROIS.open(newline='',encoding='utf8') as f: rows=list(csv.DictReader(f))
 if len(rows)!=12 or len({r['panel_id'] for r in rows})!=12 or len({r['panel_alias'] for r in rows})!=12:
  raise RuntimeError('ROI_INVENTORY_INVALID: require 12 unique panel IDs and aliases')
 with (CUST/'PANEL_CANVAS_CROSSWALK_PRIVATE.csv').open(newline='',encoding='utf8') as f: cross={r['panel_id']:r for r in csv.DictReader(f)}
 by={x['canvas_oid']:x for x in items}
 used=set()
 for r in rows:
  if r['panel_id'] not in cross or cross[r['panel_id']]['canvas_oid']!=r['canvas_oid']:
   raise RuntimeError('PANEL_CANVAS_CROSSWALK_MISMATCH:'+r['panel_id'])
  if r['canvas_oid'] not in by:raise RuntimeError('UNKNOWN_CANVAS:'+r['panel_id'])
  if r['roi_review_status']!='APPROVED_BY_CUSTODIAN':raise RuntimeError('ROI_NOT_APPROVED:'+r['panel_id'])
  try: b=tuple(int(r[k]) for k in ('x0_native','y0_native','x1_native','y1_native'))
  except (ValueError,TypeError):raise RuntimeError('ROI_MISSING_COORDINATES:'+r['panel_id'])
  x0,y0,x1,y1=b
  if not (0<=x0<x1<=by[r['canvas_oid']]['expected_width'] and 0<=y0<y1<=by[r['canvas_oid']]['expected_height'] and x1-x0>=40 and y1-y0>=40):
   raise RuntimeError('ROI_OUT_OF_BOUNDS:'+r['panel_id'])
  if (r['canvas_oid'],b) in used:raise RuntimeError('DUPLICATE_ROI:'+r['panel_id'])
  used.add((r['canvas_oid'],b));r['bbox']=b
 # Distinct panel crops from one canvas must not overlap in native pixels.
 for i,a in enumerate(rows):
  for b in rows[i+1:]:
   if a['canvas_oid']!=b['canvas_oid']:continue
   ax0,ay0,ax1,ay1=a['bbox'];bx0,by0,bx1,by1=b['bbox']
   if min(ax1,bx1)>max(ax0,bx0) and min(ay1,by1)>max(ay0,by0):
    raise RuntimeError('OVERLAPPING_PANEL_ROIS:'+a['panel_id']+':'+b['panel_id'])
 return rows

def pack(items):
 yale_evidence(items)
 approvals=load(APPROVALS)
 amap={x['canvas_oid']:x for x in approvals['canvases']}
 ok_auth,why_auth=manifest_authority_check(approvals)
 if not ok_auth:raise RuntimeError('PACKET_BLOCKED: '+why_auth)
 if not all(ok for ok,_ in report(items)):raise RuntimeError('PACKET_BLOCKED: image acquisition or Yale provenance pending')
 if not approvals.get('panel_rois_approved') or not approvals.get('panel_roi_approver_id') or not approvals.get('panel_roi_approved_utc'):
  raise RuntimeError('PACKET_BLOCKED: manual panel ROI approval pending')
 rows=validated_rois(items)
 # Canvas-aligned block invariants: each source canvas is in one contiguous block.
 if tuple(int(r['custodian_block']) for r in rows)!=BLOCK_BY_ORDER:
  raise RuntimeError('CANVAS_BLOCK_PLAN_MISMATCH')
 by_canvas={}
 for i,r in enumerate(rows):by_canvas.setdefault(r['canvas_oid'],[]).append((i,int(r['custodian_block'])))
 for cid,group in by_canvas.items():
  idx=[x[0] for x in group]; bs={x[1] for x in group}
  if len(bs)!=1 or idx!=list(range(min(idx),max(idx)+1)):
   raise RuntimeError('CANVAS_SPLIT_ACROSS_BLOCKS:'+cid)
 OUTPUT.mkdir(parents=True,exist_ok=True)
 dest=OUTPUT/PACKET
 if dest.exists():raise RuntimeError('Refusing to overwrite sealed packet')
 from PIL import Image
 blind=[]
 for i,r in enumerate(rows,1):
  cid=r['canvas_oid'];source=ORIGINALS/(cid+'.jpg')
  x0,y0,x1,y1=r['bbox'];alias=r['panel_alias']
  crop=OUTPUT/alias
  with Image.open(source) as im:
   im.crop((x0,y0,x1,y1)).convert('RGB').save(crop,format='JPEG',quality=95,subsampling=0)
  blind.append(dict(panel_alias=alias,panel_order=i,block=BLOCK_BY_ORDER[i-1],source_cluster_alias=f'SOURCE_{list(dict.fromkeys(x["canvas_oid"] for x in rows)).index(cid)+1:02d}',
   source_native_offset_px=[x0,y0],source_native_dimensions_px=[next(x['expected_width'] for x in items if x['canvas_oid']==cid),next(x['expected_height'] for x in items if x['canvas_oid']==cid)],
   source_image_sha256=sha256(source),crop_sha256=sha256(crop),crop_bytes=crop.stat().st_size,crop_width=x1-x0,crop_height=y1-y0,
   coordinate_system='native_source_canvas_pixels'))
 blind_manifest=dict(schema_version='ZODIAC-12P-BLIND-MANIFEST-2.0',image_count=12,block_sizes=list(BLOCK_SIZES),source_clusters=8,panels=blind)
 with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_STORED) as z:
  for r in blind:z.write(OUTPUT/r['panel_alias'],arcname=r['panel_alias'])
  for name in ('annotate_offline.html','ISTRUZIONI_REVISORE.md','PROVENANCE_AND_SCOPE.md'):
   z.write(REVIEWER/name,arcname=name)
  z.writestr('BLIND_PANEL_MANIFEST.json',json.dumps(blind_manifest,indent=2)+'\n')
  z.writestr('SOURCE_PROVENANCE_RECEIPT.json',json.dumps({'manifest_sha256':FROZEN_YALE_MANIFEST_SHA,'manifest_verification_method':approvals['manifest_authority']['verification_method'],'manifest_verified_utc':approvals['manifest_authority']['verified_utc'],'initial_direct_yale_fetch':'HTTP_403_OR_UNAVAILABLE_DURING_PREPARATION','source':'Yale Beinecke MS 408; mirror binaries possible with separate hash and visual attestation'},indent=2)+'\n')
  z.writestr('CROP_SHA256SUMS.txt',''.join(f"{r['crop_sha256']}  {r['panel_alias']}\n" for r in blind))
 receipt=dict(packet=PACKET,packet_sha256=sha256(dest),created_utc=dt.datetime.now(dt.timezone.utc).isoformat(),distribution='BLOCKED_UNTIL_TWO_REVIEWERS_APPROVED',
  source_image_hashes={x['canvas_oid']:sha256(ORIGINALS/(x['canvas_oid']+'.jpg')) for x in items},private_panel_map=[dict(panel_id=r['panel_id'],alias=r['panel_alias'],canvas_oid=r['canvas_oid'],bbox=list(r['bbox'])) for r in rows])
 (OUTPUT/'PACKET_RECEIPT_PRIVATE.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print('TECHNICAL PACKET CREATED',dest,'SHA256',receipt['packet_sha256'])
 print('DISTRIBUTION BLOCKED: reviewer eligibility and declarations must be checked by custodian.')

def release():
 receipt=load(OUTPUT/'PACKET_RECEIPT_PRIVATE.json')
 packet=OUTPUT/PACKET
 if not packet.is_file() or sha256(packet)!=receipt['packet_sha256']:raise RuntimeError('PACKET_INTEGRITY_FAILURE')
 qa=load(CUST/'QA_E2E_APPROVAL_PRIVATE.json')
 if not all(qa.get(k) is True for k in ('manual_e2e_approved','composite_canvas_verified','boundary_touching_object_tested','native_coordinate_roundtrip_verified','utc_and_lock_verified')):
  raise RuntimeError('MANUAL_BROWSER_E2E_NOT_APPROVED')
 if not all(qa.get(k) for k in ('test_report_file','test_report_sha256','verified_utc','tester_id')):
  raise RuntimeError('MANUAL_BROWSER_QA_REPORT_MISSING')
 qap=Path(qa['test_report_file'])
 if not qap.is_absolute():qap=ROOT/qap
 if not qap.is_file() or sha256(qap)!=qa['test_report_sha256']:
  raise RuntimeError('MANUAL_BROWSER_QA_REPORT_HASH_MISMATCH')
 elig=load(ELIGIBILITY)
 if not elig.get('distribution_authorized'):raise RuntimeError('CUSTODIAN_DISTRIBUTION_NOT_AUTHORIZED')
 rr=elig.get('reviewers',[])
 if len(rr)!=2 or len({r['reviewer_id'] for r in rr})!=2:raise RuntimeError('REQUIRE_TWO_DISTINCT_REVIEWERS')
 for r in rr:
  for k in ('name','signed_declaration_file','declaration_sha256','custodian_checked_utc'):
   if not r.get(k):raise RuntimeError('REVIEWER_INCOMPLETE:'+r['reviewer_id']+':'+k)
  for k in ('independence_checked','prior_exposure_assessed','conflict_assessed'):
   if r.get(k) is not True:raise RuntimeError('REVIEWER_NOT_APPROVED:'+r['reviewer_id']+':'+k)
  file=Path(r['signed_declaration_file'])
  if not file.is_file() or sha256(file)!=r['declaration_sha256']:raise RuntimeError('REVIEWER_SIGNATURE_FILE_MISSING_OR_CHANGED:'+r['reviewer_id'])
 receipt['distribution']='AUTHORIZED_FOR_MANUAL_CUSTODIAN_DELIVERY'
 receipt['release_authorized_utc']=dt.datetime.now(dt.timezone.utc).isoformat()
 (OUTPUT/'PACKET_RELEASE_PRIVATE.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print('AUTHORIZED FOR MANUAL DELIVERY. No files sent automatically.',receipt['packet_sha256'])

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('command',choices=['status','download','pack','release'])
 p.add_argument('--source',choices=['mirror','yale'],default='mirror',help='Only for download. Manual fallback: place full JPEGs in custodian/downloaded_originals and complete source approvals.')
 a=p.parse_args();items=get_manifest()
 if a.command=='status':report(items)
 elif a.command=='download':download(items,a.source);report(items)
 elif a.command=='pack':pack(items)
 elif a.command=='release':release()

if __name__=='__main__':
 try:main()
 except Exception as e:print('STOP:',e,file=sys.stderr);sys.exit(2)
