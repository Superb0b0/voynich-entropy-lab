import csv, importlib.util, json, pathlib, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('acq',ROOT/'acquire_and_pack.py')
acq=importlib.util.module_from_spec(spec);spec.loader.exec_module(acq)
class PreDistributionTests(unittest.TestCase):
 def test_eight_canvases_snapshot_labels(self):
  items=acq.get_manifest(); e=acq.yale_evidence(items)
  self.assertEqual(e['1006203']['label'],'71v and 72r')
  self.assertEqual(e['1006204']['label'],'72v (part)')
  self.assertEqual(e['1006205']['label'],'72v (part)')
 def test_12_panel_rois_not_yet_approved(self):
  with acq.ROIS.open() as f: rows=list(csv.DictReader(f))
  self.assertEqual(len(rows),12)
  self.assertTrue(all(x['roi_review_status']=='PENDING_MANUAL_ROI_CONFIRMATION' for x in rows))
  with self.assertRaisesRegex(RuntimeError,'ROI_NOT_APPROVED'):
   acq.validated_rois(acq.get_manifest())
 def test_no_images_have_provenance_approval(self):
  a=acq.load(acq.APPROVALS)
  self.assertFalse(a['panel_rois_approved'])
  self.assertEqual(len(a['canvases']),8)
  self.assertTrue(all(not x['yale_canvas_verified'] for x in a['canvases']))
 def test_packet_blocked(self):
  with self.assertRaisesRegex(RuntimeError,'PACKET_BLOCKED'):
   acq.pack(acq.get_manifest())
 def test_manifest_binary_authority_fail_closed(self):
  a=acq.load(acq.APPROVALS)
  self.assertEqual(acq.manifest_authority_check(a)[0],False)
 def test_canvas_aligned_blocks(self):
  with acq.ROIS.open() as f: rows=list(csv.DictReader(f))
  self.assertEqual([int(r['custodian_block']) for r in rows],list(acq.BLOCK_BY_ORDER))
  from collections import defaultdict
  by=defaultdict(set)
  for r in rows:by[r['canvas_oid']].add(r['custodian_block'])
  self.assertTrue(all(len(v)==1 for v in by.values()))
  self.assertEqual(len([r for r in rows if r['canvas_oid']=='1006203']),4)
 def test_two_reviewer_eligibility_not_fabricated(self):
  x=acq.load(acq.ELIGIBILITY)
  self.assertEqual(len(x['reviewers']),2)
  self.assertFalse(x['distribution_authorized'])
 def test_no_demo_images_in_reviewer_template(self):
  self.assertFalse(list(acq.REVIEWER.glob('*.jpg')))
 def test_annotator_has_native_coords_and_sha_and_seal(self):
  h=(acq.REVIEWER/'annotate_offline.html').read_text()
  for x in ('bbox_native_px','crop_sha256','source_image_sha256','created_utc','break_start','break_end','sealed_utc','getBoundingClientRect','nativeBox'):
   self.assertIn(x,h)
if __name__=='__main__':unittest.main()
