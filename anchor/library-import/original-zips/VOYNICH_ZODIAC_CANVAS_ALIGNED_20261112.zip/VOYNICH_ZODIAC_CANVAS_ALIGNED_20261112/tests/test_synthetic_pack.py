"""Synthetic-only pack integration test: mocks source approvals, never grants real distribution."""
import importlib.util, pathlib, unittest, tempfile, shutil, zipfile, json, hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('acq_synthetic',ROOT/'acquire_and_pack.py')
acq=importlib.util.module_from_spec(spec);spec.loader.exec_module(acq)
FIX=ROOT/'custodian/qa_fixture_only/browser_e2e_synthetic'
class SyntheticPackTest(unittest.TestCase):
 def test_pack_12_crops_8_sources_and_excludes_demo(self):
  items=acq.get_manifest(); real=acq.manifest_authority_check(acq.load(acq.APPROVALS))
  self.assertFalse(real[0])
  with tempfile.TemporaryDirectory() as td:
   td=pathlib.Path(td);orig=td/'downloaded_originals';orig.mkdir();out=td/'completed_packets'
   for x in items:shutil.copyfile(FIX/f"SOURCE_{x['canvas_oid']}.jpg",orig/f"{x['canvas_oid']}.jpg")
   import csv
   with acq.ROIS.open(newline='') as f:rows=list(csv.DictReader(f))
   # Use synthetic bounding boxes, matching the synthetic manifest, but keep private panel IDs.
   blind=json.loads((FIX/'BLIND_PANEL_MANIFEST.json').read_text())['panels']
   for r,p in zip(rows,blind):
    x,y=p['source_native_offset_px'];r['bbox']=(x,y,x+p['crop_width'],y+p['crop_height'])
   old=(acq.ORIGINALS,acq.OUTPUT,acq.manifest_authority_check,acq.report,acq.validated_rois)
   try:
    acq.ORIGINALS=orig;acq.OUTPUT=out
    acq.manifest_authority_check=lambda approvals:(True,'TEST_ONLY_MOCK')
    acq.report=lambda items:[(True,'TEST_ONLY_MOCK') for x in items]
    acq.validated_rois=lambda items:rows
    approvals=acq.load(acq.APPROVALS)
    # Local mock data only, never written to custodial approvals.
    approvals['panel_rois_approved']=True;approvals['panel_roi_approver_id']='TEST_ONLY';approvals['panel_roi_approved_utc']='2026-11-12T00:00:00Z'
    approvals['manifest_authority']['verification_method']='live_yale'
    oldload=acq.load
    acq.load=lambda p: approvals if p==acq.APPROVALS else oldload(p)
    try:acq.pack(items)
    finally:acq.load=oldload
    packet=out/acq.PACKET
    with zipfile.ZipFile(packet) as z:
     names=set(z.namelist())
     self.assertEqual(len([n for n in names if n.startswith('PANEL_') and n.endswith('.jpg')]),12)
     self.assertIn('PROVENANCE_AND_SCOPE.md',names)
     self.assertIn('SOURCE_PROVENANCE_RECEIPT.json',names)
     self.assertNotIn('SYNTHETIC_SEALED.json',names)
     self.assertFalse(any('preview' in n or 'qa_fixture' in n for n in names))
     m=json.loads(z.read('BLIND_PANEL_MANIFEST.json'))
     self.assertEqual(m['block_sizes'],[3,4,3,2]);self.assertEqual(m['source_clusters'],8)
     self.assertEqual(len({p['source_image_sha256'] for p in m['panels']}),8)
     self.assertEqual(len({p['source_image_sha256'] for p in m['panels'][3:7]}),1)
     self.assertEqual([p['block'] for p in m['panels']],[1]*3+[2]*4+[3]*3+[4]*2)
     self.assertEqual(len({p['source_cluster_alias'] for p in m['panels']}),8)
   finally:
    acq.ORIGINALS,acq.OUTPUT,acq.manifest_authority_check,acq.report,acq.validated_rois=old
if __name__=='__main__':unittest.main()
