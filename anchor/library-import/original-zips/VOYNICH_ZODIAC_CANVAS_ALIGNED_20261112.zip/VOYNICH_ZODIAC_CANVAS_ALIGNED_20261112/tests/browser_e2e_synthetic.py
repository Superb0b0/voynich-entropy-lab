"""Automated browser smoke test with synthetic panels, NOT human QA or Voynich observations.
Chromium policy blocks navigation; set_content is used. Browser crypto.subtle is
unavailable in about:blank, so SHA256 digest is delegated to Python solely in this test.
"""
from pathlib import Path
from PIL import Image,ImageDraw
from playwright.sync_api import sync_playwright
import hashlib,json,re,datetime as dt
ROOT=Path(__file__).resolve().parents[1]
FIX=ROOT/'custodian/qa_fixture_only'
FIX.mkdir(exist_ok=True)
OUT=FIX/'browser_e2e_synthetic'
OUT.mkdir(exist_ok=True)
BLOCKS=[1,1,1,2,2,2,2,3,3,3,4,4]
CANVASES=['1006200','1006201','1006202','1006203','1006203','1006203','1006203','1006204','1006204','1006205','1006206','1006207']
SHAS={}
for cid in dict.fromkeys(CANVASES):
 im=Image.new('RGB',(800,200) if cid=='1006203' else (350,350),(247,248,246))
 d=ImageDraw.Draw(im)
 d.text((12,12),f'SYNTHETIC {cid}',fill=(10,10,10))
 if cid=='1006203':
  for x in [0,200,400,600]:d.line((x,0,x,199),fill=(0,0,0),width=2)
  d.ellipse((177,60,223,110),fill=(240,40,40)) # one object straddles panel 4/5
 else:d.ellipse((120,100,170,150),fill=(40,120,240))
 path=OUT/f'SOURCE_{cid}.jpg';im.save(path,quality=95)
 SHAS[cid]=hashlib.sha256(path.read_bytes()).hexdigest()
manifest={'schema_version':'ZODIAC-12P-BLIND-MANIFEST-2.0','image_count':12,'block_sizes':[3,4,3,2],'source_clusters':8,'panels':[]}
for i,cid in enumerate(CANVASES):
 alias=f'PANEL_{i+1:02d}.jpg'
 if cid=='1006203':
  x0=[0,200,400,600][i-3];y0=0;W=200;H=200;sw=800;sh=200
 else:x0=100;y0=80;W=200;H=200;sw=350;sh=350
 with Image.open(OUT/f'SOURCE_{cid}.jpg') as im:im.crop((x0,y0,x0+W,y0+H)).save(OUT/alias,quality=95)
 p=OUT/alias
 manifest['panels'].append({'panel_alias':alias,'panel_order':i+1,'block':BLOCKS[i],
  'source_cluster_alias':f'SOURCE_{list(dict.fromkeys(CANVASES)).index(cid)+1:02d}',
  'source_native_offset_px':[x0,y0],'source_native_dimensions_px':[sw,sh],
  'source_image_sha256':SHAS[cid],'crop_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
  'crop_bytes':p.stat().st_size,'crop_width':W,'crop_height':H,'coordinate_system':'native_source_canvas_pixels'})
manifest_path=OUT/'BLIND_PANEL_MANIFEST.json'
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
html=(ROOT/'reviewer_template/annotate_offline.html').read_text()

def init_page(context):
 page=context.new_page()
 page.expose_function('sha256_from_python',lambda x:hashlib.sha256(bytes(x)).hexdigest())
 page.set_content(html,wait_until='load')
 # TEST-ONLY crypto.subtle substitute due about:blank being an insecure origin.
 page.evaluate('''() => {Object.defineProperty(window.crypto,'subtle',{configurable:true,value:{digest:async (_algorithm,buffer)=>{const hex=await window.sha256_from_python(Array.from(new Uint8Array(buffer)));return Uint8Array.from(hex.match(/../g).map(x=>parseInt(x,16))).buffer;}}})}''')
 return page

def load_inputs(page):
 page.locator('#manifest').set_input_files(str(manifest_path))
 page.wait_for_function("document.querySelector('#notice').textContent.includes('Manifest verificato')",timeout=12000)
 page.locator('#images').set_input_files([str(OUT/f'PANEL_{i:02d}.jpg') for i in range(1,13)])
 page.wait_for_function("document.querySelector('#notice').textContent.includes('12/12 SHA-256 verificati')",timeout=15000)
 page.wait_for_function("document.querySelector('#info').textContent.includes('Pannello')",timeout=15000)

def draw_box(page,x0,y0,x1,y1):
 c=page.locator('#stage');b=c.bounding_box();assert b
 page.mouse.move(b['x']+x0,b['y']+y0)
 page.mouse.down();page.mouse.move(b['x']+x1,b['y']+y1,steps=3);page.mouse.up()

def annotate_panel(page,i):
 page.locator('#mode').select_option('wheel')
 draw_box(page,20,20,180,180)
 page.locator('#mode').select_option('object')
 if i==4:draw_box(page,174,60,199,110)
 elif i==5:draw_box(page,1,60,27,110)
 else:draw_box(page,40,40,90,90)
 page.locator('#finish').click()
 if i in (3,7,10):
  page.wait_for_function("document.querySelector('#notice').textContent.includes('PAUSA OBBLIGATORIA')",timeout=5000)
  page.locator('#resume').click()
 if i<12:page.wait_for_function(f"document.querySelector('#info').textContent.includes('Pannello {i+1}/12')",timeout=8000)

with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 context=browser.new_context(accept_downloads=True,viewport={'width':1600,'height':1100})
 page=init_page(context)
 load_inputs(page)
 page.locator('#reviewer').fill('SYNTHETIC_QA_NOT_REAL_REVIEWER')
 annotate_panel(page,1)
 with page.expect_download() as info:page.locator('#draft').click()
 draft=OUT/'SYNTHETIC_DRAFT.json';info.value.save_as(draft)
 assert json.loads(draft.read_text())['current_index']==1
 # Fresh browser context/page: reload draft before images to check state roundtrip.
 page2=init_page(context)
 page2.locator('#import').set_input_files(str(draft))
 page2.wait_for_function("document.querySelector('#notice').textContent.includes('Bozza importata')")
 load_inputs(page2)
 page2.wait_for_function("document.querySelector('#info').textContent.includes('Pannello 2/12')")
 for i in range(2,13):annotate_panel(page2,i)
 with page2.expect_download() as info:page2.locator('#seal').click()
 final=OUT/'SYNTHETIC_SEALED.json';info.value.save_as(final)
 d=json.loads(final.read_text())
 assert d['review_status']=='SEALED_CLIENT_SIDE_PENDING_CUSTODIAN_HASH'
 assert d['current_index']==12 and len(d['finished_panels'])==12
 assert [x['block'] for x in d['finished_panels']]==BLOCKS
 assert len([e for e in d['events'] if e['event']=='break_start'])==3
 assert len([e for e in d['events'] if e['event']=='break_end'])==3
 assert all(re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z',x['created_utc']) for x in d['regions'])
 assert d['sealed_utc'].endswith('Z')
 assert page2.locator('#finish').is_disabled()
 # Four panel entries on composite source, with shared SHA, and exact native offsets.
 a=[r for r in d['regions'] if r['panel_alias']=='PANEL_04.jpg' and r['source_object_kind']=='human_candidate']
 b=[r for r in d['regions'] if r['panel_alias']=='PANEL_05.jpg' and r['source_object_kind']=='human_candidate']
 assert len(a)==len(b)==1,(a,b)
 assert a[0]['source_image_sha256']==b[0]['source_image_sha256']==SHAS['1006203']
 assert a[0]['bbox_native_px']==a[0]['crop_bbox_px'],a[0]
 assert b[0]['bbox_native_px']==[b[0]['crop_bbox_px'][0]+200,b[0]['crop_bbox_px'][1],b[0]['crop_bbox_px'][2]+200,b[0]['crop_bbox_px'][3]],b[0]
 assert a[0]['bbox_native_px'][2] <= 200 and b[0]['bbox_native_px'][0]>=200
 assert d['manifest_sha256']==hashlib.sha256(manifest_path.read_bytes()).hexdigest()
 # Data are demonstrative, not independent Voynich annotations.
 report={'status':'PASS_SYNTHETIC_BROWSER_E2E_WITH_SHA256_TEST_SHIM','browser':'Chromium Playwright headless set_content, navigation blocked by administrator',
 'image_source':'12 synthetic JPEG panels derived from 8 synthetic canvases',
 'test_only_crypto':'SHA-256 digest delegated to Python because about:blank has no WebCrypto',
 'checks':['12 SHA-256 image validations','manifest validation','3/4/3/2 blocks','shared source hash for composite','boundary object at x=200','draft export/import roundtrip','native pixel offsets','UTC timestamps','three breaks','final seal and UI lock'],
 'human_manual_qa':'NOT_RUN','real_canvas_1006203_test':'NOT_RUN','real_reviewer_annotations':0,
 'synthetic_final_sha256':hashlib.sha256(final.read_bytes()).hexdigest()}
 (OUT/'SYNTHETIC_BROWSER_E2E_REPORT.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2))
 browser.close()
