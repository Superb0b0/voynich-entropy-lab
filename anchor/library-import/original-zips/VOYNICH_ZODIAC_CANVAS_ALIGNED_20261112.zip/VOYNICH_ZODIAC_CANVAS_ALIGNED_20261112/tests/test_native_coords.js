const fs=require('fs'),assert=require('assert'),vm=require('vm'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../reviewer_template/annotate_offline.html'),'utf8');
const code=html.split('<script>')[1].split('</script>')[0];
new vm.Script(code); // full script syntax
function extract(name){
 const prefix='function '+name+'(';let start=code.indexOf(prefix);assert(start>=0,name);
 let brace=code.indexOf('{',start),depth=0,end=-1;
 for(let i=brace;i<code.length;i++){if(code[i]==='{')depth++;else if(code[i]==='}'){depth--;if(depth===0){end=i+1;break}}}
 return code.slice(start,end);
}
const context={Math,Number,Set,Error,RegExp,Array,console,canvas:{getBoundingClientRect:()=>({left:20,top:30,width:500,height:400})},activeImage:{naturalWidth:1000,naturalHeight:800}};
vm.createContext(context);
vm.runInContext(extract('localPoint')+'\n'+extract('nativeBox')+'\n'+extract('validateManifest'),context);
assert.deepEqual(Array.from(context.nativeBox([10,20,30,40],{source_native_offset_px:[100,200]})),[110,220,130,240]);
let p=context.localPoint({clientX:270,clientY:230});assert.equal(p.x,500);assert.equal(p.y,400);
// Eight source canvases for twelve panels, including 4-panel and 2-panel composites.
const groups=['0','1','2','3','3','3','3','4','4','5','6','7'];
const blocks=[1,1,1,2,2,2,2,3,3,3,4,4];
const panels=Array.from({length:12},(_,i)=>({panel_alias:`PANEL_${String(i+1).padStart(2,'0')}.jpg`,panel_order:i+1,block:blocks[i],source_native_offset_px:[50+i,80+i],source_native_dimensions_px:[500,500],source_image_sha256:groups[i].repeat(64),crop_sha256:'c'.repeat(64),crop_bytes:100,crop_width:200,crop_height:200}));
const m={schema_version:'ZODIAC-12P-BLIND-MANIFEST-2.0',block_sizes:[3,4,3,2],panels};
context.validateManifest(m);
assert.equal(new Set(panels.map(p=>p.source_image_sha256)).size,8);
assert.equal(panels.filter(p=>p.source_image_sha256==='3'.repeat(64)).length,4);
assert.equal(panels.filter(p=>p.source_image_sha256==='4'.repeat(64)).length,2);
const orig=panels[5].panel_alias;
panels[5].panel_alias=panels[4].panel_alias;
assert.throws(()=>context.validateManifest(m),/Manifest/);
panels[5].panel_alias=orig;
panels[6].block=3;
assert.throws(()=>context.validateManifest(m),/Manifest|diviso/);
panels[6].block=2;
context.validateManifest(m);
console.log('NODE_UNIT_PASS: source-native transforms, display scaling, 12 panels, 8 canvases, four/two-panel composites, duplicate alias and split source blocked');
