# Audit operativo aggiornato: canvas compositi e raccolta

**Stato 12/11/2026: `PRE_DISTRIBUTION_BLOCKED`.** Nessun revisore ha ricevuto il pacchetto, nessuna annotazione reale acquisita.

| Controllo | Risultato verificato | Residuo |
|---|---|---|
| Unità e clustering | 12 pannelli annidati in 8 canvas; `1006203` con quattro pannelli; blocchi 3/4/3/2 allineati ai canvas, con ID sorgente stabile nel manifest cieco | Le dipendenze da folio e manoscritto restano da trattare in analisi, senza n=12 indipendente |
| Yale | Snapshot esterna `noah-chelednik/voynich-data` corrobora `1006203 = 71v and 72r` | Accesso live Yale assente, byte del manifest primario non verificati |
| Scansioni | Percorso prioritario: acquisizione manuale da custode con accesso Yale; fallback mirror con attestazione distinta | 0/8 scansioni integrali presenti, 12 ROI non verificate |
| Provenienza | `pack` richiede manifest originale o copia autenticata con SHA-256 fissato e attestazione custodiale, non solo hash mirror | Nessuna attestazione, blocco effettivo testato |
| Annotatore | Test browser Chromium **sintetico** completo: 12 JPEG fittizi da 8 sorgenti, composito di 4 pannelli, oggetto a confine, export/import, offset nativi, UTC, pause, lock | Test manuale sulla vera scansione `1006203` NON ESEGUITO; nel browser di test SHA-256 è delegato a Python, non WebCrypto nativo |
| Reclutamento | Modulo e brief disponibili | 0/2 revisori umani reclutati; custode non designato |

**Separazione scientifica:** estensione indipendente, nessun attributo, nessun link figura–testo, nessuna inferenza dai pannelli come repliche indipendenti. ANCHOR-01: 30 `ambiguous`, 0 validati; `GATE: NOT_RUN`; H-A3R non eseguibile; RC1.4.2 bloccato. I dati sintetici restano sotto `custodian/qa_fixture_only/` e non devono entrare nel pacchetto dei revisori.
