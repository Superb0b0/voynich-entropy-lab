# Decisione operativa, 12 novembre 2026

**DISTRIBUTION_BLOCKED.** Non è stata effettuata alcuna annotazione indipendente. Non esistono due revisori reclutati o idonei. Le scansioni integrali originali non sono state acquisite nel kit. Il test completo su immagine reale `1006203` e la firma del custode mancano.

## Unità di analisi e blocchi

Le 12 unità di annotazione sono **pannelli**, ma non 12 repliche indipendenti. I pannelli sono annidati in **8 canvas sorgente**, con 4 pannelli nel canvas `1006203`. La futura analisi deve preservare l'ID del canvas come cluster di acquisizione; il folio fisico e le strutture codicologiche introducono ulteriori dipendenze, quindi nemmeno gli 8 canvas vanno automaticamente trattati come repliche statistiche indipendenti. Non effettuare inferenza basata su 12 pannelli indipendenti.

Blocchi custodiali allineati al canvas: B1 3 pannelli (1006200,1006201,1006202); B2 4 pannelli (1006203 intero); B3 3 pannelli (1006204×2,1006205); B4 2 pannelli (1006206,1006207). La struttura 3/4/3/2 mantiene il composito in una sessione, non impone che tutto il lavoro si svolga in una giornata. Registrare inizio, fine, pause, eventuali riprese. La dimensione del blocco non è una misura del carico reale, che dipende dal numero di figure e regioni.

## Provenienza e acquisizione

La fonte primaria è il manifest Yale `https://collections.library.yale.edu/manifests/2002046`, SHA-256 fissato `317d58fd9ea90392a83d9858a91eada3d0b41416a3c835857dc0154bd123a309`. La snapshot esterna corrobora le etichette dei canvas ma **non costituisce prova dei byte originali**. In questo ambiente l'accesso diretto è risultato indisponibile, incluso HTTP 403 nelle verifiche precedenti. Prima scelta operativa: **il custode designato scarica manualmente i byte del manifest e gli otto JPEG dal sito Yale da una macchina autorizzata**; in alternativa copia autenticata del manifest con hash identico e catena di provenienza, e JPEG mirror controllati separatamente per hash, dimensioni, identificativo e corrispondenza visiva. L'hash del mirror non certifica Yale. La funzione `pack` rifiuta di procedere senza i byte del manifest fissato e attestazione custodiale. Il custode deve essere nominato, non è stato nominato in questa sessione.

## QA browser

La UI usa un ritaglio alla volta con offset in pixel nativi della scansione sorgente; `1006203` viene testato come sorgente comune a quattro pannelli, non come quattro JPEG indipendenti. Un oggetto che attraversa il confine viene delimitato solo per la porzione visibile nel pannello e segnalato nelle note. Un test sintetico automatizzato non sostituisce la verifica **manuale** nel browser sulla vera immagine composita. Per `release` è richiesta una attestazione firmata del test con hash, timestamp UTC e verifiche su export, import, coordinate native e sigillatura.

## Revisori e scopo

Due esseri umani indipendenti, con dichiarazioni firmate prima della consegna, nessuna esposizione al pilota, EVA, EXP 3B o analisi precedenti. Nessun attributo visivo, nessun link figura–testo. Demo e fixture sintetici solo in directory private e mai nel ZIP dei revisori. L'estensione è **separata** dal pilota ANCHOR-01: 30 `ambiguous`, zero link validati, H-A3R non eseguibile, RC1.4.2 bloccato.
