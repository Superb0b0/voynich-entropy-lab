# Voynich, estensione zodiacale: kit canvas-aligned

**Stato `PRE_DISTRIBUTION_BLOCKED`, 12 novembre 2026.** Questo kit non autorizza ancora alcuna annotazione reale. Leggere `PRE_DISTRIBUTION_DECISION.md`.

## Unità e dipendenza

La gerarchia deve rimanere esplicita: **3 gruppi codicologici** (Quire 10, 11, 12; coniugato di f73 mancante/inferito, NON accertato), **4 folii fisici** (f70–f73), **12 pannelli visivi** (regioni di annotazione, non pagine fisiche) e **8 canvas Yale** (file di acquisizione, non repliche statistiche). Le categorie non formano una semplice gerarchia uno-a-uno: un canvas composito può attraversare folii fisici, come `1006203` (f71v e f72r). In analisi descrittiva conservare tutti gli ID; per qualunque tentativo di inferenza l'unità di dipendenza primaria è il **folio fisico**, con controllo del gruppo codicologico. **n=4 folii e n=3 gruppi non sostengono inferenze affidabili**: nessun test deve usare n=12 pannelli o n=8 canvas come repliche indipendenti.

| Livello | N | Significato |
|---|---:|---|
| Gruppi codicologici | 3 | Quire 10/11/12; f73 coniugato inferito |
| Folii fisici | 4 | f70, f71, f72, f73: livello di dipendenza primaria |
| Pannelli | 12 | ROI visive da annotare |
| Canvas | 8 | Immagini digitali; possibili compositi |

**Compositi da verificare visivamente prima della distribuzione:** `1006203` = f71v + f72r1 + f72r2 + f72r3 (4 pannelli); `1006204` = f72v3 + f72v2 (2 pannelli); `1006205` = f72v1 (1 pannello). Queste assegnazioni provengono dall'inventario preliminare e dal manifest, NON da una nuova delimitazione delle ROI. f72v continua da `1006204` a `1006205`: il revisore deve ricevere un avviso di continuità e i confini delle ROI approvate, anche con ID sorgente anonimi. I blocchi custodiali sono **3, 4, 3, 2 pannelli**, senza spezzare canvas. Il test browser su `1006203` e `1006204` reali resta obbligatorio.

## Provenienza

Il manifest primario è Yale `https://collections.library.yale.edu/manifests/2002046`, SHA-256 fissato `317d58fd9ea90392a83d9858a91eada3d0b41416a3c835857dc0154bd123a309`. Durante la preparazione l'accesso diretto Yale ha dato HTTP 403 o era indisponibile. La snapshot terza *riporta* questo hash, ma non verifica i byte Yale. **Prima della prima annotazione reale** il custode deve procurare il manifest autentico o copia autenticata con byte SHA-256 corrispondenti e documentare la catena di provenienza. Il mirror delle immagini non è autorità. Lo script `pack` richiede prova dei byte del manifest e controlli indipendenti sulle scansioni. La stessa nota compare nel materiale del revisore.

## Operatività

1. **Nominare per iscritto un custode umano non annotatore**, responsabile di acquisizione, SHA-256, timestamp UTC, distribuzione, ricevute e dichiarazioni firmate. Percorso prioritario: acquisizione **manuale da macchina con accesso Yale** degli 8 JPEG e del manifest originale. Procedura verificabile: (a) acquisire i **byte** del manifest e confrontarne SHA-256 con `317d58fd9ea90392a83d9858a91eada3d0b41416a3c835857dc0154bd123a309`; (b) estrarre dal manifest gli URL IIIF degli otto canvas; (c) acquisire ogni immagine, registrandone URL, SHA-256 proprio, dimensioni e ora UTC. Se impossibile, usare una copia autenticata del manifest e un mirror con catena di provenienza documentata: **non esistono hash Yale delle immagini da confrontare**, e l'hash del mirror non ne certifica l'identità con Yale. Registrare file, hash, dimensioni e attestazione in `custodian/`. In questo ambiente la rete esterna non ha consentito il download; **0/8 immagini integrali presenti**.
2. Il custode delimita e approva le 12 ROI in pixel nativi; per `1006203` verifica visivamente quattro regioni, per `1006204` due, e documenta la continuazione di f72v su `1006205`. Le ROI devono coprire gli oggetti pertinenti senza duplicarli arbitrariamente tra ritagli. Le ROI sono tuttora vuote e non approvate.
3. Eseguire `python acquire_and_pack.py status` e poi `python acquire_and_pack.py pack`; ogni condizione mancante blocca il pacchetto. Il pack genera 12 ritagli e manifest cieco con `source_cluster_alias`, hash sorgente, offset e blocchi 3/4/3/2. Non invia nulla.
4. Eseguire test **manuale completo nel browser sulle scansioni reali `1006203` e `1006204`**: oggetto al confine, export JSON, import, confronto con pixel nativi, verifica UTC e lock. Archiviare relazione firmata e SHA-256 in `custodian/QA_E2E_APPROVAL_PRIVATE.json`. Il test sintetico automatizzato è separato e non sostituisce questo passaggio.
5. Reclutare due revisori indipendenti, con dichiarazioni firmate e UTC. **Conoscere il Voynich in generale NON è causa di esclusione**; è incompatibile l'esposizione al nostro pilota, coordinate, diagnostica, EXP 3B, risultati zodiacali o comunicazioni con l'altro revisore. Nessun revisore è stato individuato. Registrare `custodian/REVIEWER_ELIGIBILITY_PRIVATE.json`. Eseguire `python acquire_and_pack.py release` solo dopo tutti i controlli; poi il custode consegna manualmente lo stesso ZIP e registra le sessioni e le pause.

## Separazione e limiti

Nessun attributo visivo, nessun EVA, nessun matching figura–etichetta, nessuna simulazione spacciata per osservazione. Le due anteprime del vecchio pilota restano soltanto in `custodian/pilot_reference_only/`; i dati sintetici di test in `custodian/qa_fixture_only/`, mai nel pacchetto per revisori. L'estensione non modifica ANCHOR-01: **30 esiti ufficiali `ambiguous`, zero link validati, `GATE: NOT_RUN`, H-A3R non eseguibile, RC1.4.2 bloccato.**

## Stato della UI e vincoli residui

La UI usa **`crypto.subtle.digest('SHA-256', ...)`** in produzione, non una funzione di hash sostitutiva. Il flusso sequenziale richiede la chiusura esplicita di **tutti e 12** i pannelli prima della sigillatura; per un pannello senza oggetti richiede una nota e consente stato `absent` / `not_localizable`. **Manca ancora una visualizzazione esplicita «canvas: M/N pannelli completati» e l'avviso di continuazione f72v fra sorgenti**: questo requisito di usabilità è aperto e impedisce la distribuzione finché non è verificato su immagini reali. Il test sintetico non equivale a dati reali.

**Blocco umano/materiale**: custode nominato 0/1, revisori verificati 0/2, scansioni integrali 0/8, ROI approvate 0/12. Se non si trovano due revisori indipendenti, registrare `COLLECTION_BLOCKED_NO_INDEPENDENT_REVIEWERS`; non fabbricare osservazioni.
