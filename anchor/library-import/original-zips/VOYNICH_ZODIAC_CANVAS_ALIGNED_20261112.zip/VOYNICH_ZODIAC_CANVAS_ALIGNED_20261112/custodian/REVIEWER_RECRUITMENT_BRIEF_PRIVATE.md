# Reclutamento dei due revisori umani, non avviato

**Stato: 0/2 revisori individuati.** Il custode designato è responsabile di reclutamento, consenso, conservazione delle dichiarazioni e distribuzione. Nessuna persona è stata contattata automaticamente.

Cercare due persone capaci di usare un browser offline e delimitare regioni su immagini di manoscritti. La conoscenza generale del manoscritto Voynich è consentita e può essere utile; non è richiesta competenza EVA. L'esposizione alle **nostre** coordinate precedenti, diagnostiche del pilota, EXP 3B e analisi specifiche delle etichette zodiacali è motivo di esclusione o valutazione esplicita. Evitare coautori e partecipanti alle correzioni del pilota. Il custode verifica separatamente le dichiarazioni firmate con data/ora UTC, conservando SHA-256 del file.

Inviare **soltanto dopo il completamento di provenienza, ROI e QA manuale** il pacchetto cieco identico. Nessun accesso alle annotazioni dell'altro revisore. Lavoro stimato: più sessioni, blocchi di 3/4/3/2 pannelli, pause dichiarate, possibilità di bozza. Non chiedere attributi visivi, trascrizioni o legami figura–testo.

Se due revisori indipendenti non sono disponibili, registrare `COLLECTION_BLOCKED_NO_INDEPENDENT_REVIEWERS`; non simulare annotazioni con modelli linguistici.
