# Dichiarazione di indipendenza, da firmare PRIMA della consegna delle immagini

Codice revisore assegnato dal custode: __________________

Dichiaro:
- di non aver prodotto o corretto le coordinate del pilota ANCHOR-01;
- di non essere stato/a esposto/a alle coordinate del pilota, alle sue diagnostiche, ai risultati del matching, a EXP 3B o alle discussioni e analisi specifiche di questo progetto sulle etichette zodiacali;
- di non avere accesso alle annotazioni dell'altro revisore e di non comunicare con lui/lei durante il lavoro;
- di sapere che la conoscenza pregressa del manoscritto Voynich in generale NON mi esclude; dichiaro qui ogni esposizione alle analisi **specifiche di questo progetto** e ogni eventuale esposizione pregressa rilevante: __________________;
- di dichiarare i possibili conflitti di interesse o rapporti di lavoro con i ricercatori qui: __________________;
- di comprendere che la mia firma non attesta la correttezza delle annotazioni ma la loro indipendenza operativa.

Firma: __________________  Data e ora UTC: __________________

**Custode (non revisore):** identità verificata tramite __________________; file firmato conservato in __________________; SHA-256 del file firmato __________________; timestamp UTC di ricezione __________________. La dichiarazione deve essere valutata prima della distribuzione; un'esposizione pregressa rilevante non si cancella con la firma.
