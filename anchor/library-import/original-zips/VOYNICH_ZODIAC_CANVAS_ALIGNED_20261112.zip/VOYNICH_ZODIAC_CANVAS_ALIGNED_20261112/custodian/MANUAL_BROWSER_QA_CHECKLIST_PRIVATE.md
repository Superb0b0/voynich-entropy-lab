# Checklist di accettazione manuale dell'annotatore, da eseguire sul canvas reale

Questo modulo **non è compilato**. Richiede una persona designata come tester/custode, il browser reale e le otto immagini verificate. Il test sintetico Chromium allegato non lo sostituisce.

- [ ] Aprire il pacchetto su un browser offline e caricare manifest cieco e 12 ritagli.
- [ ] Verificare che i quattro pannelli da `1006203` compaiano nello stesso blocco 2, uno alla volta, con offset nativi approvati.
- [ ] Sul vero composito, delimitare un oggetto che tocca o attraversa un confine: nel ritaglio segnare solo la parte visibile, con nota.
- [ ] Esportare bozza JSON e ricaricarla in una nuova sessione; verificare hash sorgente, offset e `bbox_native_px` contro i pixel della scansione originale.
- [ ] Verificare `created_utc`, `finished_utc`, pause e `sealed_utc` con formato UTC.
- [ ] Completare 12 pannelli di test, sigillare e provare a modificare: il lock deve impedire cambiamenti.
- [ ] Archiviare rapporto firmato e relativo SHA-256, con data/ora UTC, in `QA_E2E_APPROVAL_PRIVATE.json`.

**Esito: NON ESEGUITO.** Nessun flag deve essere valorizzato senza evidenza.
