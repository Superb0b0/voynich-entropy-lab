"""Generate from the saved model, using only training templates."""
import argparse,sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from vvm.grammar import Grammar
from vvm.lexer import load
from vvm.generator import generate

def main():
 p=argparse.ArgumentParser();p.add_argument('--tokens',type=int,default=100);p.add_argument('--seed',type=int,default=101);p.add_argument('--out',type=Path);a=p.parse_args()
 if not 1<=a.tokens<=1000000:p.error('tokens must be 1..1000000')
 rows,_=load(ROOT);train=[r for r in rows if r['split']=='train'];model=Grammar.load(ROOT/'results/model_v01.json');lines,details=generate(model,train,a.tokens,a.seed,{tuple(r['tokens']) for r in train});text='\n'.join(' '.join(r) for r in lines)+'\n'
 if a.out:a.out.write_text(text)
 else:print(text,end='')
if __name__=='__main__':main()
