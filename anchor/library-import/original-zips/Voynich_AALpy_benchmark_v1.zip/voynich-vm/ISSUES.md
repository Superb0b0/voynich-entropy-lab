# Stato dopo VVM 0.2

- Implementata e valutata memoria inter-riga esplicita: vantaggio predittivo piccolo, con controllo lag3.
- Valutazione estesa a tutti i 50 gruppi fisici con predizioni fuori campione a cinque fold.
- I template di pagina spiegano parte importante della continuità sintetica: anche la base senza cache rientra nelle quattro bande diagnostiche. Le bande da sole non identificano il meccanismo.
- Restano aperti: equivalenza del benchmark storico, confronto con i valori reali del preprocessing attuale, dipendenze di mano/argomento, variabilità generativa oltre due seed e plausibilità storica.
- Le note sotto registrano i limiti della v0.1, non tutti ancora irrisolti nella v0.2.

---

# Limiti della v0.1

1. Continuità fra righe insufficiente. Lo stato si azzera a ogni riga; una futura versione deve confrontare una memoria inter-riga esplicita con un controllo senza memoria, senza copiare righe.
2. Solo sette gruppi nel test e copertura incompleta delle sezioni. Per versioni successive serve una valutazione per gruppi pianificata che copra tutte le sezioni; non si cambia lo split v0.1 dopo averne visto l'esito.
3. Valutatore RC1.4 storico non acquisito. Nessuna attestazione di equivalenza del nuovo valutatore; conservare il profilo RC1.2 e i suoi riferimenti separati.
4. Nessun modulo cifrario o lingua sorgente. Aggiungerlo richiederebbe una specifica generativa esplicita, non una traduzione suggerita a posteriori.
5. Nessuna morfologia scoperta. I contesti di caratteri e i prefissi usati nello stato sono descrittori, non morfemi o glifi storici dimostrati.
