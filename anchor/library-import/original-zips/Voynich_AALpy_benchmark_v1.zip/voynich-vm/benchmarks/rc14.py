"""New documented implementation; NOT certified byte-equivalent to historical evaluator."""
from collections import Counter,defaultdict
BANDS={'density':(.91,.96),'adjacency':(.02,.04),'repetition':(.045,.070),'hapax':(.65,.75)}
def evaluate(lines,groups=None):
    counts=Counter(t for line in lines for t in line);vocab=set(counts);neighbors=set();patterns=defaultdict(list)
    for w in sorted(vocab):
        for i in range(len(w)):
            short=w[:i]+w[i+1:]
            if short in vocab:neighbors.add(w);neighbors.add(short)
            patterns[(len(w),w[:i]+'*'+w[i+1:])].append(w)
    for ws in patterns.values():
        if len(set(ws))>1:neighbors.update(ws)
    adj=[];rep=[]
    for i in range(1,len(lines)):
        if groups is not None and groups[i]!=groups[i-1]:continue
        a,b=set(lines[i-1]),set(lines[i]);adj.append(len(a&b)/len(a|b));rep.append(sum(w in a for w in lines[i])/len(lines[i]))
    vals={'density':sum(counts[w] for w in neighbors)/sum(counts.values()),'adjacency':sum(adj)/len(adj) if adj else None,'repetition':sum(rep)/len(rep) if rep else None,'hapax':sum(n==1 for n in counts.values())/len(counts)}
    return {'tokens':sum(counts.values()),'types':len(counts),'line_pairs':len(adj),'metrics':vals,'diagnostic_bands':{k:v is not None and BANDS[k][0]<=v<=BANDS[k][1] for k,v in vals.items()},'historical_RC14_pass':None}
