# VVM 0.2 — Memoria locale e struttura delle pagine

11 novembre 2026. Analisi esplorativa, nessuna decifrazione. V0.1 conservata, nuova valutazione predefinita senza ricercare parametri sui risultati test.

## Due risultati distinti

1. La memoria della riga P precedente migliora la previsione fuori campione, ma di poco: circa0,06% di riduzione della perdita in bit/token. È migliore anche del controllo con memoria a distanza di tre righe.
2. Conservare il regime e la forma delle pagine nei campioni sintetici fa rientrare nelle quattro bande diagnostiche anche il modello senza memoria. Il solo superamento di quelle bande non dimostra una memoria inter-riga né il recupero del programma storico.

## Valutazione su tutto il corpus

Cinque fold su 50 gruppi fisici, dieci gruppi test per fold. Nessun gruppo train/test condiviso; carte coniugate, recto, verso e pannelli rimangono insieme. Tutte le 4.130 righe P e i 35.492 token RC1.2 sono valutati una volta fuori dal fit. La stratificazione per sezione dominante è fissata prima della prima esecuzione. I fold non hanno identica numerosità in token e non rappresentano cinque repliche indipendenti.

| Modello | Bit/token, pesati per token | Bit/simbolo, EOS incluso |
|---|---:|---:|
| Base senza memoria fra righe | 11,04888 | 1,87181 |
| Memoria riga precedente | 11,04187 | 1,87063 |
| Memoria a distanza3 | 11,04611 | 1,87134 |

| Confronto principale, media per gruppo | Guadagno bit/token | IC bootstrap95% | Gruppi con guadagno positivo |
|---|---:|---:|---:|
| Lag1 rispetto base | +0,00647 | [0,00407;0,00909] | 38/50 |
| Lag1 rispetto lag3 | +0,00468 | [0,00248;0,00694] | 35/50 |

Entrambi i limiti inferiori sono positivi, quindi il criterio esplorativo fissato per questo confronto è superato. È un vantaggio piccolo; non equivale a decifrare parole o significati. Il bootstrap ricampiona i 50 gruppi sulle predizioni già ottenute, senza riaddestrare: non incorpora tutta la variabilità dei fit sovrapposti o le dipendenze fra fascicoli, mani e argomenti.

## Memoria implementata

La probabilità di parola è una miscela della grammatica full v0.1 e della frequenza della parola nella riga sorgente. Il peso è stimato soltanto su train con 50 aggiornamenti EM e prior Beta(1,19). Non si dichiara un optimum numerico esatto. I pesi lag1 sono 0,00551–0,00622 (circa0,55–0,62%); lag3 0,00246–0,00372. Nessuna griglia o modifica dopo l'esito test.

La sorgente è il locus P precedente entro la stessa unità IVTFF. Etichette non P fra loci non entrano nella memoria; non si assume che ogni coppia di loci P sia un confine paleografico contiguo. La cache si azzera al cambio di pagina/pannello. Lo stato delle parole nella riga rimane causale. Nel test la riga sorgente è osservata, nella generazione è sintetica. Non c'è accesso al testo futuro.

## Generazione a confronto

Modello grammaticale del fold0, addestrato su40 gruppi e29.018 token. Le forme e lunghezze delle pagine provengono solo dal train. La versione base e quella lag1 usano identico calendario di template, lunghezze e confini di pagina per ciascun seed, verificato automaticamente. Campioni di35.492 token ciascuno; nessuna riga identica a una riga train. Circa16,7–17,0% dei token sintetici ha forme assenti dal lessico train.

| Variante | Seed | Densità | Adiacenza | Ripetizione | Hapax/tipi |
|---|---:|---:|---:|---:|---:|
| Base | 11 | 0,94697 | 0,02689 | 0,05363 | 0,73129 |
| Lag1 | 11 | 0,94765 | 0,03037 | 0,05940 | 0,72733 |
| Base | 29 | 0,94604 | 0,02529 | 0,05104 | 0,73637 |
| Lag1 | 29 | 0,94661 | 0,02791 | 0,05526 | 0,73192 |

Tutti e quattro i campioni sono nelle quattro bande della nota storica: densità0,91–0,96; adiacenza0,02–0,04; ripetizione0,045–0,070; hapax0,65–0,75. Sono però le metriche del nuovo valutatore diagnostico, non la pipeline storica attestata. Il reale RC1.2 ha densità0,97464, fuori da quelle bande. Dunque stare nelle bande non equivale a riprodurre esattamente il profilo del reale con il preprocessing corrente. Due seed non costituiscono una stima completa della variabilità.

Il confronto base/cache nella v0.2 è controllato per i template. Il confronto v0.1→v0.2 non lo è: nella v0.1 venivano assemblati template di righe indipendenti, nella v0.2 pagine con regime coerente e si escludono i confini di pagina nel valutatore. Non si attribuisce il passaggio alle quattro bande alla sola memoria.

## Correzione della conclusione v0.1

L'affermazione che il difetto di continuità della v0.1 indicasse necessariamente la mancanza di memoria inter-riga era troppo forte. La nuova base senza memoria ottiene già valori nelle quattro bande quando si conservano i regimi e i template delle pagine. Il risultato v0.1 rimane quello misurato, ma la sua interpretazione causale viene ridimensionata. La memoria ha un piccolo contributo predittivo incrementale nel test qui eseguito; le bande aggregate da sole non lo identificano.

## Correzione di implementazione durante la consegna

Nel primo campionamento v0.2 lo stesso flusso casuale sceglieva template e parole: le diverse parole generate nei due bracci spostavano anche il calendario dei template. È stato corretto separando i due flussi casuali e rigenerando i medesimi seed, senza cambiare pesi o criteri. I primi risultati generativi sono conservati in initial_generation_unmatched_schedule.json come superseded; le predizioni fuori campione e i loro confronti sono rimasti identici. La nota al protocollo documenta la correzione, quindi non si presenta l'intero file aggiornato come congelato prima di ogni calcolo.

## Verifiche software e decisione

20 test superati, inclusi controlli della miscela contro calcoli manuali, assenza di penalità senza cache disponibile, reset fra pagine, lag3, pesi senza sovrapposizione, identità dei fold e identità dei template base/cache. Ripristino del modello serializzato verificato dalla suite. Modello del fold0 e comando sample_v02.py inclusi.

V0.2 è una versione funzionante che supera il proprio criterio predittivo esplorativo con effetto piccolo. Non supera un benchmark storico certificato, non dimostra copia locale come meccanismo storico, non genera una traduzione e non ricostruisce l'ordine originale. Il risultato più informativo per il reverse engineering è distinguere il contributo dei regimi di pagina da quello della memoria esplicita.

Riproduzione: python3 run_v02.py; python3 -m unittest discover -s tests -v; python3 sample_v02.py --tokens 100 --seed 101. Dipendenze già in requirements.txt. Codice e dati della v0.1 sono conservati; nessun artefatto dell'audit RC1.4.2 è modificato.
