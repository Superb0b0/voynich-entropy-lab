# Benchmark AALpy — protocollo prima dell'esecuzione statistica

11 novembre 2026. Corpus/parser/mappa VVM, artefatti originali invariati. AALpy2.0.0 installato da PyPI, dipendenze fissate nel lock. Una prova su200 righe train ha verificato formato, API e durata; nessun set val/test usato nella prova tecnica. Algoritmo run_Alergia(data,'mc',eps=...). Stati effettivi risultanti, non conteggi forzati 2/4/8/16. Markov chain con output sui nodi: numero di stati non direttamente confrontabile con automa a emissioni su archi.

## Target e partizioni

Ogni riga P è una traccia indipendente. Inizio '^' non valutato; ogni parola è codificata come caratteri EVA seguiti da '$', senza aggiungere spazi o un secondo fine riga. Per esempio ['qody','daiin'] diventa ^qody$daiin$. L'automa e i Markov possono conservare lo stato attraverso '$' nella stessa riga; si azzerano a ogni riga. EVA indica caratteri di trascrizione, non glifi fisici. Il marcatore '$' è una scelta di rappresentazione fissata, non una scoperta sul manoscritto.

Gruppi e cinque fold identici alla VVM0.2: fold2/3/4 train; fold1 validation; fold0 test. Tutti i coniugati/pannelli di uno stesso gruppo nella stessa partizione. Ogni modello usa tutte le righe della propria partizione. Il corpus e il fold0 sono già stati analizzati in precedenti esperimenti: test escluso dal fit e dalla selezione attuali, non corpus cieco mai visto storicamente.

## Selezione

Alergia: tre epsilon0,01/0,05/0,2. Per ogni automa, quattro pesi di backoff0,001/0,01/0,05/0,1; massimo12 candidati valutati su validation. Scelta minima log-loss per simbolo; parità entro1e-9 risolta con meno parametri, poi ordine lessicografico della configurazione. Nessun obbligo che l'automa sia piccolo se i dati non lo permettono. Timeout180secondi per ogni fit; timeout escluso e dichiarato, non risultato numerico. Se tutti falliscono, nessun risultato AALpy inventato.

Markov0/1/2/3: tre forze di Dirichlet0,1/1/5 per ordine, con prior globale; massimo12 candidati, alpha scelto su validation separatamente per ogni ordine. Contesti non osservati usano prior globale; alfabeto train più EOS e UNK. Nessuna scelta sul test. Tutti i contesti sono causali e si azzerano a ogni riga.

Dopo la selezione, rifit train+validation una volta per automa selezionato e ciascun Markov selezionato; parametri di smoothing congelati. Valutazione finale sul medesimo fold0 per tutti. VVM full0.1 e miscela con memoria0.2 riaddestrate sugli stessi gruppi train+validation, senza scelta aggiuntiva. Queste ultime usano metadati e contesti di parola/riga, quindi ricevono più informazioni dell'automa non condizionato: dichiarare la differenza.

## Probabilità e smoothing dell'automa

Le probabilità Alergia sugli archi sono conservate. Ad ogni passo, con probabilità1-delta si segue la transizione ed emette l'output del nodo destinazione; con probabilitàdelta si emette dal prior unigramma train (pseudoconteggio0,5) e si riporta lo stato nascosto al nodo iniziale. I nodi terminali senza uscite usano sempre il prior e reset. Questa è una modifica esplicita per un confronto con log-loss finite, non una capacità di smoothing nativa attribuita ad AALpy. Distribuzione filtrata esatta su tutti gli stati, non percorso singolo arbitrario. UNK train-only per simboli non osservati. Normalizzazione verificata su casi sintetici.

## Complessità e criterio

Registrare stati, archi e gradi di libertà probabilistici. AALpy: somma(max(outdegree-1,0)) + (K-1) del prior +1 del backoff. Topologia e costo dei simboli non inclusi: non è un MDL completo. Markov: numero di distribuzioni condizionate memorizzate moltiplicato K-1, più prior globale per ordini>0. È una misura della parametrizzazione esplicita, non identità di spazio delle ipotesi. Markov di complessità più vicina scelto esclusivamente confrontando questi conteggi dopo refit, non dalle perdite test. Rapporto fra parametri entro2 per chiamarlo controllo approssimativamente comparabile; altrimenti il controllo di complessità resta inconclusivo. Riportare comunque tutti gli ordini, anche quelli più forti.

Esito principale: guadagno di log-loss AALpy contro Markov1 e contro Markov di complessità più vicina; media prima per gruppo fisico test e poi fra gruppi. IC percentile95% su10.000 bootstrap degli stessi dieci gruppi, senza rifit. Interesse solo se entrambi i limiti inferiori sono positivi e il controllo di complessità è entro il rapporto prefissato. Se il riferimento di complessità coincide con Markov1 non è un secondo test indipendente. Confronti VVM descrittivi. Nessuna ottimizzazione dell'entropia generata, nessun riordino, nessuna decifrazione.
