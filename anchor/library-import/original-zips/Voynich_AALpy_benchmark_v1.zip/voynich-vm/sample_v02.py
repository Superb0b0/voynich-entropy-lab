import sys,json,argparse
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from vvm.lexer import load
from vvm.grammar import Grammar
from vvm.generator_v02 import generate_pages
from run_v02 import make_folds

def main():
 p=argparse.ArgumentParser();p.add_argument('--tokens',type=int,default=100);p.add_argument('--seed',type=int,default=101);p.add_argument('--out',type=Path);a=p.parse_args()
 if not 1<=a.tokens<=1000000:p.error('tokens must be 1..1000000')
 rows,_=load(ROOT);folds=make_folds(rows);train=[r for r in rows if folds[r['group']]!=0];model=Grammar.load(ROOT/'results_v02/model_fold0.json');weight=json.loads((ROOT/'results_v02/results.json').read_text())['weights'][0]['lambda_lag1'];lines,_,_=generate_pages(model,train,weight,a.tokens,a.seed);out='\n'.join(' '.join(r) for r in lines)+'\n'
 if a.out:a.out.write_text(out)
 else:print(out,end='')
if __name__=='__main__':main()
