import sys,unittest,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT))
from vvm.memory import mixture_logp,fit_weight,events
from vvm.grammar import Grammar
from run_v02 import make_folds

def rows():
 return [{'tokens':['qody','daiin'],'regime':('B','S'),'paragraph_start':False,'group':'g1','folio':'f1r'} for _ in range(5)]+[{'tokens':['qody','daiin'],'regime':('B','S'),'paragraph_start':False,'group':'g2','folio':'f2r'}]
class MemoryTests(unittest.TestCase):
 def test_mixture_matches_hand_calculation(self):self.assertAlmostEqual(math.exp(mixture_logp(math.log(.2),.5,True,.1)),.23)
 def test_no_source_no_penalty(self):self.assertEqual(mixture_logp(-3,0,False,.2),-3)
 def test_zero_cache_probability_has_mixture_penalty(self):self.assertAlmostEqual(mixture_logp(-3,0,True,.2),-3+math.log(.8))
 def test_simple_distribution_normalization(self):self.assertAlmostEqual(sum(math.exp(mixture_logp(math.log(p),q,True,.2)) for p,q in [(.2,.5),(.8,.5)]),1)
 def test_page_reset_and_lag(self):
  rr=rows();m=Grammar(rr);e=events(m,rr,1);self.assertFalse(e[0][4]);self.assertTrue(e[2][4]);self.assertFalse(e[-1][4]);e3=events(m,rr,3);self.assertFalse(e3[4][4]);self.assertTrue(e3[6][4]);self.assertFalse(e3[-1][4])
 def test_no_available_cache_weight_zero(self):self.assertEqual(fit_weight([('g','f',-.4,0,False,3)]),0)
 def test_no_overlap_weight_shrinks(self):self.assertLess(fit_weight([('g','f',-.4,0,True,3)]*100),1e-10)
 def test_fold_assignment_stable_and_grouped(self):
  rr=rows();self.assertEqual(make_folds(rr),make_folds(list(reversed(rr))));self.assertEqual(len(make_folds(rr)),2)

class GenerationV02Tests(unittest.TestCase):
 def test_base_cache_same_template_schedule(self):
  from vvm.generator_v02 import generate_pages
  rr=rows();rr[1]['tokens']=['qody'];rr[2]['tokens']=['daiin']*3;m=Grammar(rr)
  a,ga,_=generate_pages(m,rr,0.,100,5);b,gb,_=generate_pages(m,rr,.05,100,5)
  self.assertEqual(list(map(len,a)),list(map(len,b)));self.assertEqual(ga,gb)
  self.assertEqual(sum(map(len,a)),100)

if __name__=='__main__':unittest.main()
