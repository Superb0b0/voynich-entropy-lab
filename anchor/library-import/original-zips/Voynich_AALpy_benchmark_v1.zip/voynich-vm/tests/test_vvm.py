import sys,unittest,random,tempfile
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT))
from vvm.grammar import Grammar
from vvm.lexer import load
from vvm.state import State
from vvm.generator import generate
from benchmarks.rc14 import evaluate

def toy():
 return [{'tokens':['qody','daiin','qody'],'regime':('B','S'),'paragraph_start':True} for _ in range(30)]+[{'tokens':['chol','daiin'],'regime':('A','H'),'paragraph_start':False} for _ in range(30)]

class VVMTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.model=Grammar(toy())
 def test_distributions_normalized_positive(self):
  for mode in ('unigram','grammar','regime','state','layout','full'):
   for ctx in ('^^','qo','??'):
    p=self.model.distribution(mode,('B','S'),'qo',(True,True),ctx);self.assertAlmostEqual(float(p.sum()),1,places=12);self.assertTrue(np.all(p>0))
 def test_model_serialization_roundtrip(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'model.json';self.model.save(p);loaded=Grammar.load(p)
   a=self.model.score_row(toy()[0],'full');b=loaded.score_row(toy()[0],'full');self.assertEqual(a,b)
 def test_unknown_regime_backs_off(self):
  a=self.model.distribution('grammar',('X','X'),'xx',(False,False),'qo');b=self.model.distribution('full',('X','X'),'xx',(False,False),'qo');np.testing.assert_allclose(a,b)
 def test_grammar_has_no_external_state(self):
  a=self.model.distribution('grammar',('B','S'),'qo',(True,True),'qo');b=self.model.distribution('grammar',('A','H'),'ch',(False,False),'qo');np.testing.assert_allclose(a,b)
 def test_state_reset(self):
  s=State();s.update('qody');self.assertEqual(s.previous,'qo');s.reset();self.assertEqual(s.previous,'^')
 def test_group_disjointness_both_sides_and_panels(self):
  rows,_=load(ROOT);seen={}
  for r in rows:
   self.assertEqual(seen.setdefault(r['group'],r['split']),r['split'])
  self.assertEqual(len({r['group'] for r in rows if r['folio'].startswith(('f85','f86')) or r['folio']=='fRos'}),1)
 def test_generation_repeatable_and_no_line_copy(self):
  forbidden={tuple(r['tokens']) for r in toy()};a,_=generate(self.model,toy(),80,7,forbidden);b,_=generate(self.model,toy(),80,7,forbidden);self.assertEqual(a,b);self.assertEqual(sum(map(len,a)),80);self.assertFalse(any(tuple(r) in forbidden for r in a))
 def test_probabilities_do_not_change_after_scoring(self):
  before={t:len(v) for t,v in self.model.tables.items()};self.model.score_row({'tokens':['zzzz'],'regime':('X','X'),'paragraph_start':False},'full');self.assertEqual(before,{t:len(v) for t,v in self.model.tables.items()})
 def test_metrics_against_hand_calculation(self):
  b=evaluate([['a','b'],['a','a']]);self.assertAlmostEqual(b['metrics']['density'],1);self.assertAlmostEqual(b['metrics']['adjacency'],.5);self.assertAlmostEqual(b['metrics']['repetition'],1);self.assertAlmostEqual(b['metrics']['hapax'],.5)
 def test_density_not_transposition(self):
  b=evaluate([['ab','ba']]);self.assertEqual(b['metrics']['density'],0)
 def test_boundaries_excluded(self):
  b=evaluate([['a'],['a']],['f1r','f1v']);self.assertEqual(b['line_pairs'],0);self.assertIsNone(b['metrics']['adjacency'])

if __name__=='__main__':unittest.main()
