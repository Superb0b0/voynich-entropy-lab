import sys,unittest,math
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'src'))
from automaton_benchmark import Automaton,Markov,encode

def mc():
 return {'initial':0,'states':[{'output':'^','transitions':[[1,.4],[2,.6]]},{'output':'a','transitions':[[3,1.]]},{'output':'a','transitions':[[4,1.]]},{'output':'b','transitions':[]},{'output':'c','transitions':[]}]}
def row(tokens):return {'tokens':tokens,'group':'g'}
class AutomataTests(unittest.TestCase):
 def test_forward_sums_hidden_paths(self):
  a=Automaton(mc(),('a','b','c','$','?'),np.full(5,.2),0);b=np.array([1.,0,0,0,0]);p,b=a.step(b,'a');self.assertAlmostEqual(p,1);self.assertAlmostEqual(b[1],.4);self.assertAlmostEqual(b[2],.6);p,b=a.step(b,'b');self.assertAlmostEqual(p,.4)
 def test_probability_normalized_from_mixed_states(self):
  a=Automaton(mc(),('a','b','c','$','?'),np.full(5,.2),.05)
  for b in [np.array([1.,0,0,0,0]),np.array([.1,.2,.3,.1,.3])]:self.assertAlmostEqual(sum(a.step(b,c)[0] for c in a.alphabet),1)
 def test_terminal_state_backs_off(self):
  a=Automaton(mc(),('a','b','c','$','?'),np.full(5,.2),.05);p,b=a.step(np.array([0.,0,0,1.,0]),'c');self.assertAlmostEqual(p,.2);self.assertAlmostEqual(b[0],1)
 def test_unknown_output_finite(self):
  a=Automaton(mc(),('a','b','c','$','?'),np.full(5,.2),.05);p,_=a.step(np.array([1.,0,0,0,0]),'z');self.assertGreater(p,0)
 def test_encoding_and_score_denominators(self):
  r=row(['ab','c']);self.assertEqual(encode(r),'ab$c$')
  for order in range(4):
   m=Markov([r],order,1);bits,n=m.score(row(['za']));self.assertEqual(n,3);self.assertTrue(math.isfinite(bits))
 def test_markov_rows_reset(self):
  r=row(['ab']);m=Markov([r],1,1);self.assertEqual(m.score(r),m.score(r))
 def test_explicit_free_parameters(self):
  a=Automaton(mc(),('a','b','c','$','?'),np.full(5,.2),.05);self.assertEqual(a.parameters(),6)
if __name__=='__main__':unittest.main()
