# Benchmark di automi passivi — eseguito

Il confronto AALpy è completato. Automa selezionato:49 stati,569 archi,547 parametri probabilistici. Sul test escluso batte Markov1 (2,06957 contro2,13800 bit/simbolo) ma rimane peggiore di Markov2/3 e VVM0.2. Selezione su validation distinta; dieci gruppi fisici test. Vedere results_automata/RAPPORTO.md, selection.json e per_group.csv.

```bash
python3 -m pip install -r requirements-automata.txt
python3 -m unittest discover -s tests -v
python3 automaton_benchmark.py
```

27 test superati. Dipendenze esatte, licenza e provenienza AALpy incluse. La release del generatore resta VVM0.2; il benchmark è un'aggiunta separata, non una VVM0.3 generativa già realizzata. Corpus già studiato: analisi esplorativa, nessuna decifrazione. Per ripristinare la cronologia: `git clone voynich-aalpy-benchmark-v1.bundle voynich-vm-restored`.

---

# Voynich Virtual Machine — VVM 0.2.0

Versione attuale: memoria causale della riga precedente, confronto a lag3, validazione a cinque fold su tutti i 50 gruppi fisici rappresentati. Vedere results_v02/RAPPORTO.md. Il formato serializzato della grammatica resta 0.1.0 perché lo stesso motore è riutilizzato; versione del progetto e formato del modello sono distinti.

```bash
python3 -m unittest discover -s tests -v
python3 run_v02.py
python3 sample_v02.py --tokens 100 --seed 101
```

Il modello del fold0 è incluso in results_v02/model_fold0.json; il peso della memoria è in results_v02/results.json. Nessun addestramento sul test del fold0 è necessario per generare il campione. Il confronto predittivo usa invece tutte le cinque esclusioni, ogni locus valutato una sola volta. Le nuove sezioni non erano coperte dal test unico v0.1: risultati delle due versioni non sono un confronto diretto sullo stesso test.

V0.2: miglioramento piccolo fuori campione della memoria, circa0,0065 bit/token macro; entrambe le varianti generative con e senza cache rientrano nelle quattro bande diagnostiche. Questo non certifica il benchmark storico e non identifica un cifrario. 20 test automatici superati. I risultati v0.1 e il tag v0.1.0 restano conservati.

Archivio Git portabile: `git clone vvm-v0.2.bundle voynich-vm-restored` dalla cartella dell'archivio. I comandi e le note sotto descrivono la v0.1, ancora eseguibile.

---

# Voynich Virtual Machine — VVM 0.1.0

Emulatore sperimentale del testo Voynich, con moduli sostituibili, generazione e valutazione fuori campione. È un modello statistico esplicito, non una decifrazione e non il programma storico recuperato. L'architettura modulare da sola non costituisce una nuova spiegazione storica.

## Eseguire

Richiede Python 3.10+ e NumPy. Dalla directory del progetto:

```bash
python3 -m pip install -r requirements.txt
python3 -m unittest discover -s tests -v
python3 run.py
python3 sample.py --tokens 100 --seed 101
```

Il modello già addestrato è incluso in results/model_v01.json. sample.py lo ricarica senza riaddestrare. run.py ricrea modello, split, confronti, campioni e risultati. I parametri della v0.1 sono fissati: impostazioni numeriche non supportate causano arresto invece di essere ignorate.

## Moduli

| File | Responsabilità |
|---|---|
| src/vvm/lexer.py | Adattatore al parser RC1.2 congelato, metadati, gruppi fisici e split |
| src/vvm/grammar.py | Probabilità carattere per carattere, backoff, scoring e serializzazione |
| src/vvm/modules.py | Regimi Currier/sezione |
| src/vvm/state.py | Prefisso della parola precedente nella stessa riga |
| src/vvm/layout.py | Prima parola della riga e inizio paragrafo esplicito |
| src/vvm/generator.py | Generazione carattere per carattere con seed e divieto di copia esatta di righe train |
| benchmarks/rc14.py | Implementazione diagnostica dichiarata di quattro proprietà |
| tests/test_vvm.py | Normalizzazione, backoff, causalità, split, riproducibilità, roundtrip e metriche sintetiche |

Le probabilità sono apprese soltanto dalle righe train. Le specializzazioni sono gerarchiche, non vincoli deterministici scoperti. Lo stato non conserva righe precedenti. Le parole del lessico train possono ricomparire; la v0.1 produce anche nuove combinazioni e nuove forme. Le parole sono token EVA RC1.2, non unità linguistiche dimostrate.

## Risultato della prima esecuzione

Vedere results/RAPPORTO.md. Sono presenti due campioni da 35.492 token, un esempio breve, il modello serializzato, tutte le assegnazioni train/test e gli esiti delle ablazioni. Nessuna scelta di pesi dopo aver osservato i risultati. Il protocollo è stato scritto prima dell'esecuzione locale; non è una preregistrazione esterna. La versione Git è stata creata alla consegna, dopo l'esecuzione, e non è una prova temporale di preregistrazione.

Limiti decisivi: solo sette gruppi fisici nel test; il corpus era già studiato; test senza sezioni biologica e stelle/ricette; nessun superamento certificato RC1.4; nessuna analisi del significato o del codice storico. Lunghezze e metadati delle righe sintetiche provengono da template train: il modello non genera autonomamente l'intero layout di una pagina.

## File e provenienza

Corpus e parser originali sono conservati in corpus/. La mappa dei bifogli proviene dalla precedente ricognizione della collazione pubblicata ed è usata soltanto per prevenire la divisione di unità fisiche fra train e test. Non si esegue alcun builder del ramo RC1.4.2, PCA, clustering o conditional coupling. SOURCES.md e manifest.json identificano gli input. Un archivio Git portabile accompagna la consegna; per ricreare il repository: git clone vvm-v0.1.bundle voynich-vm-restored.
