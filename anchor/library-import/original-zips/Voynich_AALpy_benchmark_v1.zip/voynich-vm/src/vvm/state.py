class State:
    """Causal, line-local two-character prefix memory."""
    def __init__(self): self.previous='^'
    def update(self,word): self.previous=word[:2]
    def reset(self): self.previous='^'
