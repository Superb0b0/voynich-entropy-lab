def regime_key(row):
    return tuple(row['regime'])
