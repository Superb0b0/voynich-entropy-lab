"""Read frozen RC1.2 records and independent source metadata."""
import re,csv,hashlib,importlib.util
from pathlib import Path

def load(root,seed='VVM-20261111-v01'):
    root=Path(root);corpus=root/'corpus/ZL3b-n.txt';parser=root/'corpus/ivtff_parser_rc1_2.py'
    spec=importlib.util.spec_from_file_location('frozen_rc12',parser);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    report=m.parse_corpus(corpus);raw=corpus.read_text().splitlines();meta={};physical={}
    for rr in csv.DictReader((root/'corpus/physical_map_verified.csv').read_text().splitlines()):
        for side in rr['folio_recto'].split('|'):
            physical[int(re.search(r'f(\d+)',side)[1])]=rr['bifolio_id']
    for line in raw:
        a=re.match(r'^<(f\d+[rv]\d*)>\s*<!([^>]*)>',line)
        if a:
            vals=[]
            for k in ['L','I']:
                z=re.search(r'\$'+k+r'=([^\s>]+)',a[2]);vals.append(z[1] if z else 'unknown')
            meta[a[1]]=tuple(vals)
    rows=[]
    for r in report['records']:
        folio=r['folio'];a=re.match(r'f(\d+)',folio)
        group='Q14_B01' if folio=='fRos' else physical.get(int(a[1]),'leaf_'+a[1]) if a else folio
        bucket=int(hashlib.sha256((seed+':'+group).encode()).hexdigest(),16)%5
        body=m.COMMENT_RE.sub('',raw[r['physical_line']-1].split('>',1)[1])
        rows.append({**r,'group':group,'split':'test' if bucket==0 else 'train','regime':meta.get(folio,('unknown','unknown')),'paragraph_start':'<%>' in body})
    return rows,report['source']
