def position_key(index,paragraph_start):
    return (index==0, bool(paragraph_start) if index==0 else False)
