import random
from .state import State
from .layout import position_key

def generate(model,templates,n_tokens,seed,forbidden):
    rng=random.Random(seed);out=[];seen=set();remaining=n_tokens;rejections=0
    while remaining:
        r=rng.choice(templates);length=min(len(r['tokens']),remaining)
        for attempt in range(100):
            words=[];st=State()
            for j in range(length):
                for tries in range(1000):
                    chars='';ctx='^^'
                    for step in range(33):
                        p=model.distribution('full',tuple(r['regime']),st.previous,position_key(j,r['paragraph_start']),ctx)
                        c=rng.choices(model.symbols,weights=p,k=1)[0]
                        if c=='$':break
                        if c=='?':continue
                        chars+=c;ctx=(ctx+c)[-2:]
                    if c=='$' and 0<len(chars)<=32:break
                else:raise RuntimeError('word generation limit')
                words.append(chars);st.update(chars)
            key=tuple(words)
            if key not in forbidden and key not in seen:break
            rejections+=1
        else:raise RuntimeError('cannot generate an unobserved line')
        seen.add(key);out.append(words);remaining-=length
    return out,{'rejected_lines':rejections}
