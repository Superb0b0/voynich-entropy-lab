"""Explicit line-cache mixture over word probabilities."""
import math
from collections import Counter,defaultdict
from .layout import position_key
from .state import State

def word_logp(model,word,reg,previous,pos):
    ctx='^^';out=0.
    for c in word+'$':
        pr=model.distribution('full',tuple(reg),previous,pos,ctx);out+=math.log(float(pr[model.lookup.get(c,model.lookup['?'])]));ctx=(ctx+c)[-2:]
    return out

def events(model,rows,lag):
    """Previous loci must be in the same folio-side/panel; reset each page."""
    pages=defaultdict(list)
    for r in rows:pages[r['folio']].append(r)
    out=[]
    for rr in pages.values():
        for i,r in enumerate(rr):
            cache=Counter(rr[i-lag]['tokens']) if i>=lag else Counter();den=sum(cache.values());st=State()
            for j,w in enumerate(r['tokens']):
                lp=word_logp(model,w,r['regime'],st.previous,position_key(j,r['paragraph_start']));q=cache[w]/den if den else 0.
                out.append((r['group'],r['folio'],lp,q,bool(den),len(w)+1));st.update(w)
    return out

def fit_weight(ee,iterations=50):
    """MAP EM for Beta(1,19); only training events enter."""
    eligible=[(math.exp(max(lp,-700)),q) for _,_,lp,q,has,_ in ee if has]
    if not eligible:return 0.
    lam=.03
    for _ in range(iterations):
        resp=sum(lam*q/((1-lam)*p+lam*q) for p,q in eligible)
        lam=resp/(len(eligible)+18)
    return lam

def mixture_logp(lp,q,has,weight):
    if not has or weight==0:return lp
    a=math.log1p(-weight)+lp
    if q==0:return a
    b=math.log(weight)+math.log(q);top=max(a,b)
    return top+math.log(math.exp(a-top)+math.exp(b-top))
