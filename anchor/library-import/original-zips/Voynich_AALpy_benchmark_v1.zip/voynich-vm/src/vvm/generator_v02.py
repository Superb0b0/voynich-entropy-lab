import random
from collections import defaultdict
from .layout import position_key
from .state import State

def sample_word(model,rng,reg,previous,pos):
    for attempt in range(1000):
        chars='';ctx='^^'
        for step in range(33):
            p=model.distribution('full',tuple(reg),previous,pos,ctx);c=rng.choices(model.symbols,weights=p,k=1)[0]
            if c=='$':break
            if c=='?':continue
            chars+=c;ctx=(ctx+c)[-2:]
        if c=='$' and 0<len(chars)<=32:return chars
    raise RuntimeError('word generation limit')

def generate_pages(model,train,weight,n_tokens,seed):
    pages=defaultdict(list)
    for r in train:pages[r['folio']].append(r)
    templates=list(pages.values());forbidden={tuple(r['tokens']) for r in train};rng=random.Random(seed);template_rng=random.Random(seed^0x56A02);out=[];groups=[];remaining=n_tokens;page_id=0;rejected=0
    while remaining:
        template=template_rng.choice(templates);previous=[]
        for row in template:
            length=min(remaining,len(row['tokens']))
            for attempt in range(100):
                words=[];state=State()
                for j in range(length):
                    if previous and rng.random()<weight:w=rng.choice(previous)
                    else:w=sample_word(model,rng,row['regime'],state.previous,position_key(j,row['paragraph_start']))
                    words.append(w);state.update(w)
                if tuple(words) not in forbidden:break
                rejected+=1
            else:raise RuntimeError('line rejection limit')
            out.append(words);groups.append(page_id);previous=words;remaining-=length
            if not remaining:break
        page_id+=1
    assert not any(tuple(r) in forbidden for r in out)
    return out,groups,{'pages':page_id,'rejected_train_lines':rejected,'copied_train_lines':0}
