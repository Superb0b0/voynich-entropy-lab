from collections import defaultdict
from functools import lru_cache
import numpy as np
from .layout import position_key
from .state import State
from .modules import regime_key

class Grammar:
    def __init__(self,rows):
        self.symbols=tuple(sorted({c for r in rows for w in r['tokens'] for c in w}))+('$','?')
        self.lookup={c:i for i,c in enumerate(self.symbols)};self.K=len(self.symbols)
        self.counts={n:defaultdict(lambda:np.zeros(self.K)) for n in ('g0','g1','g2','regime','state','layout')}
        for r in rows:
            st=State();reg=regime_key(r)
            for j,word in enumerate(r['tokens']):
                ctx='^^';pos=position_key(j,r['paragraph_start'])
                for c in word+'$':
                    k=self.lookup[c]
                    for table,key in [('g0',''),('g1',ctx[-1:]),('g2',ctx),('regime',(reg,ctx)),('state',(reg,st.previous,ctx)),('layout',(reg,pos,ctx))]:self.counts[table][key][k]+=1
                    ctx=(ctx+c)[-2:]
                st.update(word)
        self.tables={name:{key:(c,float(c.sum())) for key,c in t.items()} for name,t in self.counts.items()}
        del self.counts
    def shrink(self,table,key,parent,strength):
        hit=self.tables[table].get(key)
        if hit is None:return parent
        c,n=hit;return (c+strength*parent)/(n+strength)
    @lru_cache(maxsize=100000)
    def distribution(self,variant,reg,previous,pos,ctx):
        p=self.shrink('g0','',np.full(self.K,1/self.K),5)
        if variant=='unigram':return p
        p=self.shrink('g1',ctx[-1:],p,5);p=self.shrink('g2',ctx,p,5)
        if variant=='grammar':return p
        p=self.shrink('regime',(reg,ctx),p,20)
        if variant in ('state','full'):p=self.shrink('state',(reg,previous,ctx),p,20)
        if variant in ('layout','full'):p=self.shrink('layout',(reg,pos,ctx),p,20)
        return p
    def score_row(self,row,variant):
        bits=0.;count=0;st=State();reg=regime_key(row)
        for j,word in enumerate(row['tokens']):
            ctx='^^';pos=position_key(j,row['paragraph_start'])
            for c in word+'$':
                p=self.distribution(variant,reg,st.previous,pos,ctx);bits-=float(np.log2(p[self.lookup.get(c,self.lookup['?'])]));count+=1;ctx=(ctx+c)[-2:]
            st.update(word)
        return bits,count
    def save(self,path):
        import json
        data={'version':'0.1.0','symbols':self.symbols,'tables':{name:[{'key':key,'counts':c.tolist()} for key,(c,n) in t.items()] for name,t in self.tables.items()}}
        path.write_text(json.dumps(data,separators=(',',':')))

    @classmethod
    def load(cls,path):
        import json
        data=json.loads(path.read_text())
        if data.get('version')!='0.1.0':raise ValueError('unsupported model version')
        obj=cls.__new__(cls);obj.symbols=tuple(data['symbols']);obj.lookup={c:i for i,c in enumerate(obj.symbols)};obj.K=len(obj.symbols)
        def freeze(x):return tuple(freeze(v) for v in x) if isinstance(x,list) else x
        obj.tables={name:{freeze(r['key']):(np.array(r['counts'],dtype=float),float(sum(r['counts']))) for r in rr} for name,rr in data['tables'].items()}
        return obj
