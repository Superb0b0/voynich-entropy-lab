import sys,json,hashlib,collections,csv,math
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from vvm.lexer import load
from vvm.grammar import Grammar
from vvm.memory import events,fit_weight,mixture_logp
from vvm.generator_v02 import generate_pages
from benchmarks.rc14 import evaluate

def make_folds(rows):
    counts=collections.defaultdict(collections.Counter)
    for r in rows:counts[r['group']][r['regime'][1]]+=len(r['tokens'])
    strata=collections.defaultdict(list)
    for g,cc in counts.items():strata[sorted(cc,key=lambda k:(-cc[k],k))[0]].append(g)
    out={};offset=0
    for sec,gg in sorted(strata.items()):
        gg.sort(key=lambda g:hashlib.sha256(('VVM-v02:'+g).encode()).hexdigest())
        for i,g in enumerate(gg):out[g]=(offset+i)%5
        offset=(offset+len(gg))%5
    return out

def run():
    cfg=json.loads((ROOT/'experiments/v02.json').read_text());assert (cfg['folds'],cfg['em_iterations'],cfg['beta_prior_a'],cfg['beta_prior_b'],cfg['memory_lags'])==(5,50,1,19,[1,3]), 'unsupported v0.2 configuration';rows,source=load(ROOT);foldmap=make_folds(rows);allstats=[];weights=[];gen=[]
    for fold in range(5):
        train=[r for r in rows if foldmap[r['group']]!=fold];test=[r for r in rows if foldmap[r['group']]==fold];assert not {r['group'] for r in train}&{r['group'] for r in test};model=Grammar(train);test_e={};ww={}
        for lag in (1,3):
            train_e=events(model,train,lag);ww[lag]=fit_weight(train_e);test_e[lag]=events(model,test,lag)
        weights.append(dict(fold=fold,train_groups=len({r['group'] for r in train}),test_groups=len({r['group'] for r in test}),train_tokens=sum(len(r['tokens']) for r in train),test_tokens=sum(len(r['tokens']) for r in test),lambda_lag1=ww[1],lambda_lag3=ww[3]))
        for name,lag,weight in [('base',1,0.),('lag1',1,ww[1]),('lag3',3,ww[3])]:
            agg=collections.defaultdict(lambda:[0.,0,0])
            for g,f,lp,q,has,n in test_e[lag]:
                agg[g][0]-=mixture_logp(lp,q,has,weight)/math.log(2);agg[g][1]+=1;agg[g][2]+=n
            for g,(bits,n,chars) in sorted(agg.items()):allstats.append(dict(fold=fold,model=name,group=g,bits=bits,tokens=n,symbols=chars,bits_per_token=bits/n,bits_per_symbol=bits/chars))
        print('fold',fold,'weights',ww,flush=True)
        if fold==0:
            model.save(ROOT/'results_v02/model_fold0.json')
            seen={w for r in train for w in r['tokens']}
            for seed in cfg['generation_seeds']:
                for mode,w in [('base',0.),('lag1',ww[1])]:
                    lines,pages,details=generate_pages(model,train,w,cfg['generated_tokens'],seed);tokens=[t for rr in lines for t in rr];types=set(tokens)
                    (ROOT/f'results_v02/generated_{mode}_{seed}.txt').write_text('\n'.join(' '.join(r) for r in lines)+'\n')
                    (ROOT/f'results_v02/pages_{mode}_{seed}.json').write_text(json.dumps(pages))
                    gen.append(dict(mode=mode,seed=seed,weight=w,**details,novel_token_fraction=sum(w not in seen for w in tokens)/len(tokens),novel_type_fraction=len(types-seen)/len(types),benchmark=evaluate(lines,pages)))
        model.distribution.cache_clear()
    assert sum(r['tokens'] for r in allstats if r['model']=='base')==35492
    rng=np.random.default_rng(cfg['seed']);groups=sorted(foldmap);ix=rng.integers(0,len(groups),(10000,len(groups)));scores={}
    for name in ('base','lag1','lag3'):
        ss=[r for r in allstats if r['model']==name];scores[name]={'bits_per_token':sum(r['bits'] for r in ss)/sum(r['tokens'] for r in ss),'bits_per_symbol':sum(r['bits'] for r in ss)/sum(r['symbols'] for r in ss),'macro_bits_per_token':float(np.mean([r['bits_per_token'] for r in ss]))}
    comp={}
    for a,b in [('base','lag1'),('lag3','lag1')]:
        va={r['group']:r['bits_per_token'] for r in allstats if r['model']==a};vb={r['group']:r['bits_per_token'] for r in allstats if r['model']==b};delta=np.array([va[g]-vb[g] for g in groups]);comp[b+'_vs_'+a]={'macro_gain_bits_per_token':float(delta.mean()),'ci95':np.quantile(delta[ix].mean(axis=1),[.025,.975]).tolist(),'positive_groups':int(sum(delta>0))}
    result={'version':'0.2.0','analysis':'exploratory','protocol_sha256':hashlib.sha256((ROOT/'experiments/PROTOCOLLO_v02.md').read_bytes()).hexdigest(),'source':source,'groups':len(groups),'OOF_lines':len(rows),'OOF_tokens':35492,'weights':weights,'scores':scores,'comparisons':comp,'criterion_passed':all(c['ci95'][0]>0 for c in comp.values()),'generated':gen,'real_diagnostic':evaluate([r['tokens'] for r in rows],[r['folio'] for r in rows])}
    (ROOT/'results_v02/results.json').write_text(json.dumps(result,indent=2))
    with (ROOT/'results_v02/per_group.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(allstats[0]));w.writeheader();w.writerows(allstats)
    with (ROOT/'results_v02/folds.csv').open('w',newline='') as f:w=csv.writer(f);w.writerow(['locus','folio','physical_group','fold','Currier','section']);w.writerows([r['locus_id'],r['folio'],r['group'],foldmap[r['group']],*r['regime']] for r in rows)
    print(json.dumps(result,indent=2))
if __name__=='__main__':run()
