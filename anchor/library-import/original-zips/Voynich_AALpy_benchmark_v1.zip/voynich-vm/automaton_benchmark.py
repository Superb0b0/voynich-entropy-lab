import sys,os,json,csv,math,time,hashlib,collections,itertools,subprocess,importlib.metadata
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
# Prefer an installed pinned package; optional local target for this execution environment.
DEPS=ROOT.parent/'aalpy_deps'
if DEPS.exists():sys.path.insert(0,str(DEPS))
from vvm.lexer import load
from vvm.grammar import Grammar
from vvm.memory import events,fit_weight,mixture_logp
from run_v02 import make_folds
O=ROOT/'results_automata'

def encode(r):return ''.join(w+'$' for w in r['tokens'])
def prior(rows):
    c=collections.Counter(''.join(encode(r) for r in rows));alphabet=tuple(sorted(c))+('?',);n=sum(c.values())+.5*len(alphabet);return alphabet,np.array([(c[x]+.5)/n for x in alphabet])
def count_mc(model):
    return len(model['states']),sum(len(s['transitions']) for s in model['states'])
def save_mc(m,path):
    ix={s:i for i,s in enumerate(m.states)}
    out={'initial':ix[m.initial_state],'states':[{'id':str(s.state_id),'output':s.output,'transitions':[[ix[t],p] for t,p in s.transitions]} for s in m.states]};path.write_text(json.dumps(out));return out

def fit_child():
    from aalpy.learning_algs import run_Alergia
    spec=json.loads(Path(sys.argv[2]).read_text());traces=json.loads(Path(spec['traces']).read_text());t=time.monotonic();m=run_Alergia(traces,'mc',eps=spec['eps']);save_mc(m,Path(spec['output']));print(json.dumps({'seconds':time.monotonic()-t,'states':len(m.states)}))

def fit_mc(rows,eps,label,timeout):
    traces=O/(label+'_traces.json');traces.write_text(json.dumps([['^']+list(encode(r)) for r in rows]));spec=O/(label+'_fit.json');out=O/(label+'_model.json');spec.write_text(json.dumps({'traces':str(traces),'eps':eps,'output':str(out)}));t=time.monotonic()
    try:
        cp=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--fit-child',str(spec)],capture_output=True,text=True,timeout=timeout)
        (O/(label+'_fit.log')).write_text(cp.stdout+'\n'+cp.stderr)
        if cp.returncode:return None,{'status':'ERROR','seconds':time.monotonic()-t,'returncode':cp.returncode}
        return json.loads(out.read_text()),{'status':'OK','seconds':time.monotonic()-t}
    except subprocess.TimeoutExpired:return None,{'status':'TIMEOUT','seconds':time.monotonic()-t}

class Automaton:
    def __init__(self,model,alphabet,q,delta):
        self.model=model;self.alphabet=alphabet;self.index={x:i for i,x in enumerate(alphabet)};self.q=q;self.delta=delta;self.n=len(model['states']);self.initial=model['initial'];self.dead=[];edges=collections.defaultdict(list)
        for i,s in enumerate(model['states']):
            if not s['transitions']:self.dead.append(i)
            else:assert abs(sum(p for j,p in s['transitions'])-1)<1e-9
            for j,p in s['transitions']:edges[model['states'][j]['output']].append((i,j,p))
        self.edges={x:(np.array([a for a,b,p in e]),np.array([b for a,b,p in e]),np.array([p for a,b,p in e])) for x,e in edges.items()}
    def step(self,belief,char):
        char=char if char in self.index else '?';noise=self.delta+(1-self.delta)*sum(belief[i] for i in self.dead);nxt=np.zeros(self.n);nxt[self.initial]=noise*self.q[self.index[char]]
        if char in self.edges:
            src,dst,p=self.edges[char];nxt+=np.bincount(dst,weights=(1-self.delta)*belief[src]*p,minlength=self.n)
        prob=float(nxt.sum());assert prob>0 and np.isfinite(prob);return prob,nxt/prob
    def score(self,r):
        belief=np.zeros(self.n);belief[self.initial]=1;loss=0.
        for x in encode(r):p,belief=self.step(belief,x);loss-=math.log2(p)
        return loss,len(encode(r))
    def parameters(self):
        return sum(max(len(s['transitions'])-1,0) for s in self.model['states'])+len(self.alphabet)-1+1

class Markov:
    def __init__(self,rows,order,strength):
        self.alphabet,self.q=prior(rows);self.index={x:i for i,x in enumerate(self.alphabet)};self.order=order;self.strength=strength;self.counts=collections.defaultdict(lambda:np.zeros(len(self.alphabet)))
        for r in rows:
            ctx='^'*order
            for x in encode(r):self.counts[ctx][self.index[x]]+=1;ctx=(ctx+x)[-order:] if order else ''
        self.probs={k:(c+strength*self.q)/(c.sum()+strength) for k,c in self.counts.items()}
    def score(self,r):
        ctx='^'*self.order;loss=0.
        for x0 in encode(r):
            x=x0 if x0 in self.index else '?';p=self.probs.get(ctx,self.q);loss-=math.log2(float(p[self.index[x]]));ctx=(ctx+x)[-self.order:] if self.order else ''
        return loss,len(encode(r))
    def parameters(self):return (len(self.probs)+(self.order>0))*(len(self.alphabet)-1)

def score(model,rows):
    out=collections.defaultdict(lambda:[0.,0])
    for r in rows:b,n=model.score(r);out[r['group']][0]+=b;out[r['group']][1]+=n
    return {g:{'bits':b,'symbols':n,'loss':b/n} for g,(b,n) in out.items()}
def micro(sc):return sum(v['bits'] for v in sc.values())/sum(v['symbols'] for v in sc.values())
def vvm_scores(model,rows,weight):
    agg=collections.defaultdict(lambda:[0.,0])
    for g,f,lp,q,has,n in events(model,rows,1):agg[g][0]-=mixture_logp(lp,q,has,weight)/math.log(2);agg[g][1]+=n
    return {g:{'bits':b,'symbols':n,'loss':b/n} for g,(b,n) in agg.items()}

def main():
    O.mkdir(exist_ok=True);cfg=json.loads((ROOT/'experiments/automata.json').read_text());assert importlib.metadata.version('aalpy')==cfg['aalpy_version'];rows,source=load(ROOT);foldmap=make_folds(rows);train=[r for r in rows if foldmap[r['group']] in cfg['train_folds']];val=[r for r in rows if foldmap[r['group']]==1];test=[r for r in rows if foldmap[r['group']]==0]
    assert not ({r['group'] for r in train}&{r['group'] for r in val}) and not ({r['group'] for r in train+val}&{r['group'] for r in test})
    cand=[];alphabet,q=prior(train)
    for eps in cfg['eps_grid']:
        mm,fit=fit_mc(train,eps,'validation_eps_'+str(eps),cfg['fit_timeout_seconds']);print('fit',eps,fit,flush=True)
        if mm is None:cand.append({'kind':'aalpy','eps':eps,**fit});continue
        for delta in cfg['backoff_grid']:
            mo=Automaton(mm,alphabet,q,delta);cand.append({'kind':'aalpy','eps':eps,'delta':delta,'validation_loss':micro(score(mo,val)),'parameters':mo.parameters(),'states':len(mm['states']),'edges':count_mc(mm)[1],**fit})
    aa=[c for c in cand if c['kind']=='aalpy' and c['status']=='OK'];selected=min(aa,key=lambda c:(round(c['validation_loss'],9),c['parameters'],c['eps'],c['delta'])) if aa else None
    chosen_markov={}
    for order in cfg['markov_orders']:
        cc=[]
        for a in cfg['markov_strengths']:
            m=Markov(train,order,a);c={'kind':'markov','order':order,'strength':a,'validation_loss':micro(score(m,val)),'parameters':m.parameters(),'status':'OK'};cc.append(c);cand.append(c)
        chosen_markov[order]=min(cc,key=lambda c:(c['validation_loss'],c['strength']))
    (O/'selection.json').write_text(json.dumps({'candidates':cand,'selected_aalpy':selected,'selected_markov':chosen_markov},indent=2));print('selection frozen',selected,flush=True)
    # Test used for the first time below, after all selections.
    fitrows=train+val;models={};complexities={}
    for order,c in chosen_markov.items():
        m=Markov(fitrows,order,c['strength']);name='Markov'+str(order);models[name]=score(m,test);complexities[name]={'parameters':m.parameters(),'contexts':len(m.probs),'strength':c['strength']}
    finalfit=None
    if selected:
        mm,finalfit=fit_mc(fitrows,selected['eps'],'final_aalpy',cfg['fit_timeout_seconds'])
        if mm is not None:
            a,q=prior(fitrows);m=Automaton(mm,a,q,selected['delta']);models['AALpy']=score(m,test);complexities['AALpy']={'parameters':m.parameters(),'states':len(mm['states']),'edges':count_mc(mm)[1],'eps':selected['eps'],'delta':selected['delta']}
    grammar=Grammar(fitrows);weight=fit_weight(events(grammar,fitrows,1));models['VVM_base']=vvm_scores(grammar,test,0.);models['VVM_memory']=vvm_scores(grammar,test,weight)
    summaries={name:{'micro_bits_per_symbol':micro(sc),'macro_bits_per_symbol':float(np.mean([v['loss'] for v in sc.values()]))} for name,sc in models.items()};rng=np.random.default_rng(cfg['seed']);groups=sorted(models['Markov1']);ix=rng.integers(0,len(groups),(cfg['bootstrap_reps'],len(groups)));comp={};closest=None;ratio=None
    if 'AALpy' in models:
        closest=min([n for n in complexities if n.startswith('Markov')],key=lambda n:abs(math.log(complexities[n]['parameters']/complexities['AALpy']['parameters'])));ratio=max(complexities[closest]['parameters'],complexities['AALpy']['parameters'])/min(complexities[closest]['parameters'],complexities['AALpy']['parameters'])
        for ref in [n for n in models if n!='AALpy']:
            delta=np.array([models[ref][g]['loss']-models['AALpy'][g]['loss'] for g in groups]);comp['AALpy_vs_'+ref]={'macro_gain':float(delta.mean()),'ci95':np.quantile(delta[ix].mean(axis=1),[.025,.975]).tolist(),'positive_groups':int(sum(delta>0))}
    passed=bool(closest and ratio<=cfg['complexity_ratio_limit'] and comp['AALpy_vs_Markov1']['ci95'][0]>0 and comp['AALpy_vs_'+closest]['ci95'][0]>0)
    result={'analysis':'exploratory','source':source,'aalpy_version':importlib.metadata.version('aalpy'),'protocol_sha256':hashlib.sha256((ROOT/'experiments/PROTOCOLLO_AUTOMATA.md').read_bytes()).hexdigest(),'split':{n:{'groups':len({r['group'] for r in rr}),'rows':len(rr),'tokens':sum(len(r['tokens']) for r in rr),'symbols':sum(len(encode(r)) for r in rr)} for n,rr in [('train',train),('validation',val),('test',test)]},'selected':selected,'final_fit':finalfit,'scores':summaries,'complexities':complexities,'nearest_complexity_markov':closest,'parameter_ratio':ratio,'comparisons':comp,'criterion_passed':passed,'vvm_memory_weight':weight}
    (O/'results.json').write_text(json.dumps(result,indent=2));out=[]
    for name,sc in models.items():
        for g,v in sc.items():out.append({'model':name,'group':g,**v})
    with (O/'per_group.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
    with (O/'partitions.csv').open('w',newline='') as f:w=csv.writer(f);w.writerow(['locus','group','partition']);w.writerows([r['locus_id'],r['group'],'test' if foldmap[r['group']]==0 else 'validation' if foldmap[r['group']]==1 else 'train'] for r in rows)
    print(json.dumps(result,indent=2))
if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--fit-child':fit_child()
    else:main()
