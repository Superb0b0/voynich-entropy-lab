# Fonti della versione 0.1

- ZL3b-n.txt originale, trascrizione IVTFF Zandbergen–Landini: https://www.voynich.nu/data/ZL3b-n.txt . Byte già recuperati negli esperimenti precedenti. SHA-256 bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc.
- ivtff_parser_rc1_2.py: artefatto originale della ricerca dell'utente, 10.599 byte, SHA-256 8a614436a2d5dc3cb30c282743929aaa21a379d9da7e691b4277c670ce2a91c5. Copiato senza modificarlo. Le sue convenzioni editoriali non vengono promosse a verità paleografica.
- physical_map_verified.csv: mappa R6 della collazione pubblicata. Schemi consultati durante R6: https://voynich.nu/layout.html ; descrizione https://voynich.nu/descr.html ; scheda storica Yale https://pre1600ms.beinecke.library.yale.edu/docs/pre1600.ms408.htm . Provenienza per riga nel CSV.
- benchmark_dieci_processi_voynich_2026-11-03.md: nota interna recuperata e letta integralmente. Definisce le quattro proprietà e le bande, ma contiene anche una revisione con rilievi aperti. L'eseguibile storico valuta_corpus_v2.py non è stato ritrovato con la ricerca nominale: il presente valutatore è un'implementazione nuova dichiarata, non una copia attestata di quella pipeline.

La soglia di densità storica e i conteggi da 34.323 token non sono trasferibili come validazione automatica del corpus RC1.2 da 35.492 token. Il corpus reale ricalcolato con il nuovo profilo ha densità 0,97464, già fuori dalla banda storica: nessun PASS globale storico viene attribuito ai sintetici.

## AALpy

Repository ufficiale: https://github.com/DES-Lab/AALpy . Esecuzione sulla release PyPI2.0.0, non sul ramo master variabile. Algoritmo verificato nel codice installato: aalpy/learning_algs/stochastic_passive/Alergia.py. Metadati wheel, versioni e impronte in third_party/aalpy/provenance.json. Licenza: https://api.github.com/repos/DES-Lab/AALpy/contents/LICENCE.txt . Nessun algoritmo attivo con interrogazioni al manoscritto è stato utilizzato.
