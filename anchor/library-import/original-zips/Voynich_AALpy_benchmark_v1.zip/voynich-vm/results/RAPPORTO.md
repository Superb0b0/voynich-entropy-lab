# VVM 0.1 — Prima esecuzione

11 novembre 2026. Prima versione funzionante di un emulatore modulare. Analisi esplorativa, nessuna decifrazione o identificazione del meccanismo storico.

## Predizione fuori campione

Train: 43 gruppi fisici, 3.792 righe, 32.503 token. Test: 7 gruppi fisici, 338 righe, 2.989 token. Le carte coniugate documentate e tutti i loro recto/verso/pannelli restano nello stesso gruppo. Split deterministico fissato prima dei risultati, senza ritoccarlo per bilanciare a posteriori le sezioni.

| Modello | Bit per simbolo test, EOS incluso (meno è meglio) |
|---|---:|
| Unigramma di caratteri | 3,85258 |
| Grammatica globale, contesto due caratteri | 2,02849 |
| Grammatica + regimi | 1,96735 |
| Regimi + stato | 1,96025 |
| Regimi + layout | 1,96688 |
| Completo: regimi + stato + layout | 1,97297 |

Le righe della tabella pesano ciascun simbolo allo stesso modo. Il modello completo riduce questa perdita del 2,74% rispetto alla grammatica globale. Il confronto primario preregolato usa però la media per gruppo fisico: guadagno 0,06489 bit/simbolo, IC bootstrap percentile95% [0,00435;0,12257], su sette gruppi test, 10.000 ricampionamenti delle perdite già stimate, senza riaddestramento.

Il completo non migliora chiaramente il modello con soli regimi: guadagno macro −0,00263, IC [−0,01410;+0,00950]. Risulta peggiore di regimi+stato (guadagno −0,01215, IC [−0,01956;−0,00409]) e di regimi+layout (−0,00569, IC [−0,00718;−0,00410]). Questi ultimi sono confronti descrittivi delle ablazioni, non prove confermative corrette per ogni confronto. Il migliore numericamente non viene riaddestrato o selezionato per riscrivere l'esito primario.

I sette gruppi test sono Q05_B04, Q06_B01, Q06_B04, Q07_B02, Q07_B03, Q08_B01, Q19_B02. Comprendono 159 righe H/A, 108 H/B, 39 P/A e 32 T/B. Non comprendono pagine biologiche né la sezione stelle/ricette. Il risultato fuori campione non dimostra generalizzazione a tali sezioni o ad altri manoscritti. Il corpus era già stato ampiamente analizzato prima di questa versione; il set test è escluso da questo fit, non da ogni conoscenza precedente.

## Generazione

| Seed | Token | Tipi | Token con forma assente nel train | Tipi assenti nel train | Copie esatte di righe train |
|---|---:|---:|---:|---:|---:|
| 11 | 35.492 | 7.587 | 15,97% | 66,64% | 0 |
| 29 | 35.492 | 7.602 | 16,28% | 67,15% | 0 |

Ogni campione ha rifiutato tre righe per copia train o duplicazione sintetica. Nuove forme rispetto al train non significano parole linguisticamente ammissibili. Dei 455 tipi test non visti nel train, i campioni generati contengono rispettivamente 72 e 73 tipi: questo è un riscontro descrittivo con una generazione molto più lunga del test, non un'accuratezza predittiva o una significatività.

I campioni sono prodotti da distribuzioni di caratteri apprese, senza recuperare frasi o righe dal corpus. I template campionati dal train forniscono lunghezza in token, metadati e marcatore d'inizio; non viene generata la geometria autonoma delle pagine. Il filtro di non copia e il limite di lunghezza delle parole rendono il processo campionato diverso dal modello non filtrato valutato con log-loss. Il simbolo UNK viene escluso dall'output sintetico.

## Quattro proprietà diagnostiche

| Campione | Densità | Adiacenza | Ripetizione locale | Hapax/tipi |
|---|---:|---:|---:|---:|
| Reale RC1.2 | 0,97464 | 0,03104 | 0,06370 | 0,67550 |
| Generato, seed11 | 0,94948 | 0,01684 | 0,03510 | 0,72901 |
| Generato, seed29 | 0,94917 | 0,01689 | 0,03403 | 0,73389 |

Le bande riportate nella nota storica sono densità0,91–0,96, adiacenza0,02–0,04, ripetizione0,045–0,070, hapax0,65–0,75. I due campioni sintetici sono nelle bande di densità e hapax e sotto quelle di adiacenza e ripetizione. Nessun superamento del benchmark congiunto. Anche il reale RC1.2 ha densità fuori dalla banda storica: non si trasferiscono soglie e valori del vecchio preprocessing come una certificazione.

Il valutatore storico originale non è stato acquisito; questa è un'implementazione dichiarata delle proprietà. L'adiacenza e la ripetizione del reale escludono i confini di unità IVTFF, mentre i sintetici sono sequenze continue di righe, senza pagine complete. I numeri non sono equivalenti a una replica attestata RC1.4. Sono utili per individuare che il generatore non conserva abbastanza continuità inter-riga, ma non provano una specifica memoria storica.

## Verifiche software

11 test automatici superati: probabilità positive e normalizzate, backoff in regimi nuovi, assenza di effetti di stato/layout nella variante disattivata, reset della memoria, disgiunzione dei gruppi fisici, generazione riproducibile senza copia esatta di righe train, modello salvato/ricaricato con scoring identico, scoring che non modifica i conteggi, metriche verificate a mano e confini di pagina esclusi. Log in tests.log.

## Decisione di versione

VVM 0.1 funziona e genera campioni nuovi. La grammatica a due caratteri è molto più informativa dell'unigramma. I regimi migliorano la previsione della grammatica globale sul piccolo insieme test fissato. La combinazione di tutti i moduli non migliora il modulo di regime da solo. La prima memoria implementata è locale alla riga e non risolve il difetto osservato di continuità tra righe.

Questa è la base software versionata di un programma di ricerca. Non è una nuova decifrazione, non recupera una lingua sottostante e non verifica plausibilità storica. L'obiettivo di riprodurre congiuntamente le quattro proprietà non è raggiunto. Nessun ramo di audit RC1.4.2 è modificato.
