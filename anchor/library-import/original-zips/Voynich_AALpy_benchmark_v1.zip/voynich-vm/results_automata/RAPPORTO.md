# Benchmark AALpy — Risultati

11 novembre 2026. Esecuzione reale di AALpy2.0.0, algoritmo passivo Alergia. Analisi esplorativa, non decifrazione. Nessun numero di stati imposto.

## Risultato principale

L'automa selezionato sulla validazione batte Markov di primo ordine sul test in tutti i dieci gruppi fisici, con una parametrizzazione probabilistica più compatta nel conteggio esplicito adottato. Rimane nettamente peggiore dei Markov di ordine2/3 e delle VVM già disponibili.

| Modello | Log-loss test, bit/simbolo (meno è meglio) | Parametri probabilistici espliciti |
|---|---:|---:|
| Markov0 | 3,85266 | 26 |
| Markov1 | 2,13800 | 728 |
| AALpy Alergia | 2,06957 | 547 |
| Markov2 | 1,88935 | 8.424 |
| Markov3 | 1,88173 | 50.856 |
| VVM base full, senza cache inter-riga | 1,87079 | non equiparato in questo conteggio |
| VVM memoria inter-riga | 1,86998 | non equiparato in questo conteggio |

AALpy riduce la perdita pesata per simbolo di circa3,20% rispetto a Markov1. Parametri547 contro728, rapporto1,33: confronto approssimativamente comparabile sotto il limite predefinito2, non uguaglianza esatta. I parametri non includono costo della topologia, codifica degli stati o tutti gli iperparametri di ricerca; non è una prova di minor lunghezza totale del programma in senso MDL.

## Selezione e dimensione

Tre epsilon0,01/0,05/0,2 e quattro pesi di backoff per automa:12 configurazioni valutate sul solo validation. Selezionati epsilon0,2 e backoff0,001. Il modello train-only aveva51 stati,566 archi,542 parametri. Dopo rifit sui gruppi train+validation, senza cambiare la configurazione:49 stati,569 archi,547 parametri. Nessun timeout o errore nei quattro fit Alergia; circa2–3 secondi per fit in questa esecuzione.

Anche i Markov hanno12 configurazioni di validation:4 ordini per3 forze di smoothing. Scelte strength0,1 per Markov0, strength5 per gli altri ordini. Le configurazioni e tutte le perdite validation sono in selection.json. Nessun modello scelto guardando le perdite test. Il riferimento di complessità più vicino risulta Markov1 dai soli conteggi di parametri: non è un secondo confronto indipendente.

## Partizioni

| Partizione | Gruppi fisici | Righe P | Token | Simboli valutabili, EOS incluso |
|---|---:|---:|---:|---:|
| Training | 30 | 2.616 | 22.546 | 133.612 |
| Validazione | 10 | 747 | 6.472 | 38.521 |
| Test | 10 | 767 | 6.474 | 37.368 |

Stessi fold fisici VVM0.2: training2/3/4, validation1, test0. Dopo selezione, train+validation sono uniti per il fit finale. Non c'è separazione dei coniugati, recto/verso o pannelli tra partizioni. Corpus e fold0 erano già stati studiati: esclusione dal fit/selezione attuali, non test storico mai osservato.

## Incertezza per gruppo fisico

Il criterio primario usa la differenza di log-loss prima mediata per gruppo, con dieci gruppi pesati ugualmente. I valori non sono le semplici differenze della tabella micro sopra.

| Guadagno AALpy rispetto al riferimento | Media bit/simbolo | IC bootstrap95% | Gruppi positivi |
|---|---:|---:|---:|
| Markov1 | +0,06834 | [0,05632;0,08034] | 10/10 |
| Markov2 | −0,17195 | [−0,18820;−0,15595] | 0/10 |
| Markov3 | −0,17996 | [−0,19689;−0,16359] | 0/10 |
| VVM base | −0,21775 | [−0,25732;−0,17705] | 0/10 |
| VVM memoria | −0,21859 | [−0,25834;−0,17791] | 0/10 |

Il criterio esplorativo rispetto a Markov1 e al controllo di complessità più vicino è superato, ma entrambi i riferimenti coincidono in questa esecuzione. Gli altri confronti sono descrittivi e mostrano il limite dell'automa selezionato. Bootstrap10.000 dei gruppi con predizioni fissate, non rifit completo né correzione per tutte le scelte storiche di ricerca. VVM usa anche metadati e contesti di parola/riga: il confronto con l'automa non condizionato non isola la sola famiglia algoritmica.

## Che cosa è stato appreso

Ogni riga è una traccia di caratteri EVA, con '$' dopo ciascuna parola e '^' iniziale non valutato. Nessuno spazio aggiuntivo o secondo fine riga. Il modello conserva stato oltre la fine parola dentro la stessa riga; reset a inizio riga. Gli stati sono nodi con output, non glifi identificati: 49 non significa49 operazioni dello scriba. Le ipotesi di automi con2/4/8/16 stati non sono state forzate e non sarebbero direttamente comparabili in questa rappresentazione.

Il benchmark dimostra che un automa finito appreso passivamente può essere una rappresentazione predittiva utile e relativamente compatta di questa codifica. Non dimostra cifratura, lingua naturale, regole storiche o ordine di lettura. Non è una nuova scoperta di dipendenza oltre i caratteri adiacenti: Markov2/3 catturano più segnale, usando più parametri.

## Probabilità e backoff

Alergia nativo può assegnare probabilità zero a sequenze nuove. Il benchmark non sostituisce zeri con una costante dopo lo scoring: definisce esplicitamente un processo con probabilitàdelta di emissione dal prior e reset al nodo iniziale. I nodi senza uscite fanno sempre backoff. Il filtraggio mantiene la distribuzione su tutti gli stati compatibili, sommando i percorsi; non sceglie arbitrariamente un solo percorso. UNK e prior sono definiti dai dati di fit. Il risultato riguarda Alergia più questo backoff documentato.

Le VVM hanno probabilità di parola con EOS; il loro log-likelihood di sequenza è normalizzato per lo stesso numero di simboli, non per il numero di sole lettere. La cache VVM è stimata solo su train+validation. Nessuna riga test entra nel fit.

## Riproducibilità e software

27 test automatici superati: precedenti20 più7 su filtraggio dei percorsi, normalizzazione della distribuzione da stati misti, nodi terminali, caratteri nuovi, denominatori, reset Markov e conteggio dei parametri.

Dipendenze esatte in requirements-automata.txt: aalpy2.0.0, pydot4.0.1, pyparsing3.3.3, numpy2.3.5. Wheel hash e hash del sorgente Alergia utilizzato in third_party/aalpy/provenance.json. AALpy non è modificato. Licenza MIT e attribuzione incluse, recuperate dal repository ufficiale. Il programma del benchmark è automaton_benchmark.py; modelli AALpy, fit, selezione, partizioni, perdite per gruppo e risultati finali sono inclusi.

Dalla directory del progetto:

```bash
python3 -m pip install -r requirements-automata.txt
python3 -m unittest discover -s tests -v
python3 automaton_benchmark.py
```

Il pacchetto usa il modulo installato con pip. La cartella aalpy_deps, se presente accanto al progetto nell'ambiente originale, è un percorso alternativo di esecuzione, non una dipendenza implicita necessaria al pacchetto scaricato. Il benchmark rigenera i file intermedi con i percorsi del nuovo ambiente. Gli input originali e le versioni VVM0.1/0.2 sono conservati. Nessun artefatto dell'audit RC1.4.2 è modificato.

## Decisione

AALpy ha superato la prima prova contro Markov1 a complessità probabilistica approssimativamente comparabile. Non sostituisce VVM0.2 come modello predittivo migliore. Si conserva come concorrente interpretabile e compatto nel banco di prova; non si forza un nuovo numero di stati o un'altra configurazione sui risultati test per farlo vincere.
