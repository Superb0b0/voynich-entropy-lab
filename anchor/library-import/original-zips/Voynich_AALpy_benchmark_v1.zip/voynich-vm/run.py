import sys,json,csv,hashlib,collections
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from vvm.lexer import load
from vvm.grammar import Grammar
from vvm.generator import generate
from benchmarks.rc14 import evaluate

def run():
    cfg=json.loads((ROOT/'experiments/v01.json').read_text());assert (cfg['order'],cfg['smoothing'],cfg['global_smoothing'],cfg['test_modulus'],cfg['test_remainder'])==(2,20.,5.,5,0), 'unsupported v0.1 configuration';rows,source=load(ROOT,cfg['split_seed']);train=[r for r in rows if r['split']=='train'];test=[r for r in rows if r['split']=='test']
    assert not {r['group'] for r in train}&{r['group'] for r in test}
    model=Grammar(train);groups=sorted({r['group'] for r in test});scores={};per=[]
    for variant in cfg['variants']:
        agg=collections.defaultdict(lambda:[0.,0])
        for r in test:
            b,n=model.score_row(r,variant);agg[r['group']][0]+=b;agg[r['group']][1]+=n
        scores[variant]={'bits_per_symbol':sum(a[0] for a in agg.values())/sum(a[1] for a in agg.values()),'macro_bits_per_symbol':float(np.mean([a[0]/a[1] for a in agg.values()])),'by_group':{g:a[0]/a[1] for g,a in agg.items()}}
        for g,(b,n) in sorted(agg.items()):per.append(dict(model=variant,group=g,bits=b,symbols=n,bits_per_symbol=b/n))
        print(variant,scores[variant]['bits_per_symbol'],flush=True)
    rng=np.random.default_rng(20261111);ix=rng.integers(0,len(groups),(cfg['bootstrap_replicates'],len(groups)));comparisons={}
    for base in ['grammar','regime','state','layout']:
        delta=np.array([scores[base]['by_group'][g]-scores['full']['by_group'][g] for g in groups]);comparisons['full_vs_'+base]={'macro_gain':float(delta.mean()),'ci95':np.quantile(delta[ix].mean(axis=1),[.025,.975]).tolist()}
    seenwords={t for r in train for t in r['tokens']};testwords={t for r in test for t in r['tokens']};forbidden={tuple(r['tokens']) for r in train};generated=[]
    for seed in cfg['generation_seeds']:
        lines,details=generate(model,train,cfg['generated_tokens'],seed,forbidden);tokens=[w for line in lines for w in line];types=set(tokens)
        assert sum(map(len,lines))==cfg['generated_tokens'] and not any(tuple(x) in forbidden for x in lines)
        (ROOT/f'results/generated_seed_{seed}.txt').write_text('\n'.join(' '.join(x) for x in lines)+'\n')
        generated.append({'seed':seed,**details,'novel_token_fraction':sum(w not in seenwords for w in tokens)/len(tokens),'novel_type_fraction':len(types-seenwords)/len(types),'unseen_test_type_hits':len((testwords-seenwords)&types),'unseen_test_types':len(testwords-seenwords),'copied_train_lines':0,'benchmark':evaluate(lines)})
    result={'version':'0.1.0','analysis':'exploratory','source':source,'split':{s:{'groups':len({r['group'] for r in rows if r['split']==s}),'lines':sum(r['split']==s for r in rows),'tokens':sum(len(r['tokens']) for r in rows if r['split']==s)} for s in ('train','test')},'models':scores,'comparisons':comparisons,'generated':generated,'real_RC12_diagnostic':evaluate([r['tokens'] for r in rows],[r['folio'] for r in rows]),'historical_RC14_status':cfg['historical_RC14_status'],'test_is_fresh_unseen_corpus':False}
    (ROOT/'results/results.json').write_text(json.dumps(result,indent=2));model.save(ROOT/'results/model_v01.json')
    with (ROOT/'results/per_group.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(per[0]));w.writeheader();w.writerows(per)
    with (ROOT/'results/split.csv').open('w',newline='') as f:w=csv.writer(f);w.writerow(['locus','folio','physical_group','split']);w.writerows((r['locus_id'],r['folio'],r['group'],r['split']) for r in rows)
    print(json.dumps({k:result[k] for k in ['split','comparisons','generated','real_RC12_diagnostic']},indent=2))
if __name__=='__main__':run()
