from pathlib import Path
import csv,json,math
ROOT=Path(__file__).resolve().parent;O=ROOT/'results_automata';A=O/'audit_v2'
r=json.loads((O/'results.json').read_text());a=json.loads((A/'audit_results.json').read_text());sel=json.loads((O/'selection.json').read_text());pg=list(csv.DictReader((O/'per_group.csv').read_text().splitlines()));groups=list(csv.DictReader((A/'physical_group_partitions.csv').read_text().splitlines()));lookup={ (v['model'],v['group']):v for v in pg}
order=['Markov0','Markov1','AALpy','Markov2','Markov3','VVM_base','VVM_memory']
md=[]
def add(s=''):md.append(s)
def table(headers,rows):
 add('| '+' | '.join(headers)+' |');add('| '+' | '.join('---' for _ in headers)+' |')
 for rr in rows:add('| '+' | '.join(str(v) for v in rr)+' |')
 add()
add('# benchmark_report_v2 — Confronto verificato AALpy, Markov e VVM')
add('\n11 novembre 2026. Revisione documentale e audit numerico dei risultati già eseguiti. Nessuna nuova ricerca di modelli, nessuna nuova selezione sul test, nessuna modifica al corpus o ai risultati originali. Alergia non viene riaddestrato: viene riletto il modello finale salvato. I conteggi Markov e VVM sono ricostruiti sulle stesse righe finali di fit, con configurazioni già congelate, per riprodurre i punteggi e misurare la rappresentazione.\n')
add('## Esito della revisione\n')
add('**Il confronto AALpy contro Markov-2 e Markov-3 era già stato eseguito sullo stesso corpus, sulle stesse partizioni e sugli stessi eventi. L’audit ne conferma i punteggi: AALpy perde in tutti i dieci gruppi test.** Non serve ripetere la selezione per ottenere questo confronto.\n')
add('Il vantaggio numerico della VVM su Markov-2/3 è invece piccolo e i suoi intervalli descrittivi per gruppo comprendono zero. La VVM riceve anche metadati e covariate che i Markov non ricevono: il confronto non isola la sola architettura. Non si dichiara una superiorità generale della VVM.\n')
add('La dicitura originale `criterion_passed=true` viene conservata: si riferiva esclusivamente a Markov-1 e al controllo di complessità più vicino, che coincideva con Markov-1. Non significa superamento di Markov-2/3 e non è un’attestazione MDL o di meccanismo storico.\n')
add('## 1. Risultati e unità\n')
table(['Modello','Bit/simbolo micro','Bit/simbolo macro'],[[n,f"{r['scores'][n]['micro_bits_per_symbol']:.8f}",f"{r['scores'][n]['macro_bits_per_symbol']:.8f}"] for n in order])
gain=r['scores']['Markov1']['micro_bits_per_symbol']-r['scores']['AALpy']['micro_bits_per_symbol'];gap=r['scores']['AALpy']['micro_bits_per_symbol']-r['scores']['Markov2']['micro_bits_per_symbol']
add(f'AALpy migliora Markov-1 di {gain:.8f} bit/simbolo; Markov-2 migliora AALpy di {gap:.8f}. Il rapporto fra i due scarti micro è {gap/gain:.4f}. È un confronto di perdite, non una prova che un tipo di memoria sia storicamente reale o assente.\n')
add('### Definizione esatta della perdita\n')
add('Per la riga r e la sua sequenza osservata y, `B_r = -sum_t log2 P(y_t | prefisso osservato, covariate consentite)`. La perdita micro è `sum_r B_r / sum_r N_r`. La perdita macro è `mean_g(sum_{r in g} B_r / sum_{r in g} N_r)`, con pari peso a ciascun gruppo fisico. I gruppi hanno dimensioni diverse; differenze micro e macro non vanno mescolate.\n')
add('Il denominatore include tutte le lettere EVA estratte e un EOS `$` per parola. Non include il simbolo iniziale `^`, spazi letterali, un ulteriore fine riga, etichette non-P o commenti. Sono valutati 37.368 simboli in 767 righe, corrispondenti a 6.474 token. Non è un conteggio di soli glifi fisici: i caratteri EVA possono rappresentare convenzioni di trascrizione.\n')
add('### Target e normalizzazione comuni\n')
add('Tutti i modelli ricevono token dallo stesso `ivtff_parser_rc1_2.py`, senza ritocchi. Dalla riga `[qody, daiin]` si ottiene la sequenza `qody$daiin$`. Il prefisso `^` serve al reset e non è valutato. Per AALpy la traccia di addestramento include un solo `^`; i Markov inizializzano il loro contesto con n simboli `^`; la grammatica VVM usa due BOS a ogni parola. Questi reset fanno parte dei rispettivi modelli, non introducono osservazioni extra nel denominatore.\n')
add('Il parser converte in minuscolo, conserva il testo interno delle graffe, esclude interi blocchi quadri e riconosce la famiglia di loci P. Si ereditano anche le sue convenzioni sulle letture incerte: l’audit attuale verifica l’identità di input e scoring, non rifà una validazione filologica del parser.\n')
add('L’alfabeto finale del fit ha 27 eventi previsti, incluso EOS e UNK `?`. Il train non usa il test per costruire l’alfabeto. Nel test concreto non risultano caratteri nuovi; le diverse regole di fallback su caratteri nuovi non incidono sui numeri qui confrontati.\n')
add('## 2. Verifiche numeriche realmente eseguite\n')
table(['Controllo','Risultato'],[
 ['Disgiunzione train/validation/test per gruppo','Verificata su tutti i 4.130 loci'],
 ['Gruppi ed eventi identici nei sette score','10 gruppi, 37.368 simboli per ogni modello'],
 ['Scarto massimo dei totali in bit ricostruiti rispetto ai CSV',f"{a['max_bit_total_error']:.3g}"],
 ['Errore massimo di normalizzazione AALpy lungo tutte le tracce test',f"{a['max_automaton_normalization_error']:.3g}"],
 ['Parole test controllate nella catena VVM parola→simboli',a['test_word_events']],
 ['Errore massimo della catena in bit per parola',f"{a['max_word_vs_symbol_chain_rule_error_bits']:.3g}"],
 ['Modifiche ai risultati/selezioni originari','Nessuna; hash conservati']])
add('Hash della sequenza test, JSON canonico di coppie `(locus, sequenza)`:\n\n`'+a['test_event_sha256']+'`\n')
add('La riproduzione riutilizza le classi di scoring del benchmark originale: è un controllo di coerenza e ripetibilità, non una seconda implementazione indipendente. La normalizzazione lungo tutte le tracce e la fattorizzazione per prefissi aggiungono controlli espliciti; non escludono ogni possibile errore condiviso.\n')
add('### VVM con cache: perché il confronto di unità è valido\n')
add('La VVM con memoria calcola `P(w)=(1-lambda)P_g(w)+lambda Q_cache(w)` per la parola intera. È una distribuzione su parole finite, non una probabilità arbitraria di punteggio. Per un prefisso u si può calcolare `F(u)=(1-lambda)P_g(prefisso u)+lambda Q_cache(prefisso u)`. La probabilità del carattere successivo è il rapporto fra la massa del prefisso esteso e quella del prefisso corrente; per EOS si usa la massa della parola esatta. Il prodotto dei rapporti coincide con P(w).\n')
add('L’audit esegue questa fattorizzazione su tutte le 6.474 parole test e la confronta con il codice di scoring originario, incluso EOS. Coincidono entro arrotondamento numerico. Quindi la differenza tra VVM e Markov non deriva da un secondo logaritmo, da un denominatore diverso o dal dimenticare EOS. Questo controllo non rende uguali le informazioni fornite ai modelli.\n')
add('## 3. Configurazioni e informazioni disponibili\n')
table(['Modello','Configurazione finale','Contesto disponibile'],[
 ['AALpy','release 2.0.0; MC Alergia; eps=0,2; delta=0,001','Prefisso di simboli nella stessa riga; nessun metadato di sezione'],
 ['Markov0','ordine0; strength=0,1','Frequenze globali'],
 ['Markov1','ordine1; strength=5','Ultimo simbolo della riga'],
 ['Markov2','ordine2; strength=5','Ultimi due simboli della riga'],
 ['Markov3','ordine3; strength=5','Ultimi tre simboli della riga'],
 ['VVM_base','full; ordini0/1/2; shrink5 globale e20 specializzazioni','Currier/sezione; prefisso della parola precedente; prima parola/inizio paragrafo'],
 ['VVM_memory',f"Stessa grammatica; lambda={r['vvm_memory_weight']:.17g}",'Come VVM_base, più frequenza delle parole nella riga P precedente entro unità IVTFF']])
add('AALpy e Markov vedono gli stessi simboli e possono attraversare `$` dentro la riga; reset al cambio di riga. VVM resetta la grammatica al cambio di parola; lo stato del prefisso della parola precedente è locale alla riga. La cache VVM si azzera al cambio di pagina/pannello. Non si usano lunghezze future della riga per prevedere i simboli.\n')
add('### Eventi non visti e smoothing\n')
add('- Markov: prior globale train con pseudoconteggio0,5 per evento; distribuzione di un contesto `(count + strength*prior)/(totale+strength)`; contesto non visto→prior.\n- AALpy: con probabilità delta emette dal prior train e resetta allo stato iniziale; con probabilità1-delta segue gli archi appresi ed emette l’output del nodo destinazione. Un nodo senza uscite usa sempre prior+reset. Il filtro somma tutti i percorsi compatibili. Non è smoothing attribuito alla libreria nativa: è parte esplicita del benchmark.\n- VVM: backoff gerarchico a distribuzioni normalizzate con forze5/20; cache come miscela probabilistica di parole. Nessun clipping del test loss o eliminazione di eventi difficili.\n')
add('### Selezione congelata e rifit\n')
add('AALpy: 3 epsilon × 4 delta =12 configurazioni validation. Markov: 4 ordini × 3 strength =12 configurazioni validation, con scelta separata della strength per ordine. AALpy train-only selezionato:51 stati,566 archi. Dopo selezione, rifit train+validation a configurazione fissa:49 stati,569 archi. La VVM è riaddestrata sugli stessi gruppi finali; lambda cache è stimato solo sul fit. Nessun iperparametro è stato cambiato durante la presente revisione. La VVM non partecipa alla stessa ricerca di12 configurazioni e non si afferma identico budget di calcolo fra tutte le famiglie.\n')
add('## 4. Partizioni per bifoglio\n')
table(['Partizione','Gruppi','Righe','Token','Simboli'],[[p,r['split'][p]['groups'],r['split'][p]['rows'],r['split'][p]['tokens'],r['split'][p]['symbols']] for p in ('train','validation','test')])
add('Fold2/3/4 per train, fold1 per validation, fold0 per test. Fit finale:40 gruppi (train+validation), test10. Gli ID fisici provengono dalla mappa R6 della collazione pubblicata; essa include unità incomplete ricostruite e non è un’autopsia del codice. Il corpus era già stato studiato: l’esclusione dal fit e dalla selezione attuali non rende il test storicamente mai osservato.\n')
table(['Gruppo','Partizione iniziale','Facce/pannelli superstiti','Righe','Simboli'],[[v['group'],v['partition'],v['folios'],v['rows'],v['symbols']] for v in groups])
add('Le 52 unità della mappa non coincidono con i50 gruppi rappresentati da loci P in questo benchmark. Non vengono create osservazioni per unità prive di testo P. `physical_group_partitions.csv` conserva anche i conteggi token.\n')
add('## 5. Risultati per gruppo test\n')
table(['Gruppo','Simboli','Markov0','Markov1','AALpy','Markov2','Markov3','VVM base','VVM cache'],[[gr,int(float(lookup['AALpy',gr]['symbols']))]+[f"{float(lookup[n,gr]['loss']):.6f}" for n in order] for gr in sorted(storedgr for (model,storedgr) in lookup if model=='AALpy')])
add('Ogni cella è bit/simbolo entro gruppo. Le perdite assolute in bit, utili per ricostruire la media micro, restano in `per_group.csv`.\n')
add('### Intervalli appaiati già disponibili\n')
table(['Guadagno di AALpy rispetto a','Media macro','IC95%','Gruppi positivi'],[[name,f"{r['comparisons']['AALpy_vs_'+name]['macro_gain']:.8f}",f"[{r['comparisons']['AALpy_vs_'+name]['ci95'][0]:.8f}; {r['comparisons']['AALpy_vs_'+name]['ci95'][1]:.8f}]",str(r['comparisons']['AALpy_vs_'+name]['positive_groups'])+'/10'] for name in ['Markov1','Markov2','Markov3','VVM_base','VVM_memory']])
add('### Precisazione sul piccolo vantaggio VVM–Markov2/3\n')
table(['Guadagno VVM cache rispetto a','Media macro','IC95%','Gruppi positivi'],[[key.replace('VVM_memory_vs_',''),f"{v['macro_gain']:.8f}",f"[{v['ci95'][0]:.8f}; {v['ci95'][1]:.8f}]",str(v['positive_groups'])+'/10'] for key,v in a['paired_descriptive_comparisons'].items()])
add('Questi due intervalli sono una rielaborazione descrittiva dei punteggi già salvati, non un nuovo test confermativo scelto prima dell’esperimento. Comprendono zero; non dimostrano un vantaggio stabile della VVM per bifoglio. Bootstrap percentile95%,10.000 ricampionamenti degli stessi dieci gruppi, nessun rifit. Non incorporano tutte le dipendenze fra fascicoli, mani o argomenti, né correzioni per tutte le scelte della ricerca precedente.\n')
add('## 6. Complessità: probabilità, struttura e descrizione\n')
add('Il numero di parametri non è una descrizione totale. Si riportano tre famiglie di misure, senza combinarle per riselezionare un modello. Gli stati di una Markov chain con output sui nodi non sono equivalenti ai contesti di un n-gramma.\n')
topo={t['model']:t for t in a['complexity_topology']}
table(['Modello','Stati espliciti','Archi espliciti','Contesti/vettori memorizzati','Dimensioni probabilistiche nominali'],[[n,topo[n].get('states') or 'N/A',topo[n].get('edges') or 'N/A',topo[n].get('stored_contexts') or 'N/A',topo[n].get('probabilistic_dimensions') if topo[n].get('probabilistic_dimensions') is not None else 'non equiparate'] for n in order])
add('AALpy: somma(d_s−1) sui nodi con uscite, più26 dimensioni del prior e1 del backoff =547. Markov: ogni distribuzione esplicita di27 eventi conta26 dimensioni, più il prior globale per ordine>0. Sono conteggi nominali della parametrizzazione: le stime condividono i dati, gli iperparametri scelti e il costo della topologia non sono completamente rappresentati. Per la VVM si conservano29.383 vettori di conteggi in tabelle gerarchiche; trattarli come29.383 stati nascosti o come gradi di libertà indipendenti sarebbe scorretto.\n')
add('### Proxy di descrizione: struttura + coefficienti a precisione fissata\n')
add('Si dichiara una convenzione calcolabile, non una lunghezza minima universale. Un intero positivo è contato con la lunghezza del codice Elias-delta `U(n)=bit_length(n)+2*floor(log2(bit_length(n)))`. Etichette di un alfabeto comune di28 simboli incluso BOS usano5 bit.\n')
add('Per AALpy, S stati ed E archi: `C_struct=U(S)+U(E+1)+ceil(log2 S)+5S+sum_s U(d_s+1)+E*ceil(log2 S)`. Include etichette dei nodi, grado di uscita, destinazioni e stato iniziale. Per Markov ordine n con C contesti: `C_struct=U(n+1)+U(C)+5*n*C`; i passaggi di contesto sono impliciti nel codice comune. Alfabeto comune, codice dell’interprete, costo degli iperparametri e metadati di famiglia non sono pienamente contati.\n')
add('La componente probabilistica nominale è `b*D`, D dimensioni esplicite e b bit per coefficiente. Non si sono quantizzati i modelli né verificate perdite dopo quantizzazione: è un proxy di costo, non un formato lossless eseguito o un vero punteggio MDL da usare per dichiarare un vincitore.\n')
table(['Modello','Struttura, bit','Coefficienti32bit, bit','Totale proxy32bit'],[[v['model'],v['structure_bits'],v['probability_bits_32'],v['total_proxy_bits_32']] for v in a['description_proxies']])
table(['Modello','Totale proxy16bit','Totale proxy32bit','Totale proxy64bit'],[[n]+[next(v['total_proxy_bits'] for v in a['precision_sensitivity'] if v['model']==n and v['coefficient_bits']==b) for b in (16,32,64)] for n in ['AALpy','Markov1','Markov2','Markov3']])
add('La direzione AALpy–Markov1 cambia fra16 e32bit: il vantaggio di compattezza non è indipendente dalla codifica. La frase “547 contro728” va dunque letta come sola componente probabilistica. Nessuna nuova selezione sul test viene giustificata con questo proxy.\n')
add('### Dimensione delle rappresentazioni serializzate\n')
table(['Modello','JSON canonico, byte','JSON con zlib9, byte'],[[v['model'],v['canonical_json_bytes'],v['zlib9_bytes']] for v in a['serialization_sizes']])
add('Il JSON rappresenta gli oggetti effettivi di scoring (per VVM i conteggi necessari a ricostruire le distribuzioni), con chiavi ordinate e senza spazi. La compressione è misurata nello stesso ambiente. Questi numeri includono struttura e coefficienti del formato adottato, ma dipendono dal formato e non rappresentano la complessità algoritmica minima o la dimensione totale del runtime. Le impronte delle serializzazioni sono in `serialization_sizes.csv`.\n')
add('## 7. Hash e cronologia Git\n')
add('Commit del benchmark sottoposto ad audit: `'+a['parent_commit']+'`. Tag `aalpy-benchmark-v1`; le versioni VVM precedenti restano immutate. Il presente rapporto è un’aggiunta successiva: il suo tag e commit sono nel bundle Git allegato.\n')
add('```text\n'+a['git_log'].strip()+'\n```\n')
table(['File','Byte','SHA-256'],[[p,v['bytes'],v['sha256']] for p,v in a['hashes'].items()])
add('L’impronta del protocollo coincide con quella registrata nei risultati originali. I nuovi file di audit hanno un manifest separato, senza riscrivere quello originale. Non si confonde la creazione di un commit dopo l’esecuzione con una preregistrazione temporale indipendente.\n')
add('## 8. Cosa possiamo concludere\n')
add('- È verificato che AALpy è migliore di Markov1 e peggiore di Markov2/3 su questo test e con questa selezione.\n- Il confronto forte tra AALpy e Markov2/3 è già disponibile e non dipende da denominatori o partizioni diversi. I loro costi di rappresentazione sono diversi.\n- La VVM ha la perdita micro più bassa fra i modelli valutati, ma non una superiorità per bifoglio dimostrata su Markov2/3; ha inoltre accesso a covariate aggiuntive.\n- Il risultato non dimostra che ogni architettura a stati nascosti sia inutile, né che tutta la struttura utile sia locale. Dimostra il limite di questa specifica famiglia Alergia selezionata e di questo budget.\n- Non è identificato un meccanismo storico, una lingua o un cifrario; non è ricostruito l’ordine delle carte. Non si riottimizza AALpy sul test per farlo vincere.\n')
add('## 9. Riproduzione della sola revisione\n')
add('Dalla directory del progetto:\n\n```bash\npython3 -m pip install -r requirements-automata.txt\npython3 audit_benchmark_v2.py\npython3 build_benchmark_report_v2.py\n```\n')
add('Il primo comando di audit rilegge il modello AALpy salvato e ricostruisce gli scorer congelati; non avvia `run_Alergia` e non rifà la selezione. Gli output originali `results.json`, `selection.json`, `per_group.csv` e i file di partizione sono soltanto letti. Il secondo comando ricrea il rapporto. I27 test del benchmark restano quelli documentati nella release originale; l’audit aggiunge verifiche eseguibili sull’intero insieme test e un’identità matematica della miscela, non una certificazione indipendente di ogni assunzione.\n')
(O/'benchmark_report_v2.md').write_text('\n'.join(md))
print(O/'benchmark_report_v2.md')
