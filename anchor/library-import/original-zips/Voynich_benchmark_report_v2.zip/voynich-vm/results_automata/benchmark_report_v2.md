# benchmark_report_v2 — Confronto verificato AALpy, Markov e VVM

11 novembre 2026. Revisione documentale e audit numerico dei risultati già eseguiti. Nessuna nuova ricerca di modelli, nessuna nuova selezione sul test, nessuna modifica al corpus o ai risultati originali. Alergia non viene riaddestrato: viene riletto il modello finale salvato. I conteggi Markov e VVM sono ricostruiti sulle stesse righe finali di fit, con configurazioni già congelate, per riprodurre i punteggi e misurare la rappresentazione.

## Esito della revisione

**Il confronto AALpy contro Markov-2 e Markov-3 era già stato eseguito sullo stesso corpus, sulle stesse partizioni e sugli stessi eventi. L’audit ne conferma i punteggi: AALpy perde in tutti i dieci gruppi test.** Non serve ripetere la selezione per ottenere questo confronto.

Il vantaggio numerico della VVM su Markov-2/3 è invece piccolo e i suoi intervalli descrittivi per gruppo comprendono zero. La VVM riceve anche metadati e covariate che i Markov non ricevono: il confronto non isola la sola architettura. Non si dichiara una superiorità generale della VVM.

La dicitura originale `criterion_passed=true` viene conservata: si riferiva esclusivamente a Markov-1 e al controllo di complessità più vicino, che coincideva con Markov-1. Non significa superamento di Markov-2/3 e non è un’attestazione MDL o di meccanismo storico.

## 1. Risultati e unità

| Modello | Bit/simbolo micro | Bit/simbolo macro |
| --- | --- | --- |
| Markov0 | 3.85266210 | 3.85215664 |
| Markov1 | 2.13800085 | 2.21735852 |
| AALpy | 2.06956879 | 2.14901829 |
| Markov2 | 1.88934781 | 1.97707079 |
| Markov3 | 1.88172619 | 1.96905845 |
| VVM_base | 1.87078622 | 1.93126832 |
| VVM_memory | 1.86997729 | 1.93042777 |

AALpy migliora Markov-1 di 0.06843206 bit/simbolo; Markov-2 migliora AALpy di 0.18022098. Il rapporto fra i due scarti micro è 2.6336. È un confronto di perdite, non una prova che un tipo di memoria sia storicamente reale o assente.

### Definizione esatta della perdita

Per la riga r e la sua sequenza osservata y, `B_r = -sum_t log2 P(y_t | prefisso osservato, covariate consentite)`. La perdita micro è `sum_r B_r / sum_r N_r`. La perdita macro è `mean_g(sum_{r in g} B_r / sum_{r in g} N_r)`, con pari peso a ciascun gruppo fisico. I gruppi hanno dimensioni diverse; differenze micro e macro non vanno mescolate.

Il denominatore include tutte le lettere EVA estratte e un EOS `$` per parola. Non include il simbolo iniziale `^`, spazi letterali, un ulteriore fine riga, etichette non-P o commenti. Sono valutati 37.368 simboli in 767 righe, corrispondenti a 6.474 token. Non è un conteggio di soli glifi fisici: i caratteri EVA possono rappresentare convenzioni di trascrizione.

### Target e normalizzazione comuni

Tutti i modelli ricevono token dallo stesso `ivtff_parser_rc1_2.py`, senza ritocchi. Dalla riga `[qody, daiin]` si ottiene la sequenza `qody$daiin$`. Il prefisso `^` serve al reset e non è valutato. Per AALpy la traccia di addestramento include un solo `^`; i Markov inizializzano il loro contesto con n simboli `^`; la grammatica VVM usa due BOS a ogni parola. Questi reset fanno parte dei rispettivi modelli, non introducono osservazioni extra nel denominatore.

Il parser converte in minuscolo, conserva il testo interno delle graffe, esclude interi blocchi quadri e riconosce la famiglia di loci P. Si ereditano anche le sue convenzioni sulle letture incerte: l’audit attuale verifica l’identità di input e scoring, non rifà una validazione filologica del parser.

L’alfabeto finale del fit ha 27 eventi previsti, incluso EOS e UNK `?`. Il train non usa il test per costruire l’alfabeto. Nel test concreto non risultano caratteri nuovi; le diverse regole di fallback su caratteri nuovi non incidono sui numeri qui confrontati.

## 2. Verifiche numeriche realmente eseguite

| Controllo | Risultato |
| --- | --- |
| Disgiunzione train/validation/test per gruppo | Verificata su tutti i 4.130 loci |
| Gruppi ed eventi identici nei sette score | 10 gruppi, 37.368 simboli per ogni modello |
| Scarto massimo dei totali in bit ricostruiti rispetto ai CSV | 0 |
| Errore massimo di normalizzazione AALpy lungo tutte le tracce test | 4.44e-16 |
| Parole test controllate nella catena VVM parola→simboli | 6474 |
| Errore massimo della catena in bit per parola | 2.13e-14 |
| Modifiche ai risultati/selezioni originari | Nessuna; hash conservati |

Hash della sequenza test, JSON canonico di coppie `(locus, sequenza)`:

`9f27ee7fb19a13b7e5407e051c94d59d0350d779be5e8f8472bf88d869b6f707`

La riproduzione riutilizza le classi di scoring del benchmark originale: è un controllo di coerenza e ripetibilità, non una seconda implementazione indipendente. La normalizzazione lungo tutte le tracce e la fattorizzazione per prefissi aggiungono controlli espliciti; non escludono ogni possibile errore condiviso.

### VVM con cache: perché il confronto di unità è valido

La VVM con memoria calcola `P(w)=(1-lambda)P_g(w)+lambda Q_cache(w)` per la parola intera. È una distribuzione su parole finite, non una probabilità arbitraria di punteggio. Per un prefisso u si può calcolare `F(u)=(1-lambda)P_g(prefisso u)+lambda Q_cache(prefisso u)`. La probabilità del carattere successivo è il rapporto fra la massa del prefisso esteso e quella del prefisso corrente; per EOS si usa la massa della parola esatta. Il prodotto dei rapporti coincide con P(w).

L’audit esegue questa fattorizzazione su tutte le 6.474 parole test e la confronta con il codice di scoring originario, incluso EOS. Coincidono entro arrotondamento numerico. Quindi la differenza tra VVM e Markov non deriva da un secondo logaritmo, da un denominatore diverso o dal dimenticare EOS. Questo controllo non rende uguali le informazioni fornite ai modelli.

## 3. Configurazioni e informazioni disponibili

| Modello | Configurazione finale | Contesto disponibile |
| --- | --- | --- |
| AALpy | release 2.0.0; MC Alergia; eps=0,2; delta=0,001 | Prefisso di simboli nella stessa riga; nessun metadato di sezione |
| Markov0 | ordine0; strength=0,1 | Frequenze globali |
| Markov1 | ordine1; strength=5 | Ultimo simbolo della riga |
| Markov2 | ordine2; strength=5 | Ultimi due simboli della riga |
| Markov3 | ordine3; strength=5 | Ultimi tre simboli della riga |
| VVM_base | full; ordini0/1/2; shrink5 globale e20 specializzazioni | Currier/sezione; prefisso della parola precedente; prima parola/inizio paragrafo |
| VVM_memory | Stessa grammatica; lambda=0.0059336143462558506 | Come VVM_base, più frequenza delle parole nella riga P precedente entro unità IVTFF |

AALpy e Markov vedono gli stessi simboli e possono attraversare `$` dentro la riga; reset al cambio di riga. VVM resetta la grammatica al cambio di parola; lo stato del prefisso della parola precedente è locale alla riga. La cache VVM si azzera al cambio di pagina/pannello. Non si usano lunghezze future della riga per prevedere i simboli.

### Eventi non visti e smoothing

- Markov: prior globale train con pseudoconteggio0,5 per evento; distribuzione di un contesto `(count + strength*prior)/(totale+strength)`; contesto non visto→prior.
- AALpy: con probabilità delta emette dal prior train e resetta allo stato iniziale; con probabilità1-delta segue gli archi appresi ed emette l’output del nodo destinazione. Un nodo senza uscite usa sempre prior+reset. Il filtro somma tutti i percorsi compatibili. Non è smoothing attribuito alla libreria nativa: è parte esplicita del benchmark.
- VVM: backoff gerarchico a distribuzioni normalizzate con forze5/20; cache come miscela probabilistica di parole. Nessun clipping del test loss o eliminazione di eventi difficili.

### Selezione congelata e rifit

AALpy: 3 epsilon × 4 delta =12 configurazioni validation. Markov: 4 ordini × 3 strength =12 configurazioni validation, con scelta separata della strength per ordine. AALpy train-only selezionato:51 stati,566 archi. Dopo selezione, rifit train+validation a configurazione fissa:49 stati,569 archi. La VVM è riaddestrata sugli stessi gruppi finali; lambda cache è stimato solo sul fit. Nessun iperparametro è stato cambiato durante la presente revisione. La VVM non partecipa alla stessa ricerca di12 configurazioni e non si afferma identico budget di calcolo fra tutte le famiglie.

## 4. Partizioni per bifoglio

| Partizione | Gruppi | Righe | Token | Simboli |
| --- | --- | --- | --- | --- |
| train | 30 | 2616 | 22546 | 133612 |
| validation | 10 | 747 | 6472 | 38521 |
| test | 10 | 767 | 6474 | 37368 |

Fold2/3/4 per train, fold1 per validation, fold0 per test. Fit finale:40 gruppi (train+validation), test10. Gli ID fisici provengono dalla mappa R6 della collazione pubblicata; essa include unità incomplete ricostruite e non è un’autopsia del codice. Il corpus era già stato studiato: l’esclusione dal fit e dalla selezione attuali non rende il test storicamente mai osservato.

| Gruppo | Partizione iniziale | Facce/pannelli superstiti | Righe | Simboli |
| --- | --- | --- | --- | --- |
| Q01_B01 | train | f1r|f1v|f8r|f8v | 76 | 3230 |
| Q01_B02 | train | f2r|f2v|f7r|f7v | 40 | 1760 |
| Q01_B03 | train | f3r|f3v|f6r|f6v | 69 | 2255 |
| Q01_B04 | validation | f4r|f4v|f5r|f5v | 40 | 1495 |
| Q02_B01 | train | f16r|f16v|f9r|f9v | 48 | 1859 |
| Q02_B02 | train | f10r|f10v|f15r|f15v | 46 | 1749 |
| Q02_B03 | validation | f11r|f11v|f14r|f14v | 35 | 1401 |
| Q02_B04 | train | f13r|f13v | 20 | 786 |
| Q03_B01 | train | f17r|f17v|f24r|f24v | 71 | 2271 |
| Q03_B02 | test | f18r|f18v|f23r|f23v | 47 | 1934 |
| Q03_B03 | train | f19r|f19v|f22r|f22v | 56 | 1927 |
| Q03_B04 | test | f20r|f20v|f21r|f21v | 44 | 1973 |
| Q04_B01 | validation | f25r|f25v|f32r|f32v | 44 | 1538 |
| Q04_B02 | train | f26r|f26v|f31r|f31v | 46 | 2331 |
| Q04_B03 | test | f27r|f27v|f30r|f30v | 45 | 1807 |
| Q04_B04 | test | f28r|f28v|f29r|f29v | 39 | 1670 |
| Q05_B01 | validation | f33r|f33v|f40r|f40v | 48 | 2135 |
| Q05_B02 | train | f34r|f34v|f39r|f39v | 56 | 3206 |
| Q05_B03 | train | f35r|f35v|f38r|f38v | 50 | 1635 |
| Q05_B04 | train | f36r|f36v|f37r|f37v | 57 | 1763 |
| Q06_B01 | train | f41r|f41v|f48r|f48v | 38 | 2306 |
| Q06_B02 | train | f42r|f42v|f47r|f47v | 64 | 2364 |
| Q06_B03 | train | f43r|f43v|f46r|f46v | 58 | 3427 |
| Q06_B04 | validation | f44r|f44v|f45r|f45v | 46 | 1927 |
| Q07_B01 | train | f49r|f49v|f56r|f56v | 82 | 2694 |
| Q07_B02 | test | f50r|f50v|f55r|f55v | 46 | 2391 |
| Q07_B03 | test | f51r|f51v|f54r|f54v | 56 | 2137 |
| Q07_B04 | train | f52r|f52v|f53r|f53v | 44 | 1638 |
| Q08_B01 | train | f57r|f66r|f66v | 56 | 3115 |
| Q08_B02 | validation | f58r|f58v|f65v | 86 | 4716 |
| Q09_B01 | test | f67r1|f67r2|f67v2|f68r1|f68r2|f68v2|f68v3 | 71 | 2185 |
| Q10_B01 | validation | f69r|f70r2 | 18 | 746 |
| Q13_B01 | train | f75r|f75v|f84r|f84v | 175 | 8335 |
| Q13_B02 | validation | f76r|f76v|f83r|f83v | 170 | 9582 |
| Q13_B03 | train | f77r|f77v|f82r|f82v | 143 | 7647 |
| Q13_B04 | train | f78r|f78v|f81r|f81v | 131 | 5993 |
| Q13_B05 | test | f79r|f79v|f80r|f80v | 173 | 9210 |
| Q14_B01 | train | f85r1|f85r2|f86v3|f86v4|f86v5|f86v6|fRos | 193 | 10197 |
| Q15_B01 | validation | f87r|f87v|f90r1|f90r2|f90v1|f90v2 | 66 | 2892 |
| Q15_B02 | train | f88r|f88v|f89r1|f89r2|f89v1|f89v2 | 89 | 5421 |
| Q17_B01 | train | f93r|f93v|f96r|f96v | 68 | 2384 |
| Q17_B02 | train | f94r|f94v|f95r1|f95r2|f95v1|f95v2 | 61 | 3243 |
| Q19_B01 | test | f102r1|f102r2|f102v1|f102v2|f99r|f99v | 96 | 4965 |
| Q19_B02 | train | f100r|f100v|f101r|f101v | 39 | 3514 |
| Q20_B01 | test | f103r|f103v|f116r | 150 | 9096 |
| Q20_B02 | train | f104r|f104v|f115r|f115v | 179 | 11442 |
| Q20_B03 | train | f105r|f105v|f114r|f114v | 161 | 10193 |
| Q20_B04 | validation | f106r|f106v|f113r|f113v | 194 | 12089 |
| Q20_B05 | train | f107r|f107v|f112r|f112v | 192 | 10846 |
| Q20_B06 | train | f108r|f108v|f111r|f111v | 208 | 14081 |

Le 52 unità della mappa non coincidono con i50 gruppi rappresentati da loci P in questo benchmark. Non vengono create osservazioni per unità prive di testo P. `physical_group_partitions.csv` conserva anche i conteggi token.

## 5. Risultati per gruppo test

| Gruppo | Simboli | Markov0 | Markov1 | AALpy | Markov2 | Markov3 | VVM base | VVM cache |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Q03_B02 | 1934 | 3.914903 | 2.367054 | 2.300198 | 2.139246 | 2.152292 | 2.056804 | 2.053808 |
| Q03_B04 | 1973 | 3.846098 | 2.184441 | 2.097807 | 1.939847 | 1.932991 | 1.825017 | 1.824390 |
| Q04_B03 | 1807 | 3.795050 | 2.320852 | 2.254281 | 2.114036 | 2.103252 | 1.994609 | 1.995309 |
| Q04_B04 | 1670 | 3.850864 | 2.193485 | 2.089224 | 1.962435 | 1.947504 | 1.772030 | 1.769835 |
| Q07_B02 | 2391 | 3.873538 | 2.139842 | 2.098084 | 1.912589 | 1.904823 | 1.944588 | 1.943952 |
| Q07_B03 | 2137 | 3.871517 | 2.256577 | 2.178599 | 1.992367 | 1.981485 | 1.977562 | 1.975671 |
| Q09_B01 | 2185 | 3.852762 | 2.436868 | 2.401370 | 2.224624 | 2.204811 | 2.278493 | 2.279282 |
| Q13_B05 | 9210 | 3.868363 | 1.979280 | 1.899059 | 1.717849 | 1.706291 | 1.710200 | 1.708971 |
| Q19_B01 | 4965 | 3.784450 | 2.278691 | 2.219421 | 1.995842 | 1.987199 | 1.931828 | 1.932488 |
| Q20_B01 | 9096 | 3.864022 | 2.016495 | 1.952140 | 1.771874 | 1.769938 | 1.821552 | 1.820572 |

Ogni cella è bit/simbolo entro gruppo. Le perdite assolute in bit, utili per ricostruire la media micro, restano in `per_group.csv`.

### Intervalli appaiati già disponibili

| Guadagno di AALpy rispetto a | Media macro | IC95% | Gruppi positivi |
| --- | --- | --- | --- |
| Markov1 | 0.06834023 | [0.05632260; 0.08033795] | 10/10 |
| Markov2 | -0.17194750 | [-0.18819597; -0.15595142] | 0/10 |
| Markov3 | -0.17995985 | [-0.19688999; -0.16358875] | 0/10 |
| VVM_base | -0.21774997 | [-0.25732400; -0.17704983] | 0/10 |
| VVM_memory | -0.21859052 | [-0.25833822; -0.17790909] | 0/10 |

### Precisazione sul piccolo vantaggio VVM–Markov2/3

| Guadagno VVM cache rispetto a | Media macro | IC95% | Gruppi positivi |
| --- | --- | --- | --- |
| Markov3 | 0.03863068 | [-0.01055782; 0.08862536] | 6/10 |
| Markov2 | 0.04664302 | [-0.00142026; 0.09586109] | 7/10 |

Questi due intervalli sono una rielaborazione descrittiva dei punteggi già salvati, non un nuovo test confermativo scelto prima dell’esperimento. Comprendono zero; non dimostrano un vantaggio stabile della VVM per bifoglio. Bootstrap percentile95%,10.000 ricampionamenti degli stessi dieci gruppi, nessun rifit. Non incorporano tutte le dipendenze fra fascicoli, mani o argomenti, né correzioni per tutte le scelte della ricerca precedente.

## 6. Complessità: probabilità, struttura e descrizione

Il numero di parametri non è una descrizione totale. Si riportano tre famiglie di misure, senza combinarle per riselezionare un modello. Gli stati di una Markov chain con output sui nodi non sono equivalenti ai contesti di un n-gramma.

| Modello | Stati espliciti | Archi espliciti | Contesti/vettori memorizzati | Dimensioni probabilistiche nominali |
| --- | --- | --- | --- | --- |
| Markov0 | N/A | N/A | 1 | 26 |
| Markov1 | N/A | N/A | 27 | 728 |
| AALpy | 49 | 569 | N/A | 547 |
| Markov2 | N/A | N/A | 323 | 8424 |
| Markov3 | N/A | N/A | 1955 | 50856 |
| VVM_base | N/A | N/A | 29383 | non equiparate |
| VVM_memory | N/A | N/A | 29383 | non equiparate |

AALpy: somma(d_s−1) sui nodi con uscite, più26 dimensioni del prior e1 del backoff =547. Markov: ogni distribuzione esplicita di27 eventi conta26 dimensioni, più il prior globale per ordine>0. Sono conteggi nominali della parametrizzazione: le stime condividono i dati, gli iperparametri scelti e il costo della topologia non sono completamente rappresentati. Per la VVM si conservano29.383 vettori di conteggi in tabelle gerarchiche; trattarli come29.383 stati nascosti o come gradi di libertà indipendenti sarebbe scorretto.

### Proxy di descrizione: struttura + coefficienti a precisione fissata

Si dichiara una convenzione calcolabile, non una lunghezza minima universale. Un intero positivo è contato con la lunghezza del codice Elias-delta `U(n)=bit_length(n)+2*floor(log2(bit_length(n)))`. Etichette di un alfabeto comune di28 simboli incluso BOS usano5 bit.

Per AALpy, S stati ed E archi: `C_struct=U(S)+U(E+1)+ceil(log2 S)+5S+sum_s U(d_s+1)+E*ceil(log2 S)`. Include etichette dei nodi, grado di uscita, destinazioni e stato iniziale. Per Markov ordine n con C contesti: `C_struct=U(n+1)+U(C)+5*n*C`; i passaggi di contesto sono impliciti nel codice comune. Alfabeto comune, codice dell’interprete, costo degli iperparametri e metadati di famiglia non sono pienamente contati.

La componente probabilistica nominale è `b*D`, D dimensioni esplicite e b bit per coefficiente. Non si sono quantizzati i modelli né verificate perdite dopo quantizzazione: è un proxy di costo, non un formato lossless eseguito o un vero punteggio MDL da usare per dichiarare un vincitore.

| Modello | Struttura, bit | Coefficienti32bit, bit | Totale proxy32bit |
| --- | --- | --- | --- |
| AALpy | 4066 | 17504 | 21570 |
| Markov0 | 2 | 832 | 834 |
| Markov1 | 148 | 23296 | 23444 |
| Markov2 | 3249 | 269568 | 272817 |
| Markov3 | 29347 | 1627392 | 1656739 |

| Modello | Totale proxy16bit | Totale proxy32bit | Totale proxy64bit |
| --- | --- | --- | --- |
| AALpy | 12818 | 21570 | 39074 |
| Markov1 | 11796 | 23444 | 46740 |
| Markov2 | 138033 | 272817 | 542385 |
| Markov3 | 843043 | 1656739 | 3284131 |

La direzione AALpy–Markov1 cambia fra16 e32bit: il vantaggio di compattezza non è indipendente dalla codifica. La frase “547 contro728” va dunque letta come sola componente probabilistica. Nessuna nuova selezione sul test viene giustificata con questo proxy.

### Dimensione delle rappresentazioni serializzate

| Modello | JSON canonico, byte | JSON con zlib9, byte |
| --- | --- | --- |
| AALpy | 16503 | 6127 |
| Markov0 | 1322 | 699 |
| Markov1 | 16674 | 8025 |
| Markov2 | 189490 | 58016 |
| Markov3 | 1137128 | 218453 |
| VVM_base | 4406464 | 205232 |
| VVM_memory | 4406481 | 205249 |

Il JSON rappresenta gli oggetti effettivi di scoring (per VVM i conteggi necessari a ricostruire le distribuzioni), con chiavi ordinate e senza spazi. La compressione è misurata nello stesso ambiente. Questi numeri includono struttura e coefficienti del formato adottato, ma dipendono dal formato e non rappresentano la complessità algoritmica minima o la dimensione totale del runtime. Le impronte delle serializzazioni sono in `serialization_sizes.csv`.

## 7. Hash e cronologia Git

Commit del benchmark sottoposto ad audit: `d473a510cba20daf6494ecfd18c04d6ab16682a5`. Tag `aalpy-benchmark-v1`; le versioni VVM precedenti restano immutate. Il presente rapporto è un’aggiunta successiva: il suo tag e commit sono nel bundle Git allegato.

```text
d473a51 Benchmark passive AALpy Alergia against selected Markov baselines and VVM
7513d5e Add VVM 0.2 causal line memory, lag control and full grouped cross-validation
64d9bb2 Implement VVM 0.1 with modular generation, held-out evaluation and reproducible results
```

| File | Byte | SHA-256 |
| --- | --- | --- |
| corpus/ZL3b-n.txt | 411671 | bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc |
| corpus/ivtff_parser_rc1_2.py | 10599 | 8a614436a2d5dc3cb30c282743929aaa21a379d9da7e691b4277c670ce2a91c5 |
| corpus/physical_map_verified.csv | 12197 | 37bfc801e824f80cd1e39ccd39f0dbf05115d805914fe0e611411a6a5eb3099f |
| experiments/PROTOCOLLO_AUTOMATA.md | 4681 | 177294636c28a8ca24571e8d58842e925363c3f1315d18a1af0822f27b22e6cd |
| experiments/automata.json | 355 | 9cd3c9343dea706a053bcc5bb5137e47930fc535878d0c8786ce69ee4776e7f6 |
| automaton_benchmark.py | 10529 | c0acaa29dc745a25deadf9b2120ea9076adf9267a53aab427fc316e68eafcddd |
| src/vvm/grammar.py | 3170 | 66cb68c56a64308d5d9dccae56d2b50c8cb3194035d1ae06a69cf0b9b6507933 |
| src/vvm/memory.py | 1653 | 8dd510bbf0e194595d752479614a7b539242383f949c3f404f08951de266364b |
| run_v02.py | 5197 | 928321da90b7170ff8f672876ff6c07e243087bd7be21837f0d1a0a8da55f1ff |
| results_automata/selection.json | 5934 | 2db5ebcdb7a5974eeb25f8479759b23748b4c9bdb07bad61dd77f1aa561bae02 |
| results_automata/results.json | 3682 | 74d25b1643d30b89191263721c66eb2518e5d5c67cacfd87dbe499ea1690c7d8 |
| results_automata/per_group.csv | 4166 | 072cff4bad31cd3086f41a886fedae193b21487b334e9da55916b72811e8bef9 |
| results_automata/partitions.csv | 97761 | fca30b212b2cbda5f1cfc7529670287096c669625d20f5f42f3aa704466120a7 |
| results_automata/final_aalpy_model.json | 17686 | 0e7cbff6d65023e0a37fad00d130d1c3b8cca6b4668038423569ded3bf4eaadd |

L’impronta del protocollo coincide con quella registrata nei risultati originali. I nuovi file di audit hanno un manifest separato, senza riscrivere quello originale. Non si confonde la creazione di un commit dopo l’esecuzione con una preregistrazione temporale indipendente.

## 8. Cosa possiamo concludere

- È verificato che AALpy è migliore di Markov1 e peggiore di Markov2/3 su questo test e con questa selezione.
- Il confronto forte tra AALpy e Markov2/3 è già disponibile e non dipende da denominatori o partizioni diversi. I loro costi di rappresentazione sono diversi.
- La VVM ha la perdita micro più bassa fra i modelli valutati, ma non una superiorità per bifoglio dimostrata su Markov2/3; ha inoltre accesso a covariate aggiuntive.
- Il risultato non dimostra che ogni architettura a stati nascosti sia inutile, né che tutta la struttura utile sia locale. Dimostra il limite di questa specifica famiglia Alergia selezionata e di questo budget.
- Non è identificato un meccanismo storico, una lingua o un cifrario; non è ricostruito l’ordine delle carte. Non si riottimizza AALpy sul test per farlo vincere.

## 9. Riproduzione della sola revisione

Dalla directory del progetto:

```bash
python3 -m pip install -r requirements-automata.txt
python3 audit_benchmark_v2.py
python3 build_benchmark_report_v2.py
```

Il primo comando di audit rilegge il modello AALpy salvato e ricostruisce gli scorer congelati; non avvia `run_Alergia` e non rifà la selezione. Gli output originali `results.json`, `selection.json`, `per_group.csv` e i file di partizione sono soltanto letti. Il secondo comando ricrea il rapporto. I27 test del benchmark restano quelli documentati nella release originale; l’audit aggiunge verifiche eseguibili sull’intero insieme test e un’identità matematica della miscela, non una certificazione indipendente di ogni assunzione.
