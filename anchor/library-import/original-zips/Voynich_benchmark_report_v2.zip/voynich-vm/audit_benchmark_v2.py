"""Read existing selections; audit exact inputs, scorers, complexity and reported totals.
No Alergia search, no alternative hyperparameter selection, no mutation of original results.
"""
import sys,json,csv,math,hashlib,zlib,collections,subprocess
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT))
from automaton_benchmark import encode,prior,Automaton,Markov,score,vvm_scores
from vvm.lexer import load
from vvm.grammar import Grammar
from vvm.memory import events,fit_weight,word_logp,mixture_logp
from vvm.state import State
from vvm.layout import position_key
O=ROOT/'results_automata';A=O/'audit_v2'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(o):return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()
def ubits(n):
    assert n>=1
    b=n.bit_length();return b+2*(b.bit_length()-1) # Elias delta positive integer length

def mixture_symbol_bits(grammar,word,reg,previous,pos,cache,weight):
    """Chain rule for the same whole-word mixture, normalized prefix by prefix."""
    den=sum(cache.values());lam=weight if den else 0.;prefix='';pg=1.;ctx='^^';bits=0.
    for ch in word+'$':
        mass=(1-lam)*pg+lam*(sum(v for w,v in cache.items() if w.startswith(prefix))/den if den else 0.)
        p=grammar.distribution('full',tuple(reg),previous,pos,ctx);pchar=float(p[grammar.lookup.get(ch,grammar.lookup['?'])]);pg_next=pg*pchar
        if ch=='$':cq=cache[word]/den if den else 0.
        else:cq=sum(v for w,v in cache.items() if w.startswith(prefix+ch))/den if den else 0.
        next_mass=(1-lam)*pg_next+lam*cq
        bits-=math.log2(next_mass/mass)
        if ch!='$':prefix+=ch;ctx=(ctx+ch)[-2:];pg=pg_next
    return bits

def run():
    A.mkdir(exist_ok=True);result=json.loads((O/'results.json').read_text());selection=json.loads((O/'selection.json').read_text());rows,source=load(ROOT);parts={r['locus']:r for r in csv.DictReader((O/'partitions.csv').read_text().splitlines())};groupsets=collections.defaultdict(set);rr=collections.defaultdict(list)
    for r in rows:
        p=parts[r['locus_id']];assert p['group']==r['group'];groupsets[r['group']].add(p['partition']);rr[p['partition']].append(r)
    assert len(parts)==len(rows)==4130 and all(len(s)==1 for s in groupsets.values())
    fit=rr['train']+rr['validation'];test=rr['test'];alph,q=prior(fit);K=len(alph);target=canonical([(r['locus_id'],encode(r)) for r in test]);unknown=sorted(set(''.join(encode(r) for r in test))-set(alph));assert not unknown
    stored=collections.defaultdict(dict)
    for r in csv.DictReader((O/'per_group.csv').read_text().splitlines()):stored[r['model']][r['group']]={k:float(r[k]) for k in ('bits','symbols','loss')}
    recomputed={};metrics=[];topologies=[];proxies=[];sensitivity=[];ref=json.loads((O/'final_aalpy_model.json').read_text());auto=Automaton(ref,alph,q,result['selected']['delta']);recomputed['AALpy']=score(auto,test)
    label_width=math.ceil(math.log2(K+1));S=len(ref['states']);E=sum(len(s['transitions']) for s in ref['states']);target_width=math.ceil(math.log2(S));struct=ubits(S)+ubits(E+1)+target_width+S*label_width+sum(ubits(len(s['transitions'])+1) for s in ref['states'])+E*target_width
    payload={'family':'AALpy_MC','alphabet':alph,'prior':q.tolist(),'delta':auto.delta,'initial':ref['initial'],'states':[{'output':s['output'],'transitions':s['transitions']} for s in ref['states']]}
    def sizes(name,payload):
        b=canonical(payload);return {'model':name,'canonical_json_bytes':len(b),'zlib9_bytes':len(zlib.compress(b,9)),'payload_sha256':hashlib.sha256(b).hexdigest()}
    metrics.append(sizes('AALpy',payload));topologies.append({'model':'AALpy','states':S,'edges':E,'alphabet_size':K,'stored_contexts':None,'probabilistic_dimensions':auto.parameters()});proxies.append({'model':'AALpy','structure_bits':struct,'probability_dimensions':auto.parameters(),'probability_bits_32':32*auto.parameters(),'total_proxy_bits_32':struct+32*auto.parameters()})
    for width in (16,32,64):sensitivity.append({'model':'AALpy','coefficient_bits':width,'structure_bits':struct,'total_proxy_bits':struct+width*auto.parameters()})
    # Check the emission distribution actually sums to one along every held-out trace.
    max_norm_error=0.
    for r in test:
        belief=np.zeros(S);belief[auto.initial]=1
        for ch in encode(r):
            norm=sum(auto.step(belief,c)[0] for c in alph);max_norm_error=max(max_norm_error,abs(norm-1));_,belief=auto.step(belief,ch)
    for n in (0,1,2,3):
        cfg=selection['selected_markov'][str(n)];m=Markov(fit,n,cfg['strength']);name='Markov'+str(n);recomputed[name]=score(m,test);C=len(m.probs)
        st=ubits(n+1)+ubits(C)+C*n*label_width
        topo={'model':name,'states':None,'edges':None,'alphabet_size':K,'stored_contexts':C,'probabilistic_dimensions':m.parameters()};topologies.append(topo)
        proxies.append({'model':name,'structure_bits':st,'probability_dimensions':m.parameters(),'probability_bits_32':32*m.parameters(),'total_proxy_bits_32':st+32*m.parameters()})
        for width in (16,32,64):sensitivity.append({'model':name,'coefficient_bits':width,'structure_bits':st,'total_proxy_bits':st+width*m.parameters()})
        metrics.append(sizes(name,{'family':'Markov','order':n,'alphabet':m.alphabet,'prior':m.q.tolist(),'context_probabilities':[(k,v.tolist()) for k,v in sorted(m.probs.items())]}))
        for p in m.probs.values():assert abs(float(p.sum())-1)<1e-10
    g=Grammar(fit);weight=fit_weight(events(g,fit,1));assert abs(weight-result['vvm_memory_weight'])<1e-12
    recomputed['VVM_base']=vvm_scores(g,test,0.);recomputed['VVM_memory']=vvm_scores(g,test,weight)
    vvm_rows={name:len(t) for name,t in g.tables.items()};D=sum(vvm_rows.values());payload={'family':'VVM','symbols':g.symbols,'tables':{name:[{'key':key,'counts':c.tolist()} for key,(c,_) in sorted(t.items(),key=lambda kv:repr(kv[0]))] for name,t in g.tables.items()}}
    for name,w in [('VVM_base',0.),('VVM_memory',weight)]:
        metrics.append(sizes(name,{**payload,'memory_weight':w}));topologies.append({'model':name,'states':None,'edges':None,'alphabet_size':g.K,'stored_contexts':D,'probabilistic_dimensions':None,'dense_row_dimension_proxy':D*(g.K-1)+(name=='VVM_memory')})
    # Verify chain-rule equality on ALL test words, including cache and EOS.
    max_chain_error=0.;nwords=0;pages=collections.defaultdict(list)
    for r in test:pages[r['folio']].append(r)
    for page in pages.values():
        for i,r in enumerate(page):
            cache=collections.Counter(page[i-1]['tokens']) if i else collections.Counter();den=sum(cache.values());st=State()
            for j,w in enumerate(r['tokens']):
                pos=position_key(j,r['paragraph_start']);lp=word_logp(g,w,r['regime'],st.previous,pos);expected=-mixture_logp(lp,cache[w]/den if den else 0,bool(den),weight)/math.log(2);actual=mixture_symbol_bits(g,w,r['regime'],st.previous,pos,cache,weight);max_chain_error=max(max_chain_error,abs(expected-actual));nwords+=1;st.update(w)
    assert max_chain_error<1e-9 and max_norm_error<1e-9
    max_score_error=0.
    for name,sc in recomputed.items():
        assert set(sc)==set(stored[name])
        for gr,v in sc.items():
            assert v['symbols']==stored[name][gr]['symbols'];max_score_error=max(max_score_error,abs(v['bits']-stored[name][gr]['bits']));assert abs(v['bits']-stored[name][gr]['bits'])<1e-8
        assert sum(v['symbols'] for v in sc.values())==37368
        assert abs(sum(v['bits'] for v in sc.values())/37368-result['scores'][name]['micro_bits_per_symbol'])<1e-10
    # Protected-input and result hashes retained; the script never overwrites the fit/results.
    paths=['corpus/ZL3b-n.txt','corpus/ivtff_parser_rc1_2.py','corpus/physical_map_verified.csv','experiments/PROTOCOLLO_AUTOMATA.md','experiments/automata.json','automaton_benchmark.py','src/vvm/grammar.py','src/vvm/memory.py','run_v02.py','results_automata/selection.json','results_automata/results.json','results_automata/per_group.csv','results_automata/partitions.csv','results_automata/final_aalpy_model.json']
    hashes={p:{'sha256':digest(ROOT/p),'bytes':(ROOT/p).stat().st_size} for p in paths};gitparent=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip();gitlog=subprocess.check_output(['git','-C',str(ROOT),'log','--format=%h %s'],text=True)
    cohort=[]
    for group in sorted(groupsets):
        rs=[r for r in rows if r['group']==group];cohort.append({'group':group,'partition':next(iter(groupsets[group])),'folios':'|'.join(sorted({r['folio'] for r in rs})),'rows':len(rs),'tokens':sum(len(r['tokens']) for r in rs),'symbols':sum(len(encode(r)) for r in rs)})
    paired={};rng=np.random.default_rng(20261111);gs=sorted(stored['AALpy']);ix=rng.integers(0,10,(10000,10))
    for label,a,b in [('VVM_memory_vs_Markov3','VVM_memory','Markov3'),('VVM_memory_vs_Markov2','VVM_memory','Markov2')]:
        ds=np.array([stored[b][k]['loss']-stored[a][k]['loss'] for k in gs]);paired[label]={'macro_gain':float(ds.mean()),'ci95':np.quantile(ds[ix].mean(axis=1),[.025,.975]).tolist(),'positive_groups':int(sum(ds>0))}
    audit={'status':'REPRODUCED_WITH_FROZEN_SELECTION_NO_ALERGIA_REFIT','parent_commit':gitparent,'test_event_sha256':hashlib.sha256(target).hexdigest(),'test_rows':len(test),'test_word_events':nwords,'test_symbols':37368,'unseen_test_characters':unknown,'max_bit_total_error':max_score_error,'max_automaton_normalization_error':max_norm_error,'max_word_vs_symbol_chain_rule_error_bits':max_chain_error,'group_partitions_disjoint':True,'same_targets_and_denominators_all_models':True,'identical_predictor_information':False,'vvm_table_rows':vvm_rows,'paired_descriptive_comparisons':paired,'hashes':hashes,'complexity_topology':topologies,'description_proxies':proxies,'precision_sensitivity':sensitivity,'serialization_sizes':metrics,'git_log':gitlog}
    (A/'audit_results.json').write_text(json.dumps(audit,indent=2))
    for filename,data in [('physical_group_partitions.csv',cohort),('description_proxies.csv',proxies),('precision_sensitivity.csv',sensitivity),('serialization_sizes.csv',metrics)]:
        with (A/filename).open('w',newline='') as f:wr=csv.DictWriter(f,fieldnames=list(data[0]));wr.writeheader();wr.writerows(data)
    print(json.dumps({k:audit[k] for k in ['max_bit_total_error','max_automaton_normalization_error','max_word_vs_symbol_chain_rule_error_bits','description_proxies','precision_sensitivity','serialization_sizes','paired_descriptive_comparisons','vvm_table_rows']},indent=2))
if __name__=='__main__':run()
