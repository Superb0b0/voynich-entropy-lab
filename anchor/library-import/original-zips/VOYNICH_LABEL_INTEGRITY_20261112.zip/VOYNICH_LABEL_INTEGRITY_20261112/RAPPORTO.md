# EXP-FIRST-WORD-05 | Audit di integrità delle etichette zodiacali

**12 novembre 2026 · Esplorativo · Nessuna decifrazione.**

## Scopo
Controllare la perdita di informazione causata dal trattare come parola unica le etichette grafiche delle quattro mezze ruote zodiacali (f70v1, f71r, f71v, f72r1). La fonte dell’analisi è il file congelato `source_labels_rings.csv` dell’esperimento FIRST-WORD-03, qui incluso per la riproducibilità. La separazione per punto segue i token trascritti, non prova di per sé un confine lessicale o grammaticale.

## Nuova osservazione
Dei 58 record leggibili ZL3b, 17 (29,3%) contengono più parole; dei 60 IT2a, 22 (36,7%). La frequenza `ot` nell’anello di cinque, rispetto a quello di dieci, dipende dal criterio di lettura dell’etichetta. `results.csv` confronta `first_ot`, `any_ot`, `all_ot`, `last_ot` con 9.999 permutazioni delle assegnazioni ad anello **entro ciascuna pagina**.

## Confondenti
`conditional.csv` conserva anche i controlli per pagina × lunghezza dell’etichetta (una vs più parole), per pagina × iniziale `o` e per l’intersezione. Il test sulla prima parola è p≈0,0867 ZL3b e p≈0,1242 IT2a quando si conservano sia pagina, sia numero di parole, sia prima iniziale `o`. Questi p sono **nominali e post-hoc**, non corretti per tutta la ricerca precedente: nessuna evidenza robusta di un significato di `ot`.

## Integrità iconografica
La descrizione di René Zandbergen (voynich.nu/q10 e /q11) attesta 15 figure per ciascuna delle quattro mezze ruote, per un totale di 60, e attribuisce alla pagina f72r1 l’assenza delle vasche in un anello. Non fornisce però un registro esaustivo figura↔etichetta per costume, postura, copricapo o gesti. La tabella specialistica www.voynich.com/enigma/fig11.pdf non è una prova indipendente dell’associazione fra numero di figure e nome del nostro `ring=0/1`: l’ordine delle colonne è ambiguo se estratto come testo. Pertanto **non** abbiamo rietichettato gli anelli senza confronto geometrico individuale. Tutte le proprietà visive individuali rimangono sconosciute.

## Eccezioni verificabili altrove
La descrizione della quire 11 conferma una figura senza stella su f72r2 (Gemelli) e una figura con corona su f72r3 (Cancro), f72v3 (Leone) e f72v1 (Bilancia), senza però consentire l'abbinamento della singola etichetta a tali figure. Non abbiamo trasformato questi elementi in osservazioni positive per il test lessicale.

## Limiti
Le due trascrizioni non sono repliche indipendenti; il campione è stato analizzato ripetutamente; definizioni di parole ed etichette devono essere ricontrollate sulla fotografia. L'uso di un confronto a livello di singole etichette non autorizza affermazioni su 60 soggetti indipendenti. Nessun gate RC1.4.2 è stato modificato.

## Riproduzione
Da questa cartella: `python audit.py && python conditional.py` (richiede numpy e pandas). Le simulazioni sono seed-fixed ma non costituiscono una validazione indipendente.
