from pathlib import Path
import pandas as pd,numpy as np
S=Path(__file__).resolve().parent; D=pd.read_csv(S/'labels_reaudited.csv');out=[]
for tr,v in D.groupby('transcription'):
 v=v.reset_index(drop=True).copy(); v['multi']=(v.n_words>1).astype(int)
 for metric in ['first_ot','last_ot']:
  for cond,keys in [('folio',['folio']),('folio_multi',['folio','multi']),('folio_first_o',['folio','first_o']),('folio_multi_first_o',['folio','multi','first_o'])]:
   vv=v.copy(); x=vv[metric].to_numpy();mask=(vv.ring==1).to_numpy();fs=vv.folio.to_numpy(); folios=vv.folio.unique();
   def calc(mm): return float(np.mean([x[(fs==f)&mm].mean()-x[(fs==f)&~mm].mean() for f in folios]))
   obs=calc(mask);rng=np.random.default_rng(20261112);groups=[g.index.to_numpy() for _,g in vv.groupby(keys,dropna=False)]
   vals=np.empty(9999)
   for j in range(len(vals)):
    mm=mask.copy()
    for inds in groups: mm[inds]=rng.permutation(mask[inds])
    vals[j]=calc(mm)
   pv=(1+np.count_nonzero(np.abs(vals-vals.mean())>=abs(obs-vals.mean())-1e-12))/(len(vals)+1)
   out.append(dict(transcription=tr,metric=metric,condition=cond,n=len(vv),observed=obs,p=pv,unique_values=len(np.unique(vals))))
q=pd.DataFrame(out);q.to_csv(S/'conditional.csv',index=False);print(q.to_string(index=False))
