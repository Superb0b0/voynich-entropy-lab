from pathlib import Path
import pandas as pd,numpy as np,json,math
S=Path(__file__).resolve().parent
p=S.parent/'VOYNICH_FIGURE_POSITION_20261112'/'source_labels_rings.csv'
d=pd.read_csv(p,keep_default_na=False)
out=[];m=[]
for tr,a in d.groupby('transcription'):
 a=a[a.clean.astype(str).str.lower()=='true'].copy()
 for _,r in a.iterrows():
  words=[x for x in str(r.raw).split('.') if x]
  row=dict(transcription=tr,folio=r.folio,ring=int(r.ring),locus=int(r.locus),raw=r.raw,n_words=len(words),first=r.word,first_ot=int(str(r.word).startswith('ot')),any_ot=int(any(w.startswith('ot') for w in words)),all_ot=int(all(w.startswith('ot') for w in words)),second_or_later_ot=int(any(w.startswith('ot') for w in words[1:])),last_ot=int(words[-1].startswith('ot')),first_o=int(str(r.word).startswith('o')))
  m.append(row)
 a=pd.DataFrame([x for x in m if x['transcription']==tr]);
 for metric in ['first_ot','any_ot','all_ot','last_ot']:
  obs=np.mean([v[v.ring==1][metric].mean()-v[v.ring==0][metric].mean() for _,v in a.groupby('folio')]);
  folios={f:v.reset_index(drop=True) for f,v in a.groupby('folio')}
  rng=np.random.default_rng(20261112);N=9999;null=[]
  for j in range(N):
   q=[]
   for f,v in folios.items():
    mask=np.zeros(len(v),bool);mask[rng.choice(len(v),size=int((v.ring==1).sum()),replace=False)]=True
    x=v[metric].to_numpy();q.append(x[mask].mean()-x[~mask].mean())
   null.append(np.mean(q))
  null=np.array(null)
  pv=(1+np.count_nonzero(np.abs(null-null.mean())>=abs(obs-null.mean())-1e-12))/(N+1)
  out.append(dict(transcription=tr,metric=metric,n_labels=len(a),multi_label_count=int((a.n_words>1).sum()),n_secondary_ot=int(a.second_or_later_ot.sum()),observed_difference=round(float(obs),6),p_two_sided=float(pv),seed=20261112,permutations=N))
pd.DataFrame(m).to_csv(S/'labels_reaudited.csv',index=False)
pd.DataFrame(out).to_csv(S/'results.csv',index=False)
print(pd.DataFrame(out).to_string(index=False))
