Exploratory zodiac label integrity audit. Run: python audit.py and python conditional.py. Read RAPPORTO.md. No translation claimed.
