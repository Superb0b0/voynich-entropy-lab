# Schema ANCHOR v1.1.0, revisione 2 (DRAFT)

Questa revisione corregge tre lacune dello schema precedente: SHA-256 non nullable e obbligatorio per ciascun file sorgente; livello RIPORTATO/RIPRODOTTO esplicito; PASS subordinato a verifica riprodotta, revisore, data, script/hash, comando e riferimenti alle evidenze.

`branch=EXPLORATORY_ANCHOR`, `classification=ESPLORATIVO`, `gate_effect=NONE` sono costanti. Le nuove importazioni partono da PENDING/RIPORTATO. Lo schema consente PASS solo con prove; non concede alcuna autorizzazione operativa.

Nota: lo schema valida struttura e forma dei digest, non dimostra che i digest corrispondano ai file. Il controllo `format` date/date-time richiede un validatore che abiliti FormatChecker. Non modifica la release 1.0.0.
