# EXP-MORPHOGEN-01 (esplorativo, NON validato)

Risultati e metodi in `RAPPORTO.md`.

- `run.py`, `runs.csv`, `results.json`: 50 generazioni senza famiglie persistenti.
- `family.py`, `family_runs.csv`, `family_results.json`: 30 generazioni con genealogia delle forme.
- `diagnostics.py`, `diagnostics.csv`, `diagnostics.json`: verifica indipendente dalle metriche di scelta.
- `upstream/`: fonti e codice del precedente gate, con trascrizioni originali.

Riprodurre da un archivio estratto, con `python run.py && python family.py && python diagnostics.py`. Dipendenze: NumPy. I file risultato possono essere sovrascritti.

**Attenzione:** non è stato superato un gate confermativo né decifrato il manoscritto. Il test del folio è stato riutilizzato da precedenti studi.
