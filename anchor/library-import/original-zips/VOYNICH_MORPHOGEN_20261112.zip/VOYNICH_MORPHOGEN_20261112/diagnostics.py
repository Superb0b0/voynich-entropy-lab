#!/usr/bin/env python3
"""Additional posthoc probes, not part of original model selection. Real heldout vs 5 fixed seeds."""
from pathlib import Path
import json,csv,statistics
from collections import Counter
import numpy as np
ROOT=Path(__file__).resolve().parent
src=(ROOT/'family.py').read_text();ns={'__file__':str(ROOT/'family.py'),'__name__':'diagnostic_setup'}
exec(compile(src[:src.index('result={')],str(ROOT/'family.py'),'exec'),ns)
folios,meta,base,test=ns['folios'],ns['meta'],ns['base'],ns['test']
matched_or,build,generate=ns['matched_or'],ns['build'],ns['generate']

def desc(rows,base_vocab):
    tokens=[w for row in rows for w in row]
    n=len(tokens);linefirst=[row[0] for row in rows if row]
    chars=Counter(''.join(tokens));pref=Counter(w[:2] for w in tokens if len(w)>=2)
    def ratio(condition,items):return sum(bool(condition(x)) for x in items)/len(items) if items else 0
    return {'mean_length':sum(map(len,tokens))/n,
            'length_ge_9':ratio(lambda x:len(x)>=9,tokens),
            'length_le_3':ratio(lambda x:len(x)<=3,tokens),
            'oov_type_rate':len(set(tokens)-base_vocab)/len(set(tokens)),
            'oov_token_rate':ratio(lambda w:w not in base_vocab,tokens),
            'first_qo':ratio(lambda w:w.startswith('qo'),linefirst),
            'first_y':ratio(lambda w:w.startswith('y'),linefirst),
            'first_o':ratio(lambda w:w.startswith('o'),linefirst),
            'all_qo':ratio(lambda w:w.startswith('qo'),tokens),
            'token_types':len(set(tokens)),
            'yo_matched_or':matched_or(rows)['or'],
            'yo_strata':matched_or(rows)['strata'],
            'prefix2_top10':pref.most_common(10),
            'char_top10':chars.most_common(10)}

report={'description':'Additional diagnostics, model selected for attention posthoc. Not a blind test.','results':{}}
for trans in ['zl','it']:
    spec=build(trans);vocab=spec[0]
    ref=[list(row[trans]) for f in sorted(test) for p in folios[f] for row in p]
    vals={'reference':desc(ref,vocab),'models':{}}
    for kind in ['family_10_30','family_15_15','family_20_20']:
        measures=[]
        for seed in [3301,3302,3303,3304,3305]:
            sample,_=generate(trans,kind,seed,spec)
            measures.append(desc(sample,vocab))
        means={k:float(np.mean([m[k] for m in measures])) for k in ['mean_length','length_ge_9','length_le_3','oov_type_rate','oov_token_rate','first_qo','first_y','first_o','all_qo','token_types','yo_matched_or','yo_strata']}
        vals['models'][kind]={'means':means,'runs':measures}
    report['results'][trans]=vals
(ROOT/'diagnostics.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
rows=[]
for trans,r in report['results'].items():
    rows.append({'trans':trans,'kind':'Voynich reference',**{k:v for k,v in r['reference'].items() if isinstance(v,(float,int))}})
    for kind,a in r['models'].items():rows.append({'trans':trans,'kind':kind,**a['means']})
with (ROOT/'diagnostics.csv').open('w',newline='') as fh:
    import csv
    w=csv.DictWriter(fh,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print('DONE')
