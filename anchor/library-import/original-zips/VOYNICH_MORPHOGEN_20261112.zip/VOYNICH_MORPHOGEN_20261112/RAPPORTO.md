# Voynich, EXP-MORPHOGEN-01 | Parole nuove e genealogie grafiche

**12 novembre 2026 | ESPLORATIVO | Gate NON SUPERATO**

## Risultato

Il semplice aumento delle mutazioni indipendenti recupera la percentuale di hapax ma abbassa l’adiacenza e la ripetizione. Un secondo generatore che ricicla parole delle due righe precedenti e genera varianti a un edit raggiunge valori molto più vicini al Voynich, ma sovrastima la continuità, la novità per occorrenza e l’asimmetria posizionale. Nessuna configurazione è considerata una spiegazione storica validata.

**Disegno:** gli input reali e lo split dei 54 folii appartengono a un dataset già esaminato. Le due trascrizioni ZL3b e IT2a non sono osservazioni indipendenti. Soltanto lunghezze di riga, struttura dei paragrafi ed etichette Currier dei folii di prova entrano nei generatori; forme e probabilità di base sono stimate sui folii di addestramento. Nessuna parola reale del folio di prova è copiata dal generatore.

## Medie dei 5 semi (ZL3b)

| Modello | Densità | Adiacenza | Ripetizione | Hapax | Edit-1 fra righe |
|---|---:|---:|---:|---:|---:|
| **Voynich campione** | 0.9468 | 0.0271 | 0.0569 | 0.7157 | 0.2060 |
| Solo vocabolario base | 0.9357 | 0.0215 | 0.0426 | 0.5143 | 0.1601 |
| Mutazioni indipendenti 15% | 0.9408 | 0.0158 | 0.0312 | 0.6609 | 0.1388 |
| Mutazioni indipendenti 30% | 0.9444 | 0.0117 | 0.0232 | 0.7342 | 0.1242 |
| Mutazioni 15% da forma recente | 0.9485 | 0.0162 | 0.0317 | 0.6622 | 0.1715 |
| Famiglia: ripresa 10%, mutazione 30% | 0.9676 | 0.0347 | 0.0668 | 0.7234 | 0.2627 |
| Famiglia: ripresa 15%, mutazione 15% | 0.9563 | 0.0524 | 0.1002 | 0.6402 | 0.2046 |
| Famiglia: ripresa 20%, mutazione 20% | 0.9602 | 0.0641 | 0.1227 | 0.6583 | 0.2290 |

**I cinque semi** sono dichiarati nel codice, non selezionati dopo i risultati. In totale sono state effettivamente eseguite 80 generazioni (50 nel primo confronto, 30 nei tre modelli a famiglie); nessuna delle configurazioni riproduce tutte le proprietà insieme. I valori sopra sono medie di cinque prove e non stime di incertezza su manoscritti indipendenti.

## Controllo diagnostico aggiuntivo (ZL3b)

| Misura | Voynich | Famiglia 10/30 |
|---|---:|---:|
| Lunghezza media token | 5.1489 | 5.2097 |
| Quota **tipi** mai presenti nel training | 0.5857 | 0.5887 |
| Quota **occorrenze** di tipi fuori training | 0.2033 | 0.3526 |
| Frazione di righe che iniziano con qo | 0.1240 | 0.1131 |
| OR yX/oX appaiato | 3.5998 | 5.5938 |

Il fatto che la quota di tipi fuori dal training coincida non implica che il lessico sia modellato bene: nel sintetico tali tipi occupano più del 35% delle occorrenze, contro il 20% del manoscritto. Il confronto con IT2a è incluso nei CSV e presenta lo stesso problema.

## Specifica del primo generatore

- Vocabolario di campionamento: **solo tipi dei folii base** (nessuna parola di prova usata per formarlo).
- Mutazione a edit-1 tramite inserzione, cancellazione, sostituzione; versione "licensed" accetta solo coppie di caratteri presenti nel vocabolario base; nessun filtro basato sui folii di test.
- Quantità di mutazioni fissata prima dell’esecuzione per ogni modello: 0, 15% o 30%. Possibile memoria di folio pari al 5%.
- Posizione: intervento applicato a posteriori mediante scambio con una parola iniziata in y presente nella stessa riga (probabilità fissa 0,42); **non è un fenomeno che emerge spontaneamente**.

## Specifica della seconda famiglia

- A ogni posizione della riga: scelta dal vocabolario base, oppure riutilizzo di un token delle due righe precedenti dello stesso paragrafo, oppure edit-1 da token recente.
- Configurazioni dichiarate nel codice prima dell’esecuzione: riutilizzo/mutazione 15%/15%, 10%/30%, 20%/20%.
- Senza contesto precedente disponibile, backoff verso il vocabolario base; possibili mutazioni fallite dopo 24 tentativi.
- Le forme create in precedenza possono ricevere ulteriori mutazioni; ciò genera vere genealogie di varianti, **ma la somiglianza non equivale a un’identità semantica**.

## Criteri di falsificazione e limiti

1. Il modello 10/30 ottiene hapax vicini al reale, ma presenta densità, adiacenza, ripetizione e soprattutto edit-1 fra righe superiori; fallisce il benchmark congiunto.
2. L’OR yX/oX è sovrastimato; per giunta la posizione y-iniziale è imposta. Non si può usarne la somiglianza per inferire una regola crittografica storica.
3. I folii di test erano stati già utilizzati in precedenti confronti; non esiste un vero test indipendente nuovo.
4. Le due trascrizioni sono osservazioni correlate dello stesso manoscritto.
5. Layout, soglie di lunghezza e divisione in paragrafi sono imposti. Il modello **non genera un manoscritto completo autonomamente**.
6. I parametri della seconda famiglia sono stati progettati dopo i risultati della prima: il confronto è esplorativo.
7. Le bande legacy erano calibrate sul corpus storico completo, non sul campione ~10.000 token. Perciò qui confrontiamo i generatori con **gli stessi folii** invece di proclamare un pass formale nelle vecchie bande.

## Interpretazione

Il prossimo bersaglio scientifico non è semplicemente aggiungere mutazioni, ma disaccoppiare tre processi: (A) creazione di nuove forme, (B) sopravvivenza e ripetizione delle forme per occorrenza, (C) continuità delle famiglie grafiche sulle righe. Un modello che li tratti come lo stesso parametro produce inevitabilmente un trade-off. Questa è un’ipotesi sperimentale, non una decifrazione.

## Riproducibilità

Richiede Python 3.11+ e NumPy; tutti gli input e gli script del precedente gate sono conservati in `upstream/`. Da un percorso estratto indipendente:

```bash
python run.py
python family.py
python diagnostics.py
```

Il controllo di portabilità è stato **effettivamente eseguito** da una cartella temporanea estranea alla directory originale: `run.py` e `family.py` terminano con codice 0 e rigenerano i rispettivi CSV. I dati archiviati in `runs.csv` e `family_runs.csv` sono i risultati osservati in questa sessione; i programmi li sovrascrivono alla riesecuzione.

**Regime:** il gate RC1.4.2 (`CLOSED_PENDING_VALIDATION`) resta congelato. Nessun builder visivo-testuale, PCA o clustering è stato lanciato.
