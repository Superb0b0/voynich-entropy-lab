# Voynich · EXP-ZODIAC-CROSSWALK-01

Audit riproducibile dei conteggi di 12 diagrammi zodiacali e delle etichette IVTFF in ZL3b e IT2a.

Eseguire `python audit.py` dalla cartella estratta. Il programma ricalcola `results.json`, `folio_reconciliation.csv` e `reconciliation_exceptions.csv` usando `source_labels.csv` incluso. Il codice blocca immediatamente eventuali conteggi inattesi con un'asserzione. Le quantità delle figure derivano dalle descrizioni pubbliche citate in `RAPPORTO.md`, non da nuova annotazione delle scansioni originali.
