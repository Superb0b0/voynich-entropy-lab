# EXP-ZODIAC-CROSSWALK-01 · Audit dei conteggi figura–etichetta

Data: 12 novembre 2026. Esplorativo, in sola lettura. Non modifica RC1.4.2.

## Risultato principale

Le dodici pagine zodiacali del manoscritto conservato comprendono 299 figure e 299 etichette (secondo le descrizioni iconografiche citate e il parser già utilizzato negli esperimenti FIRST-WORD). **Questa eguaglianza globale maschera due eccezioni locali**:

- f70v2, Pesci: **29 figure, 30 etichette**. La fonte primaria di riferimento iconografico dice che 29 etichette sono vicine a figure umane e la trentesima è vicina a una delle stelle centrali. Quale locus specifico sia questa etichetta non è qui verificato mediante coordinate: non inferirlo dall'ultimo locus.
- f72r2, Gemelli: **30 figure, 29 etichette**. Una delle figure nell'anello esterno, sulla sinistra, non ha etichetta; una figura diversa, nell'anello esterno in basso a destra, non ha stella. I due casi non devono essere confusi.

Le altre dieci pagine coincidono quanto al numero di figure e etichette (non è una prova di corrispondenza *individuale*). Due trascrizioni dello stesso manoscritto concordano sui conteggi: non costituiscono due testimoni storicamente indipendenti.

## Tabella delle quantità

| Folio | Figure | Etichette | Delta etichette − figure |
|---|---:|---:|---:|
| f70v2 | 29 | 30 | +1 |
| f70v1 | 15 | 15 | 0 |
| f71r | 15 | 15 | 0 |
| f71v | 15 | 15 | 0 |
| f72r1 | 15 | 15 | 0 |
| f72r2 | 30 | 29 | −1 |
| f72r3 | 30 | 30 | 0 |
| f72v3 | 30 | 30 | 0 |
| f72v2 | 30 | 30 | 0 |
| f72v1 | 30 | 30 | 0 |
| f73r | 30 | 30 | 0 |
| f73v | 30 | 30 | 0 |
| **Totale** | **299** | **299** | **0** |

## Fonti utilizzate

Descrizioni di René Zandbergen (versioni delle pagine aggiornate nel 2025):
- https://www.voynich.nu/q10/index.html (f70v2 e f70v1)
- https://www.voynich.nu/q11/index.html (f71r–f72v1)
- https://www.voynich.nu/q12/index.html (f73r–f73v)

Le 299 righe testuali per trascrizione provengono da `source_labels.csv`, copia conservata dell'input sperimentale precedente `VOYNICH_FIGURE_ATTRIBUTES_20261112/input_labels.csv`. SHA-256 in `SHA256SUMS.txt`.

## Ulteriori controlli

- Sono state conteggiate 299 etichette in ZL3b e 299 in IT2a, con 12 pagine ciascuna.
- Secondo il parser conservato, la prima parola è certa per 274/299 in ZL3b e 296/299 in IT2a; la differenza riguarda la leggibilità e non la presenza dell'etichetta.
- Nessuna delle 299 coppie figura–parola è **qui** certificata mediante un collegamento spaziale individuale (bounding box della figura e punto di ancoraggio del testo). L'uguaglianza dei conteggi non dà automaticamente il diritto di abbinare elementi per ordine di locus o indice di catalogo.
- L'indicazione "trentesima" nella fonte descrittiva non permette da sola di dichiarare che la parola `otolal` o `otylal` sia quella vicino alla stella centrale. È necessario il riscontro sull'immagine originale.

## Regola operativa

Per tutte le future analisi iconografiche: tenere i loci originali separati; non trasmettere gli attributi della figura a una etichetta finché non sono documentate coordinate visive e confidenza di abbinamento; f70v2 e f72r2 sono **BLOCKED_INDIVIDUAL_JOIN**. Le altre dieci pagine sono `COUNT_MATCH_ONLY`, non `INDIVIDUAL_JOIN_PASS`.

Nessun significato lessicale identificato; nessuna inferenza semantica promossa. Pipeline RC1.4.2 congelata.
