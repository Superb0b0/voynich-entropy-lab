#!/usr/bin/env python3
"""Reconcile manuscript zodiac FIGURE counts and IVTFF label counts, not figure-to-label coordinates.
Source: https://www.voynich.nu/q10/index.html, q11/index.html, q12/index.html;
figure counts are manually transcribed from source prose on 2026-11-12.
The input CSV was produced by an earlier exploratory parser. Do not mutate it.
"""
from pathlib import Path
import csv, collections, json, hashlib, math
B=Path(__file__).resolve().parent
INPUT=B/'source_labels.csv'
PAGES=[
('f70v2','Pisces',29,30,'q10','29 nymphs; 30th label beside central star'),
('f70v1','Aries I',15,15,'q10','15 figures and 15 labels'),
('f71r','Aries II',15,15,'q11','15 figures and 15 labels'),
('f71v','Taurus I',15,15,'q11','15 figures and 15 labels'),
('f72r1','Taurus II',15,15,'q11','15 figures and 15 labels; outer ring without tubs'),
('f72r2','Gemini',30,29,'q11','30 figures, 29 labels; one outer-ring figure lacks a label'),
('f72r3','Cancer',30,30,'q11','30 figures and 30 labels'),
('f72v3','Leo',30,30,'q11','30 figures and 30 labels'),
('f72v2','Virgo',30,30,'q11','30 figures and 30 labels'),
('f72v1','Libra',30,30,'q11','30 figures and 30 labels'),
('f73r','Scorpio',30,30,'q12','30 figures and 30 labels'),
('f73v','Sagittarius',30,30,'q12','30 figures and 30 labels'),
]
raw=list(csv.DictReader(INPUT.open(encoding='utf8',newline='')))
d=collections.defaultdict(list)
for row in raw:d[(row['transcription'],row['folio'])].append(row)
headers=['transcription','folio','sign','figure_count_source','label_count_source','label_count_parsed','difference_labels_minus_figures','source_page','source_note','count_status','first_word_certain','uncertain_first_words','multi_token_labels','individual_figure_label_matches_verified']
result=[]
for t in ['ZL3b','IT2a']:
 for f,sign,nfig,nlab,quire,note in PAGES:
  entries=d[(t,f)]; assert len(entries)==nlab,(t,f,len(entries),nlab)
  ss=sum(x['sure']=='True' for x in entries)
  result.append(dict(transcription=t,folio=f,sign=sign,figure_count_source=nfig,label_count_source=nlab,label_count_parsed=len(entries),difference_labels_minus_figures=nlab-nfig,source_page=f'https://www.voynich.nu/{quire}/index.html',source_note=note,count_status=('COUNT_MATCH' if nfig==nlab else 'COUNT_MISMATCH'),first_word_certain=ss,uncertain_first_words=nlab-ss,multi_token_labels=sum(len(x['tokens_clean'].split())>1 for x in entries),individual_figure_label_matches_verified='NO; aggregate page-level counts only'))
with (B/'folio_reconciliation.csv').open('w',encoding='utf8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=headers);w.writeheader();w.writerows(result)
exceptions=[dict(folio='f70v2',kind='LABEL_WITHOUT_NYMPH',n_extra=1,figure_class='central star',source='https://www.voynich.nu/q10/index.html',source_specificity='the 30th label is near one of two central stars',label_locus='UNRESOLVED',label_word='UNRESOLVED',action='Do not match by list index or assume last locus belongs to the star'),dict(folio='f72r2',kind='NYMPH_WITHOUT_LABEL',n_extra=1,figure_class='outer-ring left nymph',source='https://www.voynich.nu/q11/index.html',source_specificity='one nymph lacks a label, not the same as the nymph lacking a star',label_locus='ABSENT',label_word='ABSENT',action='Do not assign a neighboring label to the unlabeled figure')]
with (B/'reconciliation_exceptions.csv').open('w',encoding='utf8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=exceptions[0]);w.writeheader();w.writerows(exceptions)
# '299 figure tokens' is not treated as 299 matched figure-label pairs.
report={t:{'folios':len(PAGES),'figure_total':sum(x[2] for x in PAGES),'label_total':sum(x[3] for x in PAGES),'parsed_total':sum(len(d[(t,x[0])]) for x in PAGES),'pages_with_count_mismatch':[x[0] for x in PAGES if x[2]!=x[3]],'pages_matching_count':sum(x[2]==x[3] for x in PAGES),'certain_first_token_labels':sum(r['first_word_certain'] for r in result if r['transcription']==t),'ambiguous_first_token_labels':sum(r['uncertain_first_words'] for r in result if r['transcription']==t)} for t in ['ZL3b','IT2a']}
report['global_status']='COUNT_TOTAL_EQUALS_299_BUT_TWO_LOCAL_MISMATCHES; INDIVIDUAL FIGURE->LABEL BINDING NOT VERIFIED'
report['source_input_sha256']=hashlib.sha256(INPUT.read_bytes()).hexdigest()
(B/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(report,indent=2))
