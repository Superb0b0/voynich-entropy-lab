# ASTRO-09 | f69r e la rosa dei venti Oxford MS 17 f40v

Data: 12 novembre 2026. Analisi esplorativa, ZL3b-n.txt in sola lettura. La pipeline RC1.4.2 rimane congelata.

## Ipotesi fissate

- H1, **comune grammatica iconografica**: f69r e la rosa dei venti del ms. Oxford St John's College 17, f40v condividono una costruzione grafica direzionale. Non richiede la stessa quantità di etichette.
- H2, **mappatura lessicale diretta a dodici nomi**: le dodici denominazioni latine dei venti nel manoscritto Oxford hanno un corrispettivo univoco in altrettante scritte Voynich definibili senza scegliere a posteriori.

## Evidenze esterne (dalla letteratura, non ricontate su raster)

René Zandbergen, *Special Topics: Illustrations in the Voynich MS*, https://www.voynich.nu/extra/sp_illustr.html, riprende una comparazione di Ellie Velinska: direzioni cardinali racchiuse da coppie di linee e direzioni intermedie evidenziate; 45 elementi perimetrali in f69r e 46 nel ms Oxford. Oxford: 12 nomi di venti in 4 gruppi da 3; Voynich: 22 scritte radiali.

La scheda del manoscritto Oxford fornisce f40v e il contesto cosmografico: https://iiif.biblissima.fr/collections/manifest/6565d7ee43bb55943793e5701204364e5d305a30; https://digital.library.mcgill.ca/ms-17/index.htm. La tradizione di immagini dei venti è ampia: non è stabilita una dipendenza diretta Oxford -> Voynich.

## Controlli propri sul corpus ZL3b

Input: `/mnt/data/files/ZL3b-n.txt`, SHA-256 `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc`.

- f69r, 22 loci `@Ro` (loci 21–42), suddivisi in 5 iscrizioni con due parole, 12 con tre, 5 con quattro: **66 parole** in tutto, media 3 per iscrizione.
- f69r, 16 settori esterni `@L0` (loci 5–20).
- f69r, 6 piccole iscrizioni centrali `@L0` (loci 44–49), in parte ambigue.
- f69v (stesso foglio, stessa mano riportata nel catalogo), 28 loci `@Ri` (loci 4–31): 23 iscrizioni monoverbali, 5 con due parole.
- Differenza fra le iscrizioni multi-parola: f69r 22/22 vs f69v 5/28. Fisher esatto unilaterale su questi due pannelli `p = 9.096e-10` (test *descrittivo post-hoc*, NON prova di semantica e NON generalizzabile a pagine indipendenti).

I conteggi delle parole usano i separatori `.` e `,` dell'IVTFF e conservano le letture incerte fra parentesi. Non si tratta di un parser morfologico.

## Decisione

- H1: **compatibile, non esclusiva**. Il parallelismo geometrico è documentato, ma non testa una parentela genealogica univoca fra i manoscritti.
- H2: **non sostenuta**. Le 22 scritte radiali non hanno una regola indipendente di riduzione a 12 nomi. I 16 settori esterni suggerirebbero un'altra possibile scelta a posteriori; anch'essa non autorizzata.
- Il forte contrasto fra i due lati dello **stesso foglio** (f69r 22 iscrizioni pluriverbali, f69v 28 prevalentemente monoverbali) mostra che la funzione e la disposizione dei testi dipendono dal singolo schema grafico: è un vincolo di impaginazione da non confondere con prova lessicale.

## Condizione necessaria per una traduzione

Servono dodici posizioni selezionate **prima** di leggere i segni, mediante una regola geometrica indipendente (per esempio i dodici indicatori di direzione); occorrerebbe poi dimostrare che le scritte in quelle dodici posizioni rappresentano nomi di vento attraverso un test esterno o una seconda figura non utilizzata per formulare la regola. I dati attuali non stabiliscono questa corrispondenza.

**Conclusione:** f69r probabilmente utilizza un linguaggio visuale compatibile con i diagrammi medievali dei venti; nessuna parola Voynich è stata tradotta. Non va eseguita una lettura forzata `12 venti = 12 etichette`.
