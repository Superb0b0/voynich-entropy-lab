#!/usr/bin/env python3
import re, json, hashlib, collections, statistics, pathlib
src=pathlib.Path('/mnt/data/files/ZL3b-n.txt')
raw=src.read_bytes(); lines=raw.decode('utf-8').splitlines()
rows=[]
for l in lines:
    m=re.match(r'^<f(69[rv])\.(\d+),([@+&=])([A-Za-z0-9]+)>\s*(.*)$',l)
    if not m: continue
    folio,n,marker,kind,t=m.groups();
    # remove embedded comments and descriptions before counting dots
    cleaned=re.sub(r'<!.*?>|<\$>|<%>','',t).strip()
    words=re.split(r'[.,]',cleaned)
    words=[w for w in words if w and not w.isspace()]
    rows.append(dict(folio='f'+folio,locus=int(n),kind=kind,word_count=len(words),text=cleaned))
count=lambda folio,kind:sum(1 for x in rows if x['folio']==folio and x['kind']==kind)
rad=[x for x in rows if x['folio']=='f69r' and x['kind']=='Ro']; outer=[x for x in rows if x['folio']=='f69r' and x['kind']=='L0' and 5<=x['locus']<=20]; central=[x for x in rows if x['folio']=='f69r' and x['kind']=='L0' and 44<=x['locus']<=49]; back=[x for x in rows if x['folio']=='f69v' and x['kind']=='Ri']
assert (len(rad),len(outer),len(central),len(back))==(22,16,6,28)
res={'corpus_sha256':hashlib.sha256(raw).hexdigest(),'folio_f69r':{'outer_sectors':len(outer),'radial_loci':len(rad),'central_glyph_loci':len(central),'radial_word_count_distribution':dict(sorted(collections.Counter(x['word_count'] for x in rad).items())),'radial_mean_word_count':round(statistics.mean(x['word_count'] for x in rad),4),'radial_total_tokens_approx':sum(x['word_count'] for x in rad),'outer_word_count_distribution':dict(sorted(collections.Counter(x['word_count'] for x in outer).items())),'center_glyphs':[x['text'] for x in central]},'folio_f69v':{'radial_loci':len(back),'radial_word_count_distribution':dict(sorted(collections.Counter(x['word_count'] for x in back).items()))},'external_reported_not_measured':{'voynich_f69r_outer_motifs':45,'oxford_ms17_f40v_outer_motifs':46,'oxford_ms17_f40v_wind_names':12,'voynich_f69r_colored_rays_blue':8,'voynich_f69r_colored_rays_green':4},'limits':['Word counts follow period/comma splitting of ZL3b, not a verified morphological parser.','External geometry/counts are attributed to Zandbergen/Velinska, not independently machine-counted.','No alignment from twelve Oxford wind names to 22 f69r radial texts is specified.']}
path=pathlib.Path(__file__).with_name('RESULTS.json');path.write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(res,ensure_ascii=False,indent=2))
