import csv,math,random,json,itertools,re,hashlib,collections
from pathlib import Path
from statistics import mean
p=Path(__file__).parent
source=p/'input_labels.csv'
entries=[r for r in csv.DictReader(open(source)) if r['transcription']=='ZL3b' and r['folio']=='f70v2']
# The public visual catalog describes 29 Pisces figures with ordinal k=1..29.
# It independently reports blue-painted head-coverings at k=7,9,10,11,12,13.
# Label transcription and segmentation are from the source corpus, not from interpreting the image.
# The original 30 source labels contain an extra terminal 'otolal', not assigned to a figure.
assert len(entries)==30, len(entries)
assert entries[-1]['raw']=='otolal'
assert [r['raw'] for r in entries[:5]]==['otalalg','ykary','otar?','oty','oky.ody']
assert entries[12]['raw']=='ch{ckhh}y'
blue={7,9,10,11,12,13}
rows=[]
for i,r in enumerate(entries[:29],1):
    ring='outer' if i<=19 else 'inner'
    raw=r['raw']; w=r['first'] if r['sure']=='True' else ''
    rows.append(dict(k=i,folio='f70v2',ring=ring,source_locus=r['locus'],source_label=raw,first_word=w,first_word_certain=bool(w),blue_painted_head=(i in blue),head_attribution='painted_blue_headwear' if i in blue else 'other_or_unclassified',star=True,source_visual='https://end.rito.one/solved/data/all_299_figures.json',visual_confidence='high' if i in blue else 'mixed'))
with open(p/'figure_labels_pisces.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
outer=rows[:19];valid=[r for r in outer if r['first_word_certain']]
print('outer',len(outer),'valid',len(valid),'blue valid',sum(r['blue_painted_head'] for r in valid))

def lev(a,b):
 if a==b:return 0
 if abs(len(a)-len(b))>1:return 2
 # edit dist 1 incl replacement, deletion, insertion
 if len(a)==len(b):return sum(x!=y for x,y in zip(a,b))
 if len(a)>len(b):a,b=b,a
 i=j=0;skipped=0
 while i<len(a) and j<len(b):
  if a[i]==b[j]:i+=1;j+=1
  else:skipped+=1;j+=1
  if skipped>1:return 2
 return 1

def evaluate(indices, subset,score):
 a=[subset[i]['first_word'] for i in indices]
 pairs=list(itertools.combinations(a,2))
 if score=='ed1':return sum(lev(x,y)==1 for x,y in pairs)/len(pairs)
 if score=='prefix2':return sum(x[:2]==y[:2] for x,y in pairs)/len(pairs)
 if score=='length':return mean(len(x) for x in a)
 if score=='suffix2':return sum(x[-2:]==y[-2:] for x,y in pairs)/len(pairs)

n=len(valid); k=sum(r['blue_painted_head'] for r in valid); observed=frozenset(i for i,r in enumerate(valid) if r['blue_painted_head']);
vals={key:[] for key in ['ed1','prefix2','suffix2','length']}; obs={key:evaluate(observed,valid,key) for key in vals};
for inds in itertools.combinations(range(n),k):
 for key in vals: vals[key].append(evaluate(inds,valid,key))
exact={key:{'observed':obs[key], 'null_mean':mean(vals[key]), 'p_upper_exact':sum(x>=obs[key]-1e-12 for x in vals[key])/len(vals[key]),'p_lower_exact':sum(x<=obs[key]+1e-12 for x in vals[key])/len(vals[key])} for key in vals}
# Spatially adjusted null: cyclic rotations of 19-position *blue motif* around the same folio.
spatial={}
for key in ['ed1','prefix2','suffix2']:
 shift_vals=[]
 for shift in range(19):
  chosen=frozenset((i+shift-1)%19+1 for i in blue)
  inds=[i for i,r in enumerate(valid) if r['k'] in chosen]
  if len(inds)<2:continue
  shift_vals.append({'shift':shift,'score':evaluate(inds,valid,key),'n':len(inds)})
 spatial[key]={'observed':obs[key],'null_mean':mean(x['score'] for x in shift_vals),'p_upper':sum(x['score']>=obs[key]-1e-12 for x in shift_vals)/len(shift_vals),'n_shifts':len(shift_vals),'shift_scores':shift_vals}
# Based on public JSON records of first 29 as shown by source, manually curated attributes:
# Selected nearest visible star-point counts, not an independent sample, do not perform a second test.
source_points=[7,7,6,6,7,7,6,7,7,6,6,6,6,7,7,7,7,8,7,8,6,6,7,6,6,8,7,7,7]
assert len(source_points)==29
for r,pts in zip(rows,source_points):r['star_points']=pts
with open(p/'figure_labels_pisces.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
# Correlation of star points and simple label length in entire Pisces, sensitivity no low-confidence labels.
pointrows=[r for r in rows if r['first_word'] and isinstance(r['star_points'],int)]
import numpy as np
x=np.array([len(r['first_word']) for r in pointrows]);y=np.array([r['star_points'] for r in pointrows]);pearson=float(np.corrcoef(x,y)[0,1]);
# Within-ring permutation of points (source quality indicative only)
rng=np.random.default_rng(20261112); perm=[]
for _ in range(9999):
 yp=y.copy()
 for ring in ('outer','inner'):
  ids=np.array([i for i,r in enumerate(pointrows) if r['ring']==ring]);yp[ids]=rng.permutation(yp[ids])
 perm.append(float(np.corrcoef(x,yp)[0,1]))
result={'source':'secondary, labels seen by catalog annotators, not independently blinded','source_n_figures':29,'corpus_n_labels':30,'unmatched_source_locus':entries[-1]['locus'],'unmatched_label':entries[-1]['raw'],'n_outer':19,'outer_valid_labels':n,'blue_head_valid':k,'exact_n_assignments':len(next(iter(vals.values()))),'test_exploratory':True,'exact_tests':exact,'spatial_shift':spatial,'star_points_vs_label_length':{'n':len(pointrows),'r':pearson,'p_two_sided_within_ring':(1+sum(abs(a)>=abs(pearson) for a in perm))/(len(perm)+1),'permutations':len(perm)}}
(p/'results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('spatial_shift',)},ensure_ascii=False,indent=2))
print('shift', {k:{a:b for a,b in d.items() if a!='shift_scores'} for k,d in spatial.items()})
