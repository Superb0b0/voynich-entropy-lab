# Voynich, EXP-FIRST-WORD-09

Prima analisi puntuale di attributi delle figure zodiacali, confronto interno a f70v2: capelli/copricapi blu e relazioni grafiche fra etichette. **Esito: negativo**. Due trascrizioni dello stesso manoscritto, analisi esplorativa.

Esegui: `python pilot.py` e `python it2a_check.py` (dipendenze: numpy). Risultati nei JSON; leggi `RAPPORTO.md` per criteri, criticità e interpretazione. Nessun elemento attesta una parola decifrata. RC1.4.2 invariato.
