# EXP-FIRST-WORD-09 · Etichette e copricapi blu nei Pesci (f70v2)

**12 novembre 2026. Test esplorativo, senza parole decifrate.** Non modifica RC1.4.2.

## Provenienza e limiti

L'origine delle annotazioni degli attributi è il repertorio secondario `https://end.rito.one/solved/data/all_299_figures.json`, sezione f70v2, figure 1–29. Il repertorio afferma che le descrizioni siano state effettuate da più lettori, ma include anche la lettura delle etichette ed è ospitato su un sito che sostiene una propria interpretazione del manoscritto: **non è annotazione cieca indipendente certificata**. La relazione fra figura e posizione è assunta dall'ordine del repertorio, verificata contro l'ordine delle prime 29 etichette della trascrizione; il locus finale 33, `otolal` (ZL3b) / `otylal` (IT2a), è una **trentesima etichetta senza corrispondente figura nel repertorio**. Questo disallineamento non va sanato arbitrariamente. Gli attributi `blue_painted_head` e numero di punte delle stelle sono trascritti dal repertorio secondario, non da una nuova valutazione cieca originale.

## Ipotesi testata

Le figure f70v2 7, 9, 10, 11, 12, 13 del primo anello, descritte con copricapo o capelli dipinti in blu, dovrebbero avere etichette **più simili** delle altre etichette dello stesso anello. Sono misurate quattro proprietà: coppie a distanza di Levenshtein 1, prefisso di due caratteri uguale, suffisso di due caratteri uguale, lunghezza media. Il controllo esatto riassegna la stessa numerosità di blue-head a parole dell'anello esterno, mantenendo invariata ogni parola. Un secondo controllo trasla ciclicamente il pattern di sei posizioni lungo le 19 posizioni originali; preserva in tal modo la contiguità del pattern dei copricapi blu. **I due sistemi di trascrizione descrivono il medesimo manoscritto: concordanza non equivale a replica indipendente.**

## Risultati

| Misura | ZL3b osservata | ZL3b media nulla | p unilaterale aumento | IT2a osservata | IT2a media nulla | p unilaterale aumento |
|---|---:|---:|---:|---:|---:|---:|
| Coppie a edit 1 | 0.000 | 0.075 | 1.000 | 0.067 | 0.094 | 0.761 |
| Coppie con prefisso 2 uguale | 0.200 | 0.383 | 0.938 | 0.133 | 0.386 | 1.000 |
| Coppie con suffisso 2 uguale | 0.000 | 0.067 | 1.000 | 0.000 | 0.058 | 1.000 |
| Lunghezza media | 5.600 | 5.000 | 0.151 | 5.000 | 4.684 | 0.279 |

Le combinazioni esatte sono 4.368 per ZL3b (5 etichette blu leggibili su 16 etichette leggibili dell'anello) e 27.132 per IT2a (6 su 19). Nella prima trascrizione l'etichetta k13 ha trascrizione incerta e resta esclusa dalla metrica sulle parole complete. Il controllo di traslazione ciclica **non** rivela un arricchimento di coppie edit1/prefisso/suffisso delle etichette blu. Per la somiglianza dei prefissi, l'effetto osservato è semmai minore del caso casuale, con p unilaterale inferiore IT2a=0.0348, ma questo dato è esplorativo, multiple-testing e non concorda quantitativamente con ZL3b; nessun significato è giustificato.

Controllo secondario, soltanto descrittivo: numero dei punti stellari del repertorio contro lunghezza della prima parola su 26 etichette ZL3b leggibili. Correlazione r = -0.021; p ≈ 0.945 per 9.999 permutazioni del numero di punti all'interno di ciascun anello. Nessuna evidenza di relazione.

## Conclusione

**Il segnale previsto non c'è.** Non risulta che le figure con copricapi dipinti di blu abbiano etichette morfologicamente più somiglianti nel folio dei Pesci. Il campione è piccolo, non indipendente e le etichette visive restano da validare. Un test forte richiederebbe annotatori indipendenti *senza etichette*, consenso sull'assegnazione figura↔etichetta e folii riservati prima della scelta delle ipotesi. L'esperimento non prova che non esista una relazione semantica e non propone alcuna traduzione.

## Riproduzione

Da questa cartella: `python pilot.py` e `python it2a_check.py`. Il file `input_labels.csv` è una copia immutata di quello del precedente dossier FIRST-WORD-08. I risultati sono `results.json`, `it2a_results.json` e `figure_labels_pisces.csv`. La carta delle stelle è trascrizione manuale della fonte secondaria e non un nuovo dataset indipendente.
