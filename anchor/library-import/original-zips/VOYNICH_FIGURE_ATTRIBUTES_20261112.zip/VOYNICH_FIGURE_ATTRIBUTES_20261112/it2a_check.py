import csv, itertools, json
from pathlib import Path
from statistics import mean
p=Path(__file__).parent
source=p/'input_labels.csv'
labels=[r for r in csv.DictReader(open(source)) if r['transcription']=='IT2a' and r['folio']=='f70v2']
assert len(labels)==30 and labels[-1]['raw']=='otylal'
blue={7,9,10,11,12,13}
# Exact label positions k=1..29 and source-locus alignment, as for ZL3b.
selected=[{'k':i,'first':r['first'],'valid':r['sure']=='True' and bool(r['first'])} for i,r in enumerate(labels[:19],1)]
valid=[r for r in selected if r['valid']]
obs=tuple(i for i,r in enumerate(valid) if r['k'] in blue)

def lev(a,b):
 if a==b:return 0
 if abs(len(a)-len(b))>1:return 2
 if len(a)==len(b):return sum(u!=v for u,v in zip(a,b))
 if len(a)>len(b):a,b=b,a
 i=j=skips=0
 while i<len(a):
  if a[i]==b[j]:i+=1;j+=1
  else:j+=1;skips+=1
  if skips>1:return 2
 return 1

def calc(inds,metric):
 z=[valid[i]['first'] for i in inds];pairs=list(itertools.combinations(z,2))
 if metric=='edit1':return sum(lev(a,b)==1 for a,b in pairs)/len(pairs)
 if metric=='prefix2':return sum(a[:2]==b[:2] for a,b in pairs)/len(pairs)
 if metric=='suffix2':return sum(a[-2:]==b[-2:] for a,b in pairs)/len(pairs)
 if metric=='length':return mean(map(len,z))

result={'transcription':'IT2a','outer_labels':19,'valid':len(valid),'blue':len(obs),'labels_unmatched':labels[-1]['raw'],'exploratory':True,'tests':{}}
for metric in ['edit1','prefix2','suffix2','length']:
 o=calc(obs,metric); values=[calc(indices,metric) for indices in itertools.combinations(range(len(valid)),len(obs))]
 shifts=[]
 for j in range(19):
  ids=[i for i,r in enumerate(valid) if r['k'] in {((b+j-1)%19)+1 for b in blue}]
  if len(ids)>=2:shifts.append(calc(ids,metric))
 result['tests'][metric]={'observed':o,'null_mean':mean(values),'p_upper':sum(v>=o-1e-12 for v in values)/len(values),'p_lower':sum(v<=o+1e-12 for v in values)/len(values),'n_assignments':len(values),'rotation_p_upper':sum(v>=o-1e-12 for v in shifts)/len(shifts)}
(p/'it2a_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
