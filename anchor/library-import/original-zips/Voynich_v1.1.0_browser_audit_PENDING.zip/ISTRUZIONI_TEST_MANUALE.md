# Test browser v1.1.0 candidata

Aprire `site/index.html` dal pacchetto candidato in un browser autorizzato.

1. Controllare il messaggio di verifica SHA-256 dati base.
2. Aprire ANCHOR e controllare `Hash voce ANCHOR verificato nel browser ✔`.
3. Aprire Matrice artefatti, applicare insieme stato, versione e testo, verificare righe coerenti e azzeramento.
4. Aprire Decisioni e note, salvare una nota temporanea e usare Esporta JSON; verificare che il file scaricato sia JSON valido e contenga la nota.
5. Ricaricare la pagina e verificare che la nota rimanga; eliminarla dopo il test.

Registrare browser/versione, URL o file locale, ora, risultati, evidenze e revisore. Non modificare la release originale.
