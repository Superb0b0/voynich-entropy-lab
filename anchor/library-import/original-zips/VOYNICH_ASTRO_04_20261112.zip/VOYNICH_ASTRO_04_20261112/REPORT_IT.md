# ASTRO-04 — le scritte circolari lunari riconoscono la Luna su un altro fascicolo?
12 novembre 2026 · Analisi esplorativa, non preregistrata · corpus ZL3b in sola lettura · RC1.4.2 invariato.

## Domanda
Un'indicazione semantica della Luna nelle scritte circolari di f68r1 e f68r3 è sufficientemente stabile da avvicinarle alle scritte della Luna in f86v4 più di quelle del Sole in f85r2, distante e in altro fascicolo?

## Etichette figurative prima dell'analisi del testo
Le identificazioni di Sole/Luna sono descritte nella documentazione iconografica: f68r1.37 circonda la Luna, f68r3.22 è il piccolo anello intorno alla Luna, f85r2 ha il Sole al centro e f86v4 la Luna. f85r2 comprende due cerchi di testo ZL3b, f86v4 quattro. La pagina f68r2 non è stata usata perché senza un'identificazione incontrovertibile di quale dei due cerchi ZL3b sia Sole e quale Luna. Il corpus di f85/86 è attribuito alla lingua B e mano 2; f68 alla mano 4. Questi fattori rendono impossibile una conclusione causale semantica con il campione presente.

## Dati e test
Source SHA-256: `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc`.
Totale parole estratte dalle quattro unità: f68r1.37 6, f68r3.22 10, f85r2 due anelli 48, f86v4 quattro anelli 143. Normalizzazione EVA di base con rimozione delle incertezze in parentesi e annotazioni di codice, **non una trascrizione diplomatica pulita**. Coseno TF-IDF dei bigrammi/trigrammi di caratteri; successiva sensibilità a pari quantità con 1000 campionamenti senza reinserimento di 10 parole da ogni complesso lontano. I campionamenti sono ripetizioni tecniche, non nuove pagine indipendenti e non danno un p-value.

## Risultati
- Bigrammi sulle unità complete: f68r1(luna) → f85r2(sole) 0,3743 e → f86v4(luna) 0,3813; f68r3(luna) → f85r2(sole) 0,4543 e → f86v4(luna) 0,4964. Vantaggio lunare piccolo e lunghezze altamente sbilanciate.
- I due pannelli lontani fra loro (Sole f85r2 e Luna f86v4) hanno somiglianza 0,8433, **maggiore della somiglianza fra i due pannelli lunari vicini f68r1/f68r3, 0,2801**. La grafia e la sezione fisica sono spiegazioni alternative plausibili.
- Con 10 parole campionate da ciascuna unità lontana, differenza media **Luna lontana meno Sole lontano**, bigrammi: −0,0180 (per f68r1), −0,0004 (per f68r3). Trigrammi: −0,0021, +0,0027. I segni non sono stabili.
- La quota di campionamenti in cui la Luna lontana prevale è 39,1% e 48,4% per i bigrammi; 46,6% e 51,4% per i trigrammi. Campionamenti correlati e post hoc: non interpretarli come frequenze inferenziali.

## Verdetto
**NESSUNA EVIDENZA LESSICALE TRASFERIBILE IN QUESTO TEST.** Non viene identificato un segno o una parola per «Luna»; non si può neppure escludere una codifica astronomica, perché le unità confrontate possono essere testi descrittivi diversi, con lunghezze diverse e provenienti da due mani/registri differenti. La coppia Sole/Luna di f85r2/f86v4 è anche fisicamente vicina, e perciò non è una replica indipendente del medesimo motivo.

## Azione scientificamente giustificata
Non inventare un nuovo algoritmo sulle stesse quattro stringhe. Servirebbe una tabella iconografica indipendente con molteplici etichette della **stessa funzione materiale** attorno a Sole/Luna in fascicoli e mani diversi; oppure individuare una fonte esterna con nessi numerici/astronomici verificabili. Tenere distinto il ramo ASTRO dal gate RC1.4.2 congelato.

## Riproducibilità
Da questa cartella `python run.py` richiede Python, NumPy e scikit-learn. I valori sono in `results.json`. Nessuna fonte esterna è riscritta. Fonti iconografiche: René Zandbergen, Quire 9, https://voynich.nu/q09/index.html ; Quire 14, https://voynich.nu/q14/index.html.
