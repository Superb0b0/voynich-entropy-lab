import re, json, hashlib, collections, itertools
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
src=Path(__file__).with_name('ZL3b-n.txt')
rows={}
for line in src.read_text(encoding='utf-8-sig').splitlines():
 m=re.match(r'^<(f\d+[rv]\d*\.\d+),([@+&=*][A-Za-z0-9]+)>\s+(.*)$',line)
 if m:
  key,kind,body=m.groups()
  if 'Cc' not in kind:continue
  body=re.sub(r'<![^>]*>',' ',body)
  body=re.sub(r'\{[^}]+\}','',body)
  body=re.sub(r'\[([^]:]+):[^]]+\]',r'\1',body)
  body=re.sub(r'@\d+;','',body)
  ws=re.findall(r'[a-z]+',body)
  rows[key]=ws
# high-confidence only: inner moon circle at f68r3.22; f68r1 circle at moon; distant sun and moon with one/four bands
keys=['f68r1.37','f68r3.22','f85r2.1','f85r2.24','f86v4.1','f86v4.2','f86v4.3','f86v4.4']
assert all(k in rows for k in keys)
# concatenate all rings (sun f85r2 has two, moon f86v4 has four)
groups={'near_moon_f68r1':rows['f68r1.37'], 'near_moon_f68r3':rows['f68r3.22'], 'far_sun_f85r2':rows['f85r2.1']+rows['f85r2.24'], 'far_moon_f86v4':sum((rows[k] for k in ['f86v4.1','f86v4.2','f86v4.3','f86v4.4']),[])}
# duration/genre differences: compare full + first 30 words standardized
result={'source_sha':hashlib.sha256(src.read_bytes()).hexdigest(),'groups':{k:{'n':len(w),'first':w[:8]} for k,w in groups.items()}}
for cap in [None,30]:
 texts=[' '.join(v[:cap]) for v in groups.values()]
 rr={}
 for n in [2,3]:
  model=TfidfVectorizer(analyzer='char',ngram_range=(n,n),lowercase=False)
  mat=cosine_similarity(model.fit_transform(texts))
  rr[str(n)]={k:{kk:round(float(mat[i,j]),6) for j,kk in enumerate(groups)} for i,k in enumerate(groups)}
 result['full' if cap is None else 'first30']=rr
# no significance because 2 near-moon samples same quire/hand, 2 distant pages hand2/Language B
Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
print(json.dumps(result,indent=2,ensure_ascii=False))
# explicit equal-token-count sensitivity: 1000 random 10-token draws of each distant page
import numpy as np
rng=np.random.default_rng(4042026)
subsamples={}
for n in (2,3):
 fulltext=[' '.join(v) for v in groups.values()]
 vec=TfidfVectorizer(analyzer='char',ngram_range=(n,n)).fit(fulltext)
 near=vec.transform([' '.join(groups['near_moon_f68r1']),' '.join(groups['near_moon_f68r3'])])
 vals=[]
 for i in range(1000):
  # same cap 10 without replacement; distant objects are unequal length so standardized
  s=[]
  for k in ['far_sun_f85r2','far_moon_f86v4']:
   words=groups[k]; ids=sorted(rng.choice(len(words),10,replace=False))
   s.append(' '.join(words[j] for j in ids))
  M=cosine_similarity(near,vec.transform(s))
  vals.append([float(M[0,1]-M[0,0]),float(M[1,1]-M[1,0])])
 a=np.array(vals)
 subsamples[str(n)]={'mean_moon_minus_sun':a.mean(axis=0).tolist(),'proportion_moon_greater':(a>0).mean(axis=0).tolist(),'quantile05_95':np.quantile(a,[.05,.95],axis=0).tolist()}
result['matched_10_token_distant_draws']=subsamples
Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
print('MATCHED',json.dumps(subsamples))
