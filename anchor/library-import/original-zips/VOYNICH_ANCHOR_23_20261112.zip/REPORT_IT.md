# VOYNICH ANCHOR-23 | Test degli invarianti di una sostituzione biunivoca

12 novembre 2026. Ramo esplorativo indipendente, senza modificare RC1.4.2.

## Risultato essenziale

Una sostituzione **biunivoca carattere-per-carattere** preserva esattamente lunghezza e confini delle parole, caratteri ripetuti, identità della prima/ultima lettera e frequenza delle parole. È una necessità matematica, non una misura statistica. Sono escluse da questa prova sostituzioni omofoniche, cifrari verbosi, abbreviazioni, spazi artificiali, trasposizioni e molti sistemi storici realistici.

Controllo di confronto: brano latino medico autentico Borg 0010r, 59 parole alfabetiche di almeno due lettere, con le espansioni tra parentesi quadre rimosse. È un brano breve con spazi editoriali, NON un campione rappresentativo del latino quattrocentesco.

| Misura | Borg latino | ZL3b | IT2a |
|---|---:|---:|---:|
| mean_token_length | 4.7627 | 5.0150 | 5.1051 |
| short_le_3 | 0.4068 | 0.1823 | 0.1583 |
| long_ge_8 | 0.1356 | 0.0643 | 0.0653 |
| within_token_doubled | 0.0678 | 0.2552 | 0.2579 |
| start_equals_end | 0.0339 | 0.0301 | 0.0323 |

## Sensibilità a campioni delle stesse dimensioni

Sono state campionate 5.000 finestre di 59 parole consecutive per trascrizione (seed fisso). Le percentuali seguenti rappresentano la quota di finestre Voynich con una misura uguale o superiore a quella del piccolo campione latino; non sono p-value di un modello storico con campionamento comparabile.

| Misura | ZL3b (quota finestre >= Borg) | IT2a |
|---|---:|---:|
| mean_token_length | 0.733 | 0.8116 |
| short_le_3 | 0.0032 | 0.0012 |
| long_ge_8 | 0.1002 | 0.1036 |
| within_token_doubled | 0.9964 | 0.9958 |
| start_equals_end | 0.4996 | 0.5148 |

## Decisione

Le differenze misurate non possono essere corrette scegliendo una nuova chiave **dentro il modello biunivoco**. Non autorizzano a scartare in assoluto quel modello per Voynich: manca la prova che gli spazi EVA siano confini delle parole originali, e un solo breve testo latino non descrive la varietà di testi latini, italiani e tecnico-medici.

Il prossimo investimento non è indovinare una chiave monoalfabetica, ma costruire un test a testo nascosto su un cifrario **verboso/omofonico reversibile**, dove il decodificatore deve recuperare contenuti nuovi senza usare la struttura Voynich per scegliere regole dopo il fatto.

## Provenienza

Borg plain SHA-256 `0d46338eb517b58c70169b1a12653838cdfce1394645bc24f6f52820be27da13`
ZL3b SHA-256 `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc`
IT2a SHA-256 `7f27a8b0feed8f6de0a99900df6bf912dd1d295c38e5f830bac8b41c3f536fb5`

Estrazione indipendente dei soli loci +P con caratteri ASCII minuscoli e lunghezza >= 2; non sostituisce il parser canonico RC1.4.
