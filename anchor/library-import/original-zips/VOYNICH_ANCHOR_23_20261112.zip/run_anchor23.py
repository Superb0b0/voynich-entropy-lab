from pathlib import Path
import re,hashlib,random,math,json,zipfile,collections,statistics
base=Path('/mnt/data/VOYNICH_ANCHOR_23_20261112');base.mkdir(exist_ok=True)
zlpath=Path('/mnt/data/files/ZL3b-n.txt');itpath=Path('/mnt/data/files/IT2a-n.txt');borgpath=Path('/mnt/data/VOYNICH_ANCHOR_12_20261112/inputs/borg_0010r_plaintext_extracted.txt')
def extract_voynich(p):
 out=[]
 for line in p.read_text().splitlines():
  if not re.match(r'^<[^>]+,\+P\d+>',line): continue
  s=line.split('>',1)[1].split('<!',1)[0]
  s=re.sub(r'\[[^\]]*\]',' ',s)
  s=re.sub(r'<[^>]*>',' ',s)
  out.extend(re.findall(r'(?<![a-z])[a-z]{2,}(?![a-z])',s))
 return out
# For Borg, editorial bracketed segments excluded. Treat whitespace as written in benchmark's normalized Latin.
p=re.findall(r'\b[a-z]+\b',re.sub(r'\[[^]]*\]',' ',borgpath.read_text().lower()))
p=[x for x in p if len(x)>=2]
N=len(p)
def feature(words):
 w=words
 return {'count':len(w),'mean_token_length':sum(map(len,w))/len(w),'short_le_3':sum(len(x)<=3 for x in w)/len(w), 'long_ge_8':sum(len(x)>=8 for x in w)/len(w),'within_token_doubled':sum(any(a==b for a,b in zip(x,x[1:])) for x in w)/len(w),'start_equals_end':sum(x[0]==x[-1] for x in w)/len(w)}
keys=list(feature(p).keys())[1:]
result={'design':'A bijective single-character substitution preserves word boundaries, token lengths, within-token equality, and word identities. Compare only these necessary conditions.','limits':'Borg is a 58ish-word 15th century Latin medical excerpt with editorial whitespace and uncertain transcription; Voynich EVA tokenization may not correspond to plaintext word boundaries. Descriptive comparison, not a formal rejection of historical monoalphabetic ciphers.','reference':{'name':'Borg 0010r Latin benchmark excerpt (without bracketed headings or one-character tokens)', 'path':str(borgpath),'sha256':hashlib.sha256(borgpath.read_bytes()).hexdigest(),'features':feature(p)},'corpora':{},'random_seed':20261112,'windows_per_corpus':5000}
random.seed(20261112)
for label,path in [('ZL3b',zlpath),('IT2a',itpath)]:
 t=extract_voynich(path)
 feat=feature(t)
 windows=[feature(t[i:i+N]) for i in (random.randrange(0,len(t)-N+1) for _ in range(5000))]
 comparisons={}
 for k in keys:
  arr=[w[k] for w in windows]; val=result['reference']['features'][k]
  comparisons[k]={'reference':round(val,5),'voynich_corpus':round(feat[k],5),'voynich_window_p05':round(sorted(arr)[int(.05*len(arr))],5),'voynich_window_p95':round(sorted(arr)[int(.95*len(arr))],5),'fraction_voynich_windows_at_least_as_high':round(sum(x>=val for x in arr)/len(arr),5)}
 result['corpora'][label]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'eligible_tokens':len(t),'comparisons':comparisons}
(base/'result.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
report=['# VOYNICH ANCHOR-23 | Test degli invarianti di una sostituzione biunivoca','', '12 novembre 2026. Ramo esplorativo indipendente, senza modificare RC1.4.2.','', '## Risultato essenziale','', 'Una sostituzione **biunivoca carattere-per-carattere** preserva esattamente lunghezza e confini delle parole, caratteri ripetuti, identità della prima/ultima lettera e frequenza delle parole. È una necessità matematica, non una misura statistica. Sono escluse da questa prova sostituzioni omofoniche, cifrari verbosi, abbreviazioni, spazi artificiali, trasposizioni e molti sistemi storici realistici.','',f'Controllo di confronto: brano latino medico autentico Borg 0010r, {N} parole alfabetiche di almeno due lettere, con le espansioni tra parentesi quadre rimosse. È un brano breve con spazi editoriali, NON un campione rappresentativo del latino quattrocentesco.','', '| Misura | Borg latino | ZL3b | IT2a |','|---|---:|---:|---:|']
for k in keys:
 row=[result['reference']['features'][k],result['corpora']['ZL3b']['comparisons'][k]['voynich_corpus'],result['corpora']['IT2a']['comparisons'][k]['voynich_corpus']]
 report.append('| '+k+' | '+' | '.join(f'{v:.4f}' for v in row)+' |')
report+=['','## Sensibilità a campioni delle stesse dimensioni','',f'Sono state campionate 5.000 finestre di {N} parole consecutive per trascrizione (seed fisso). Le percentuali seguenti rappresentano la quota di finestre Voynich con una misura uguale o superiore a quella del piccolo campione latino; non sono p-value di un modello storico con campionamento comparabile.','', '| Misura | ZL3b (quota finestre >= Borg) | IT2a |','|---|---:|---:|']
for k in keys: report.append('| '+k+' | '+ ' | '.join(str(result['corpora'][n]['comparisons'][k]['fraction_voynich_windows_at_least_as_high']) for n in ['ZL3b','IT2a'])+' |')
report+=['','## Decisione','', 'Le differenze misurate non possono essere corrette scegliendo una nuova chiave **dentro il modello biunivoco**. Non autorizzano a scartare in assoluto quel modello per Voynich: manca la prova che gli spazi EVA siano confini delle parole originali, e un solo breve testo latino non descrive la varietà di testi latini, italiani e tecnico-medici.','', 'Il prossimo investimento non è indovinare una chiave monoalfabetica, ma costruire un test a testo nascosto su un cifrario **verboso/omofonico reversibile**, dove il decodificatore deve recuperare contenuti nuovi senza usare la struttura Voynich per scegliere regole dopo il fatto.','', '## Provenienza','',f"Borg plain SHA-256 `{result['reference']['sha256']}`",f"ZL3b SHA-256 `{result['corpora']['ZL3b']['sha256']}`",f"IT2a SHA-256 `{result['corpora']['IT2a']['sha256']}`",'','Estrazione indipendente dei soli loci +P con caratteri ASCII minuscoli e lunghezza >= 2; non sostituisce il parser canonico RC1.4.']
(base/'REPORT_IT.md').write_text('\n'.join(report)+'\n')
# Copy reproducible code, rewriting output directory in new cwd not needed as paths mounted
(base/'run_anchor23.py').write_text(Path(__file__).read_text())
with zipfile.ZipFile('/mnt/data/VOYNICH_ANCHOR_23_20261112.zip','w',zipfile.ZIP_DEFLATED) as z:
 for file in sorted(base.iterdir()):z.write(file,arcname=file.name)
print(json.dumps({'N':N,'reference':result['reference']['features'],'zl':result['corpora']['ZL3b']['comparisons'],'it':result['corpora']['IT2a']['comparisons']},indent=2))
