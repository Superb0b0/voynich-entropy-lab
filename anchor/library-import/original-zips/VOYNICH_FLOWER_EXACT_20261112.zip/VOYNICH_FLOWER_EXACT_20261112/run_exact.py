#!/usr/bin/env python3
"""Exhaustive conditional randomization audit of exploratory flower pilot.
Only relabel existing data; no textual/visual sources modified.
"""
from pathlib import Path
from itertools import combinations,product
from collections import defaultdict
from math import comb
import csv,hashlib,json
import numpy as np
ROOT=Path(__file__).resolve().parent
OUT=ROOT
FIELDS=['prefix_qo','prefix_ch','prefix_sh','prefix_ol','suffix_dy','suffix_y','mean_length','type_token_ratio']
rows=list(csv.DictReader((ROOT/'labels_and_features.csv').open()))
allres=[];detail=[]
for case,excluded in [('original',set()),('exclude_f25v',{'f25v'}),('exclude_f25v_f7r',{'f25v','f7r'})]:
    r=[x for x in rows if x['folio'] not in excluded]
    y=np.array([int(x['label']) for x in r]);M=np.array([[float(x[k]) for k in FIELDS] for x in r]);sd=M.std(axis=0);sd[sd<1e-10]=1
    groups=defaultdict(list)
    for i,x in enumerate(r):groups[(x['quire'],x['currier'])].append(i)
    movable=[]
    for key,ids in sorted(groups.items()):
        k=int(y[ids].sum()); n=len(ids)
        if 0<k<n:movable.append((key,ids,k))
    total=np.prod([comb(len(idx),k) for key,idx,k in movable]).item()
    sets=[[tuple(c) for c in combinations(ids,k)] for _,ids,k in movable]
    obs=(M[y==1].mean(0)-M[y==0].mean(0))/sd
    exceed=np.zeros(len(FIELDS),int); exceed_adj=np.zeros(len(FIELDS),int); nulls=[]
    for config in product(*sets):
        a=y.copy()
        for (_,ids,_),positives in zip(movable,config):
            a[ids]=0;a[list(positives)]=1
        d=(M[a==1].mean(0)-M[a==0].mean(0))/sd
        exceed+=(abs(d)>=abs(obs)-1e-12)
        exceed_adj+=(abs(d).max()>=abs(obs)-1e-12)
        nulls.append(d)
    assert len(nulls)==total
    nulls=np.array(nulls)
    for j,f in enumerate(FIELDS):
        detail.append({'case':case,'feature':f,'positive_mean':float(M[y==1,j].mean()),'negative_mean':float(M[y==0,j].mean()),'standardized_effect':float(obs[j]),'exact_p':float(exceed[j]/total),'exact_maxT_p':float(exceed_adj[j]/total),'number_extreme':int(exceed[j]),'null_space':total,'null_median':float(np.median(nulls[:,j]))})
    allres.append({'case':case,'excluded':sorted(excluded),'n':len(r),'positive':int(y.sum()),'negative':int((1-y).sum()),'effective_strata':[{'quire':key[0],'currier':key[1],'n':len(ids),'n_negative':len(ids)-k,'combinations':comb(len(ids),k)} for key,ids,k in movable],'exact_randomizations':int(total),'log2_distinct_randomizations':float(np.log2(total)),'fixed_labels':int(len(r)-sum(len(ids) for _,ids,k in movable)),'best_nominal_p':min(float(exceed[j]/total) for j in range(len(FIELDS))),'best_adjusted_p':min(float(exceed_adj[j]/total) for j in range(len(FIELDS)))})
with (OUT/'exact_pvalues.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(detail[0]));w.writeheader();w.writerows(detail)
(OUT/'exact_summary.json').write_text(json.dumps({'status':'EXACT_CONDITIONAL_PILOT_NOT_INDEPENDENT_VALIDATION','source':'VOYNICH_FLOWER_PILOT_20261112/labels_and_features.csv','input_sha256':hashlib.sha256((ROOT/'labels_and_features.csv').read_bytes()).hexdigest(),'scenarios':allres},indent=2,ensure_ascii=False))
for case in allres:
 print(case)
for x in detail:
 if x['feature'] in ['suffix_y','suffix_dy']:print(x['case'],x['feature'],'p_exact',x['exact_p'],'p_maxT',x['exact_maxT_p'])
