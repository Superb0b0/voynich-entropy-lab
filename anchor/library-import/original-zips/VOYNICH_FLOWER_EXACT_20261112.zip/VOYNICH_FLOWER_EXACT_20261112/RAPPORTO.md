# Voynich | EXP-FLOWER-EXACT-01

**12 novembre 2026 | Audit statistico esatto di un campione esplorativo già studiato.** Nessuna decifrazione. Nessuna nuova annotazione umana o lettura delle immagini è stata certificata in questa fase. La pipeline RC1.4.2 rimane congelata.

## Ipotesi controllata

Il campione botanico precedente conteneva 44 pagine descritte con fiori e 4 descritte esplicitamente senza fiori, su 48 pagine complessive. Otto proprietà testuali erano state definite prima del test: prefissi `qo`, `ch`, `sh`, `ol`; suffissi `dy`, `y`; lunghezza media; rapporto tipi/token.

L'esperimento precedente aveva estratto 19.999 permutazioni **con reinserimento** delle etichette all'interno degli strati quire × Currier. Questo audit esegue l'**enumerazione esatta** di tutte le configurazioni distinte, inclusa quella osservata, e calcola i valori p bilaterali e i p max-statistici simultanei sulle otto feature. Le medie sono per folio e la scala è la deviazione standard dell'intero campione, come nel programma precedente.

## Spazio nullo effettivo

| Campione | Strati con variazione | Configurazioni distinte | Folii bloccati nel campione |
|---|---|---:|---:|
| 44 positivi, 4 negativi | quire A/Currier A: C(8,2)=28; D/A: C(8,1)=8; F/A: C(6,1)=6 | **1.344** | **26 su 48** |
| Senza f25v | A/A: C(8,2)=28; F/A: C(6,1)=6 | **168** | **33 su 47** |
| Senza f25v e f7r | A/A: C(7,2)=21; F/A: C(6,1)=6 | **126** | **33 su 46** |

La maggioranza dei folii non può cambiare etichetta con questi vincoli. Un aumento del numero di permutazioni Monte Carlo non aggiungerebbe configurazioni indipendenti.

## Risultati esatti

| Campione | p nominale della terminazione `y` | Miglior p corretto maxT fra le 8 feature |
|---|---:|---:|
| Tutti i 48 folii | **0,016369** | **0,417411** |
| Escluso f25v, incerto | **0,059524** | **0,720238** |
| Esclusi anche f7r, controverso | **0,071429** | **0,595238** |

La feature nominalmente migliore non è statisticamente convincente dopo la correzione per confronti multipli. Il risultato non può essere interpretato come prova che `y` significhi «fiore».

## Quali problemi restano

1. Le classi delle immagini derivano da una compilazione secondaria; **non** sono una revisione in cieco e indipendente.
2. La categoria «senza fiori» ha solo 3–4 attestazioni, con casi incerti e controversi.
3. Nessun test è cieco: i folii e le ipotesi sono stati esaminati ripetutamente.
4. Nel pilot sono stati fissati gli strati ma non esistono equivalenti scambiabili per gran parte dei folii.
5. Le sole associazioni tra feature della trascrizione e descrizioni botaniche non consentono di assegnare un significato alle parole.

## Protocollo per un successivo campione nuovo

- Selezionare prima le immagini da annotare, separatamente dal testo e dai punteggi linguistici.
- Due valutatori indipendenti, ciechi a `y` e alle statistiche, classificano ogni folio in `VISIBLE_FLOWER`, `VERIFIED_ABSENT`, `UNCERTAIN` o `NOT_REVIEWABLE`. L'assenza richiede che l'immagine sia sufficientemente visibile e completa da escludere il tratto definito; in caso contrario `UNCERTAIN`.
- Dichiarare *a priori* quali parti visive si intendano per «fiore» e come trattare fiori stilizzati, boccioli e diagrammi. Risolvere le divergenze senza vedere i testi.
- Acquisire nuovi folii per quire/Currier con **entrambe le classi presenti** e, soprattutto, un numero ragionevole di negativi; la griglia iniziale non può da sola garantire tale disponibilità.
- Bloccare in anticipo una misura primaria (per esempio una sola famiglia grafica) e un controllo negativo; gli otto indici storici restano esplorativi.
- Sottoporre le etichette con discordanze a giudizio di un terzo annotatore. Misurare accordo inter-annotatore. Non imputare assenze dal silenzio delle fonti.
- Nessuna analisi di coupling RC1.4.2 o promozione a `PASS` prima che i rilievi di provenienza e i vincoli del gate siano risolti.

`human_review_blinded.csv` non contiene le etichette storiche: è intenzionale, per evitare la contaminazione. `source_disputes.csv` è un registro *separato* e va consultato dopo la prima revisione in cieco.

## File e riproduzione

- `run_exact.py`: enumera lo spazio nullo completo e rigenera `exact_pvalues.csv`, `exact_summary.json`.
- `labels_and_features.csv`: copia con hash del file del pilot originario, non una nuova revisione.
- `human_review_blinded.csv`: modulo da completare **soltanto** dopo effettiva visione delle immagini.
- `source_disputes.csv`: problematiche delle etichette esistenti, separate dalla griglia cieca.
- `build_review_sheet.py`: rigenera le due griglie.

Dipendenza: Python 3.9+ e NumPy. Esecuzione: `python run_exact.py && python build_review_sheet.py`.

**Decisione: `FAIL_CLOSED_NO_SEMANTIC_MATCH`**. Il test esatto conferma il risultato negativo, quantifica perché i controlli sono deboli e prepara un campione per una successiva verifica iconografica reale.
