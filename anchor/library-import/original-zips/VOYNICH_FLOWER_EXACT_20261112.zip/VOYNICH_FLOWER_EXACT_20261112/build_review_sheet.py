#!/usr/bin/env python3
"""Prepare blinded human-review sheet without treating archival labels as verified."""
from pathlib import Path
import csv,collections
ROOT=Path(__file__).resolve().parent
rows=list(csv.DictReader((ROOT/'labels_and_features.csv').open()))
groups=collections.defaultdict(list)
for r in rows:groups[(r['quire'],r['currier'])].append(r)
review=[]
for r in rows:
 g=groups[(r['quire'],r['currier'])]
 v=any(x['label']=='0' for x in g) and any(x['label']=='1' for x in g)
 out={'folio':r['folio'],'quire':r['quire'],'currier':r['currier'],'review_priority':'PRIMARY_EXCHANGEABLE' if v else 'SECONDARY_FIXED_IN_LEGACY_TEST', 'sample_scope':'botanical_pilot','reviewer_1':'','reviewer_2':'','reviewer_1_confidence':'','reviewer_2_confidence':'','adjudication':'','source_image_checked':'','image_uri_or_canvas_id':'','blind_to_text':'YES_REQUIRED','notes':''}
 review.append(out)
with (ROOT/'human_review_blinded.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(review[0]));w.writeheader();w.writerows(review)
prior=[]
for r in rows:
 if r['label']=='0':
  prior.append({'folio':r['folio'],'legacy_class':'NEGATIVE_REQUIRES_VERIFICATION','source_conflict':'VISUAL_UNCERTAINTY' if r['folio']=='f25v' else 'NO_INDEPENDENT_REVIEW', 'quire':r['quire'],'currier':r['currier']})
 elif r['folio']=='f7r':prior.append({'folio':'f7r','legacy_class':'POSITIVE_REQUIRES_ADJUDICATION','source_conflict':'CONTRADICTORY_SOURCE_DESCRIPTION','quire':r['quire'],'currier':r['currier']})
with (ROOT/'source_disputes.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(prior[0]));w.writeheader();w.writerows(prior)
print('review rows:',len(review),'primary:',sum(x['review_priority']=='PRIMARY_EXCHANGEABLE' for x in review),'disputes:',len(prior))
