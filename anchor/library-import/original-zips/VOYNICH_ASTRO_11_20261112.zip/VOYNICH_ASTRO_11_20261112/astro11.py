#!/usr/bin/env python3
"""ASTRO-11: tests on radial labels, no semantic key; read-only input files."""
from pathlib import Path
from collections import Counter,defaultdict
from scipy.stats import fisher_exact
import re,json,hashlib,random,statistics
HERE=Path(__file__).resolve().parent
SEED=20261112

def parse(src):
    groups=defaultdict(list)
    for line in src.read_text(encoding='utf-8').splitlines():
        m=re.match(r'^<(f\d+[rv]\d?)\.(\d+),[@+&*]R([io])>\s*(.*)',line)
        if not m:continue
        fol,num,side,txt=m.groups()
        txt=re.sub(r'<!.*?>','',txt).strip()
        units=[x for x in re.split(r'[.,]',txt) if x]
        groups[(fol,side)].append(dict(locus=int(num),text=txt,unit_count=len(units),first=txt[:1]))
    for group in groups.values():group.sort(key=lambda x:x['locus'])
    return groups

def main():
    data={}
    for name in ['ZL3b-n.txt','IT2a-n.txt']:
        path=HERE/'inputs'/name; groups=parse(path)
        v=groups[('f69v','i')];r=groups[('f69r','o')]
        assert (len(v),len(r))==(28,22)
        repeated={k:n for k,n in Counter(x['text'] for x in v).items() if n>1}
        assert repeated=={'okeod':3},repeated
        o_v=sum(x['first']=='o' for x in v);o_r=sum(x['first']=='o' for x in r)
        control_singles=[x for k,g in groups.items() if k!=('f69v','i') and len(g)>=4 for x in g if x['unit_count']==1]
        v_singles=[x for x in v if x['unit_count']==1]
        o_vs=sum(x['first']=='o' for x in v_singles)
        o_cs=sum(x['first']=='o' for x in control_singles)
        p_r=float(fisher_exact([[o_v,28-o_v],[o_r,22-o_r]],alternative='greater').pvalue)
        p_s=float(fisher_exact([[o_vs,len(v_singles)-o_vs],[o_cs,len(control_singles)-o_cs]],alternative='greater').pvalue)
        initials=[x['first'] for x in v]
        observed=sum(initials[i]==initials[(i+1)%28] for i in range(28))
        rng=random.Random(SEED);null=[];shuf=initials.copy()
        for _ in range(20000):
            rng.shuffle(shuf)
            null.append(sum(shuf[i]==shuf[(i+1)%28] for i in range(28)))
        entry={
            'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'f69v':{'n':28,'first_glyphs':dict(Counter(initials)), 'exact_repeated_labels':repeated,
                    'repeated_loci':[x['locus'] for x in v if x['text']=='okeod'],
                    'singles':len(v_singles),'singles_start_o':o_vs,
                    'circular_neighbour_same_initial':observed,'circular_null_mean':round(statistics.mean(null),5),
                    'circular_permutation_one_sided_p':round((1+sum(t>=observed for t in null))/(len(null)+1),6)},
            'f69r':{'n':22,'start_o':o_r},
            'start_o_fisher_vs_f69r_one_sided_p':round(p_r,7),
            'same_length_control':{'other_radial_groups_with_min_4_loci':len([k for k,g in groups.items() if k!=('f69v','i') and len(g)>=4]),
                                   'single_locus_control_n':len(control_singles),'single_locus_control_start_o':o_cs,
                                   'fisher_one_sided_p':round(p_s,7)},
            'labels':[{'locus':x['locus'],'text':x['text']} for x in v]
        }
        data[name]=entry
    result={'experiment':'ASTRO-11','mode':'exploratory','scope':'f69v 28 radial texts, ZL3b and IT2a','transliterations':data,
            'interpretation':{'strong_simple_name_model':'challenged by triple exact occurrence of okeod in both transcriptions',
              'caveat':'Palaeographic re-reading could distinguish 1+ of these, and names might be abbreviated/homographic.',
              'start_o':'Descriptive difference vs recto is confounded by inscription length and diagram function.',
              'not_tested':'Direct mapping to 28 historical mansion names, reading direction and first station not independently anchored.'}}
    (HERE/'RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    for k,v in data.items():
        print(k,'repeats',v['f69v']['exact_repeated_labels'],'O',v['f69v']['first_glyphs'],'p_recto',v['start_o_fisher_vs_f69r_one_sided_p'],'p_single',v['same_length_control']['fisher_one_sided_p'],'adjacency_p',v['f69v']['circular_permutation_one_sided_p'])

if __name__=='__main__':main()
