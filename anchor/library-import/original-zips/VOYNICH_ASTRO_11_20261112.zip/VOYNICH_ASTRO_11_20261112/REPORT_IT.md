# ASTRO-11 | Le 28 iscrizioni di f69v e l'ipotesi delle dimore lunari

**12 novembre 2026 · esplorativo · nessuna decifrazione.** Pipeline RC1.4.2 intatta (`CLOSED_PENDING_VALIDATION`). Corpus ZL3b-n e IT2a-n letti in sola lettura.

## Ipotesi concorrenti

- **H1, etichette nominali distinte.** Le 28 iscrizioni radiali costituiscono una lista di 28 nomi identificabili, uno per ciascuna dimora lunare, con un codice che distingue nomi differenti.
- **H2, schema cosmografico numerico.** I 28 elementi sono disegnati secondo una tradizione lunare, ma le iscrizioni potrebbero contenere annotazioni diverse da nomi, abbreviazioni omografe, oppure gruppi di segni organizzati per una funzione ancora ignota.
- **H0, numero non diagnostico.** 28 elementi non bastano, da soli, a identificare un sistema astronomico. Esistono tradizioni di 27/28 dimore e altri sistemi con ventotto divisioni.

## Evidenze esterne, indipendenti dai nostri conteggi

René Zandbergen registra esplicitamente per f69v **28 iscrizioni radiali** e considera le 28 dimore lunari una **identificazione possibile**, non una soluzione: https://voynich.nu/q10/index.html.

La lista storica documentata da al-Farghani comprende 28 dimore distinte; la terza, al-Thurayya, designa le Pleiadi. Fonte e riferimenti bibliografici: https://www.islam.museum/en/concept/manazil-al-qamar/.

Una discussione paleografica del 21–22 febbraio 2025, precedente al nostro esperimento, rileva precisamente la tripla lettura `okeod` e propone letture alternative basate sui tratti originali. L'autore dichiara l'incertezza di alcune correzioni: https://voynich.ninja/thread-4501-post-64535.html. **L'accordo fra trascrizioni non è quindi un facsimile verificato né una prova assoluta che i tre segni originali coincidano.**

## Controlli eseguiti

Lo script allegato, con dipendenza Python `scipy`, rilegge entrambe le trascrizioni e identifica i 28 loci `@Ri` f69v. Rilegge inoltre i 22 loci `@Ro` f69r, un controllo interno fisicamente vicinissimo, e tutti i gruppi radiali di almeno quattro loci per il confronto fra iscrizioni singole.

1. **Ripetizioni esatte:** in *entrambe* le trascrizioni `okeod` ricorre tre volte fra le 28 iscrizioni, ai loci `f69v.14`, `f69v.18` e `f69v.27`. Ne risultano **26 stringhe distinte** su 28. Questo contraddice **H1 nella sua forma letterale** (28 nomi differenti con forme diverse) *se la lettura dei tre segni è corretta*. Non respinge H2: una grafia omografa o un'abbreviazione resta possibile.
2. **Iniziali `o-`:** 20/28 su f69v, contro 7/22 sul recto f69r, Fisher unilaterale **p = 0,0058225**. Confronto *post-hoc*, confuso dal tipo di iscrizione: f69v è prevalentemente monoverbale, f69r pluriverbale.
3. **Controllo sulla stessa lunghezza:** selezionando esclusivamente le iscrizioni radiali di una sola unità, per ZL3b troviamo 15/23 che iniziano con `o` in f69v e 10/22 in tutti gli altri undici gruppi radiali con almeno quattro iscrizioni, Fisher unilaterale **p = 0,15071**. Per IT2a: 22 iscrizioni semplici in f69v, contro 22 di controllo, **p = 0,27169**. L'eccezionalità dell'iniziale **non sopravvive chiaramente al controllo per lunghezza**; questi gruppi non sono repliche statisticamente indipendenti.
4. **Ordine circolare delle iniziali:** 17/28 coppie confinanti nel ciclo condividono il primo segno, contro media 15,06 in 20.000 rimescolamenti del multinsieme delle 28 iniziali, **p ~ 0,199**. Non emerge una regola ciclica convincente. Questo controllo usa l'ordine dei loci, non una sequenza spaziale completamente verificata sul facsimile.

## Verdetto

**Numero 28 compatibile con le dimore lunari, ma non discriminante.** Il modello forte «28 nomi diversi scritti in 28 forme distinte» è problematico per la tripla ricorrenza di `okeod` in ZL3b e IT2a; tuttavia una rilettura paleografica indipendente può eliminare parte delle duplicazioni. La predominanza delle iniziali `o` non fornisce una chiave perché appare sensibile alla lunghezza e al genere di testo, mentre non vediamo un ordine dei prefissi sorprendente.

Non esistono un **punto d'inizio** e una **direzione di lettura** indipendentemente certificati, né una regola di traduzione dei 28 nomi medievali a priori. Non effettuiamo alcun allineamento post-hoc con i nomi di al-Farghani.

**Punto di arresto:** per fare un ulteriore test lessicale serve anzitutto una doppia lettura paleografica cieca dei loci `.14`, `.18`, `.27` su immagine ad alta risoluzione, e un punto d'inizio ricavato dalla geometria indipendentemente dal testo. Senza tali condizioni, ulteriori confronti fonetici sarebbero liberi di aggiustarsi ai dati.

## Integrità

La cartella `inputs/` contiene le due trascrizioni originali per la riproduzione; `RESULTS.json` è generato da `astro11.py`. Gli hash dei file sono registrati in `MANIFEST.sha256`. Il programma non altera le fonti, né gli artefatti della pipeline RC1.4.2.
