# ANCHOR-22 — Confronto botanico entro pannello e controllo di anteriorità

**Data:** 12 novembre 2026. **Stato:** registro di test generato e controllo delle fonti; **nessun nuovo risultato da immagini**. I documenti RC1.4.2 rimangono intatti (`CLOSED_PENDING_VALIDATION`).

## 1. Risultato esterno indipendente dal nostro programma

Il repository pubblico `thisisntjon/voynich`, esperimento `s128 (P-72)` del 19 ottobre 2026, pubblica un esperimento su 18 abbinamenti frammento farmaceutico / pagina botanica scelti da confronti visivi. Il file `record/results_s128_20261019T090659.txt`, recuperato usando il connettore GitHub, ha Git blob SHA `bea9d2a9244e9a43ad0c4b3403cbc937bc06a62d`. Riporta, per ZL3b, rango primo `0/18`, reciprocal rank medio 0,0254 e `p_primary=0,7202`. Il controllo positivo sulla trasmissione nome→capitolo del manoscritto Egerton 747 passa in `200/200` ricampionamenti. Il test di potenza con collegamento simulato k=5 dichiara 0,958. I corpora RF1b e IT2a non confermano una direzione positiva. **Queste sono dichiarazioni del file esterno, qui lette ma non replicate con codice indipendente.**

Fonti: https://github.com/thisisntjon/voynich/blob/main/record/results_s128_20261019T090659.txt , https://github.com/thisisntjon/voynich/blob/main/FINDINGS.md

Questa ricerca testa il collegamento fra *nome della pianta* e testo botanico più direttamente di ANCHOR-08. Esiste una sovrapposizione di problemi e di alcune coppie con il nostro studio, quindi un altro test lessicale con gli stessi criteri sarebbe largamente ridondante.

## 2. Dati locali congelati

L'input `ANCHOR_20_20261112/pairs_11.csv` presenta 9 corrispondenze catalogate come migliori e 2 considerate dubbie, classificazioni di Stolfi e **non** verità sperimentali. Il programma calcola SHA-256 dell'input; la somiglianza di radice compare in 11/11 e non distingue le categorie. L'indicazione di foglie simili è 7/9 contro 0/2; il Fisher unilaterale già calcolato in ANCHOR-21 dà `p=0,1091`. Il corpus contiene quindi selezione retrospettiva e non certifica veri positivi/negativi.

## 3. Nuovo registro prospettico (non un test eseguito)

Il programma `build_anchor22.py` ha creato una matrice esaustiva di **24 possibili abbinamenti** *entro lo stesso pannello farmaceutico*: 16 in `f102r2`, 4 in `f102r1`, 4 in `f89v3`. Fra questi, 8 sono gli abbinamenti già indicati dal catalogo; gli altri 16 sono abbinamenti incrociati costruiti per confronto e **non negativi scientificamente verificati**. `f102v1` resta fuori perché nel catalogo possiede un unico candidato e non offre un confronto entro pannello. I due casi dubbi storici sono tenuti separati, fuori da questo ranking.

Le stesse otto associazioni storiche servono solo come etichetta del registro di custodia: **NON** sono risultati conseguiti da un nuovo algoritmo. Le righe di `blind_candidates.csv` contengono solo ID e campi di annotazione vuoti. Il file `custodian_answer_key.csv` mantiene la mappatura, deve essere nascosto ai revisori.

**Blocco attuale:** mancano crop originali della Yale sufficientemente comparabili, maschere delle scritte e due annotazioni umane indipendenti. Le immagini locali disponibili nella sessione riguardano diagrammi zodiacali dell'Ariete, non i pannelli botanici da testare. Perciò non è lecito calcolare accuratezza visuale, p-value o attribuzioni semantiche su ANCHOR-22.

## 4. Decisione scientifica

- **STOP**: ulteriore ricerca di una corrispondenza diretta etichetta farmaceutica→nome nel testo della pianta, salvo nuova evidenza primaria.
- **TEST VISIVO ANCORA APERTO**: mascherare i testi nelle immagini originali; confrontare radici + foglie + anomalie non botaniche sullo stesso pannello; controllare la capacità di classificazione su ritagli non usati per tarare il metodo; testare stabilità inter-revisore. La matrice prospettica evita di costruire gli abbinamenti *dopo* aver letto i risultati.
- **VERSO LA SEMANTICA**: anche la riuscita di quel test dimostrerebbe soltanto una relazione fra immagini interne. Per tradurre serve un secondo documento con nome leggibile **indipendentemente verificato**, più una regola che funzioni su altre parole non selezionate.

## 5. Riproducibilità e separazione dei ruoli

`build_anchor22.py` genera `blind_candidates.csv`, `custodian_answer_key.csv`, `historical_pairs.csv`, `RESULTS.json`; il manifest elenca hash/byte dei file. Non modificare i registri storici. Il file di custodia e lo script non devono essere mostrati ai revisori prima che le schede siano compilate. Il registro è un artefatto operativo e **non una scoperta di nuovi abbinamenti botanici**.
