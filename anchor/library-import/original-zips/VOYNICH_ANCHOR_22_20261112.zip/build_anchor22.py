import csv,hashlib,itertools,json, pathlib,random,collections
OUT=pathlib.Path(__file__).resolve().parent
SOURCE=pathlib.Path('/mnt/data/ANCHOR_20_20261112/pairs_11.csv')
source_sha=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
with SOURCE.open(newline='') as f: rows=list(csv.DictReader(f))
positive=[r for r in rows if r['historical_class']=='positive']
poor=[r for r in rows if r['historical_class']=='poor']
groups=collections.defaultdict(list)
for r in positive: groups[r['pharma'].split('_')[0]].append(r)
# Collocationally controlled decoy panel: same physical pharma region, cross matching only within that region.
records=[]
for group,items in sorted(groups.items()):
    if len(items)<2:continue
    for herb,phar in itertools.product(items,items):
        records.append(dict(panel=group,herbal=herb['herbal'],pharma_fragment=phar['pharma'],
            catalog_pair=int(herb['herbal']==phar['herbal']),status='UNANNOTATED_NOT_VALIDATED'))
# Do not label the catalog match in blinded input; reserve it in custodian table.
random.Random(20261112).shuffle(records)
with (OUT/'blind_candidates.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,['blind_id','root_branch_score','leaf_shape_score','flower_score','anomaly_score','notes','reviewer_id'])
    w.writeheader()
    for i,r in enumerate(records,1):
        r['blind_id']=f'K{i:03d}'
        w.writerow({k:r.get(k,'') for k in w.fieldnames})
with (OUT/'custodian_answer_key.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,['blind_id','panel','herbal','pharma_fragment','catalog_pair','status']);w.writeheader();w.writerows({k:r.get(k,'') for k in w.fieldnames} for r in records)
with (OUT/'historical_pairs.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,rows[0].keys());w.writeheader();w.writerows(rows)
stats={'input_sha256':source_sha,'input_positive':len(positive),'input_poor':len(poor),'within_panel_pairs':len(records),'catalog_matches':sum(r['catalog_pair'] for r in records),'constructed_cross_matches':sum(not r['catalog_pair'] for r in records),'single_candidate_panels_excluded':[g for g,rs in groups.items() if len(rs)<2],'panel_counts':{g:len(rs) for g,rs in groups.items()},'data_status':'pair list & blind manifest only; no image-based evaluations performed','external_prior_art':{'repo':'thisisntjon/voynich','file':'record/results_s128_20261019T090659.txt','git_blob':'bea9d2a9244e9a43ad0c4b3403cbc937bc06a62d','tested_pairs':18,'Voynich_top1':0,'Voynich_p_primary':0.7202,'Egerton_positive_control_pass_share':1.0,'power_k5_reported':0.958,'independent_replication':'not independently rerun here'}}
(OUT/'RESULTS.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2)+'\n')
for p in sorted(OUT.iterdir()):
    if p.name=='MANIFEST_SHA256.json':continue
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(OUT.iterdir()) if p.is_file()}
(OUT/'MANIFEST_SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(stats,indent=2))
