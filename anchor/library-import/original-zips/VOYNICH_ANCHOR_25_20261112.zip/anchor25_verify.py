#!/usr/bin/env python3
"""Independent, intentionally limited Naibbe token-compatibility check.
Greshko M.A. (2025), Cryptologia. DOI 10.1080/01611194.2025.2566408.
Published Naibbe tables are obtained independently; copyright and license
remain with their author; this script does not redistribute the tables.
"""
import argparse, csv, hashlib, io, json, random, re, statistics, urllib.request
from pathlib import Path
URL='https://raw.githubusercontent.com/greshko/naibbe-cipher/main/references/naibbe_tables.csv'
TABLE_BLOB_SHA1='5cd34fb81d80faf3b4d57dbf1719c05ffde25302'
CORPUS_SHA256='bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc'

def tables(raw):
    blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    if blob!=TABLE_BLOB_SHA1: raise ValueError('Source table SHA1 mismatch: '+blob)
    d={k:{} for k in ('unigram','prefix','suffix')}
    rows=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))))
    for row in rows:
        kind,tabl,letter=row['code'].split('_'); word=row['glyphs']
        d[kind].setdefault(word,set()).add(letter)
    assert len(rows)==414, len(rows)
    return d

def corpus_tokens(raw):
    if hashlib.sha256(raw).hexdigest()!=CORPUS_SHA256: raise ValueError('Corpus mismatch')
    out=[]; nlines=0
    for line in raw.decode('utf-8').splitlines():
        if not re.match(r'^<[^>]+,\+P\d+>',line):continue
        nlines+=1
        t=re.sub(r'^<[^>]+>','',line)
        t=re.sub(r'<[^>]*>','',t)
        t=re.sub(r'\[[^\]]*\]','',t)
        t=re.sub(r';[^ ]*','',t)
        t=t.translate(str.maketrans('','','{}'))
        out += [w for w in re.split(r'[.,\s]+',t) if re.fullmatch('[a-z]+',w)]
    return out,nlines

def summarize(tokens,d):
    total=len(tokens); known=amb=unig=big=0; numread=0
    for w in tokens:
        opts=set(d['unigram'].get(w,()))
        if opts: unig+=1
        hasbig=False
        for i in range(1,len(w)):
            for a in d['prefix'].get(w[:i],()):
                for b in d['suffix'].get(w[i:],()):
                    opts.add(a+b);hasbig=True
        if hasbig:big+=1
        if opts:
            known+=1;numread+=len(opts)
            if len(opts)>1:amb+=1
    return {'total':total,'covered':known,'coverage':known/total,'ambiguous':amb,'ambiguous_fraction_all':amb/total,'ambiguous_fraction_covered':amb/known,'unigram':unig,'bigram':big,'mean_candidates_covered':numread/known}

def main():
    a=argparse.ArgumentParser();a.add_argument('--corpus',default='ZL3b-n.txt');a.add_argument('--tables',help='Locally supplied exact original naibbe_tables.csv (else fetch official URL)');a.add_argument('--null-reps',type=int,default=40);x=a.parse_args()
    t=Path(x.tables).read_bytes() if x.tables else urllib.request.urlopen(URL,timeout=30).read()
    d=tables(t); tokens,nlines=corpus_tokens(Path(x.corpus).read_bytes())
    actual=summarize(tokens,d)
    r=random.Random(257);nulls=[]
    for _ in range(x.null_reps):
        shuffled=[]
        for w in tokens:
            chars=list(w);r.shuffle(chars);shuffled.append(''.join(chars))
        nulls.append(summarize(shuffled,d)['coverage'])
    result={'method':'published glyph table; unigram and one prefix+suffix split; no compound, contextual rules or decipherment', 'paragraph_lines':nlines,'tokens':len(tokens),'unique_tokens':len(set(tokens)),'actual':actual,'null_shuffle_within_word':{'replicates':len(nulls),'mean':statistics.mean(nulls),'min':min(nulls),'max':max(nulls)},'table_blob_sha1':TABLE_BLOB_SHA1,'corpus_sha256':CORPUS_SHA256}
    print(json.dumps(result,indent=2,ensure_ascii=False))
if __name__=='__main__':main()
