# ANCHOR-25 | Copertura di lettura delle tabelle pubblicate Naibbe

**Data:** 12 novembre 2026. **Stato:** esplorativo, analisi autonoma in sola lettura; nessuna modifica a RC1.4.2 (`CLOSED_PENDING_VALIDATION`).

## Domanda

Quale frazione delle parole trascritte ZL3b ammette almeno una lettura secondo le **414 associazioni pubbliche** del cifrario Naibbe di Michael A. Greshko, utilizzando una corrispondenza per unigramma oppure una singola divisione in prefisso e suffisso? Quante sono ambigue e quanto vale la copertura per parole con caratteri rimescolati?

## Origini documentali

- Tabella: `greshko/naibbe-cipher`, `references/naibbe_tables.csv`, Git blob SHA-1 `5cd34fb81d80faf3b4d57dbf1719c05ffde25302`, **414 righe**. Le tabelle originali sono copyright Greshko (2025) e NON sono riprodotte nel pacchetto.
- Corpus: `ZL3b-n.txt`, 411.671 byte, SHA-256 `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc`.
- Studio: Greshko, Michael A. (2025), *The Naibbe cipher: a substitution cipher that encrypts Latin and Italian as Voynich Manuscript-like ciphertext*, **Cryptologia**, DOI: `10.1080/01611194.2025.2566408`.

## Regole della diagnostica

Si analizzano le righe IVTFF marcate `+P`, rimuovendo i commenti inline e le alternative non certe fra parentesi quadre, e prendendo solo i token ASCII minuscoli. Per ogni token si formano tutte le letture definite da (a) unigramma esatto, (b) una divisione prefisso+ suffisso presente nelle tabelle. Non si applicano le regole complete del cifrario Naibbe: **nessun composto, disambiguazione contestuale, ripristino degli spazi o ricerca di chiave ignota**.

## Risultati osservati

| Misura | Esito |
|---|---:|
| Righe paragrafo lette | 3.674 |
| Token conformi all'estrattore esplorativo | 30.762 |
| Tipi distinti | 6.490 |
| Token con almeno una lettura | **24.476 (79,57%)** |
| Token senza lettura | 6.286 (20,43%) |
| Token con più letture distinte | **12.377 (40,23% di tutti; 50,57% dei coperti)** |
| Token riconosciuti come unigramma | 13.162 |
| Token con almeno un'interpretazione da prefisso+suffisso | 23.076 |
| Tipi distinti con almeno una lettura | 2.566 su 6.490 (39,54%) |

Con **40** randomizzazioni dei caratteri all'interno di ogni token, mantenendo invariato l'inventario delle lettere e la lunghezza di ciascuna parola, la copertura media dei controlli è stata **13,09%**, compresa fra **12,76% e 13,38%**. Questo null non è un test statistico sufficiente per avvalorare una decifrazione: le tabelle sono progettate sul profilo Voynich, quindi un testo Voynich autentico ci si aspetta che presenti una maggiore copertura di parole rimescolate.

## Interpretazione e limiti

1. **La tabella Naibbe riconosce strutture della trascrizione Voynich.** Questo è un controllo di compatibilità, non una scoperta sul significato.
2. **L'ambiguità è ampia già a livello del singolo token**, prima di applicare vincoli di lingua, ordine delle lettere e testo plausibile. La quota delle ambiguità non equivale a una misura della recuperabilità effettiva della chiave.
3. La chiave è **nota e pubblicata**. L'esperimento non recupera una chiave sconosciuta e non decifra il Voynich.
4. Il test sui caratteri rimescolati è deliberatamente debole: ignora le regole morfologiche del corpus e non fornisce un modello nullo storicamente plausibile.
5. L'estrattore volutamente semplice differisce dalla pipeline RC1.4; **non confrontare le cardinalità come se fossero lo stesso dataset**.
6. Il risultato non prova che il manoscritto sia stato cifrato con Naibbe, che è una costruzione moderna progettata per imitare alcune statistiche del Voynich.

## Prossimo gate sensato

Invece di adattare ulteriormente la chiave sul manoscritto, testare un recuperatore della **chiave nascosta** su dati Naibbe generati da una variante parametrica e su cifrari di controllo storici. Congelare train/test, definire linguaggi ammessi e criteri di successo prima del recupero; valutare simultaneamente errore di plaintext, falsi positivi e incertezza delle letture. Un semplice decoder con la tabella originale già in mano non soddisfa il gate.

## Riproducibilità

`python anchor25_verify.py --corpus ZL3b-n.txt --tables /path/naibbe_tables.csv`

Lo script standard-library verifica sia il digest del corpus sia il **Git blob SHA-1** della tabella. Se non è indicato `--tables`, prova a scaricare la tabella dal repository ufficiale. Il pacchetto non contiene la tabella dell'autore. Un ambiente senza internet non può completare la riesecuzione se la tabella non viene fornita localmente. Lo script è stato compilato sintatticamente e il corpus verificato in questa sessione; i conteggi sopra sono stati calcolati sul contenuto originale tramite lettura strumentale.
