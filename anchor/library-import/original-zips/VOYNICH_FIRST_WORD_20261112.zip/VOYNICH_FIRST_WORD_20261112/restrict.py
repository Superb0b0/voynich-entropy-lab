import csv,json,itertools
from pathlib import Path
B=Path(__file__).parent
p=list(csv.DictReader((B/'pairwise.csv').open())); fours=['f70v1','f71r','f71v','f72r1']
out=[]
for tr in ('ZL3b','IT2a'):
 d={frozenset([r['folio1'],r['folio2']]):r for r in p if r['transcription']==tr}
 arrangements=[(('f70v1','f71r'),('f71v','f72r1')),(('f70v1','f71v'),('f71r','f72r1')),(('f70v1','f72r1'),('f71r','f71v'))]
 for k in ['exact_jaccard','near_rate_1','same_prefix3']:
  vals=[sum(float(d[frozenset(pair)][k]) for pair in pairs)/2 for pairs in arrangements]
  out.append({'transcription':tr,'metric':k,'observed_matched_sign':vals[0],'alternative_mismatch_1':vals[1],'alternative_mismatch_2':vals[2],'exact_one_sided_p':sum(v>=vals[0]-1e-12 for v in vals)/3,'n_possible_matchings':3})
with (B/'restricted_control.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
print(json.dumps(out,indent=2))
