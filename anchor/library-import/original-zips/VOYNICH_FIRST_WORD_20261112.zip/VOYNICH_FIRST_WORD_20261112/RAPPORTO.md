# EXP-FIRST-WORD-01 · Tentativo di ancoraggio lessicale, zodiaco Voynich
12 novembre 2026 · Esplorativo · Nessuna decifrazione dichiarata

## Domanda
Le due versioni illustrate di Ariete (f70v1, f71r) e Toro (f71v, f72r1) condividono più etichette di versioni di segni diversi? Il testo in grafia latina con i nomi dei mesi è un'aggiunta distinta dalla scrittura indecifrata e non vale come traduzione.

## Dati e metodo
File IVTFF ZL3b-n (2025) e IT2a-n (2025) inclusi. Estrazione conservativa dei loci etichetta zodiacale @Lz e &Lz delle 12 pagine, escludendo le righe di testo circolare. In caso di locuzione multiparola, si analizza soltanto il primo token; per ZL3b si esclude il primo token dubbio o con grafia incerta. 299 loci per trascrizione, 274 primi token certi in ZL3b e 296 in IT2a.

Confronto fra insiemi di primi token (Jaccard esatto), proporzione di token con una variante alla distanza Levenshtein 1 nella seconda pagina, e condivisione dei primi 3 caratteri. I due veri abbinamenti sono Ariete-Ariete e Toro-Toro. Il controllo cruciale limita il confronto alle 4 pagine da 15 etichette, con esattamente 3 possibili accoppiamenti disgiunti di quelle 4 pagine. Quindi il minimo p esatto possibile è 1/3. La ricerca su tutte e 12 pagine con 1485 accoppiamenti di coppie è una sensibilità ESPLORATIVA, non il test principale perché confonde il numero di etichette (15 vs 29-30) e la posizione del folio.

## Risultati
- Toro, ZL3b: due forme esattamente comuni, `char` e `otaiin`; Ariete nessuna.
- Toro, IT2a: due forme comuni, `char` e `otaiin`; Ariete una (`otol`).
- Test esatto ristretto di tutti gli abbinamenti, Jaccard: p=0,3333 sia per ZL3b sia per IT2a. Anche le altre misure (varianti di un edit; prefissi comuni di tre caratteri) hanno p=0,3333.
- Lo schermo non condizionato delle 12 pagine dà p=0,1010 in ZL3b e p=0,01145 in IT2a per Jaccard; questo test non è adeguatamente confrontabile a causa delle dimensioni delle pagine e NON fornisce evidenza indipendente del significato.
- Nei dati originali ZL3b, contando occorrenze di parole exact-match nei loci di ogni tipo: `char` è presente in 82 loci e 59 folii, `otaiin` in 138 loci e 67 folii, `otol` in 72 loci e 62 folii. Non sono forme esclusive delle immagini zodiacali e non possono essere interpretate come nomi dei segni su questa base.

## Principali limiti
- Le etichette sono associate a figure periferiche che portano stelle, non direttamente agli emblemi animali al centro.
- Non sono disponibili 12 esemplari indipendenti dello stesso oggetto. Soltanto due coppie di segni compaiono due volte.
- I due sistemi di trascrizione descrivono il medesimo manoscritto, non due testimonianze indipendenti.
- Il conteggio a un edit è diretto e non aggiustato per distribuzione lunghezze delle parole; test esplorativo.
- Ancoraggi semantici fittizi (per esempio `char` = toro) non sono ammessi.

## Verdetto
Nessun candidato traducibile validato. L'esperimento illustra perché la ripetizione di un'etichetta non dimostra un significato. Il prossimo test decisivo necessita di identificazioni figure-etichetta controllate e molte ripetizioni dello stesso referente con negativi comparabili. Pipeline RC1.4.2 invariata e congelata.

## Fonti pubbliche
- Rene Zandbergen, `https://www.voynich.nu/writing.html` (nomi dei mesi in grafia distinta)
- Rene Zandbergen, `https://www.voynich.nu/q11/index.html` (descrizione folii zodiacali)
- Jorge Stolfi, `https://www.ic.unicamp.br/~stolfi/voynich/Notes/040/html/f71v.htm` e `f72r1.htm` (descrizioni Toro).

## Riproduzione
`python first_word.py` e `python restrict.py` nella cartella estratta. I CSV `labels.csv`, `pairwise.csv`, `restricted_control.csv` e `results.json` sono prodotti dai due script. SHA256SUMS.txt contiene impronte per ogni altro file.
