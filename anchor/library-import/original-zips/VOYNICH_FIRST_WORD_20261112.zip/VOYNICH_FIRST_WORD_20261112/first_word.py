import re,csv,json,hashlib, itertools,random,math
from collections import defaultdict,Counter
from pathlib import Path
base=Path(__file__).parent
FILES={'ZL3b':Path(__file__).parent/'input'/'ZL3b-n.txt','IT2a':Path(__file__).parent/'input'/'IT2a-n.txt'}
SIGNS={'f70v2':'Pisces','f70v1':'Aries','f71r':'Aries','f71v':'Taurus','f72r1':'Taurus','f72r2':'Gemini','f72r3':'Cancer','f72v3':'Leo','f72v2':'Virgo','f72v1':'Libra','f73r':'Scorpio','f73v':'Sagittarius'}
pat=re.compile(r'^<(f\d+[rv]\d?)\.(\d+),([@&]Lz)>\s*(?:<![^>]+>)?(.*)$')
def parse(path):
 d=defaultdict(list)
 for line in path.read_text().splitlines():
  m=pat.match(line)
  if not m:continue
  f,i,lc,raw=m.groups()
  if f not in SIGNS:continue
  raw=re.sub(r'<![^>]*>','',raw).split('<$>')[0]
  # strict EVA single token: if uncertain skip; for phrase take first clean token separately
  parts=re.split('[., ]',raw)
  words=[w for w in parts if re.fullmatch('[a-z]+',w)]
  first=words[0] if parts and re.fullmatch('[a-z]+',parts[0]) else None
  d[f].append({'folio':f,'sign':SIGNS[f],'locus':int(i),'raw':raw,'first':first,'tokens_clean':words,'sure':first is not None})
 return d

def lev1(a,b):
 if a==b:return 0
 if abs(len(a)-len(b))>1:return 2
 if len(a)>len(b):a,b=b,a
 if len(a)==len(b):return 1 if sum(x!=y for x,y in zip(a,b))==1 else 2
 # now len diff 1
 i=j=0;ed=0
 while i<len(a) and j<len(b):
  if a[i]==b[j]:i+=1;j+=1
  else:ed+=1;j+=1
  if ed>1:return 2
 return 1

def metrics(x,y):
 a=[r['first'] for r in x if r['sure']]; b=[r['first'] for r in y if r['sure']]
 sa=set(a);sb=set(b);exact=sa&sb
 near=sum(any(lev1(w,t)==1 for t in sb) for w in sa)
 return {'n1':len(a),'n2':len(b),'exact_shared':len(exact),'exact_jaccard':len(exact)/len(sa|sb) if sa|sb else 0,
         'near_from_1':near,'near_rate_1':near/len(sa) if sa else 0, 'same_prefix3':sum(any(w[:3]==t[:3] for t in sb) for w in sa)/len(sa) if sa else 0,'shared_tokens':sorted(exact)}

result={};rows=[];perlabel=[]
for trans,path in FILES.items():
 data=parse(path)
 for f,ls in data.items():
  for r in ls:perlabel.append({'transcription':trans,**r,'tokens_clean':' '.join(r['tokens_clean'])})
 pairs=[]
 for f,g in itertools.combinations(SIGNS,2):
  m=metrics(data[f],data[g]);same=SIGNS[f]==SIGNS[g]
  rr={'transcription':trans,'folio1':f,'folio2':g,'same_sign':int(same),**m};pairs.append(rr)
  rows.append({k:v for k,v in rr.items() if k!='shared_tokens'})
 obs=[p for p in pairs if p['same_sign']]
 # exact all unordered disjoint 2 pair matchings from same 12 pages without replacement, size adjusted via pair-size restrictions? 2 pairs among 12 equals 1485? enumerate combinatorial 12 choose 4*3 = 1485
 metric_names=['exact_jaccard','near_rate_1','same_prefix3']
 nodes=list(SIGNS)
 matchings=[]
 for a,b,c,d in itertools.combinations(nodes,4):
  for (f,g),(h,k) in [((a,b),(c,d)),((a,c),(b,d)),((a,d),(b,c))]:
   pp=next(p for p in pairs if {p['folio1'],p['folio2']}=={f,g})
   qq=next(p for p in pairs if {p['folio1'],p['folio2']}=={h,k})
   matchings.append((pp,qq))
 distribution={}
 for metric in metric_names:
  v=sum(p[metric] for p in obs)/2
  null=[(x[metric]+y[metric])/2 for x,y in matchings]
  distribution[metric]={'observed':v,'null_mean':sum(null)/len(null),'p_upper_exact':sum(t>=v-1e-12 for t in null)/len(null),'rank':sum(t>v+1e-12 for t in null),'n_matchings':len(null)}
 result[trans]={'n_loci':sum(len(t) for t in data.values()),'n_certain_first_words':sum(sum(r['sure'] for r in t) for t in data.values()),'pages':{f:len(data[f]) for f in SIGNS},'identical_sign_pairs':obs,'null_matching':distribution}
with (base/'labels.csv').open('w',newline='') as out:
 w=csv.DictWriter(out,fieldnames=['transcription','folio','sign','locus','raw','first','tokens_clean','sure']);w.writeheader();w.writerows(perlabel)
with (base/'pairwise.csv').open('w',newline='') as out:
 w=csv.DictWriter(out,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(base/'results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
print(json.dumps(result,indent=2)[:7800])
