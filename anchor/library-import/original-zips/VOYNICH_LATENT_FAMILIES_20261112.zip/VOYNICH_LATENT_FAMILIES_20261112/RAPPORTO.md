# Rapporto tecnico: famiglie latenti e persistenza

**Regime:** esplorativo, post-hoc sui folii già analizzati. **Gate globale:** FAIL.

## Disegno sperimentale

Tre modelli senza regole posizionali artificiali: controllo globale, famiglie strette (12 radici; durata 3 righe) e famiglie ampie (24 radici; durata 6 righe). Per ogni parola, campionamento da repertorio Currier di addestramento oppure da una famiglia o dalle ultime due righe; mutazione vincolata ai bigrammi grafici autorizzati dal training. 3 semi per modello e trascrizione, per 18 generazioni.

La fase 02, **esplicitamente post-hoc**, verifica la persistenza delle famiglie oltre il confine di paragrafo lasciando attive tre radici su quattro. Ha 6 nuove generazioni, più 6 repliche non indipendenti del broad di fase 01.

## Confronti

| Trascrizione | Modello | Densità | Adiacenza | Ripetizione | Hapax | Edit1 vicine | Jaccard interno | Jaccard oltre confine | OR y/o |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| zl | voynich_original | 0.9468 | 0.0271 | 0.0569 | 0.7157 | 0.2060 | 0.0305 | 0.0139 | 3.600 |
| zl | global_control | 0.9360 | 0.0171 | 0.0348 | 0.5230 | 0.1522 | 0.0184 | 0.0120 | 0.951 |
| zl | latent_narrow | 0.9520 | 0.0476 | 0.0986 | 0.7358 | 0.1828 | 0.0566 | 0.0131 | 1.413 |
| zl | latent_broad | 0.9499 | 0.0280 | 0.0561 | 0.7549 | 0.1558 | 0.0338 | 0.0056 | 1.266 |
| zl | latent_persist_POSTHOC | 0.9506 | 0.0288 | 0.0578 | 0.7629 | 0.1550 | 0.0332 | 0.0120 | 0.819 |
| it | voynich_original | 0.9632 | 0.0290 | 0.0592 | 0.6965 | 0.2162 | 0.0328 | 0.0147 | 3.202 |
| it | global_control | 0.9586 | 0.0179 | 0.0353 | 0.5048 | 0.1567 | 0.0181 | 0.0167 | 0.903 |
| it | latent_narrow | 0.9689 | 0.0472 | 0.0992 | 0.7296 | 0.1836 | 0.0561 | 0.0130 | 0.756 |
| it | latent_broad | 0.9617 | 0.0283 | 0.0565 | 0.7526 | 0.1550 | 0.0342 | 0.0058 | 0.715 |
| it | latent_persist_POSTHOC | 0.9631 | 0.0280 | 0.0565 | 0.7552 | 0.1591 | 0.0325 | 0.0107 | 0.905 |

## Diagnosi

Il modello broad è il più vicino in densità, ripetizione e adiacenza fra quelli provati, ma eccede di hapax (ZL3b 0,7549 contro 0,7157; IT2a 0,7526 contro 0,6965), ha meno edit1 tra righe adiacenti (ZL3b 0,1558 contro 0,2060), e non produce l'OR posizionale (ZL3b 1,27 contro 3,60). La continuità attraverso i paragrafi è troppo bassa (0,0056 contro 0,0139).

La variante a persistenza parziale migliora il confronto oltre i confini (ZL3b 0,0120, IT2a 0,0107), ma gli hapax restano ancora alti e il fenomeno posizionale manca. Nessun test cieco nuovo, nessuna decifrazione.

## Scelta operativa

Non aggiustare altri pesi su questi stessi folii. Congelare questo meccanismo come baseline falsificabile. Il prossimo studio deve utilizzare nuove misure non viste (distribuzioni di prefissi, token OOV e statistiche per singolo folio) e poi un test fuori campione o su un corpus di controllo distinto. RC1.4.2 immutato.
