#!/usr/bin/env python3
"""Generative falsification of locked unified exploratory model, NOT a decipherment.
Input from prior experiment, same folio split reused. Entire generator builds each folio from zero.
Sampling is a normalized mixture; unavailable conditional components back off to global.
"""
import json, math, csv, hashlib, sys
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np
ROOT=Path(__file__).resolve().parent
PARENT=(ROOT/'upstream' if (ROOT/'upstream').exists() else ROOT.parent/'VOYNICH_UNIFIED_GATE_20261112')
ns={'__file__':str(PARENT/'edit_neighborhood.py'),'__name__':'generator_only'}
src=(PARENT/'edit_neighborhood.py').read_text()
exec(compile(src[:src.index('out={')],str(PARENT/'edit_neighborhood.py'),'exec'),ns)
folios,meta,base,val,test=ns['folios'],ns['meta'],ns['base'],ns['val'],ns['test']
prob=ns['Gfunc'];index_vocab=ns['index_vocab']
fit=json.loads((PARENT/'edit1_results.json').read_text())
assert len(set(test)&set(base))==0
# Historical reference benchmarks, NOT fit targets.
BANDS={'density':(.91,.96),'adjacency':(.02,.04),'repetition':(.045,.07),'hapax':(.65,.75)}

# Efficient edit distance 1: same length one substitution, or one insertion/deletion.
def summary(rows):
    tokens=[w for row in rows for w in row]
    f=Counter(tokens);types=set(f);similar=set();deleted={}
    for w in types:
        for i in range(len(w)):
            d=w[:i]+w[i+1:]
            if d in types:similar.update((w,d))
            if d in deleted and deleted[d]!=w:similar.update((w,deleted[d]))
            else:deleted[d]=w
    density=sum(f[w] for w in similar)/len(tokens)
    hapax=sum(v==1 for v in f.values())/len(f)
    ja=[];re=[];edit=[]
    for prev,row in zip(rows,rows[1:]):
        a,b=set(prev),set(row)
        u=len(a|b)
        ja.append(len(a&b)/u if u else 0)
        re.append(sum(w in a for w in row)/len(row) if row else 0)
        # Cross-row edit1: generate signatures for the two sets only
        ad=defaultdict(set)
        for w in a:
            for i in range(len(w)):ad[w[:i]+w[i+1:]].add(w)
        hit=0
        for w in row:
            yes=False
            for i in range(len(w)):
                d=w[:i]+w[i+1:]
                if d in a or any(v!=w for v in ad.get(d,())):yes=True;break
            if not yes:
                # token w is shorter by one than a previous token
                yes=w in ad
            hit+=yes
        edit.append(hit/len(row) if row else 0)
    return {'density':density,'adjacency':float(np.mean(ja)),'repetition':float(np.mean(re)),
            'hapax':hapax,'edit1_between_adjacent_rows':float(np.mean(edit)),
            'tokens':len(tokens),'lines':len(rows),'types':len(f)}

def matched_or(rows):
    by=defaultdict(lambda:[0,0,0,0])
    for row in rows:
        for j,w in enumerate(row):
            if len(w)<4 or w[0] not in 'yo':continue
            s=w[1:];a=by[s];a[(0 if w[0]=='y' else 2)+(j>0)]+=1
    num=den=0;strata=0
    for a,b,c,d in by.values():
        n=a+b+c+d
        if a+b<2 or c+d<2 or (a+c)==0 or (b+d)==0:continue
        num+=a*d/n;den+=b*c/n;strata+=1
    return {'or':num/den if den else None,'strata':strata}


def draw_global(rng,global_words,global_cdf):
    return global_words[np.searchsorted(global_cdf,rng.random(),side='right')]

# Complete generative process. Uses only generated context; never real test words.
def generate(trans,seed,kind):
    G,_=prob(trans)
    wordsall=set(next(iter(G.values())))
    neighbors=index_vocab(wordsall)
    by_class={}
    for c,p in G.items():
        words=sorted(p)
        ps=np.asarray([p[w] for w in words]);ps/=ps.sum()
        by_class[c]=(words,np.cumsum(ps))
    rng=np.random.default_rng(seed)
    out=[];per_folio={}
    for f in sorted(test):
        cat=meta[f];glob,cdf=by_class[cat]
        fol_history=[];recent_par=[];whole=[]
        # original folio's LAYOUT ONLY, not test lexical content
        for par in folios[f]:
            prev=[];newpar=[]
            for row in par:
                n=len(row[trans]);newrow=[]
                recent=[w for sub in prev[-2:] for w in sub]
                viable=[w for w in recent if neighbors.get(w)]
                for col in range(n):
                    # 0.05 folio memory, 0.02 edit-one memory, remainder global;
                    # missing component backs off to global.
                    def proposal():
                        if kind=='baseline':return draw_global(rng,glob,cdf)
                        r=rng.random()
                        if r<.05 and fol_history:
                            return fol_history[int(rng.integers(len(fol_history)))]
                        if kind=='unified' and r<.07 and viable:
                            anchor=viable[int(rng.integers(len(viable)))]
                            nbs=neighbors[anchor]
                            return nbs[int(rng.integers(len(nbs)))]
                        return draw_global(rng,glob,cdf)
                    if kind in ('baseline','folio') or col!=0: w=proposal()
                    else:
                        # Equivalent to multiplying y words by exp(beta=1),
                        # rejection accept y=1, other words=exp(-1).
                        for _ in range(100000):
                            w=proposal()
                            if w.startswith('y') or rng.random()<math.exp(-1):break
                        else:raise RuntimeError('rejection failed')
                    newrow.append(w)
                fol_history.extend(newrow);prev.append(newrow);newpar.append(newrow)
            whole.extend(newpar)
        out.extend(whole);per_folio[f]=whole
    return out,per_folio

# Real reference based on same layout / folios, no training leakage in generator.
rows_out=[];report={'status':'EXPLORATORY_FALSIFICATION_REUSED_FOLIO_TEST','seeds':list(range(1101,1106)),
 'generator':'Locked weights F=0.05 EDIT=0.02 BETA=1 for both transcripts; normalized on availability by fallback global; global G estimated only on base; same paragraph and line lengths as heldout, but no test words sampled.',
 'bands':BANDS,'results':{},'source_digests':{},'limitations':['Not blind: this same heldout manuscript previously examined.','Global vocabulary is transductive, including test types.','Flat edit-one neighbor list rather than historically inferred transformations.','No conditional tuning, no re-estimating on synthetic outputs.','Exact printed Voynich words, not ciphertext/plaintext decipherment.']}
for trans in ['zl','it']:
    print('START',trans,flush=True)
    reference=[]
    for f in sorted(test):
        for par in folios[f]:
            reference.extend([list(row[trans]) for row in par])
    R=summary(reference);R.update({'suffix_or':matched_or(reference)})
    report['results'][trans]={'reference':R,'replicates':[]}
    for kind in ['baseline','folio','folio_position','unified']:
        for seed in report['seeds']:
            rows,_=generate(trans,seed,kind)
            s=summary(rows);s['suffix_or']=matched_or(rows)
            passband={k:BANDS[k][0]<=s[k]<=BANDS[k][1] for k in BANDS}
            s.update({'kind':kind,'seed':seed,'bands_pass':passband})
            assert s['tokens']==R['tokens'] and s['lines']==R['lines']
            report['results'][trans]['replicates'].append(s)
            rows_out.append({'transcription':trans,'kind':kind,'seed':seed,**{k:s[k] for k in BANDS},'edit1_between_adjacent_rows':s['edit1_between_adjacent_rows'],
                             'suffix_or':s['suffix_or']['or'],'suffix_strata':s['suffix_or']['strata'], 'passed_four':sum(passband.values())})
            print(trans,kind,seed,{k:round(s[k],4) for k in BANDS},'edit1',round(s['edit1_between_adjacent_rows'],4),'matched_or',s['suffix_or'],flush=True)
    for kind in ['baseline','folio','folio_position','unified']:
        ss=[x for x in report['results'][trans]['replicates'] if x['kind']==kind]
        report['results'][trans][kind+'_mean']={k:float(np.mean([v[k] for v in ss])) for k in list(BANDS)+['edit1_between_adjacent_rows']}
        orvals=[v['suffix_or']['or'] for v in ss if v['suffix_or']['or'] is not None]
        report['results'][trans][kind+'_mean']['suffix_or']=float(np.mean(orvals)) if orvals else None
        report['results'][trans][kind+'_pass_four']=sum(sum(v['bands_pass'].values())==4 for v in ss)
( ROOT/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
with (ROOT/'replicates.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows_out[0]));w.writeheader();w.writerows(rows_out)
print('RESULTS_READY',flush=True)
