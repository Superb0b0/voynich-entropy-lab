#!/usr/bin/env python3
"""Voynich sequential source mixture experiment, exploratory; original inputs untouched.

Competing probabilistic mechanisms: G (global Currier-stratified word frequencies),
P (all previous paragraph lines), R1 (last line), R2 (last two lines).
Independent folio-disjoint base/validation/test; fixed parameter grid.
"""
import re, json, hashlib, csv, importlib.util
from pathlib import Path
from collections import defaultdict, Counter
from math import log
import numpy as np

ROOT=Path(__file__).resolve().parent
INPUT=(ROOT/'inputs' if (ROOT/'inputs').exists() else Path('/mnt/data/VOYNICH_SEQ_LINE_MEMORY_20261112/inputs'))
HASH={'ZL3b-n.txt':'bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc',
      'zl3b_P_ms408.tsv':'41c3ea40b7f71ea612fbee49a65ebd253231a209ce2d5096131126c957bcd1f2',
      'IT2a-n.txt':'7f27a8b0feed8f6de0a99900df6bf912dd1d295c38e5f830bac8b41c3f536fb5'}
for file,sha in HASH.items():
    assert hashlib.sha256((INPUT/file).read_bytes()).hexdigest()==sha, file

pfile=INPUT/'ivtff_parser_rc1_2.py'
spec=importlib.util.spec_from_file_location('rc12_readonly',pfile)
p=importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
zrec=p.parse_corpus(INPUT/'ZL3b-n.txt')['records']
itrec=p.parse_corpus(INPUT/'IT2a-n.txt',verify_source=False)['records']
assert len(zrec)==4130 and len(itrec)==4118
it_by={r['locus_id']:r for r in itrec}
zwords=[]
for row in (INPUT/'zl3b_P_ms408.tsv').read_text().splitlines():
    f,t=row.split('\t',1);zwords.append((f,t.split()))
assert len(zwords)==len(zrec)
rawz=(INPUT/'ZL3b-n.txt').read_text().splitlines(); rawit=(INPUT/'IT2a-n.txt').read_text().splitlines()
meta={}
for line in rawz:
    m=re.match(r'^<([^>,.]+)>\s*<!',line)
    if m:
        y=re.search(r'\$L=([^\s>]+)',line)
        meta[m[1]]=y.group(1) if y else '?'

# Use aligned common loci and strict common paragraph boundary for both sources.
folios=defaultdict(list);previous_folio=None
for zr,(fol,zlist) in zip(zrec,zwords):
    r=it_by.get(zr['locus_id'])
    if r is None: previous_folio=None; continue
    assert fol==zr['folio']==r['folio']
    zstart='<%>' in rawz[zr['physical_line']-1]
    istart='<%>' in rawit[r['physical_line']-1]
    if fol!=previous_folio or zstart or istart or not folios[fol]:
        folios[fol].append([])
    folios[fol][-1].append({'locus':zr['locus_id'],'zl':tuple(zlist),'it':tuple(r['tokens'])})
    previous_folio=fol
assert sum(len(g) for pg in folios.values() for g in pg)==4118

# Split independent of word contents; Currier-stratified folio split.
seed=20261112+4507
rng=np.random.default_rng(seed)
base=[];validation=[];test=[]
for currier in ['A','B','?']:
    ff=[f for f in folios if meta.get(f)==currier]
    if not ff:continue
    rng.shuffle(ff)
    nbase=int(.55*len(ff));nval=int(.20*len(ff))
    base.extend(ff[:nbase]);validation.extend(ff[nbase:nbase+nval]);test.extend(ff[nbase+nval:])
assert not (set(base)&set(validation) or set(base)&set(test) or set(validation)&set(test))

GRID=[0,.01,.02,.04,.06,.08,.10,.15,.20,.30,.40,.55,.70]
SMOOTH=0.10

def global_prob(trans):
    # Full vocabulary is fixed in advance from the examined corpus; no test frequencies.
    vocab=set(t for pg in folios.values() for par in pg for row in par for t in row[trans])
    n_vocab=len(vocab)
    class_counts={c:Counter() for c in ('A','B','?')}
    for f in base:
        for par in folios[f]:
            for row in par:class_counts[meta[f]].update(row[trans])
    G={}
    for c,counts in class_counts.items():
        s=sum(counts.values()) + SMOOTH*n_vocab
        G[c]={w:(counts.get(w,0)+SMOOTH)/s for w in vocab}
    return G,n_vocab

def features(trans,fs,G,swap=None):
    """Per-word conditional probabilities for actual token at each noninitial paragraph line.
    Optional shuffling of interior rows within paragraphs for null control.
    """
    out=[]
    for f in fs:
        c=meta[f];g=G[c]
        for pi,original in enumerate(folios[f]):
            order=list(original)
            if swap is not None and len(order)>3:
                ids=list(range(1,len(order)-1));swap.shuffle(ids)
                order=order[:1]+[order[j] for j in ids]+order[-1:]
            old=Counter();last1=Counter();last2=Counter();total=0;nt1=0;nt2=0
            for index,row in enumerate(order):
                tokens=row[trans]
                if index and tokens:
                    for token in tokens:
                        out.append((f,g.get(token,0),old[token]/total if total else 0,
                                    last1[token]/nt1 if nt1 else 0,
                                    last2[token]/nt2 if nt2 else 0))
                old.update(tokens);total+=len(tokens)
                last1=Counter(tokens);nt1=len(tokens)
                if index==0: last2=Counter(tokens);nt2=len(tokens)
                else:
                    last2=Counter(order[index-1][trans]);last2.update(tokens)
                    nt2=len(order[index-1][trans])+len(tokens)
    return out

def arr(rows):
    return np.array([r[1:] for r in rows], dtype=float)

def score(X,para,recent,which):
    # normalized probabilistic mixture, avoid conditionals based on outcome.
    col=2 if which=='one' else 3
    mix=(1.0-para-recent)*X[:,0] + para*X[:,1] + recent*X[:,col]
    if np.any(mix<=0):raise RuntimeError('Negative or zero prediction probability')
    return np.log(mix)

OUT={ 'experiment':'EXP_SEQ_NEXT_TOKEN_20261112', 'status':'EXPLORATORY',
      'design':{'seed':seed,'vocab':'transcription-specific known vocabulary; G counts train folios only, additive smoothing 0.10 per type',
                'splits':'Currier-stratified 55% base to estimate unigram G, 20% validation to select mixture weights, 25% test held out; folio-disjoint',
                'mixture':'(1-theta-lambda)*global_G + theta*past_paragraph_counts + lambda*recent_1_or_2_line_counts',
                'parameter_grid':GRID,
                'evaluation':'heldout token NLL, folio cluster bootstrap, label-shuffle null of interior paragraph rows',
                'shared_loci':'4,118 ZL3b/IT2a; common paragraph boundaries',
                'warnings':['Parameter hypotheses developed after previous Voynich analyses; exploratory not preregistered.',
                  'All metrics based on same manuscript; IT2a is correlated replication.',
                  'Vocab known transductively; test word frequencies are not used.',
                  'An improvement in token log-loss is not a decoding or semantic proof.']},
      'input_sha256':HASH,'folio_splits':{'base':base,'validation':validation,'test':test},
      'results':{}
}

for tr in ('zl','it'):
    G,vocab=global_prob(tr)
    A=arr(features(tr,validation,G));W=features(tr,test,G);B=arr(W)
    assert len(A)>0 and len(B)>0
    # Models: global only, global+all previous in paragraph, +last1, +last2.
    opts={}
    for family in ('global','paragraph','last1','last2'):
        configs=[(0.,0.)] if family=='global' else ([(h,0.) for h in GRID] if family=='paragraph'
              else [(h,r) for h in GRID for r in GRID if h+r<=.90])
        best=None
        for h,r in configs:
            if family=='last1':metric='one'
            else:metric='two'
            ss=float(score(A,h,r,metric).mean())
            if best is None or ss>best[0]:best=(ss,h,r)
        opts[family]={'validation_mean_logprob':best[0],'theta':best[1],'lambda':best[2]}
    evals={}
    for name,info in opts.items():
        col='one' if name=='last1' else 'two'
        lp=score(B,info['theta'],info['lambda'],col)
        evals[name]={'test_mean_nll':float(-lp.mean()), 'test_perplexity':float(np.exp(-lp.mean()))}
    # Paired folio tests with same test words.
    seenF=sorted(set(f for f,*_ in W))
    group={f:np.array([i for i,w in enumerate(W) if w[0]==f],dtype=int) for f in seenF}
    boot=np.random.default_rng(seed+(2 if tr=='it' else 1))
    BOOT=4999
    differences={}
    for left,right in [('paragraph','global'),('last1','paragraph'),('last2','paragraph'),('last2','last1'),('last2','global')]:
        def pv(model):
            item=opts[model];return score(B,item['theta'],item['lambda'],'one' if model=='last1' else 'two')
        d=pv(left)-pv(right)
        obs=float(d.mean());res=np.zeros(BOOT)
        for ib in range(BOOT):
            fs=boot.choice(seenF,len(seenF),replace=True)
            chunks=np.concatenate([group[f] for f in fs]);res[ib]=float(d[chunks].mean())
        differences[left+'_minus_'+right]={'mean_logprob_gain_nats_per_token':obs,
                'CI95_folio_bootstrap':[float(v) for v in np.quantile(res,[.025,.975])],
                'percent_perplexity_reduction':float(100*(1-np.exp(-obs)))}
    OUT['results'][tr]={'vocabulary_size':vocab,'n_validation_tokens':len(A),'n_test_tokens':len(B),
                  'n_test_folios':len(seenF), 'parameters':opts,'evaluation':evals,
                  'model_comparisons':differences}

    # The inference claim is conditional to paragraph order. Shuffle interior lines 999 times in heldout folios,
    # with endpoints fixed: compare relative gain of original fitted last2 model over fitted paragraph model.
    # The null for past/global prevalence remains a valid language model, not a label-permutation.
    nperm=999
    nul=np.zeros(nperm)
    pr=opts['paragraph'];rc=opts['last2']
    for k in range(nperm):
        s=np.random.default_rng(seed+100000*(1 if tr=='zl' else 2)+k)
        C=arr(features(tr,test,G,swap=s))
        nul[k]=np.mean(score(C,rc['theta'],rc['lambda'],'two')-score(C,pr['theta'],pr['lambda'],'two'))
    actual=differences['last2_minus_paragraph']['mean_logprob_gain_nats_per_token']
    OUT['results'][tr]['interior_shuffle_negative_control']={'n_perms':nperm,'mean_null_delta':float(nul.mean()),
        'sd_null_delta':float(nul.std(ddof=1)), 'observed_delta':actual,
        'p_above':float((1+np.count_nonzero(nul>=actual))/(nperm+1)),
        'q025_q975':[float(v) for v in np.quantile(nul,[.025,.975])]}

OUTPUT=ROOT/'RESULTS.json';OUTPUT.write_text(json.dumps(OUT,indent=2,ensure_ascii=False))
with (ROOT/'SUMMARY.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['transcription','model','validation_logprob','theta','lambda','test_nll','test_perplexity'])
    for tr,v in OUT['results'].items():
        for name,params in v['parameters'].items():
            ev=v['evaluation'][name]
            w.writerow([tr,name,params['validation_mean_logprob'],params['theta'],params['lambda'],ev['test_mean_nll'],ev['test_perplexity']])
print(json.dumps({k:{'model_comp':v['model_comparisons'],'models':v['parameters'],'shuffled':v['interior_shuffle_negative_control'],'test_tokens':v['n_test_tokens']} for k,v in OUT['results'].items()},indent=2))
