#!/usr/bin/env python3
"""Exploratory extension: recent edit-distance-one neighborhood vs exact-repetition context.
This is post-hoc and reuses examined heldout folios; no independent confirmation claim.
"""
from pathlib import Path
import numpy as np,json,csv,hashlib
from collections import Counter,defaultdict
ROOT=Path(__file__).resolve().parent
s=ROOT/'unified_gate.py'
ns={'__file__':str(s),'__name__':'unified_setup_only'}
text=s.read_text()
exec(compile(text[:text.index('results={}')],str(s),'exec'),ns)
folios,meta,base,val,test=ns['folios'],ns['meta'],ns['base'],ns['val'],ns['test']
Gfunc=ns['Gfunc'];LP=ns['LP'];best_on_val=ns['best_on_val'];FGRID=ns['FGRID'];BETAGRID=ns['BETAGRID']
RGRID=[0.,.005,.01,.02,.04,.08]

def index_vocab(vocab):
    # Deletion signatures support one substitution, one insertion, one deletion.
    by_del=defaultdict(set); by_mask=defaultdict(set)
    for w in vocab:
        for i in range(len(w)):
            by_del[w[:i]+w[i+1:]].add(w)
            by_mask[(len(w),i,w[:i],w[i+1:])].add(w)
    neighbors={}
    for w in vocab:
        out=set(by_del.get(w,()))
        for i in range(len(w)):
            out.update(by_mask.get((len(w),i,w[:i],w[i+1:]),()))
            d=w[:i]+w[i+1:]
            if d in vocab:out.add(d)
        out.discard(w)
        neighbors[w]=tuple(out)
    return neighbors

def data(t,fs,G,neighbors):
    feats=[];folio_ids=[]
    for f in fs:
        g=G[meta[f]]; g_y=sum(prob for w,prob in g.items() if w.startswith('y'))
        fol=Counter();nfol=0
        for par in folios[f]:
            hist=[]
            for row in par:
                words=row[t]
                if not words:continue
                recent=Counter(w for h in hist[-2:] for w in h)
                nrecent=sum(recent.values())
                q=Counter();given=0
                for w,c in recent.items():
                    nbs=neighbors.get(w,())
                    if not nbs:continue
                    given+=c
                    for nb in nbs:q[nb]+=c/len(nbs)
                if given:
                    for key in q:q[key]/=given
                fy=sum(v for w,v in fol.items() if w.startswith('y'))/nfol if nfol else 0.
                ry=sum(v for w,v in recent.items() if w.startswith('y'))/nrecent if nrecent else 0.
                qy=sum(p for w,p in q.items() if w.startswith('y'))
                for col,w in enumerate(words):
                    feats.append([g[w],fol[w]/nfol if nfol else 0.,
                                  recent[w]/nrecent if nrecent else 0.,q[w],
                                  g_y,fy,ry,qy,float(col==0),float(w.startswith('y'))])
                    folio_ids.append(f)
                hist.append(words);fol.update(words);nfol+=len(words)
    return np.asarray(feats,float),np.asarray(folio_ids,dtype=object)

def score(X,f,exact,edit,beta):
    bg=1-f-exact-edit
    p=bg*X[:,0]+f*X[:,1]+exact*X[:,2]+edit*X[:,3]
    py=bg*X[:,4]+f*X[:,5]+exact*X[:,6]+edit*X[:,7]
    if np.any(p<=0):raise ValueError('bad probability')
    return np.log(p)+X[:,8]*(X[:,9]*beta-np.log1p(np.expm1(beta)*py))

out={'status':'POSTHOC_EXPLORATORY_REUSES_PREVIOUS_TEST','hypothesis':'edit-one words from preceding two lines explain local dependencies better than exact-word memory',
     'control':'locked val/test folio lists from original prior analysis, no retuning on test','models':{}}
for trans in ['zl','it']:
    G,vocab=Gfunc(trans)
    neighbor=index_vocab(set(next(iter(G.values()))))
    V,_=data(trans,val,G,neighbor);T,fs=data(trans,test,G,neighbor)
    configs={
       'folio_position':[(f,0.,0.,b) for f in FGRID for b in BETAGRID],
       'folio_plus_exact':[(f,r,0.,b) for f in FGRID for r in RGRID for b in BETAGRID if f+r<.9],
       'folio_plus_edit1':[(f,0.,r,b) for f in FGRID for r in RGRID for b in BETAGRID if f+r<.9],
       'folio_plus_both':[(f,e,d,b) for f in FGRID for e in RGRID for d in RGRID for b in BETAGRID if f+e+d<.9]
    }
    fit={}
    for name,options in configs.items():
        w=max(options,key=lambda z:float(score(V,*z).mean()))
        lp=score(T,*w)
        fit[name]={'params_folio_exact_edit_beta':list(w),'nll':float(-lp.mean()),'mean_logprob':float(lp.mean())}
    u=np.unique(fs);ids={f:np.flatnonzero(fs==f) for f in u}
    rng=np.random.default_rng(20261112+12400+(trans=='it'))
    boots=[np.concatenate([ids[f] for f in rng.choice(u,len(u),replace=True)]) for _ in range(1999)]
    contrasts={}
    for a,b in [('folio_plus_exact','folio_position'),('folio_plus_edit1','folio_position'),('folio_plus_both','folio_position'),('folio_plus_both','folio_plus_exact')]:
        pa=score(T,*fit[a]['params_folio_exact_edit_beta']);pb=score(T,*fit[b]['params_folio_exact_edit_beta']);diff=pa-pb
        bs=np.array([diff[idx].mean() for idx in boots]);contrasts[f'{a}_minus_{b}']={'mean_gain_nats':float(diff.mean()),'ci95':np.quantile(bs,[.025,.975]).tolist()}
    out['models'][trans]={'n_validation':len(V),'n_test':len(T),'vocab':vocab,
       'with_edit_neighbors':sum(bool(x) for x in neighbor.values()),'fits':fit,'contrasts':contrasts}
(ROOT/'edit1_results.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
