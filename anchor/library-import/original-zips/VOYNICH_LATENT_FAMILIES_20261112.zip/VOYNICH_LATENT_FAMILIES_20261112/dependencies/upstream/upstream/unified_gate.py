#!/usr/bin/env python3
"""Exploratory unified probabilistic Voynich test (one source family, three hypotheses).
Baseline frequencies + past-folio field + last-two-lines + first-position y-prefix bias.
Folio-disjoint fixed split, validation-only hyperparameter selection, test-only scoring.
Does NOT generate text and is not a preregistered independent holdout.
"""
from pathlib import Path
import json, csv, math, hashlib, sys
from collections import Counter, defaultdict
import numpy as np
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'exp_next_token.py'
ns={'__file__':str(SOURCE),'__name__':'unified_setup'}
source=SOURCE.read_text(encoding='utf-8')
exec(compile(source[:source.index("for tr in ('zl','it'):")],str(SOURCE),'exec'),ns)
folios,meta,base,val,test=ns['folios'],ns['meta'],ns['base'],ns['validation'],ns['test']
Gfunc=ns['global_prob']; splits=ns['OUT']['folio_splits']
assert not(set(base)&set(test) or set(val)&set(test) or set(base)&set(val))
# Constants declared before data scoring; the family was chosen on previously explored manuscript data.
FGRID=[0.0,.02,.05,.10,.20,.35]
RGRID=[0.0,.01,.03,.06,.10]
BETAGRID=[0.0,.15,.30,.50,.75,1.0]

def rows_data(t,fs,G):
    feats=[]; firsty=[]; firsto=[]; row_meta=[]; totalrows=0
    for f in fs:
        g=G[meta[f]]
        g_y=sum(p for w,p in g.items() if w.startswith('y'))
        fol=Counter();nfol=0
        for par in folios[f]:
            prior=[]
            for j,row in enumerate(par):
                words=row[t]
                if not words:continue
                R=Counter(w for priorrow in prior[-2:] for w in priorrow)
                nR=sum(R.values())
                fy=sum(cnt for w,cnt in fol.items() if w.startswith('y'))/nfol if nfol else 0
                ry=sum(cnt for w,cnt in R.items() if w.startswith('y'))/nR if nR else 0
                for col,w in enumerate(words):
                    # conditional line-start is first token of the line, irrespective of paragraph position
                    feature=(g[w],fol[w]/nfol if nfol else 0,R[w]/nR if nR else 0,
                            g_y,fy,ry, float(col==0),float(w.startswith('y')),float(w.startswith('o')))
                    feats.append((f,feature))
                    if w.startswith('y'):firsty.append((f,col,j,w))
                    if w.startswith('o'):firsto.append((f,col,j,w))
                fol.update(words);nfol+=len(words);prior.append(words);totalrows+=1
    X=np.asarray([entry[1] for entry in feats],dtype=float)
    fs=np.asarray([entry[0] for entry in feats],dtype=object)
    return X,fs,firsty,firsto,totalrows

def LP(X,f,r,beta):
    bg=1-f-r
    pw=bg*X[:,0]+f*X[:,1]+r*X[:,2]
    assert np.all(pw>0)
    mass_y=bg*X[:,3]+f*X[:,4]+r*X[:,5]
    mult=np.exp(beta)
    return np.log(pw)+X[:,6]*(X[:,7]*beta-np.log1p((mult-1)*mass_y))

# For y/o conditional OR, compute observed at first vs nonfirst among words beginning y/o.
# This is not matching yX and oX suffixes; it is a coarser preregistered-in-script diagnostic.
def odds(X):
    yo=(X[:,7]+X[:,8])>0
    a=np.sum(yo & (X[:,7]==1) & (X[:,6]==1));b=np.sum(yo & (X[:,7]==1) & (X[:,6]==0))
    c=np.sum(yo & (X[:,8]==1) & (X[:,6]==1));d=np.sum(yo & (X[:,8]==1) & (X[:,6]==0))
    return {'y_first':int(a),'y_other':int(b),'o_first':int(c),'o_other':int(d),
            'OR_y_first_vs_o':float(a*d/(b*c)) if b*c else None}

def best_on_val(V, family):
    settings=[]
    for f in FGRID:
      for r in RGRID:
       if f+r>=.9:continue
       for beta in BETAGRID:
        if family=='global' and (f or r or beta):continue
        if family=='folio' and (r or beta):continue
        if family=='folio_position' and r:continue
        if family=='folio_recent' and beta:continue
        if family=='global_position' and (f or r):continue
        settings.append((f,r,beta))
    return max(settings,key=lambda p:float(np.mean(LP(V,*p))))

results={}
for trans in ['zl','it']:
    G,vocab=Gfunc(trans)
    V,_,_,_,nValRows=rows_data(trans,val,G)
    T,ff,_,_,nTestRows=rows_data(trans,test,G)
    modes=['global','folio','global_position','folio_position','folio_recent','unified']
    tuned={m:best_on_val(V,m) for m in modes}
    lp={m:LP(T,*tuned[m]) for m in modes}
    scores={m:{'params_folio_recent_beta':tuned[m], 'mean_logprob':float(lp[m].mean()),
               'nll':float(-lp[m].mean()),'perplexity':float(np.exp(-lp[m].mean()))} for m in modes}
    test_folios=sorted(set(ff))
    byfolio={f:np.flatnonzero(ff==f) for f in test_folios}
    comparisons={}
    pairings=[('folio','global'),('global_position','global'),('folio_position','folio'),
              ('folio_recent','folio'),('unified','folio_position'),('unified','folio_recent'),('unified','global')]
    B=2999;rng=np.random.default_rng(20261112+9500+(1 if trans=='it' else 0))
    sampled=[np.concatenate([byfolio[f] for f in rng.choice(test_folios,size=len(test_folios),replace=True)]) for _ in range(B)]
    for aa,bb in pairings:
        diff=lp[aa]-lp[bb]
        bs=np.asarray([diff[idx].mean() for idx in sampled])
        comparisons[f'{aa}_minus_{bb}']={'mean_gain_nats':float(diff.mean()),'folio_boot_ci95':np.quantile(bs,[.025,.975]).tolist(),
           'perplexity_reduction_percent':float(100*(1-np.exp(-diff.mean())))}
    # For an unoptimized out-of-sample positional diagnostic, y/o OR in all tokens.
    obs_yo=odds(T)
    # predicted (marginal) y/o conditional first-vs-other within token occurrences requires integration,
    # not generated by the model; leave absent rather than invent a simulated OR.
    results[trans]={'vocab_transductive_types':vocab,'validation_tokens':int(len(V)),
      'test_tokens':int(len(T)),'test_rows':nTestRows,'test_folios':len(test_folios),
      'model_scores':scores,'pairwise':comparisons,'heldout_y_o_unmatched':obs_yo}

status={'experiment':'VOYNICH_UNIFIED_GATE_20261112','status':'EXPLORATORY_HYPOTHESIS_REUSE_NOT_INDEPENDENT_CONFIRMATION',
 'full_text_generation':'NOT_IMPLEMENTED',
 'design':{'folio_splits':splits,'sha256':ns['HASH'],
 'model':'P(word)= (1-f-r)*global_Currier + f*empirical_past_folio + r*empirical_previous_two_lines; first word Y-initial multiply exp(beta), normalized by 1+(exp(beta)-1)*P(Y-initial).',
 'model_grids':{'folio':FGRID,'recent':RGRID,'beta_y_first':BETAGRID},
 'validation_only_tuning':True,'previous_test_reused_from_prior_research':True,
 'three_endpoints':['heldout folio gain','heldout local-two-lines gain','heldout first-position y-prefix gain'],
 'not_equivalent_to_suffix_matched_yX_oX_OR':True},
 'results':results}
(ROOT/'results.json').write_text(json.dumps(status,indent=2))
with (ROOT/'scores.csv').open('w',newline='') as out:
 w=csv.writer(out);w.writerow(['transcription','model','folio_weight','recent_weight','y_initial_beta','test_nll','test_perplexity'])
 for tr,v in results.items():
  for m,d in v['model_scores'].items():w.writerow([tr,m,*d['params_folio_recent_beta'],d['nll'],d['perplexity']])
print(json.dumps({'design':status['design']['model'],'results':results},indent=2))
