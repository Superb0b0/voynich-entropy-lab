#!/usr/bin/env python3
"""Family lineage vs independent invention. Posthoc new class, parameter choices fixed in script.
Scores on PREVIOUSLY INSPECTED folios. No search, no synthetic adaptation.
"""
from pathlib import Path
import csv,json,math,sys
import numpy as np
ROOT=Path(__file__).resolve().parent
src=(ROOT/'run.py').read_text(); ns={'__file__':str(ROOT/'run.py'),'__name__':'family_setup'}
exec(compile(src[:src.index('start=time.monotonic()')],str(ROOT/'run.py'),'exec'),ns)
folios,meta,base,val,test=ns['folios'],ns['meta'],ns['base'],ns['val'],ns['test']
build,mutation,summary,matched_or,apply_position=ns['build'],ns['mutation'],ns['summary'],ns['matched_or'],ns['apply_position']
SEEDS=[3301,3302,3303,3304,3305]
# beta: probability of exact reuse from recent 2 rows
# theta: probability of glyph mutation of a recent 2-row form
# rest: global base-vocabulary draw (no folio feedback, to avoid redundant mechanisms)
SETTINGS={'family_15_15':(.15,.15),'family_10_30':(.10,.30),'family_20_20':(.20,.20)}

def generate(trans,setting,seed,spec):
    reuse,novel=SETTINGS[setting];vocab,alpha,charw,licensed,distributions=spec
    rng=np.random.default_rng(seed)
    rows=[];fresh=set();attempts=0;success=0
    for f in sorted(test):
        words,cdf=distributions[meta[f]]
        for par in folios[f]:
            prev=[]
            for true_row in par:
                recent=[w for row in prev[-2:] for w in row]
                arr=[]
                for j in range(len(true_row[trans])):
                    R=rng.random()
                    if recent and R<reuse:
                        w=recent[int(rng.integers(len(recent)))]
                    elif R<reuse+novel:
                        attempts+=1
                        anchor=(recent[int(rng.integers(len(recent)))] if recent else words[int(np.searchsorted(cdf,rng.random(),side='right'))])
                        ww=mutation(anchor,rng,alpha,charw,licensed,True,vocab)
                        w=ww if ww else anchor
                        if ww:success+=1;fresh.add(w)
                    else:
                        w=words[int(np.searchsorted(cdf,rng.random(),side='right'))]
                    arr.append(w)
                prev.append(arr);rows.append(arr)
    apply_position(rows,seed)
    return rows,{'newtypes':len(fresh),'mutation_attempts':attempts,'mutation_success':success,'oov_occurrences':sum(w not in vocab for row in rows for w in row)}

result={'experiment':'EXP-MORPHOGEN-FAMILY-01','status':'POSTHOC_EXPLORATORY','settings':SETTINGS,'seeds':SEEDS,
'limits':['Old heldout folios already examined; no confirmatory testing.','New family mechanisms introduced after observing independent-mutation failure.','True test row and paragraph lengths reused.','Within-line y-first intervention is explicitly imposed, not emerging.','Both transcripts are of one manuscript.'],
'reference':{},'runs':[]}
for trans in ['zl','it']:
    spec=build(trans);reference=[list(row[trans]) for f in sorted(test) for p in folios[f] for row in p]
    result['reference'][trans]=summary(reference)
    for kind in SETTINGS:
        for seed in SEEDS:
            rows,extra=generate(trans,kind,seed,spec)
            z=summary(rows);z.update(extra);z.update({'trans':trans,'kind':kind,'seed':seed,'yo_or':matched_or(rows)['or']})
            result['runs'].append(z)
            print(trans,kind,seed,'hapax',round(z['hapax'],3),'density',round(z['density'],3),'adj',round(z['adjacency'],3),'rep',round(z['repetition'],3),'edit1',round(z['edit1_between_adjacent_rows'],3),flush=True)
(ROOT/'family_results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
with (ROOT/'family_runs.csv').open('w',newline='') as fh:
    w=csv.DictWriter(fh,fieldnames=list(result['runs'][0]));w.writeheader();w.writerows(result['runs'])
print('DONE',len(result['runs']))
