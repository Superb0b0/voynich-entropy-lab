#!/usr/bin/env python3
"""Exploratory generative falsification; all mutations depend on BASE folios only.
No tuning against synthetic or heldout results. Same heldout layout (not lexicon) as prior work.
"""
import sys, json, csv, math, hashlib, time
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np
ROOT=Path(__file__).resolve().parent
PARENT=(ROOT/'upstream' if (ROOT/'upstream').exists() else ROOT.parent/'VOYNICH_GENERATIVE_GATE_20261112')
ns={'__file__':str(PARENT/'generate_gate.py'),'__name__':'morph_setup_only'}
src=(PARENT/'generate_gate.py').read_text()
exec(compile(src[:src.index('rows_out=[]')],str(PARENT/'generate_gate.py'),'exec'),ns)
folios,meta,base,val,test=ns['folios'],ns['meta'],ns['base'],ns['val'],ns['test']
summary=ns['summary']; matched_or=ns['matched_or']
assert len(set(test)&set(base))==len(set(test)&set(val))==0

# Freeze rules before observing any generated output. Pre-specified seed and innovation fractions.
SEEDS=[2201,2202,2203,2204,2205]
KINDS={'base_only':(0,False,False), 'random_mut15':(.15,False,False),
       'licensed_mut15':(.15,True,False),'licensed_mut30':(.30,True,False),
       'licensed_recent15':(.15,True,True)}
HIST_FOLIO=.05; POSITION_BETA=1.
VOWELS='aeiouy'

def build(trans):
    counts={c:Counter() for c in ('A','B','?')}
    for f in base:
        for par in folios[f]:
            for row in par: counts[meta[f]].update(row[trans])
    vocab=set().union(*(set(x) for x in counts.values()))
    chars=Counter(''.join(w for c in counts.values() for w,n in c.items() for _ in range(min(n,20))))
    alphabet=sorted(chars)
    charweights=np.asarray([chars[c] for c in alphabet],dtype=float);charweights/=charweights.sum()
    licensed=set()
    for w in vocab:
        licensed.update(zip(w,w[1:]))
    for c in counts:
        if not counts[c]:counts[c]=sum(counts.values(),Counter())
    by_class={}
    for c,cn in counts.items():
        words=sorted(cn);pr=np.asarray([cn[w]+.1 for w in words],dtype=float);pr/=pr.sum()
        by_class[c]=(words,np.cumsum(pr))
    return vocab,alphabet,charweights,licensed,by_class

def mutation(word,rng,alphabet,charweights,licensed,mode_licensed,vocab):
    # A single character edit on a sampled parent. All character weights and permissible
    # glyph bigrams are learned from BASE only; never test lexical content.
    if not word:return None
    for attempt in range(24):
        op=int(rng.integers(3));i=int(rng.integers(len(word)+(op==1)))
        if op==0:  # substitution
            ch=alphabet[int(rng.choice(len(alphabet),p=charweights))]
            cand=word[:i]+ch+word[i+1:]
        elif op==1: # insertion
            ch=alphabet[int(rng.choice(len(alphabet),p=charweights))]
            cand=word[:i]+ch+word[i:]
        else: # deletion
            cand=word[:i]+word[i+1:]
        if not 2<=len(cand)<=16 or cand==word or cand in vocab:continue
        if mode_licensed and any(pair not in licensed for pair in zip(cand,cand[1:])):continue
        return cand
    return None

def generate(trans,kind,seed,spec):
    innovate,licensed_on,recent_on=KINDS[kind]
    vocab,alph,weights,licensed,by=spec
    rng=np.random.default_rng(seed)
    out=[];newtypes=set();mutation_attempts=0;mutation_success=0
    for f in sorted(test):
        class_words,cdf=by[meta[f]]
        fol_history=[]
        for par in folios[f]:
            last=[]
            for true_row in par:
                row=[];recent=[w for r in last[-2:] for w in r]
                for i in range(len(true_row[trans])):
                    # Keep baseline 5% folio memory and same explicit first-y preference;
                    # innovate on top of this using 15/30% single-edit proposed forms.
                    if fol_history and rng.random()<HIST_FOLIO:
                        parent=fol_history[int(rng.integers(len(fol_history)))]
                    else:
                        parent=class_words[int(np.searchsorted(cdf,rng.random(),side='right'))]
                    w=parent
                    if innovate and rng.random()<innovate:
                        mutation_attempts+=1
                        if recent_on and recent and rng.random()<.5:
                            parent=recent[int(rng.integers(len(recent)))]
                        trial=mutation(parent,rng,alph,weights,licensed,licensed_on,vocab)
                        if trial is not None:
                            w=trial;newtypes.add(w);mutation_success+=1
                    # Rejection on y-prefix for first token; exact reweighting of the
                    # just proposed token distribution is approximated by repeat draws,
                    # using independently drawn full proposals, NOT accepting a fixed draw.
                    # To avoid extra proposal complexity, use y-initial boosting by editing
                    # neither form nor parent: sample a new base word if first-token fails.
                    if i==0 and kind=='base_only':
                        # Known fixed simplistic y preference. For inventive models, preserve
                        # SAME probability by candidate-rejection separately below.
                        pass
                    row.append(w)
                last.append(row);fol_history.extend(row);out.append(row)
    return out,{'newtypes':len(newtypes),'mutation_attempts':mutation_attempts,'mutation_success':mutation_success,
                'newtype_occurrences':sum(w not in vocab for row in out for w in row)}

# Preserve explicitly learned y-initial first-row mechanism in an independent,
# local deterministic postgeneration operation applying same procedure to ALL modes.
def apply_position(rows,seed):
    # Position-only stable swap within a line, not more randomness across modes.
    # Keep token multiset and line lengths fixed. Gate compares y/o OR with caution.
    rng=np.random.default_rng(seed+900000)
    for row in rows:
        if len(row)<2 or row[0].startswith('y'):continue
        y=[j for j in range(1,len(row)) if row[j].startswith('y')]
        if y and rng.random()<.42:
            j=y[int(rng.integers(len(y)))];row[0],row[j]=row[j],row[0]

start=time.monotonic();out=[];report={'experiment':'EXP-MORPHOGEN-01','status':'EXPLORATORY_REUSED_TEST','seeds':SEEDS,'models':KINDS,
 'limits':['Heldout split already investigated in earlier work; not blind.',
 'Original line and paragraph lengths are supplied; not generated.',
 'Position preference uses a fixed within-line swap; cannot count as emergent.',
 'Mutation distribution and base vocabulary learned only on original base-folios.',
 'IT2a and ZL3b are correlated readings of the same manuscript.',
 'No synthetic-result tuning; implementation conventions are exploratory.'], 'reference':{},'runs':[]}
for trans in ('zl','it'):
    spec=build(trans)
    real=[list(row[trans]) for f in sorted(test) for p in folios[f] for row in p]
    ref=summary(real);ref['yo_or']=matched_or(real)['or'];report['reference'][trans]=ref
    print('START',trans,'test',ref['tokens'],'vocab_base',len(spec[0]),flush=True)
    for kind in KINDS:
        for seed in SEEDS:
            rows,details=generate(trans,kind,seed,spec)
            apply_position(rows,seed)
            metrics=summary(rows)
            metrics['yo_or']=matched_or(rows)['or']
            row=dict(trans=trans,kind=kind,seed=seed,**metrics,**details)
            out.append(row)
            print(trans,kind,seed, 'hapax',round(metrics['hapax'],3),'dens',round(metrics['density'],3),'adj',round(metrics['adjacency'],3),'rep',round(metrics['repetition'],3),flush=True)
    print('TRANS COMPLETED',trans,'seconds',int(time.monotonic()-start),flush=True)
report['runs']=out
(ROOT/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
with (ROOT/'runs.csv').open('w',newline='') as fh:
    w=csv.DictWriter(fh,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
print('FINISHED',len(out),'elapsed',time.monotonic()-start,flush=True)
