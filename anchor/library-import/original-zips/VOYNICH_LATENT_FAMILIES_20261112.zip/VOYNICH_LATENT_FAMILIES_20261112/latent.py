#!/usr/bin/env python3
"""EXP-LATENT-FAMILIES-01 exploratory, never blind: parameters committed in file before running.
Only training folio vocabulary enters generation; heldout rows provide layout lengths ONLY.
No explicit y-position swap. The hypothesis is latent family anchors with short-lived active state.
"""
from pathlib import Path
import numpy as np, json, csv, math, hashlib, time
from collections import Counter
ROOT=Path(__file__).resolve().parent
up=ROOT/'dependencies'/'family.py'
s=up.read_text(); env={'__file__':str(up),'__name__':'latent_setup'}
exec(compile(s[:s.index('result={')],str(up),'exec'),env)
folios,meta,base,val,test=env['folios'],env['meta'],env['base'],env['val'],env['test']
build,mutation,summary,matched_or=env['build'],env['mutation'],env['summary'],env['matched_or']
assert not(set(base)&set(test) or set(val)&set(test))
SEEDS=[7601,7602,7603]
# Two frozen hypotheses, plus a global unmodified distribution negative control.
SETTINGS={
 'global_control':dict(family_prob=0.,recent_prob=0.,novel_prob=0.,num_roots=0,ttl=0),
 'latent_narrow':dict(family_prob=.30,recent_prob=.10,novel_prob=.35,num_roots=12,ttl=3),
 'latent_broad':dict(family_prob=.22,recent_prob=.08,novel_prob=.45,num_roots=24,ttl=6),
}

def generate(trans,mode,seed,spec):
 cfg=SETTINGS[mode];vocab,abc,charw,licensed,by=spec;rng=np.random.default_rng(seed)
 output=[];layout=[];channels=Counter();
 for f in sorted(test):
  wordlist,cdf=by[meta[f]]
  def global_pick():return wordlist[int(np.searchsorted(cdf,rng.random(),side='right'))]
  roots=[global_pick() for _ in range(cfg['num_roots'])]
  activ=[];par_id=0
  for par in folios[f]:
   # Folio families persist, activated for short bursts of lines.
   if roots:
    ids=rng.choice(len(roots),size=min(4,len(roots)),replace=False)
    activ=[(roots[int(j)],cfg['ttl']) for j in ids]
   prev=[]
   for source_row in par:
    recent=[w for r in prev[-2:] for w in r]
    row=[]
    for j in range(len(source_row[trans])):
     channel='global';root=None
     p=rng.random()
     if roots and p<cfg['family_prob']:
      channel='family'; root=activ[int(rng.integers(len(activ)))][0]
     elif recent and p<cfg['family_prob']+cfg['recent_prob']:
      channel='recent';root=recent[int(rng.integers(len(recent)))]
     if root is None:root=global_pick()
     # Same mutation test independently in family/recent/global mechanisms;
     # no direct OOV test lexical access.
     if rng.random()<cfg['novel_prob']:
      candidate=mutation(root,rng,abc,charw,licensed,True,vocab)
      if candidate:root=candidate;channel+='_edit'
     row.append(root);channels[channel]+=1
    output.append(row);layout.append((f,par_id))
    prev.append(row)
    if activ:
     updated=[]
     for root,lifetime in activ:
      if lifetime>1:updated.append((root,lifetime-1))
      else:updated.append((roots[int(rng.integers(len(roots)))],cfg['ttl']))
     activ=updated
   par_id+=1
 return output,layout,channels

def local_metrics(rows,layout):
 J,R,CrossJ,CrossR=[],[],[],[]
 for i in range(1,len(rows)):
  a=set(rows[i-1]);b=set(rows[i]);u=len(a|b)
  j=len(a&b)/u if u else 0.
  r=sum(w in a for w in rows[i])/max(len(rows[i]),1)
  if layout[i]==layout[i-1]:J.append(j);R.append(r)
  else:CrossJ.append(j);CrossR.append(r)
 return dict(jaccard_within=float(np.mean(J)),repetition_within=float(np.mean(R)),jaccard_cross=float(np.mean(CrossJ)),repetition_cross=float(np.mean(CrossR)),pairs_within=len(J))

out={'experiment':'EXP-LATENT-FAMILIES-01','status':'EXPLORATORY_POSTHOC_REUSED_HOLDOUT','settings':SETTINGS,'seeds':SEEDS,'limitations':['Prior heldout folios were analyzed repeatedly in prior experiments, so this is not blind.','True heldout line length/paragraph boundaries supplied to generators.','Families initialized from base-fold Currier distributions, NOT inferred from hidden heldout words.','Parameters selected a priori for this run but hypothesis class was suggested by inspecting prior outcomes.','No positional yX/oX mechanism inserted; expected failure is informative.'], 'reference':{},'runs':[]}
for trans in ('zl','it'):
 spec=build(trans)
 ref=[list(row[trans]) for f in sorted(test) for par in folios[f] for row in par]
 layout=[(f,p) for f in sorted(test) for p,par in enumerate(folios[f]) for row in par]
 target={**summary(ref),**local_metrics(ref,layout),'yo_or':matched_or(ref)['or']}
 out['reference'][trans]=target
 print('REAL',trans,{k:round(target[k],4) for k in ['density','adjacency','repetition','hapax','jaccard_within','repetition_within','yo_or']},flush=True)
 for mode in SETTINGS:
  for seed in SEEDS:
   rows,layout,ch=generate(trans,mode,seed,spec)
   assert len(rows)==len(ref) and all(len(a)==len(b) for a,b in zip(rows,ref))
   score={**summary(rows),**local_metrics(rows,layout),'yo_or':matched_or(rows)['or']}
   row={'trans':trans,'model':mode,'seed':seed,**score,'channels':dict(ch)}
   out['runs'].append(row)
   print('RUN',trans,mode,seed,{k:round(score[k],4) for k in ['density','adjacency','repetition','hapax','jaccard_within','repetition_within','yo_or']},flush=True)
(ROOT/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
keys=[k for k in out['runs'][0] if k!='channels']
with (ROOT/'runs.csv').open('w',newline='') as fh:
 w=csv.DictWriter(fh,fieldnames=keys);w.writeheader();w.writerows([{k:r[k] for k in keys} for r in out['runs']])
print('COMPLETED',len(out['runs']),flush=True)
