# EXP-LATENT-FAMILIES-01/02 | Voynich | 12 novembre 2026

**Stato: ESPLORATIVO, GATE NON SUPERATO. Non è una decifrazione.**

## Che cosa è stato eseguito

- `latent.py`: 18 generazioni in due trascrizioni, tre modelli × tre semi; i modelli e i semi sono dichiarati nel sorgente prima dell'esecuzione.
- `latent_persistence.py`: 12 generazioni aggiuntive, di cui sei ripetizioni del modello broad e sei modifiche post-hoc per persistenza di tre famiglie su quattro attraverso il confine di paragrafo.
- `runs.csv`, `persistence_runs.csv`, `SUMMARY.csv`: dati e medie; `results.json`, `persistence_results.json`: dati completi.
- `dependencies/`: sorgenti e trascrizioni congelati dall'esperimento precedente. Lo script non usa il contenuto lessicale dei folii di controllo per generare parole, ma **usa la lunghezza reale di ciascuna riga e la struttura dei paragrafi**.

Riproduzione offline: `python latent.py && python latent_persistence.py`; richiede NumPy. Tutto viene rieseguito sullo *stesso* campione già analizzato nei lavori precedenti. Non può essere considerato un test cieco.

## Verdetto

Le famiglie latenti riproducono in modo approssimativo densità, adiacenza e ripetizione, ma **non** il tasso degli hapax, l'arricchimento di varianti edit-1, il segnale posizionale yX/oX, né tutti i confini di paragrafo. La variante post-hoc con famiglie persistenti riduce soprattutto il deficit ai confini. Nessun generatore è compatibile con tutti i criteri.

## Limiti

- Parametri esplorativi; selezione delle famiglie dopo analisi dei fallimenti precedenti.
- Solo tre semi per modello e trascrizione; non adeguato a stime precise degli estremi.
- I folii di controllo erano già stati esaminati; nessuna validazione indipendente.
- I due trascritti rappresentano lo stesso manoscritto, non due campioni indipendenti.
- Forma delle righe e confini dei paragrafi sono *forniti* al generatore, non predetti.
- Nessuna inferenza sul linguaggio in chiaro o sulla verità storica dell'algoritmo.
- La pipeline RC1.4.2 resta immutata in `CLOSED_PENDING_VALIDATION`.
