# EXP-OBJECT-02

Nuovo pilot quantitativo su 48 pagine botaniche con attestazioni esplicite di presenza/assenza di fiori. **Risultato nullo dopo correzione multipla**, con sensibilità a descrizioni iconografiche contraddittorie. `REPORT.md` contiene i dati, le fonti, il metodo e i limiti.

Per riprodurre: `python pilot.py` e i due programmi `pilot_excluding_*.py`.

Sorgente botanica esterna: `geoffitect/voynich/data/analysis/plant_analysis.json` (Git blob `d7d79ec9b2808d46a37bf1349919fa08f00ce2a3`), compilazione da voynich.nu. I campi *non menzionati* non sono trattati come assenti. I file testuali forniti derivano dai materiali precedentemente verificati del progetto.
