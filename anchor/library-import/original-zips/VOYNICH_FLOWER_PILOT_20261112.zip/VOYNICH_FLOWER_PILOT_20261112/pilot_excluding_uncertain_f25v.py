#!/usr/bin/env python3
"""Exploratory source-derived, explicitly positive/negative flowers pilot. No unmentioned=absent."""
import csv,re,json,collections,hashlib
from pathlib import Path
import numpy as np
BASE=Path(__file__).resolve().parent/'sensitivity_without_f25v';BASE.mkdir(exist_ok=True)
SRC=BASE.parent/'input'
positive='f1v f2r f4r f4v f7r f8v f9v f11r f11v f14r f14v f15r f16v f17r f18r f19r f20r f20v f22r f22v f23r f24r f26r f27r f27v f28v f29v f30r f32r f32v f33r f33v f34r f35r f38v f39v f40r f40v f42v f44r f45r f45v f47v f48v'.split()
negative='f3r f8r f47r'.split()
label={x:1 for x in positive};label.update({x:0 for x in negative});assert len(label)==47
text=collections.defaultdict(list)
for line in (SRC/'zl3b_P_ms408.tsv').read_text().splitlines():
    f,body=line.split('\t',1);text[f]+=body.split()
meta={}
for l in (SRC/'ZL3b-n.txt').read_text().splitlines():
    m=re.match(r'^<(f\d+[rv])>\s*<!([^\n]+)',l)
    if m:meta[m[1]]=dict(re.findall(r'\$(\w+)=([^\s>]+)',m[2]))
rows=[]
for f in sorted(label):
    if f not in text or f not in meta: continue
    words=text[f];m=meta[f];n=len(words)
    if n<10:continue
    d={'folio':f,'label':label[f],'evidence':'flower feature vs explicit no_flowers','tokens':n,'quire':m.get('Q','?'),'currier':m.get('L','?')}
    for name,fn in {
        'prefix_qo':lambda w:w.startswith('qo'),
        'prefix_ch':lambda w:w.startswith('ch'),
        'prefix_sh':lambda w:w.startswith('sh'),
        'prefix_ol':lambda w:w.startswith('ol'),
        'suffix_dy':lambda w:w.endswith('dy'),
        'suffix_y':lambda w:w.endswith('y'),
        'mean_length':len,
    }.items():d[name]=sum(fn(w) for w in words)/n
    d['type_token_ratio']=len(set(words))/n
    rows.append(d)
assert sum(x['label']==0 for x in rows)>=3
features=[x for x in rows[0] if x not in ('folio','label','evidence','tokens','quire','currier')]
labels=np.array([x['label'] for x in rows]);mat=np.array([[x[k] for k in features] for x in rows]);
# Standardize by overall dispersion, not outcome label. Class means unweighted by folio.
scale=np.std(mat,axis=0);scale[scale<1e-10]=1
obs=(mat[labels==1].mean(axis=0)-mat[labels==0].mean(axis=0))/scale
# Conditional permutation within exact Currier x quire strata, 19999 draws. 
strata=collections.defaultdict(list)
for i,x in enumerate(rows):strata[(x['currier'],x['quire'])].append(i)
valid=[v for v in strata.values() if len(v)>1 and 0<labels[v].sum()<len(v)]
rng=np.random.default_rng(261112)
R=19999;counts=np.ones(len(features));maxcounts=np.ones(len(features));distinct=set()
for _ in range(R):
    y=labels.copy()
    for ids in valid:y[ids]=rng.permutation(labels[ids])
    d=(mat[y==1].mean(axis=0)-mat[y==0].mean(axis=0))/scale
    counts+=(np.abs(d)>=np.abs(obs)-1e-12)
    maxcounts+=(np.max(np.abs(d))>=np.abs(obs)-1e-12)
results=[]
for j,f in enumerate(features):results.append({'feature':f,'positive_mean':float(mat[labels==1,j].mean()),'explicit_negative_mean':float(mat[labels==0,j].mean()),'standardized_difference':float(obs[j]),'conditional_perm_p_two_sided':float(counts[j]/(R+1)),'maxT_p_fwer':float(maxcounts[j]/(R+1))})
with (BASE/'labels_and_features.csv').open('w',newline='') as fo:
    w=csv.DictWriter(fo,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
with (BASE/'results.csv').open('w',newline='') as fo:
    w=csv.DictWriter(fo,fieldnames=list(results[0]));w.writeheader();w.writerows(results)
summary={'status':'EXPLORATORY_DESCRIPTIVE_AND_CONDITIONAL_PERMUTATION','source':'geoffitect/voynich data/analysis/plant_analysis.json; Git blob d7d79ec9b2808d46a37bf1349919fa08f00ce2a3; descriptions secondary and not independently re-reviewed','n_labeled':len(label),'n_in_P_corpus':len(rows),'n_positive':int(labels.sum()),'n_explicit_negative':int((1-labels).sum()),'n_strata':len(strata),'strata_with_outcome_variation':{str(k):[int(sum(labels[v])),int(len(v)-sum(labels[v]))] for k,v in strata.items() if 0<labels[v].sum()<len(v)},'permutations':R,'feature_count':len(features),'lowest_unadjusted_p':min(x['conditional_perm_p_two_sided'] for x in results),'lowest_maxT_p':min(x['maxT_p_fwer'] for x in results),'flags':['Secondary feature descriptions not independently verified; explicit no_flowers only treated as negative','Labels selected from feature subset with positive/negative explicit statements; source missingness nonrandom','Small n of true negative observations; large confidence uncertainty','Fixed 8 simple text statistics, no word-search or gloss selection','Permutation conditional on Currier x quire; strata with no within-group label variation remain fixed','Not a blind semantic validation; never use results as meaning decipherment','RC1.4.2 not modified'],'source_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [SRC/'zl3b_P_ms408.tsv',SRC/'ZL3b-n.txt']}}
(BASE/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({'summary':summary,'results':results},indent=2))
