# EXP-OBJECT-02 | Pilot di presenza/assenza floreale nel Voynich

**Data:** 12 novembre 2026. **Esito:** `NEGATIVE / EXPLORATORY_ONLY`. Nessuna associazione semantica confermata.

## Domanda

Le pagine botaniche esplicitamente descritte con fiori presentano differenze testuali rispetto a quelle esplicitamente descritte senza fiori, dopo il controllo della quire e della varietà Currier?

## Fonti e problemi di affidabilità

- Compilazione botanica secondaria: `geoffitect/voynich/data/analysis/plant_analysis.json`, Git blob `d7d79ec9b2808d46a37bf1349919fa08f00ce2a3`, dichiarata derivata da descrizioni di voynich.nu. NON è una codifica indipendente e blindata delle immagini.
- Consultazione incrociata: https://voynich.nu/q01/index.html, https://voynich.nu/q04/index.html, https://voynich.nu/q06/index.html.
- `f3r`, `f8r`, `f47r` hanno descrizioni esplicite di assenza di fiori. `f25v` è descritto come apparentemente privo di fiori, ma difficile da leggere: **incerto**. `f7r` ha descrizioni confliggenti: l'illustrazione è definita «grande fiore», mentre una lista Gheuens/Rapaport dice «no fruits or flowers». Trattarlo come positivo certo è discutibile.
- Non citati ≠ assenti: esclusi tutti i folii senza un'attestazione positiva o negativa esplicita. Le descrizioni di parti fiorite non implicano una specie botanica certa.
- Trascrizione: ZL3b, solo loci P; profili visivi V1 non impiegati. Nessuna pipeline RC1.4.2 eseguita.

## Impostazione sperimentale

- **Set base:** 48 pagine botaniche, 44 positive e 4 negative esplicite nella fonte secondaria.
- Otto feature testuali **definite prima del calcolo**: percentuale di token con prefisso `qo`, `ch`, `sh`, `ol`; suffisso `dy` e `y`; lunghezza media; rapporto tipi/token.
- Differenze fra medie di folio (non fra singoli token); normalizzate con deviazione standard dell'intero campione.
- 19.999 permutazioni condizionali all'incrocio Currier × quire, conservando il numero di pagine di ogni classe entro lo strato; test bilaterali e correzione max-statistica sulle otto misure. Seme 261112. Gli strati privi di variazione delle classi non vengono permutati.

## Risultati

| Campione | Positivi | Negativi | Minimo p nominale | Minimo p maxT corretto | Conclusione |
|---|---:|---:|---:|---:|---|
| Base | 44 | 4 | 0,01555 | 0,40765 | Nessuna evidenza corretta |
| Escluso `f25v` incerto | 44 | 3 | 0,06055 | 0,72190 | Nessuna evidenza |
| Esclusi `f25v` e `f7r` controversi | 43 | 3 | 0,07400 | 0,59555 | Nessuna evidenza |

Nel campione base il suffisso `y` compare nel 36,97% dei token delle pagine positive e nel 24,34% delle negative. Ma l'apparente differenza non resiste né alla correzione multipla né all'esclusione dei casi iconografici controversi.

## Perché questa non è una prova semantica

1. Solo 3–4 pagine negative: scarsa potenza e sensibilità a singoli folii.
2. Selezione delle pagine da un dataset descrittivo incompleto e non casuale: i risultati condizionali non si estendono a tutte le pagine botaniche.
3. Alcune etichette sono incerte o contraddittorie, e non sono state aggiudicate da annotatori indipendenti e ciechi al testo.
4. Le feature testuali sono generiche e associate a sezione, mano e trascrizione; nessuna è la lettura di una parola come «fiore».
5. Il Voynich è già stato esplorato ripetutamente: il campione non è un vero test cieco.

## Decisione

`FAIL_CLOSED`: nessuna inferenza parola–oggetto; nessuna promozione di etichette non verificate a ground truth, e nessuna modifica della pipeline RC1.4.2. La prossima condizione per un test attendibile è un set annotato in cieco con positivi e negativi sufficienti all'interno della stessa quire/Currier, preferibilmente due annotatori indipendenti e verifiche di accordo.

## Riproduzione

Dalla cartella estratta, con Python 3 e NumPy:

```
python pilot.py
python pilot_excluding_uncertain_f25v.py
python pilot_excluding_uncertain_f25v_f7r.py
```

I file CSV con le feature per pagina e con i risultati completi sono inclusi. Tutti i numeri del rapporto sono stati calcolati da questi script, con semi deterministici.
