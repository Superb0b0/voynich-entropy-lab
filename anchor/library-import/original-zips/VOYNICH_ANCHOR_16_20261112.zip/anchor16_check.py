import csv, itertools, json, pathlib, hashlib
base=pathlib.Path('/mnt/data/VOYNICH_ANCHOR_15_20261112/REGISTER_VISUAL_MATCHES.csv')
rows=list(csv.DictReader(base.open()))
by={r['folio_erbario']:r for r in rows}
a,b=by['f18v'],by['f23r']
c,d=by['f48r'],by['f48v']
def parse(r):
    rr,cc=r['posizione_riga_colonna'].split(':')
    return (r['frammento_farmaceutico'],int(rr),int(cc))
assert a['frammento_farmaceutico']==b['frammento_farmaceutico']=='f102r2'
assert c['frammento_farmaceutico']==d['frammento_farmaceutico']=='f89v3'
slots=[parse(by[k]) for k in ['f47v','f32v','f18v','f23r']]
possible=list(itertools.combinations(slots,2))
same_row=[(x,y) for x,y in possible if x[1]==y[1]]
adj=[(x,y) for x,y in same_row if abs(x[2]-y[2])==1]
result={'source_sha256':hashlib.sha256(base.read_bytes()).hexdigest(), 'n_visual_matches':len(rows),'f18v_f23r':{'source_relation':'opposite leaves of a single bifolio; same face', 'target':[parse(a),parse(b)],'same_row_adjacent':True},'f48r_f48v':{'source_relation':'two faces of one leaf','target':[parse(c),parse(d)],'same_row_adjacent':False},'conditional_permutation':{'scope':'four catalogued correspondences on f102r2, restricted to two rows with two observed matched slots each','slots':slots,'pairs_total':len(possible),'same_row_pairs':len(same_row),'same_row_adjacent_pairs':len(adj),'conditional_p_same_row':len(same_row)/len(possible),'caution':'descriptive combinatorial check only: no independent sampling; discovered after inspecting pair; cannot assign discovery significance'},'external_parallel':{'name':'British Library Egerton MS 747, Tractatus de herbis','role':'potential comparison source, not verified visual match','catalog_url':'https://searcharchives.bl.uk/catalog/032-001983805'},'semantic_claim':'NONE'}
out=pathlib.Path('/mnt/data/ANCHOR_16_ORDER_TEST.json');out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
