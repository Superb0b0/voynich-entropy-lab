# ANCHOR-16 | Verifica della conservazione della vicinanza fisica
**Data:** 12 novembre 2026. **Stato:** controllo documentale e combinatorio esplorativo, NON decifrazione.

## Dati di partenza
Nove corrispondenze proposte fra piante botaniche e frammenti farmaceutici, già elencate nell'inventario ANCHOR-15. Le corrispondenze derivano dai cataloghi di René Zandbergen e Jorge Stolfi, e NON sono state nuovamente certificate dal confronto cieco delle immagini.

- La coppia f18v/f23r appartiene allo stesso lato di un bifoglio ed è riprodotta nei frammenti 212 e 213, affiancati sulla riga 3 di f102r2.
- Le piante f48r/f48v sono disegnate sui due lati dello stesso folio e sono associate a frammenti sulla medesima pagina f89v3, ma in righe distinte: 3:4 e 1:5. È un controesempio contro la versione **universale** dell'ipotesi 'oggetti fisicamente associati sono sempre riprodotti affiancati'. Le due relazioni fisiche però non sono identiche (bifoglio, stesso lato, contro stesso foglio su lati opposti): non è una confutazione della versione stretta limitata allo stesso lato del bifoglio.

## Controllo combinatorio condizionato
Tra i quattro frammenti di f102r2 già catalogati come copia di una pianta botanica (205, 206, 212, 213) vi sono quattro posti in due righe, due posti per riga. Se la coppia delle fonti f18v/f23r fosse fissata **in anticipo** e i due posti a lei attribuiti fossero scelti uniformemente tra i sei possibili accoppiamenti, solo due coppie di posizioni sarebbero affiancate nella medesima riga (2/6=1/3). È un controllo puramente descrittivo, non un valore p inferenziale: l'osservazione della coppia è post-selezione e la distribuzione realmente generativa non è nota.

## Analogo esterno documentato, non identificazione
L'**Egerton MS 747** della British Library contiene il *Tractatus de herbis* con immagini botaniche e rubriche leggibili. La scheda pubblica localizza il trattato ai ff. 1r–106v e immagini di piante anche ai ff. 106v–109r. Serve come potenziale corpus di confronto, ma **non è stata verificata** la corrispondenza di una sua pianta con f18v o f23r; non si assegna pertanto alcun nome botanico.

## Esito
- Regola universale di conservazione della vicinanza: NON SOSTENUTA, controesempio f48r/f48v.
- Regola ristretta al bifoglio visto sullo stesso lato: compatibile con un singolo esempio, NON DIMOSTRATA.
- Significato delle etichette: SCONOSCIUTO.
- Stato RC1.4.2 immutato, nessun file storico modificato.

## Riferimenti
- https://www.voynich.nu/q03/index.html
- https://voynich.nu/q19/index.html
- https://www.ic.unicamp.br/en/~stolfi/EXPORT/voynich/00-06-07-word-grammar/Notes/064/work/projects/voynich/projects/programs/c/big/big/projects/voynich/Notes/091/report/report_091.html
- https://www.voynich.nu/q06/index.html
- https://searcharchives.bl.uk/catalog/032-001983805
