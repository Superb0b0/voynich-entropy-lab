from pathlib import Path
import csv,json,hashlib
from scipy.stats import fisher_exact
p=Path(__file__).resolve().parents[1]/'ANCHOR_20_20261112'/'pairs_11.csv'
rows=list(csv.DictReader(p.open()))
pos=[x for x in rows if x['historical_class']=='positive']
poor=[x for x in rows if x['historical_class']=='poor']
out={'source':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'n_positive':len(pos),'n_poor':len(poor),'features':{}}
for feat in ['root_match','leaves_match','flower_match']:
 a=sum(int(x[feat]) for x in pos);b=len(pos)-a;c=sum(int(x[feat]) for x in poor);d=len(poor)-c
 stat,pval=fisher_exact([[a,b],[c,d]],alternative='greater')
 out['features'][feat]={'table':[[a,b],[c,d]],'fisher_one_sided_p':float(pval),'odds_ratio':str(stat)}
print(json.dumps(out,indent=2))
(Path(__file__).parent/'result.json').write_text(json.dumps(out,indent=2)+'\n')
