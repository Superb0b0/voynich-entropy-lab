# ANCHOR-21 — Verifica di selezione e protocollo iconografico

Data 12 novembre 2026. Stato: audit documentale riproducibile, non verifica indipendente delle immagini e non decifrazione.

## Fonte
Jorge Stolfi, *Repeated plant drawings* (pagina aggiornata 18 novembre 2025), https://www.ic.unicamp.br/en/~stolfi/EXPORT/voynich/00-06-07-word-grammar/Notes/064/work/projects/voynich/projects/programs/c/big/big/projects/voynich/Notes/096/work/Notes/091/report/report_091.html

Dati: archivio storico `ANCHOR_20_20261112/pairs_11.csv` in sola lettura. Non modificati RC1.4.2 e relativi registri.

## Risultato
Le foglie sono documentate come simili in 7/9 coppie giudicate convincenti e in 0/2 coppie giudicate deboli. Fisher esatto unilaterale p=0,1090909091. Radici 9/9 contro 2/2, p=1; fiori 1/9 contro 0/2, p=9/11. Le categorie derivano dalla stessa analisi iconografica: il test verifica la separazione retrospettiva dei giudizi, non un criterio oggettivo esterno. I due `poor matches` sono casi incerti, non negativi certi.

## Problema
Il dataset è stato selezionato perché le coppie somigliavano già, soprattutto nelle radici. Confrontarlo con due coppie scartate dall'autore favorisce una validazione circolare. Ogni stima di precisione predittiva del matching botanico ottenuta da queste sole undici coppie sarebbe non valida.

## Protocollo per il prossimo test reale
1. Congelare una lista di tutte le 9 coppie storiche positive, le 2 dubbie e almeno 30 decoy creati mescolando i medesimi frammenti farmaceutici con fogli botanici di altra provenienza, vincolando dimensione e tipologia delle parti visibili.
2. Acquisire le immagini originali ad alta risoluzione dal manifest Yale MS 408, registrando canvas ID, crop, URL, hash e licenza. Ritagli normalizzati alla stessa scala e senza scritte visibili.
3. Codificare prima dell'ispezione umana una griglia di dettagli: radice (numero biforcazioni, angoli, nodi), foglie (lamina, nervatura, inserzione, contorno), fiori e anomalie non botaniche; distinguere assenza reale da non visibile.
4. Due revisori, su immagini randomizzate e senza folio, testo o etichette, registrano punteggi e confidenza. Risolvere conflitti senza mostrare le classi storiche. Inserire coppie di duplicati identici per controllo di affidabilità.
5. Calcolare ranking entro un set di candidature per ciascun frammento con test permutazionale a livello di foglio, testando esplicitamente l'ipotesi che un insieme di caratteristiche superi la sola radice. Separare falsi abbinamenti costruiti e casi storici incerti.
6. Solo una volta raggiunta affidabilità visuale, aprire le denominazioni di manoscritti esterni; formare coppie nome-etichetta e validare regole di lettura su altri folii.

## Blocco operativo
Non è stato prodotto un nuovo dataset di crop completi, né una doppia annotazione cieca. Le immagini Yale sono pubblicamente accessibili, ma questo ambiente non le ha acquisite in forma completa e confrontabile durante questa esecuzione. Nessun p-value qui riportato conferma una semantica o una traduzione Voynich.
