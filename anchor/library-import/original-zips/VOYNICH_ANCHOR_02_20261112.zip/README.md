# ANCHOR-02 | Pacchetto riproducibile

**Stato: esplorativo, nessun test semantico validato.** Vedi `results/ANCHOR_02_REPORT_IT.md`.

## Esecuzione dalla root del pacchetto
```bash
python scripts/run_anchor02_zl3b.py --corpus inputs/ZL3b-n.txt --out ricalcolo
python scripts/run_anchor02.py --inventory inputs/ANCHOR_01_snapshot/figure_inventory_corrected.csv --corpus inputs/ZL3b-n.txt --out ricalcolo
python scripts/anchor02_geometry_diagnostic.py inputs/ANCHOR_01_snapshot ricalcolo
python scripts/make_anchor02_review_sheet.py inputs/ANCHOR_01_snapshot ricalcolo
```

`numpy` e `scipy` richiesti per la diagnostica geometrica; `Pillow` per la tavola immagini. La parte testuale usa Python standard. Non eseguire e non modificare script/parser storici congelati.

La tavola di ritagli è preliminare e può includere glifi o corpi incompleti: non è un dataset cieco validato.
