"""Create preliminary figure-only crop sheets (NOT certified blind; estimated polygons)."""
from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
import json,hashlib,csv,math,random,sys
src=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
geo=json.load(open(src/'coordinates_draft.json'))
rec=[r for r in geo['records'] if r['kind']=='body']
assert len(rec)==30
rng=random.Random(20261112)
rng.shuffle(rec)
canvases={1006201: Image.open(src/'sources/1006201.jpg').convert('RGB'),1006202:Image.open(src/'sources/1006202.jpg').convert('RGB')}
info={id:json.load(open(src/f'sources/iiif_{id}.json')) for id in canvases}
w,h=200,260
sheet=Image.new('RGB',(5*230+20,6*290+20),'white')
draw=ImageDraw.Draw(sheet)
meta=[]
for i,r in enumerate(rec):
    oid=r['canvas_oid'];im=canvases[oid];iiif=info[oid]
    sx=im.width/iiif['width'];sy=im.height/iiif['height']
    poly=r['polygon'];coords=[(x*sx,y*sy) for x,y in poly]
    x0=max(0,math.floor(min(x for x,y in coords)));x1=min(im.width,math.ceil(max(x for x,y in coords)))
    y0=max(0,math.floor(min(y for x,y in coords)));y1=min(im.height,math.ceil(max(y for x,y in coords)))
    # Margin could show script: no blinding asserted.
    crop=im.crop((x0,y0,x1,y1))
    crop.thumbnail((w,h-15),Image.Resampling.LANCZOS)
    row,col=divmod(i,5);slot=(col*230+15,row*290+25)
    sheet.paste(crop,(slot[0]+(w-crop.width)//2,slot[1]+(h-crop.height)//2))
    blind_id='B'+hashlib.sha256(('ANCHOR02|'+r['id']).encode()).hexdigest()[:7].upper()
    draw.text((slot[0],slot[1]-17),blind_id,fill='black')
    meta.append({'blind_id':blind_id,'figure_id':r['id'],'page_id':r['page_id'],'canvas_oid':oid,'source_bbox_preview':str([x0,y0,x1,y1]),'certified_blind':'NO','crop_clearance':'PENDING_TEXT_LEAK_CHECK'})
sheet.save(out/'preliminary_figure_contact_sheet.jpg',quality=90)
with open(out/'CUSTODIAN_CROP_KEY.csv','w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(meta[0]));w.writeheader();w.writerows(meta)
with open(out/'ATTRIBUTE_REVIEW_TEMPLATE.csv','w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['blind_id','reviewer_id','source_legibility_ok','body_visibility','holding_star_yes_no_uncertain','headwear_yes_no_uncertain','garment_sleeves_yes_no_uncertain','remarks']);w.writeheader()
 for r in meta:w.writerow({'blind_id':r['blind_id']})
print('Created',len(meta),'figure crops; contact sheet',sheet.size)
