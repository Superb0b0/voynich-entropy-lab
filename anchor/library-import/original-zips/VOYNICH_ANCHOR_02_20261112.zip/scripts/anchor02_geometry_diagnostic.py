"""NEW exploratory optimization on ANCHOR_01 frozen distance table; cannot validate links."""
import sys,csv,json,collections,math
from pathlib import Path
import numpy as np
from scipy.optimize import linear_sum_assignment
source=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
d=list(csv.DictReader(open(source/'all_candidate_distances.csv',encoding='utf-8')))
a={r['label_locus_id']:r for r in csv.DictReader(open(source/'link_audit.csv',encoding='utf-8'))}
groups=collections.defaultdict(list)
for row in d:groups[(row['page_id'],row['ring'])].append(row)
all_links=[];summaries=[]
for (page,ring),rows in sorted(groups.items()):
    labels=sorted(set(x['label_locus_id'] for x in rows),key=lambda x:int(x.split('.')[-1]))
    figs=sorted(set(x['figure_id'] for x in rows))
    assert len(labels)==len(figs),(page,ring,len(labels),len(figs))
    ll={v:i for i,v in enumerate(labels)}; ff={v:i for i,v in enumerate(figs)}
    mat=np.full((len(labels),len(figs)),np.inf)
    bylabel=collections.defaultdict(list)
    for x in rows:
        mat[ll[x['label_locus_id']],ff[x['figure_id']]]=float(x['distance_px']);bylabel[x['label_locus_id']].append(x)
    rr,cc=linear_sum_assignment(mat)
    assert len(rr)==len(labels) and np.isfinite(mat[rr,cc]).all()
    sumcost=mat[rr,cc].sum();changed=0
    for row,col in zip(rr,cc):
        locus,fig=labels[row],figs[col]
        if fig!=a[locus]['nearest_candidate_figure_id']:changed+=1
        # alternative global assignment forbidding one chosen edge
        mm=mat.copy();mm[row,col]=np.inf
        try:
            x,y=linear_sum_assignment(mm); altcost=mm[x,y].sum() if np.isfinite(mm[x,y]).all() else np.inf
        except ValueError: altcost=np.inf
        local=sorted(bylabel[locus],key=lambda x:float(x['distance_px']))
        bounds_stable=(float(local[0]['assumed_distance_norm_high']) < float(local[1]['assumed_distance_norm_low']))
        source_warning=a[locus]['source_warning'].lower()=='true'
        all_links.append({'page':page,'ring':ring,'locus':locus,'forced_assignment':fig,
            'original_nearest':a[locus]['nearest_candidate_figure_id'],'assigned_is_original_nearest':fig==a[locus]['nearest_candidate_figure_id'],
            'source_warning':source_warning,'nearest_local_stable_assumed_bounds':bounds_stable,
            'cost_increase_if_assignment_forbidden_px':None if math.isinf(altcost) else float(altcost-sumcost),
            'status':'UNVALIDATED_EXPLORATORY_GEOMETRY'})
    summaries.append({'page':page,'ring':ring,'n':len(labels),'mincost_total_px':float(sumcost),'not_nearest_assignments':changed})
report={'status':'EXPLORATORY_NO_LINK_VALIDATION','assumed_distance_interval':'preexisting 24 px total uncertainty on each distance; NOT empirical uncertainty',
 'n_links':len(all_links),'locally_stable_under_assumed_bounds':sum(x['nearest_local_stable_assumed_bounds'] for x in all_links),
 'globally_forced_not_original_nearest':sum(not x['assigned_is_original_nearest'] for x in all_links),
 'source_warned':sum(x['source_warning'] for x in all_links),
 'priority_manual_review':sorted(set(x['locus'] for x in all_links if x['source_warning'] or not x['nearest_local_stable_assumed_bounds'] or not x['assigned_is_original_nearest'])),
 'groups':summaries,'links':all_links,
 'limitations':['Assignment is a model choice and does not establish true figure-label linkage.','The assumed pixel bounds were not empirically calibrated.','Rectangles are single-operator approximations.','No visual feature annotation or translation attempted.','The previous frozen rules and outcomes remain unchanged.']}
(out/'geometry_diagnostic.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with open(out/'geometry_diagnostic_links.csv','w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(all_links[0]));w.writeheader();w.writerows(all_links)
print(json.dumps({k:v for k,v in report.items() if k not in ('links','groups')},indent=2))
print('group summaries',summaries)
