#!/usr/bin/env python3
"""ANCHOR-02 exploratory non-semantic structural triage on historical label inventory.
Does not modify legacy artifacts. No geometrical/semantic validation claimed.
"""
import argparse, collections, csv, hashlib, itertools, json, math, random, re, statistics
from pathlib import Path

PAGES=['f70v2','f70v1','f71r','f71v','f72r1','f72r2','f72r3','f72v3','f72v2','f72v1']
SIGNS=['Pisces','Aries','Aries','Taurus','Taurus','Gemini','Cancer','Leo','Virgo','Libra']
HOLDOUT=['f73r','f73v']
SEED=20261112

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def toks(s): return re.findall('[a-z]+',s.lower())
def feat(s, kind):
    words=toks(s)
    if kind=='tri': return [w[i:i+3] for w in words for i in range(len(w)-2)]
    if kind=='pre2': return [w[:2] for w in words if len(w)>=2]
    if kind=='word': return words
    raise ValueError(kind)
def cosine(a,b):
    dot=sum(v*b.get(k,0) for k,v in a.items()); da=sum(v*v for v in a.values()); db=sum(v*v for v in b.values())
    return dot/math.sqrt(da*db) if da and db else 0

def all_matchings_two(n=10):
    pairs=list(itertools.combinations(range(n),2))
    return [(p,q) for i,p in enumerate(pairs) for q in pairs[i+1:] if set(p).isdisjoint(q)]

def summary_for_feature(rows,kind):
    # TF-IDF w idf across all ten panels, no sign info used.
    cc={p:collections.Counter(v for row in rows if row['page_id']==p for v in feat(row['historical_label_text'],kind)) for p in PAGES}
    df=collections.Counter(k for v in cc.values() for k in v)
    n=len(PAGES)
    vv={p:{k:(1+math.log(v))*(1+math.log((n+1)/(df[k]+1))) for k,v in c.items()} for p,c in cc.items()}
    s={(i,j):cosine(vv[PAGES[i]],vv[PAGES[j]]) for i,j in itertools.combinations(range(10),2)}
    observed_pairs=((1,2),(3,4))
    score=lambda pairs:statistics.mean(s[tuple(sorted(pp))] for pp in pairs)
    obs=score(observed_pairs)
    allscores=[score(p) for p in all_matchings_two()]
    # Conditional adjacent control: two non-overlapping pairs of neighboring charts.
    adjacent=[(i,i+1) for i in range(9)]
    adj_scores=[score((a,b)) for i,a in enumerate(adjacent) for b in adjacent[i+1:] if set(a).isdisjoint(b)]
    raw_comparisons=[{'pair':f'{PAGES[i]}:{PAGES[j]}','same_sign':SIGNS[i]==SIGNS[j],'adjacent':j==i+1,'cosine':round(v,5)} for (i,j),v in s.items()]
    return {'feature':kind,'n_panels':n,'observed_same_sign_pairs':[f'{PAGES[i]}:{PAGES[j]}' for i,j in observed_pairs],
        'observed_mean_cosine':obs,'unconditional_exact_n':len(allscores),'unconditional_exact_one_sided_p':sum(x>=obs-1e-12 for x in allscores)/len(allscores),
        'adjacent_disjoint_exact_n':len(adj_scores),'adjacent_disjoint_one_sided_p':sum(x>=obs-1e-12 for x in adj_scores)/len(adj_scores),
        'adjacent_mean_null':statistics.mean(adj_scores),'random_pairing_mean_null':statistics.mean(allscores),
        'per_pair':raw_comparisons}

def sequence_test(rows,kind='pre2',B=20000):
    # Count equality among consecutive positions in a circular layout, within each page+ring.
    rings=[]; excluded=collections.Counter()
    for (pg,rg), grp_it in itertools.groupby(sorted(rows,key=lambda r:(r['page_id'],r['historical_region'])),key=lambda r:(r['page_id'],r['historical_region'])):
        if rg not in ('inner','outer'):
            excluded['non_ring']+=1;continue
        group=list(grp_it)
        valid=[]
        for r in group:
            if r['historical_region_ordinal_status']!='source_reported':
                excluded['ordinal_uncertain']+=1; continue
            try: pos=int(r['historical_region_ordinal'])
            except ValueError: excluded['ordinal_bad']+=1;continue
            tok=toks(r['historical_label_text'])
            if not tok: excluded['no_alpha']+=1;continue
            # Exactly one feature per label, not one per word
            f=tok[0][:2] if kind=='pre2' else tok[0][-2:]
            valid.append((pos,f))
        if len(valid)<5:
            excluded['too_short']+=1;continue
        positions=[x for x,_ in valid]
        if len(set(positions))!=len(positions):
            excluded['duplicate_ordinals']+=1;continue
        seq=[f for _,f in sorted(valid)]
        rings.append({'page':pg,'ring':rg,'features':seq,'n':len(seq)})
    def count_neighbor_equal(vals):return sum(vals[i]==vals[(i+1)%len(vals)] for i in range(len(vals)))
    observed=sum(count_neighbor_equal(r['features']) for r in rings)
    n_edges=sum(len(r['features']) for r in rings)
    # analytical expectation under random circular order, fixed multiset per ring
    expected=sum(sum(x*(x-1) for x in collections.Counter(r['features']).values())/(len(r['features'])-1) for r in rings)
    rng=random.Random(SEED+ (0 if kind=='pre2' else 1)); sims=[]
    for _ in range(B):
        total=0
        for r in rings:
            sh=r['features'].copy();rng.shuffle(sh);total+=count_neighbor_equal(sh)
        sims.append(total)
    ge=sum(x>=observed for x in sims)
    le=sum(x<=observed for x in sims)
    return {'feature':kind,'ring_count':len(rings),'label_count':sum(len(x['features']) for x in rings),'observed_equal_edges':observed,'total_circular_edges':n_edges,'expected_equal_edges_exact':expected,
       'effect_observed_minus_expected':observed-expected,'permutation_B':B,'one_sided_more_similarity_p':(ge+1)/(B+1),
       'one_sided_less_similarity_p':(le+1)/(B+1),'null_mean':statistics.mean(sims),'null_std':statistics.pstdev(sims),
       'per_ring':[{'page':r['page'],'ring':r['ring'],'n':r['n'],'observed_equal':count_neighbor_equal(r['features'])} for r in rings],
       'excluded':dict(excluded)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--inventory',required=True);ap.add_argument('--corpus',required=True);ap.add_argument('--out',required=True);a=ap.parse_args()
    out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    with open(a.inventory,encoding='utf-8-sig',newline='') as f: rows_all=list(csv.DictReader(f))
    rows=[r for r in rows_all if r['page_id'] in PAGES and r['source_object_kind']=='human_candidate']
    assert len(PAGES)==10 and all(sum(r['page_id']==p for r in rows)>0 for p in PAGES)
    assert sha(a.corpus)=='bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc'
    counts={p:sum(r['page_id']==p for r in rows) for p in PAGES}
    result={'experiment':'ANCHOR-02','status':'EXPLORATORY_NON_SEMANTIC_TRIAGE','date':'2026-11-12',
       'data':{'inventory_sha256':sha(a.inventory),'corpus_sha256':sha(a.corpus),'n_rows_inventory':len(rows_all), 'n_selected_labels':len(rows),'chart_label_counts':counts,
       'selected_panels':dict(zip(PAGES,SIGNS)),'untouched_holdout_panels':HOLDOUT,'source':'Grove-Stolfi historic labels via ANCHOR_01; text-to-figure join NOT validated'},
       'hypothesis_1':'same zodiac sign panels have higher unsupervised label-profile similarity; alternative pair and adjacency controls; candidate semantic association only',
       'hypothesis_2':'neighboring historically ordered labels show greater prefix/suffix similarity than within-ring random circular permutations; layout/ordinal test, NOT decoded numbers',
       'same_sign_main_trigram':summary_for_feature(rows,'tri'),'same_sign_sensitivity_prefix2':summary_for_feature(rows,'pre2'),
       'sequence_main_first2':sequence_test(rows,'pre2'), 'sequence_sensitivity_last2':sequence_test(rows,'suf2'),
       'limitations':['Historically reported visual mappings are not validated independently.','Two same-sign pairs only, both adjacent and composed of 15-label half-sign diagrams.','Consecutive order inherited from source indices, not independently re-read.','No visual attribute annotations; no semantic decoding test has been run.','No multiple-testing adjustment for exploratory secondary statistics; no causal interpretation.','Holdouts are reserved, not evaluated.','Historical RC1.4.2 gate unaffected.']}
    (out/'results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    with open(out/'panel_pairs.csv','w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['pair','same_sign','adjacent','cosine']);w.writeheader();w.writerows(result['same_sign_main_trigram']['per_pair'])
    with open(out/'selected_panels.csv','w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['page_id','sign','n_historical_human_labels','role']);w.writeheader();w.writerows([{'page_id':p,'sign':s,'n_historical_human_labels':counts[p],'role':'discovery'} for p,s in zip(PAGES,SIGNS)]+[{'page_id':p,'sign':'Scorpio' if p=='f73r' else 'Sagittarius','n_historical_human_labels':'not inspected','role':'holdout'} for p in HOLDOUT])
    print(json.dumps({'labels':len(rows),'counts':counts,'same_sign_trigram':{k:v for k,v in result['same_sign_main_trigram'].items() if k!='per_pair'},'first2':{k:v for k,v in result['sequence_main_first2'].items() if k not in ('per_ring','excluded')},'last2':{k:v for k,v in result['sequence_sensitivity_last2'].items() if k not in ('per_ring','excluded')}},indent=2))
if __name__=='__main__':main()
