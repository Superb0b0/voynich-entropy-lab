#!/usr/bin/env python3
"""Exploratory ANCHOR-02: IVTFF Lz direct, no validated geometric associations."""
from pathlib import Path
import argparse, re, json, collections, itertools, math, statistics, hashlib, random, csv
PAGES=['f70v2','f70v1','f71r','f71v','f72r1','f72r2','f72r3','f72v3','f72v2','f72v1']
SIGNS=['Pisces','Aries','Aries','Taurus','Taurus','Gemini','Cancer','Leo','Virgo','Libra']
SEED=20261112

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def words(s):return re.findall(r'[a-z]+',s.lower())
def feats(s,k):
    ww=words(s)
    if k=='trigram':return [w[i:i+3] for w in ww for i in range(len(w)-2)]
    if k=='prefix2':return [w[:2] for w in ww if len(w)>=2]
    if k=='word':return ww
    raise ValueError(k)
def load(path):
    pat=re.compile(r'^<([^>,]+),([@&]Lz)>\s*(.*)$')
    labels=collections.defaultdict(list); groups=collections.defaultdict(list)
    for line in Path(path).read_text(encoding='utf-8').splitlines():
        m=pat.match(line)
        if not m:continue
        locus,kind,content=m.groups();page=locus.split('.')[0]
        if page not in PAGES:continue
        # Inline comment (starts with <! and ends with >)
        content=re.sub(r'<!.*?>','',content).strip()
        row={'page':page,'locus':locus,'kind':kind,'transcription':content,'tokens':words(content)}
        if kind=='@Lz' or not groups[page]: groups[page].append([])
        groups[page][-1].append(row)
        labels[page].append(row)
    return labels,groups

def similarity(labels,typ):
    cnt={p:collections.Counter(f for row in labels[p] for f in feats(row['transcription'],typ)) for p in PAGES}
    DF=collections.Counter(k for c in cnt.values() for k in c)
    vect={p:{k:(1+math.log(v))*(1+math.log((11)/(1+DF[k]))) for k,v in c.items()} for p,c in cnt.items()}
    def cos(a,b):
        num=sum(v*b.get(k,0) for k,v in a.items());den=math.sqrt(sum(v*v for v in a.values())*sum(v*v for v in b.values()))
        return num/den if den else 0
    sims={(i,j):cos(vect[PAGES[i]],vect[PAGES[j]]) for i,j in itertools.combinations(range(10),2)}
    obs_pairs=((1,2),(3,4))
    score=lambda pairs:statistics.mean(sims[tuple(sorted(pair))] for pair in pairs)
    obs=score(obs_pairs)
    pairs=list(sims)
    all_two=[(a,b) for index,a in enumerate(pairs) for b in pairs[index+1:] if set(a).isdisjoint(b)]
    adj=[(i,i+1) for i in range(9)]
    adj_two=[(a,b) for index,a in enumerate(adj) for b in adj[index+1:] if set(a).isdisjoint(b)]
    return {'feature':typ,'matching_pairs':[list(x) for x in obs_pairs], 'observed_mean_cosine':obs,
      'unconditional_n':len(all_two),'unconditional_upper_tail_p':sum(score(x)>=obs-1e-12 for x in all_two)/len(all_two),
      'adjacent_only_n':len(adj_two),'adjacent_only_upper_tail_p':sum(score(x)>=obs-1e-12 for x in adj_two)/len(adj_two),
      'adjacent_only_null_mean':statistics.mean(score(x) for x in adj_two),
      'pairs':[{'page_a':PAGES[i],'page_b':PAGES[j],'similarity':v,'same_sign':SIGNS[i]==SIGNS[j],'adjacent':j==i+1} for (i,j),v in sims.items()]}

def adjacency(groups,feature,B=20000):
    blocks=[]
    for p in PAGES:
        for z,g in enumerate(groups[p],1):
            yy=[]
            for r in g:
                tok=r['tokens']
                if not tok:continue
                yy.append(tok[0][:2] if feature=='prefix2' else tok[0][-2:])
            if len(yy)>=5:blocks.append((p,z,yy))
    def sc(seq):return sum(a==b for a,b in zip(seq,seq[1:]))
    observed=sum(sc(yy) for _,_,yy in blocks)
    expected=sum(sum(v*(v-1) for v in collections.Counter(yy).values())/len(yy) for _,_,yy in blocks)
    rng=random.Random(SEED+(1 if feature=='suffix2' else 0)); sims=[]
    for _ in range(B):
        total=0
        for _,_,yy in blocks:
            q=yy.copy();rng.shuffle(q);total+=sc(q)
        sims.append(total)
    return {'feature':feature,'n_blocks':len(blocks),'n_labels_in_blocks':sum(len(x) for _,_,x in blocks),'n_linear_adjacency_edges':sum(len(x)-1 for _,_,x in blocks),
       'observed_equal_edges':observed,'null_expected_edges':expected,'effect_edges':observed-expected,
       'permutation_B':B,'permutation_upper_tail_p':(sum(x>=observed for x in sims)+1)/(B+1),
       'permutation_lower_tail_p':(sum(x<=observed for x in sims)+1)/(B+1), 'null_sd':statistics.pstdev(sims),
       'block_sizes':[{'page':p,'block':z,'n':len(x)} for p,z,x in blocks]}

def main():
    p=argparse.ArgumentParser();p.add_argument('--corpus',required=True);p.add_argument('--out',required=True);a=p.parse_args()
    out=Path(a.out);out.mkdir(exist_ok=True,parents=True)
    digest=sha(a.corpus)
    if digest!='bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc':raise ValueError('SHA mismatch')
    labels,groups=load(a.corpus)
    counts={p:len(labels[p]) for p in PAGES}
    result={'study':'ANCHOR-02 / ZL3b primary','status':'EXPLORATORY_NOT_SEMANTIC_DECIPHERMENT','source_sha256':digest,
      'page_count':10,'labels_count':sum(counts.values()),'per_page':counts,'panel_signs':dict(zip(PAGES,SIGNS)),
      'reserved_untested_panels':['f73r','f73v'],'source_locus':'Only @Lz and &Lz; inline IVTFF comments stripped; glyph alternatives retained as strings for cleaning',
      'same_sign_trigram':similarity(labels,'trigram'),'same_sign_prefix2_sensitivity':similarity(labels,'prefix2'),
      'label_order_prefix2':adjacency(groups,'prefix2'),'label_order_suffix2':adjacency(groups,'suffix2'),
      'limitations':['Exploratory: the metric family and source comparison were refined after examining archival-inventory results.','The two same-sign pairs are consecutive half-sign wheels; adjacency and sample size are confounds.','Locus sequence in IVTFF is not a validated per-figure clockwise mapping.','@Lz block breaks are transcription grouping, not necessarily geometric rings.','This test does not connect any text string to a visual attribute or identify any word meaning.','The two final panels were excluded from tests; metadata and example labels were previously inspected during preparation, so this is NOT a fully blind holdout.','No changes to RC1.4.2 frozen data or gate.']}
    (out/'primary_zl3b_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    with open(out/'zl3b_label_records.csv','w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=['page','sign','locus','kind','transcription']);w.writeheader()
        for page in PAGES:
            for r in labels[page]:w.writerow({**{k:r[k] for k in ('page','locus','kind','transcription')},'sign':SIGNS[PAGES.index(page)]})
    with open(out/'zl3b_pairs.csv','w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=['page_a','page_b','similarity','same_sign','adjacent']);w.writeheader();w.writerows(result['same_sign_trigram']['pairs'])
    print(json.dumps({'counts':counts,'same_sign':{k:v for k,v in result['same_sign_trigram'].items() if k!='pairs'},'prefix2':{k:v for k,v in result['label_order_prefix2'].items() if k!='block_sizes'},'suffix2':{k:v for k,v in result['label_order_suffix2'].items() if k!='block_sizes'}},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
