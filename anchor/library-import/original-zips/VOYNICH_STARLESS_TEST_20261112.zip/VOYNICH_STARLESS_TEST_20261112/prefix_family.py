#!/usr/bin/env python3
"""All-two-character-prefix FWER test of five starless figures vs same-page stars.
Source annotations are exploratory and come from a non-peer-reviewed secondary catalogue.
The family of *all* eligible two-character prefixes is tested, avoiding a post hoc of-only claim.
"""
from pathlib import Path
import csv,collections,math,json
import numpy as np
P=Path(__file__).resolve().parent
R=list(csv.DictReader((P/'label_inventory.csv').open()))
folio_order=['f72r2','f72r3','f72v2','f73v']
output={}
for trans in ['ZL3b','IT2a']:
 pages={f:[] for f in folio_order}
 for r in R:
  if r['transcription']!=trans:continue
  raw=r['raw']; prefix=raw[:2] if len(raw)>1 and raw[:2].isalpha() and raw[:2].islower() else None
  if prefix is not None: pages[r['folio']].append({'prefix':prefix,'starless':int(r['starless_source']),'locus':int(r['locus']),'raw':raw})
 prefixes=sorted(set(x['prefix'] for v in pages.values() for x in v))
 # For each prefix the exact conditional one-sided tail of count of the prefix among five flagged labels.
 # Four independent hypergeometric variates, with 1,2,1,1 draws within four folios.
 def tail_probs_for_prefix(z):
  polynomial=[1.0]
  for f in folio_order:
   rr=pages[f];N=len(rr); K=sum(r['prefix']==z for r in rr); n=sum(r['starless'] for r in rr)
   probs=[math.comb(K,k)*math.comb(N-K,n-k)/math.comb(N,n) if 0<=k<=K and 0<=n-k<=N-K else 0.0 for k in range(n+1)]
   polynomial=np.convolve(polynomial,probs)
  return [sum(polynomial[k:]) for k in range(len(polynomial))]
 tails={z:tail_probs_for_prefix(z) for z in prefixes}
 obs_counts={z:sum(r['starless'] and r['prefix']==z for rr in pages.values() for r in rr) for z in prefixes}
 p_obs={z:tails[z][obs_counts[z]] for z in prefixes}
 selected=min(p_obs,key=p_obs.get)
 B=99999;rng=np.random.default_rng(11122026)
 pagearr={f:np.array([prefixes.index(r['prefix']) for r in pages[f]],dtype=int) for f in folio_order}
 nsel={f:sum(r['starless'] for r in pages[f]) for f in folio_order}
 count=0
 # record null minimum p; source data fixed across prefix family
 for b in range(B):
  selected_arr=np.concatenate([rng.choice(pagearr[f],size=nsel[f],replace=False) for f in folio_order])
  freqs=np.bincount(selected_arr,minlength=len(prefixes))
  minp=min(tails[z][int(freqs[i])] for i,z in enumerate(prefixes))
  count+=minp<=p_obs[selected]+1e-12
 page_details={f:{'N':len(pages[f]),'starless':sum(r['starless'] for r in pages[f]),'of_total':sum(r['prefix']=='of' for r in pages[f]),'of_starless':sum(r['prefix']=='of' and r['starless'] for r in pages[f])} for f in folio_order}
 # Within Cancer nymphs 10 and 18: x of the only two of-labels; any 2 of 30
 cancer=pages['f72r3']; c_all=len(cancer); c_of=sum(r['prefix']=='of' for r in cancer); csel=sum(r['starless'] for r in cancer); cselected_of=sum(r['prefix']=='of' and r['starless'] for r in cancer)
 cancer_hyper=sum(math.comb(c_of,k)*math.comb(c_all-c_of,csel-k)/math.comb(c_all,csel) for k in range(cselected_of,min(c_of,csel)+1))
 # Exact Cancer positions groups 1-10,11-20,21-30 by corpus order; hypothesis ring effect only sensitivity
 outer=[r for r in cancer if 2<=r['locus']<=11]; middle=[r for r in cancer if 12<=r['locus']<=21]
 oc=sum(x['prefix']=='of' for x in outer);mc=sum(x['prefix']=='of' for x in middle)
 ringp=(oc/len(outer))*(mc/len(middle))
 output[trans]={'n_catalogued_starless':sum(nsel.values()),'readable_first_two':sum(len(x) for x in pages.values()),'tested_two_char_prefixes':len(prefixes),'best_prefix':selected,'best_prefix_count':obs_counts[selected],'best_prefix_exact_nominal_p':p_obs[selected],'familywise_adjusted_mc_p':(1+count)/(B+1),'of_exact_nominal_p':p_obs.get('of'),'cancer_exact_conditional_p_of':cancer_hyper,'cancer_outer_middle_assumed_ring_sensitivity_p':ringp,'page_counts':page_details,'top_five_prefixes':sorted([(z,obs_counts[z],round(p_obs[z],6)) for z in prefixes],key=lambda t:t[-1])[:5],'caveats':['Same page conditioning removes page-level confounds but not ring nor exact label position.','Two-character prefix family defined after earlier experiments, exploratory not independent.','The catalog is one non-peer-reviewed source; no independent eye-blinded image annotations.','Cancer outer/middle grouping based on sequential locus ranges, assumed not verified against every figure.']}
(P/'prefix_family_results.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(output,ensure_ascii=False,indent=2))
