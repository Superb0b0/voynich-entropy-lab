#!/usr/bin/env python3
"""EXP-FIRST-WORD-08: preregistered-in-code exploratory absence-of-star tests.
Five positive annotations sourced solely from the END catalogue and located by
matching the glyph strings to independently stored ZL3b locus tables.
All negatives are catalogued as star-bearing at the SAME page level. Labels
source: frozen ZL3b and IT2a, no text-derived positive annotations.
"""
from pathlib import Path
import csv, re, json, collections, math, itertools, hashlib
import numpy as np
P=Path(__file__).resolve().parent
source=P/'input_labels.csv'
rows=list(csv.DictReader(source.open()))
# Figure n -> ZL3b locus, verified against text and catalog label
starless={'f72r2':[14], 'f72r3':[11,20], 'f72v2':[24], 'f73v':[19]}
# Pre-selected comparative text descriptors. Avoid score-conditioned feature selection.
FN=['prefix_o','prefix_ot','prefix_of','suffix_y','suffix_dy','label_multitoken','len_first','first_rarity']
def clean_tokens(r):
 return [w for w in re.split(r'[., ]',r['raw']) if re.fullmatch('[a-z]+',w)]
def feature(r, frequency):
 t=clean_tokens(r); first=t[0] if t else ''
 # explicitly exclude if the *first raw token* contains uncertainty; never shift to a later word
 first_piece=re.split(r'[., ]',r['raw'])[0]
 if not re.fullmatch('[a-z]+',first_piece):return None
 return np.array([first.startswith('o'),first.startswith('ot'),first.startswith('of'),first.endswith('y'),first.endswith('dy'),len(t)>1,len(first),-math.log((frequency[first]+.5)/(sum(frequency.values())+.5*len(frequency)))],float)
reports={}; registry=[]
for trans in ['ZL3b','IT2a']:
 page_rows=collections.defaultdict(list)
 for r in rows:
  if r['transcription']==trans and r['folio'] in starless:page_rows[r['folio']].append(r)
 for f in page_rows: page_rows[f].sort(key=lambda r:int(r['locus']))
 full_freq=collections.Counter(r['first'] for r in rows if r['transcription']==trans and r['first'])
 # selected records: locate by locus from source match, verify order against catalog
 pos,neg=[],[]; flags=[]
 for f,group in page_rows.items():
  for r in group:
   is_starless=int(r['locus']) in starless[f]
   v=feature(r,full_freq)
   registry.append({'transcription':trans,'folio':f,'locus':r['locus'],'raw':r['raw'],'starless_source':int(is_starless),'first_clean':int(v is not None),'first':r['first']})
   if v is None:
    if is_starless:flags.append((f,r['locus'],r['raw']))
    continue
   (pos if is_starless else neg).append((f,r['locus'],v))
 strata={f:[] for f in starless}
 for f,l,v in pos+neg:strata[f].append(v)
 for f in strata:strata[f]=np.stack(strata[f])
 # If raw label unreadable, cannot include target in numerical test.
 chosen={f:sum(1 for q,n,v in pos if q==f) for f in starless}
 # Correct: null compare observed selected count per folio, among CLEAN labels. Condition on readability.
 arr_obs=np.stack([v for _,_,v in pos]); obs=arr_obs.mean(axis=0)
 B=49999; rng=np.random.default_rng(20261112); sims=np.zeros((B,len(FN)))
 for k in range(B):
  samples=[]
  for f,data in strata.items():
   n=chosen[f]
   if n:samples.append(data[rng.choice(len(data),size=n,replace=False)])
  sims[k]=np.concatenate(samples).mean(axis=0)
 mn=sims.mean(axis=0); sd=sims.std(axis=0)
 z=(obs-mn)/np.where(sd>0,sd,1)
 zs=(sims-mn)/np.where(sd>0,sd,1)
 maxz=np.max(abs(zs),axis=1)
 results=[]
 for i,name in enumerate(FN):
  p=(1+np.sum(abs(sims[:,i]-mn[i])>=abs(obs[i]-mn[i])-1e-12))/(B+1)
  pc=(1+np.sum(maxz>=abs(z[i])-1e-12))/(B+1)
  results.append({'metric':name,'positive_mean':round(float(obs[i]),6),'control_null_mean':round(float(mn[i]),6),'z':round(float(z[i]),4),'p_two_sided_mc':round(float(p),5),'p_maxT_8_tests':round(float(pc),5)})
 reports[trans]={'source_labels':sum(len(v) for v in page_rows.values()),'clean_labels':sum(len(v) for v in strata.values()),'positives_catalog':sum(map(len,starless.values())),'positive_analyzable':len(pos),'unreadable_positives':flags,'heldout_positive_pages':len(starless),'null_permutations':B,'features':results,'selected_folios_counts':chosen,'limitations':['Catalogue labels and art annotations from same secondary website; visual classifications not independently double-audited.','Transcriptions ZL3b/IT2a share the physical manuscript.','Within-page null removes sign/page effects but not position/ring confounds.','Features prespecified in script but hypotheses explored after prior zodiac tests.']}
with (P/'label_inventory.csv').open('w',newline='') as fh:
 w=csv.DictWriter(fh,fieldnames=list(registry[0]));w.writeheader();w.writerows(registry)
with (P/'metrics.csv').open('w',newline='') as fh:
 w=csv.DictWriter(fh,fieldnames=['transcription']+list(reports['ZL3b']['features'][0]));w.writeheader()
 for t in reports:
  for m in reports[t]['features']:w.writerow({'transcription':t,**m})
(P/'results.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(reports,indent=2))
