# Voynich | EXP-FIRST-WORD-08

Verifica esplorativa delle etichette di cinque figure zodiacali prive di stella in due trascrizioni; 4 folii coinvolti. Test su 8 descrittori e, soprattutto, su tutti i 22 prefissi di due lettere con correzione per confronti multipli.

La coincidenza `of` del Cancro è notevole ma NON confermata fuori pagina. NON identifica una parola del Voynich.

## Files
- `input_labels.csv`: copia congelata dell'estrazione preesistente di 598 etichette, 299 per trascrizione
- `test.py`, `prefix_family.py`: esecutori Python riproducibili (numpy)
- `label_inventory.csv`, `metrics.csv`, `results.json`, `prefix_family_results.json`: risultati
- `REPORT.md`: interpretazione, limiti, provenienza dei dati visivi
- `SHA256SUMS.txt`: SHA256 degli artefatti

Pipeline RC1.4.2 invariata, gate semantico NON SUPERATO.
