# EXP-FIRST-WORD-08 | Figure zodiacali senza stella

**Data:** 12 novembre 2026  
**Stato:** ESPLORATIVO; prima parola NON identificata; RC1.4.2 congelata.

## Materiali
- Etichette del corpus Voynich ZL3b e IT2a già estratte nel precedente EXP-FIRST-WORD-01, 299 etichette per trascrizione, conservate in `input_labels.csv`.
- Annotazioni visive **secondarie** tratte dal repertorio *The 299 zodiac figures of the Voynich Manuscript* (https://end.rito.one/solved/figures.html; dati grezzi linkati su https://end.rito.one/solved/data/all_299_figures.json): 299 figure, cinque segnalate prive di stella. Questo dataset è pubblicato su un sito che sostiene anche una controversa decifrazione; le annotazioni **non sono state riverificate alla cieca da un team indipendente**. I cinque identificativi sono stati riscontrati per corrispondenza con le etichette del nostro corpus: Gemelli f72r2 locus 14, Cancro f72r3 locus 11 e 20, Vergine f72v2 locus 24, Sagittario f73v locus 19.
- Etichette con testo incerto: la figura Cancer 18 ha ZL3b `of???.o.eeesaly`, ma IT2a `ofais.o.seesaly`; in ZL3b sono visibili le due lettere iniziali `of`, non tutta la parola.

## Risultati
- Nel Cancro, i **due soli** prefissi `of` della pagina coincidono con le **due figure senza stella**. Assumendo un test **pre-specificato soltanto su `of`**, la probabilità ipergeometrica esatta fra le 30 posizioni è 1/C(30,2) = **0,00229885**. Questo dato **non è una p-value confermativa**, perché `of` emerge dopo molti esperimenti lessicali ed è una caratteristica selezionata guardando queste etichette.
- I prefissi `of` **non predicono** l'assenza di stella negli altri tre folii: **0/3** figure senza stella etichettate con `of`; 5 figure con stella etichettate `of` in ZL3b, 4 in IT2a.
- Test su **tutti i 22 prefissi a due lettere** nei quattro folii, con 99.999 ri-assegnazioni delle etichette all'interno della stessa pagina e correzione empirica della p minima: prefisso migliore `of`; ZL3b p nominale esatta **0,030809**, FWER **0,11977**; IT2a p nominale esatta **0,023686**, FWER **0,09891**. Nessuna supera alpha=0,05 dopo la correzione.
- Analisi ulteriore su otto descrittori testuali, 49.999 permutazioni pagina-stratificate: in ZL3b si escludono le parole incerte dalla misura basata sulla parola intera (4 positive valutabili); in IT2a sono valutabili tutte e cinque. La misura `of` in IT2a ha p_maxT 0,03496 entro quella specifica famiglia di otto confronti, ma **non** sopravvive alla famiglia più ampia di 22 prefissi e alla ricerca esplorativa già effettuata.
- Sensibilità Cancro per due blocchi consecutivi da 10 figure: valore ipotetico 0,0111 qualora questi corrispondano agli anelli esterno e medio; l'assegnazione di tutti i 30 individui ad anelli non è stata indipendentemente verificata e quindi non è usata come test primario.

## Interpretazione
L'assenza di stella non ha un marcatore testuale comune dimostrato. Il doppio `of` nel Cancro è **un'anomalia descrittiva locale**, non una lettura di `of` come «senza stella». Le due trascrizioni riguardano le stesse figure e non costituiscono due replicazioni indipendenti. La p nominale 0,0023 non rappresenta la probabilità della decifrazione. Nessuna selezione causale, semantica o calendaria è giustificata.

## Riproduzione
Da questa directory: `python test.py` e `python prefix_family.py` (richiede `numpy`). Entrambi gli esecutori leggono esclusivamente i file presenti nello stesso archivio e producono `results.json`, `metrics.csv`, `label_inventory.csv`, `prefix_family_results.json`.
