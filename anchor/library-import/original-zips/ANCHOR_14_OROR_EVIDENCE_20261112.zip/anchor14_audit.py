import re,json,hashlib,pathlib
root=pathlib.Path('/mnt/data/files')
out={}
for name in ['ZL3b-n.txt','IT2a-n.txt']:
 b=(root/name).read_bytes(); lines=b.decode('utf-8-sig').splitlines(); entries=[]
 for line in lines:
  m=re.match(r'^<([^<>]+)>\s*(.*)$',line)
  if not m: continue
  locus,payload=m.groups()
  if not re.search(r'\.\d+,',locus):continue
  # Editorial comments are not ciphertext; remove first
  text=re.sub(r'<!.*?>','',payload)
  # Only count exact dot-separated tokens, stripping layout signs, keeping uncertainty tokens non-exact
  text=text.replace('<->','.').replace('<%>','').replace('<$>','')
  tokens=[t.strip(' ,\t') for t in text.split('.') if t.strip(' ,\t')]
  if 'oror' in tokens:
   entries.append({'locus':locus,'token_position':[i for i,t in enumerate(tokens) if t=='oror'],'raw_excerpt':payload[:165]})
 out[name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'oror_exact_tokens_loci':entries,'f116v_rows':[l for l in lines if l.startswith('<f116v.')],'f100r6':[l for l in lines if l.startswith('<f100r.6,')],'f102v2_3':[l for l in lines if l.startswith('<f102v2.3,')]}
p=pathlib.Path('/mnt/data/ANCHOR_14_OROR_AUDIT.json');p.write_text(json.dumps(out,indent=2,ensure_ascii=False));print(json.dumps(out,indent=2,ensure_ascii=False)[:10000]);print('OUTPUT',p)
