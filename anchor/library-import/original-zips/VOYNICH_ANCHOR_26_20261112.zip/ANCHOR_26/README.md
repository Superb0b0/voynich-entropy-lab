ANCHOR-26 (2026-11-12) - esperimento riproducibile di recupero con testo noto.

python run_anchor26.py

Si tratta di un simulatore LIMITATO con due colonne degli unigrammi Naibbe e una permutazione segreta. Non è il programma Naibbe ufficiale, non è un attacco ciphertext-only e non decifra il Voynich.

File:
 - run_anchor26.py: simulatore + recuperatore + test di controllo
 - borg_0010r_plaintext_extracted.txt: latino da benchmark Borg (fonte storica già acquisita)
 - results.json: output verificato
 - REPORT_IT.md: metodologia, risultati e limiti
