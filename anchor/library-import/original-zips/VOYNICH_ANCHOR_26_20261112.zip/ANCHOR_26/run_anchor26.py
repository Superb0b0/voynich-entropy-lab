#!/usr/bin/env python3
"""ANCHOR-26: controlled crib-based recovery from a secret letter permutation.
Synthetic channel built with two public Naibbe unigram columns; NOT Naibbe proper.
Source: Greshko (2025), greshko/naibbe-cipher references/naibbe_tables.csv.
"""
import hashlib, json, random, re, statistics
from collections import defaultdict
from pathlib import Path

ALPHABET = 'abcdefghi lmnopqr stuvxyz'.replace(' ','')
ALPHA = '''a:ol b:qokchdy c:chey d:cheey e:chedy f:qokchey g:qokchy h:qokchedy i:shedy l:qokal m:qokar n:daiin o:aiin p:qoky q:qokol r:qokeedy s:qokeey t:qokaiin u:qokain v:qokey x:qokor y:qokdy z:qokeeedy'''
BETA1 = '''a:or b:okchdy c:okedy d:cheedy e:ar f:okchey g:okchy h:okchedy i:qokedy l:okal m:okar n:dal o:al p:oky q:okol r:okeedy s:okeey t:okaiin u:okain v:okey x:okor y:okdy z:okeeedy'''
def parse(s):
    return dict(x.split(':') for x in s.split())
TABLES = (parse(ALPHA), parse(BETA1))
assert len(ALPHABET)==23 and all(set(x)==set(ALPHABET) for x in TABLES)
ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'borg_0010r_plaintext_extracted.txt'
def plaintext():
    s=SOURCE.read_text(encoding='utf-8')
    s=re.sub(r'\[[^]]*\]', ' ', s).lower()
    return ''.join(c for c in s if c in ALPHABET)

def generate(text,seed):
    rng=random.Random(seed)
    perm=list(ALPHABET)
    rng.shuffle(perm)
    key=dict(zip(ALPHABET,perm))
    # Per-character channel: glyph boundaries are explicitly exposed, a favorable baseline.
    glyphs=[TABLES[rng.randrange(2)][key[c]] for c in text]
    return glyphs,key

def train_and_predict(glyphs,text,cut):
    # Ciphertext and aligned known plaintext supplied ONLY for the training prefix.
    d=defaultdict(set)
    for glyph,letter in zip(glyphs[:cut],text[:cut]):
        d[glyph].add(letter)
    mapping={g:next(iter(v)) for g,v in d.items() if len(v)==1}
    ambiguous={g:sorted(v) for g,v in d.items() if len(v)>1}
    held=glyphs[cut:]
    truth=text[cut:]
    pred=''.join(mapping.get(x,'?') for x in held)
    nknown=sum(p!='?' for p in pred)
    correct=sum(p==t for p,t in zip(pred,truth))
    return {'train_characters':cut,'heldout_characters':len(truth),'learned_glyphs':len(mapping),
            'conflicting_glyphs':len(ambiguous),'heldout_coverage':round(nknown/len(truth),6),
            'heldout_accuracy_all':round(correct/len(truth),6),
            'heldout_accuracy_conditional':round(correct/nknown,6) if nknown else None,
            'unknown_heldout':len(truth)-nknown,'incorrect_heldout':nknown-correct,
            'examples_ambiguity':dict(list(ambiguous.items())[:4])}

def main():
    s=plaintext()
    tests=[]
    for portion in (0.25,0.5,0.7):
        for seed in range(1000,1100):
            glyphs,key=generate(s,seed)
            cut=int(len(s)*portion)
            res=train_and_predict(glyphs,s,cut)
            res.update({'fraction':portion,'seed':seed})
            tests.append(res)
    aggregate=[]
    for portion in (0.25,0.5,0.7):
        group=[r for r in tests if r['fraction']==portion]
        aggregate.append({'train_fraction':portion,'runs':len(group),
          'mean_coverage':round(statistics.mean(x['heldout_coverage'] for x in group),6),
          'mean_accuracy_all':round(statistics.mean(x['heldout_accuracy_all'] for x in group),6),
          'mean_conditional_accuracy':round(statistics.mean(x['heldout_accuracy_conditional'] or 0 for x in group),6),
          'mean_conflicts':round(statistics.mean(x['conflicting_glyphs'] for x in group),2),
          'min_accuracy_all':min(x['heldout_accuracy_all'] for x in group),
          'max_accuracy_all':max(x['heldout_accuracy_all'] for x in group)})
    # Intrinsic collisions: even full public tables can reuse glyphs for different plaintext letters.
    reverse=defaultdict(set)
    for tab in TABLES:
        for plain,glyph in tab.items():reverse[glyph].add(plain)
    collision={g:sorted(s) for g,s in reverse.items() if len(s)>1}
    # One representative run; deterministic input/output hashes for verification.
    g,key=generate(s,1042)
    cut=int(len(s)*.5)
    example=train_and_predict(g,s,cut)
    example.update({'cipher_sha256':hashlib.sha256((' '.join(g)).encode()).hexdigest(),
                    'plaintext_sha256':hashlib.sha256(s.encode()).hexdigest(),
                    'secret_permutation_sha256':hashlib.sha256(json.dumps(key,sort_keys=True).encode()).hexdigest()})
    # Negative controls: misaligned known-plaintext crib, not revealed to learner as false.
    negatives=[]
    for shift in range(1,51):
        fake=s[shift:cut+shift]
        if len(fake)<cut:fake=(s[shift:]+s[:cut-len(s[shift:])])[:cut]
        corrupt=fake+s[cut:]
        z=train_and_predict(g,corrupt,cut)
        # Measure false decoder against the genuine heldout plaintext.
        z['shift']=shift
        negatives.append(z)
    result={'status':'EXPLORATORY_SYNTHETIC_NOT_VOYNICH_DECIPHERMENT','negative_controls':{
       'count':len(negatives),
       'consistent_wrong_cribs':sum(x['conflicting_glyphs']==0 for x in negatives),
       'min_conflict_glyphs':min(x['conflicting_glyphs'] for x in negatives),
       'median_conflict_glyphs':statistics.median(x['conflicting_glyphs'] for x in negatives)},
      'origin':'Greshko 2025 Naibbe public unigram alpha & beta1 glyph columns, transcribed from author table',
      'channel':'SECRET_PERMUTATION + RANDOM_ALPHA_BETA_UNIGRAM, exposed symbol boundaries; not full Naibbe',
      'known_plaintext':'aligned prefix supplied to decoder only',
      'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
      'plaintext_length':len(s),'alphabet_size':len(ALPHABET),
      'unique_output_glyphs':len(reverse),'intrinsic_collision_glyphs':collision,
      'summary':aggregate,'representative':example,
      'limits':['Training uses a known-plaintext crib and explicit glyph boundaries.',
        'It does not learn a key from ciphertext-only.',
        'It uses only two unigram tables, no bigrams, compounds or respacing.',
        'The plaintext is a short medieval Latin sample with editorial normalization.',
        'The Voynich itself has no confirmed crib.']}
    (ROOT/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'length':len(s),'summary':aggregate,'collisions':collision,'representative':example},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
