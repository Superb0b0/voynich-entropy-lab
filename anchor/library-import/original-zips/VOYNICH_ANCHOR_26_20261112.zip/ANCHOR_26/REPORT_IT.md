# ANCHOR-26 | Recupero della chiave nascosta sotto un'ancora nota

Data: 12 novembre 2026. **Stato: esperimento sintetico esplorativo, NON decifrazione del manoscritto Voynich.**

## Domanda

Quando si nasconde una permutazione segreta dell'alfabeto e si cifrano caratteri latini con due colonne di unigrammi pubblicate nel lavoro di Greshko, quanto del testo riservato viene recuperato imparando soltanto da un frammento latino noto e correttamente allineato? Il sistema distingue riferimenti deliberatamente falsi?

## Procedura

Si usano le colonne `unigram_alpha` e `unigram_beta1` della tabella Naibbe pubblica (`greshko/naibbe-cipher`, file `references/naibbe_tables.csv`, Git blob `5cd34fb81d80faf3b4d57dbf1719c05ffde25302`). Per ogni replica si genera una permutazione casuale di 23 lettere latine, che rimane segreta al recuperatore. Ogni carattere del testo latino di Borg 0010r (rimozione editoriale delle annotazioni fra parentesi, punteggiatura e spazi) è codificato con una delle due forme disponibili. Le frontiere di ogni glifo cifrato sono deliberatamente note. Il recuperatore memorizza esclusivamente le associazioni viste nel frammento iniziale; i simboli mai incontrati sono marcati `?`. Non legge il testo di prova fino al calcolo del punteggio.

Per ciascuna delle porzioni di testo noto 25%, 50%, 70%, si ripete il processo con 100 permutazioni e scelte omofoniche diverse. Sono 300 esecuzioni. Un caso con metà testo noto viene inoltre messo alla prova contro 50 frammenti falsi, spostati rispetto al testo cifrato autentico.

## Risultati

| Testo noto | Media caratteri riservati recuperati | Correttezza fra i soli recuperati |
|---|---:|---:|
| 25% | 86,89% | 100% |
| 50% | 96,01% | 100% |
| 70% | 98,25% | 100% |

Per la replica esemplificativa con 50% di testo noto, 141 caratteri allenano 34 associazioni: sui successivi 141 caratteri, 138 letti correttamente e 3 marcati ignoti. La differenza fra dato appreso e dato riservato è reale nel simulatore, ma il sistema ha una struttura molto favorevole: le codifiche visibili per lettera non collidono tra lettere diverse all'interno delle due tabelle selezionate.

Controllo negativo: nessuno dei 50 frammenti noti falsamente allineati produce una mappa senza contraddizioni; il minimo è 23 glifi contraddittori, la mediana 26.

## Interpretazione

Questo **non dimostra recuperabilità da solo testo cifrato**, e non è un test completo della cifratura Naibbe. Verifica una proposizione più limitata: un frammento autentico di significato, sufficientemente lungo e correttamente allineato, permette di recuperare un canale semplice con permutazione segreta. Il risultato dimostra inoltre che i falsi allineamenti testati sono discriminabili.

**Limiti forti:** (1) glifi separati visibilmente invece di gruppi Voynich; (2) note le due colonne e noto l'alfabeto; (3) solo unigrammi, nessuna codifica di bigrammi, composizione, variazione di confine o rispaziatura; (4) piccolo testo latino con omissioni editoriali; (5) l'accuratezza condizionata perfetta è favorita dalla mappatura iniettiva scelta; (6) il Voynich non fornisce ancora un *crib* accertato; (7) l'esperimento non prova che il Voynich sia cifrato, né che il Naibbe ne sia il meccanismo.

## Conclusione operativa

Il collo di bottiglia è **l'ancoraggio verificabile**, non soltanto l'invenzione di una chiave. Per progredire verso il Voynich occorre una previsione semantica indipendente, oppure un vero recuperatore *ciphertext-only*, valutato su controllo storico e testo riservato. Il lavoro rimane esterno a RC1.4.2 (`CLOSED_PENDING_VALIDATION`).

## Riproduzione

`python run_anchor26.py` con Python 3. Produce `results.json` con informazioni di provenienza e digest. Nessun pacchetto Python non-standard richiesto. Testo latino estratto dal benchmark pubblico Borg già acquisito negli esperimenti ANCHOR-12/23.

Riferimenti: Michael A. Greshko, *Cryptologia* (online 2025), DOI: 10.1080/01611194.2025.2566408. Il programma originale Naibbe include molte altre regole non implementate qui.
