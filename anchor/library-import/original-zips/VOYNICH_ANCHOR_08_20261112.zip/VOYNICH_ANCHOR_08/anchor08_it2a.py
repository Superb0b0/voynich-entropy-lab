#!/usr/bin/env python3
"""Exploratory cross-section visual-pair/lexical test, built on public Stolfi visual correspondences.
Never imports or executes the frozen RC1.4.2 pipeline.
"""
from pathlib import Path
from collections import Counter, defaultdict
from itertools import permutations, product
import hashlib, json, math, re, csv

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'inputs/IT2a-n.txt'
PDF={ 'f102r1': {'row3': ['f1v','f37v']},
      'f102r2': {'row1':['f47v','f32v'], 'row3':['f18v','f23r']},
      'f102v1': {'row2':['f19r']},
      'f89v2': {'row1':['f48v'], 'row3':['f48r']} }
# Explicit mapping of visual source to content strips, not claims of individual words.
# Source: Jorge Stolfi, Repeated plant drawings (last update 2025-11-18)

line_reg=re.compile(r'^<(f\d{1,3}[rv](?:\d)?)\.(\d+),([^>]*)>\s*(.*)$')
page_reg=re.compile(r'^<(f\d{1,3}[rv](?:\d)?)>\s*')
strip_comm=re.compile(r'<!.*?>')
def tokens(s):
    s=strip_comm.sub(' ',s).replace('<%>','').replace('<$>','')
    return [v for v in re.split(r'[\s\.,]+',s) if re.fullmatch(r'[a-z]{2,}',v)]

def load(txt):
    allp=defaultdict(list); pg_kind={}; page=None;kind=''
    for line in txt.splitlines():
        m=page_reg.match(line)
        if m:
            page=m.group(1); kind=''; continue
        if line.startswith('# ') and 'herbal' in line.lower(): pg_kind[page]='herbal'
        if not page:continue
        m=line_reg.match(line)
        if m:
            pf,idx,attr,content=m.groups()
            if pf != page: raise RuntimeError('page mismatch')
            if 'P0' not in attr and not attr.startswith(('+Pc','+Pr','=Pt')):continue
            if '<%>' in content or not allp[page]:allp[page].append([])
            allp[page][-1].extend(tokens(content))
    return allp,pg_kind

text=DATA.read_text('utf-8'); allp,kinds=load(text)
_,kinds=load((ROOT/'inputs/ZL3b-n.txt').read_text('utf-8'))
metadata={'source_sha256':hashlib.sha256(DATA.read_bytes()).hexdigest(), 'source_bytes':DATA.stat().st_size}
for page in PDF:
    print(page,'paragraph_lengths',list(map(len,allp[page])))
for page in ['f1v','f18v','f19r','f23r','f32v','f37v','f47v','f48r','f48v']:
    print(page,'all tokens',sum(map(len,allp[page])))

# Cosine IDF: build weights from all herbal pages only. This metric is fixed
# before comparing correct row scores, and is evaluated against exact row permutations.
N=sum(k=='herbal' for k in kinds.values())
df=Counter()
for page,k in kinds.items():
    if k=='herbal': df.update(set(t for p in allp[page] for t in p))
def idf(t): return math.log((1+N)/(1+df.get(t,0)))+1

def vec(words):
    c=Counter(words);v={t: math.sqrt(n)*idf(t) for t,n in c.items()}
    norm=math.sqrt(sum(x*x for x in v.values()))
    return {t:x/norm for t,x in v.items()} if norm else {}
def cosine(v,w):return sum(x*w.get(k,0) for k,x in v.items())

def getrows(page):
    pars=allp[page]
    # f102v1 has two visually grouped plant strips; IT2a subdivides
    # the first strip's text into two paragraphs whereas ZL3b does not.
    # Join those two units on structural, externally specified grounds.
    if page=='f102v1' and len(pars)==3:
        pars=[pars[0]+pars[1],pars[2]]
    return {f'row{i+1}':p for i,p in enumerate(pars)}

samples=[]
for pg,grp in PDF.items():
    rows=getrows(pg)
    for row,herbals in grp.items():
        assert row in rows, (pg,row,list(rows))
        for h in herbals:
            a=[t for p in allp[h] for t in p]
            sims={k:cosine(vec(a),vec(v)) for k,v in rows.items()}
            overlap={k:len(set(a)&set(v)) for k,v in rows.items()}
            samples.append({'herbal':h,'pharma':pg,'row':row,'similarity':sims,'overlap':overlap,'n_herbal_tokens':len(a),'n_pharma_rows':len(rows)})

# Exact nuisance-controlled null: for each pharma *page* injectively reassign
# observed visually defined row groups to distinct paragraphs of same page,
# preserving the 2+2 grouping and pharmaceutical page information.
page_scores={}
for pg,grp in PDF.items():
    rows=list(getrows(pg))
    matches=list(grp)
    variants=[]
    for assignment in permutations(rows,len(matches)):
        mp=dict(zip(matches,assignment))
        val=sum(s['similarity'][mp[s['row']]] for s in samples if s['pharma']==pg)
        ov=sum(s['overlap'][mp[s['row']]] for s in samples if s['pharma']==pg)
        variants.append({'score':val,'overlap':ov,'map':mp})
    observed=next(x for x in variants if all(x['map'][r]==r for r in matches))
    page_scores[pg]={'observed':observed,'variants':variants}
combinations=list(product(*(v['variants'] for v in page_scores.values())))
obs=sum(v['observed']['score'] for v in page_scores.values()) /len(samples)
null_scores=[sum(v['score'] for v in cm)/len(samples) for cm in combinations]
obsov=sum(v['observed']['overlap'] for v in page_scores.values())
null_ov=[sum(v['overlap'] for v in cm) for cm in combinations]
pval=sum(x>=obs-1e-12 for x in null_scores)/len(null_scores)
pov=sum(x>=obsov for x in null_ov)/len(null_ov)
print('TOTAL',len(samples),'null_permutations',len(null_scores),'IDF_cosine_obs',obs,'p',pval,'overlap_obs',obsov,'p_overlap',pov)
for s in samples:
    rank=1+sum(v>s['similarity'][s['row']]+1e-10 for v in s['similarity'].values())
    print(s['herbal'],s['pharma'],s['row'],'sim',round(s['similarity'][s['row']],4),'rank',rank,'/',len(s['similarity']))

# Verify the only two labeled plant fragments on f102r2 row 3 are not automatically plant names.
first={h:next((p[0] for p in allp[h] if p),None) for h in ['f18v','f23r']}
labels={'f18v':'koldarod','f23r':'odalydary'}
label_check=[]
for h,label in labels.items():
    ws=[t for p in allp[h] for t in p]
    label_check.append({'herbal':h,'pharma_label':label,'first_herbal_token':first[h], 'label_verbatim_on_herbal_page':label in ws,'prefix4_shared_with_herbal_word':any(t[:4]==label[:4] for t in ws),'herbal_word_count':len(ws)})

out={'metadata':metadata,'source':'Jorge Stolfi, Repeated plant drawings, visual herb/pharma matches; page-to-row mapping based on described drawing rows and local transcription layout.','status':'EXPLORATORY_NOT_DECIPHERMENT','independent_visual_matches':len(samples),'per_pharma_page':{k:{'n_paragraphs':len(allp[k]),'matched_row_groups':list(PDF[k])} for k in PDF},'idf_cosine':{'observed':obs,'null_mean':sum(null_scores)/len(null_scores),'exact_p_one_sided':pval,'total_exact_arrangements':len(null_scores)},'exact_lexical_overlap':{'observed':obsov,'null_mean':sum(null_ov)/len(null_ov),'exact_p_one_sided':pov},'pairs':samples,'direct_labeled_fragments':label_check,'method_note':'Paragraphs on f89v3 are in ZL3b under f89v2. No graphic-label association has been independently audited; test requires only visual match to strip, not label position. All 9 visuals are from one catalogue and should not be treated as 9 independent sources. No semantic interpretation is licensed.'}
(ROOT/'results_it2a.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
with (ROOT/'visual_match_scores_it2a.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['herbal','pharma','row','observed_similarity','row_rank','n_herbal_tokens','candidate_rows']);w.writeheader()
    for s in samples:
        w.writerow({'herbal':s['herbal'],'pharma':s['pharma'],'row':s['row'],'observed_similarity':round(s['similarity'][s['row']],6),'row_rank':1+sum(v>s['similarity'][s['row']]+1e-10 for v in s['similarity'].values()),'n_herbal_tokens':s['n_herbal_tokens'],'candidate_rows':' | '.join(f'{k}:{v:.5f}' for k,v in s['similarity'].items())})
