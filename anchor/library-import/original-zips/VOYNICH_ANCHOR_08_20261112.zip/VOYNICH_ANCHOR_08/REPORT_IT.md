# VOYNICH • ANCHOR-08 • Una prova semantica attraverso le immagini

**Data:** 12 novembre 2026  
**Stato:** analisi esplorativa; nessuna decifrazione, nessuna attribuzione di significato linguistico.

## Domanda

Quando uno stesso disegno vegetale è ripetuto in un'erbario e nella sezione farmaceutica, il paragrafo farmaceutico della rispettiva riga contiene un'impronta lessicale più vicina al testo della pagina botanica rispetto agli altri paragrafi farmaceutici dello stesso pannello?

## Fonte indipendente delle associazioni visive

Jorge Stolfi, *Repeated plant drawings*, ultima modifica 18 novembre 2025: https://www.ic.unicamp.br/en/~stolfi/EXPORT/voynich/00-06-07-word-grammar/Notes/064/work/projects/voynich/projects/programs/c/big/big/projects/voynich/Notes/096/work/Notes/091/report/report_091.html . La fonte elenca **nove** corrispondenze tra disegni botanici e farmaceutici. Sono proposte di somiglianza, non identificazioni botaniche certe. Non abbiamo creato le coppie in base alle parole.

| Erbario | Pannello farmaceutico | Riga di disegni |
|---|---|---|
| f1v | f102r1 | 3 |
| f37v | f102r1 | 3 |
| f47v | f102r2 | 1 |
| f32v | f102r2 | 1 |
| f18v | f102r2 | 3 |
| f23r | f102r2 | 3 |
| f19r | f102v1 | 2 |
| f48v | f89v2 (nell'inventario visivo «f89v3») | 1 |
| f48r | f89v2 (nell'inventario visivo «f89v3») | 3 |

La corrispondenza fra una riga di disegni e il relativo paragrafo è un'**assunzione di modello**, basata sulla disposizione del testo; non abbiamo una prova paleografica che ogni disegno sia descritto in quel paragrafo. In f102v1 IT2a spezza in due il testo del primo gruppo e ZL3b lo tiene unito: il test riunisce i due blocchi della prima riga in entrambe le rappresentazioni, per conservare le due unità visive, senza ottimizzazione su risultati.

## Metodo riproducibile

Le parole di ciascuna pagina erboristica (loci P) sono confrontate con tutte le righe di testo della propria pagina farmaceutica, senza usare gli abbinamenti in fase di costruzione delle frequenze. I token ambigui sono esclusi; si usa il coseno fra vettori di frequenze pesate IDF dei token EVA (trasformazione radice quadrata sulle frequenze). I pesi sono costruiti sulle pagine botaniche del corpus. Il nullo rispetta il pannello farmaceutico e i raggruppamenti di pagine botaniche assegnati alla medesima riga; vengono enumerate tutte le **216** combinazioni di riassegnazione dei paragrafi.

Per la sensibilità si usa il medesimo calcolo su IT2a Takahashi. Test aggiuntivo descrittivo: numero di parole intere condivise, senza correzioni lessicali o ipotesi di equivalenza fra caratteri.

## Risultati

| Corpus | Coseno medio osservato | p esatto, 216 permutazioni | Parole condivise totali | p per parole condivise |
|---|---:|---:|---:|---:|
| ZL3b | 0,03141 | 0,17593 | 38 | 0,25926 |
| IT2a | 0,03058 | 0,18056 | 40 | 0,09259 |

Le associazioni visive non producono un vantaggio lessicale significativo secondo il criterio operativo considerato. La prova non ha potenza elevata: solo nove osservazioni e poche righe per pagina, con coppie correlate entro lo stesso pannello. Inoltre non deve diventare una prova «contro il significato» in senso assoluto: il nome della pianta potrebbe non trovarsi nel paragrafo, oppure la forma scritta potrebbe cambiare in funzione della sezione o della grammatica.

### Due frammenti etichettati direttamente

Secondo l'allineamento delle figure catalogate e dei loci del pannello f102r2:

- `f102r2.21,@Lf`: **koldarod**, frammento #212, visivamente associato a f18v; la sequenza esatta non compare nella pagina f18v, né è il suo primo token (`told`).
- `f102r2.22,@Lf`: **odalydary**, frammento #213, visivamente associato a f23r; la sequenza esatta non compare nella pagina f23r, né è il suo primo token (`pydchdom`).

Le due letture sono identiche in ZL3b e IT2a. Questo respinge una versione molto semplice della teoria «nome della pianta copiato alla lettera», ma non sistemi con abbreviazioni, varianti, nomi di preparazioni o codici differenti.

## Il candidato semantico più netto rimasto: sette stelle

Nella pagina astronomica f68r3 la sequenza `doaro` appare al locus `f68r3.11,@Ls`. La sua lettura coincide in ZL3b e Takahashi IT2a ed è una sola occorrenza esatta in entrambi i corpus. La figura vicina è un gruppo compatto di sette stelle, da tempo proposto come rappresentazione delle **Pleiadi**. È una plausibile **ancora iconografica**, non una traduzione: non sappiamo se l'etichetta nomini il gruppo, una proprietà o una funzione nel diagramma.

Fonti sulla disposizione e sull'ipotesi Pleiadi: https://vib.tamagothi.de/index.php?id=f68r3&show=page ; https://www.voynich.nu/q09/ . Il fatto che `doaro` ricorra una sola volta impedisce un controllo di ripetizione letterale. La ricerca di una *seconda rappresentazione iconografica della stessa entità*, non la forzatura del termine in una lingua proposta a posteriori, è il prossimo tentativo ad alta leva.

## Valutazione e decisione

1. I duplicati botanici illustrati forniscono un test intersezionale non circolare nella scelta delle coppie, ma il test lessicale semplice è negativo su entrambe le trascrizioni.
2. Non identifichiamo né assumiamo significati di parole Voynich.
3. Per continuare in modo informativo serve una *seconda occorrenza iconograficamente identificabile* della medesima entità oppure documentazione storica di una fonte comune per una figura che sia associata a un elemento testuale controllabile.
4. Non si ripetono test di morfologia su etichette zodiacali senza una previsione semantica esatta e verificabile.
5. RC1.4.2 e tutti gli artefatti congelati restano intatti; `CLOSED_PENDING_VALIDATION`, `RP-01` aperto, `f085v` irrisolto.

## Integrità e comando

I file originali usati nel test hanno SHA-256: ZL3b `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc`, IT2a `7f27a8b0feed8f6de0a99900df6bf912dd1d295c38e5f830bac8b41c3f536fb5`.

Esecuzione dalla cartella del pacchetto:

```bash
python anchor08.py
python anchor08_it2a.py
```

Nessuna pipeline originale è stata riscritta, eseguita o modificata. Le statistiche non sono validate attraverso una preregistrazione esterna e non stabiliscono identificabilità semantica.
