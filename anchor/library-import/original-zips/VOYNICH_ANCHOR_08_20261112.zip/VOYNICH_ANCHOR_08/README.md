# ANCHOR-08 • Voynich cross-section visual/lexical test

Read REPORT_IT.md before using the data.

Input corpora: `inputs/ZL3b-n.txt`, `inputs/IT2a-n.txt` (original bytes, SHA in report).
Scripts: `python anchor08.py`; `python anchor08_it2a.py`. Standard library only.
Outputs: `results.json`, `results_it2a.json`; `visual_match_scores.csv`, `visual_match_scores_it2a.csv`.
Zero plaintext recovered. This test evaluates a particular cross-section lexical-reuse hypothesis and is exploratory only. It does not run the frozen RC1.4.2 pipeline.
