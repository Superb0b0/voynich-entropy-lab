VISUAL QA PENDING. This package is NOT certified blind, may still contain writing and crop errors.
Inspect all image crops before attributing garment/body features.
Reviewer should never see full dataset with label transcriptions or linkage key.
If a masked patch hides an attribute, mark uncertain; never guess.
Return the CSV without consulting Voynich label text.