# ASTRO-07 | Repliche del motivo tripartito e controllo dell'ipotesi Oresme

Data: 12 novembre 2026. **Ricognizione documentale**, non analisi cieca delle scansioni, non decifrazione.

## Ipotesi da ASTRO-06
Una grammatica cosmografica composta da: (A) cerchio centrale tripartito (tipo T-O); (B) regione di stelle; (C) confine ondulato o *nebuly* che delimita la regione celeste. Predizione debole: A ricompare su altri fogli; predizione forte: A+B+C ricompaiono con la stessa relazione spaziale su altri fogli non utilizzati per formulare l'ipotesi.

## Evidenze
- **f68v3**: A+B+C documentati nelle descrizioni; otto fasce spiraliformi testuali. È la pagina da cui nasce la previsione, dunque non è un test fuori campione.
- **Rosette, angolo superiore destro**: A è documentato, ma non l'intera relazione spaziale A+B+C nel medesimo piccolo motivo. Non un successo per la previsione forte.
- **f86v3**: A è documentato da Stolfi; la figura è piccola e associata a segni/scribbles parzialmente illeggibili. B e C in relazione allo stesso piccolo motivo non documentati. Non un successo per la previsione forte.
- **BnF Français 565, fol. 1r**: diagramma con globo tripartito, cielo stellato e fascia di nubi. Confronto noto almeno dal 2014 (Ellie Velinska). La figura non autorizza inferenze di copia diretta né la lettura del Voynich.

## Correzione bibliografica rilevante
Il parallelo iconografico preciso di **BnF Français 565** è la miniatura di **folio 1r**, all'inizio del *Traité de la sphère*, non la miniatura di folio 23r. Il folio 23r raffigura Oresme che offre al re Carlo V la traduzione del *Livre du ciel et du monde*. Il manoscritto contiene entrambe le opere, in sezioni diverse: ff. 1–22v e 23–171v. Fonti: catalogo IIIF Biblissima e BnF; Nick Pelling, *Cipher Mysteries* (2017).

## Seconda cautela storica
Il simbolo tripartito non determina da solo tre nomi geografici. Uno studio storico discusso da Pelling segnala che il diagramma di f1r di Oresme rielabora profondamente il consueto significato continentale della T-O map: la metà inferiore può rappresentare una massa d'acqua e i quarti superiori territori distinti. Quindi non è corretto assegnare automaticamente Asia/Europa/Africa alle tre regioni Voynich né usare queste etichette come chiave senza prova aggiuntiva.

## Esito
- Debole (forma tripartita ripetuta): **sostenuta, ma la ricorrenza era già nota in letteratura**, quindi nessuna scoperta nuova.
- Forte (intera composizione ricorrente con rapporto spaziale specifico): **non verificata**; le descrizioni dei pannelli alternativi sono insufficienti per confermarla e non permettono di dichiarare un'assenza a livello di immagine.
- Collegamento iconografico alla tradizione di Oresme: **plausibile come analogia culturale, non prova di dipendenza diretta**.
- Traduzione di eventuali parole centrali: **nessuna**.
- Statistica: **nessun p-value**. La selezione di esempi non è un campione cieco e le ricorrenze sono state suggerite dalle fonti stesse.

## Fonti
1. René Zandbergen, https://www.voynich.nu/illustr.html
2. René Zandbergen, https://voynich.nu/q09/index.html
3. Jorge Stolfi, https://vib.tamagothi.de/index.php?id=f86v3&show=page
4. Biblissima, https://iiif.biblissima.fr/collections/manifest/4d402953e89fb48aa4313a55aace72bcb1b4c80d
5. BnF, https://expositions.bnf.fr/monde-en-spheres/grand/mes_005.php
6. Nick Pelling, https://ciphermysteries.com/2017/10/18/bnf-francais-565-nicole-oresme-jean-de-berrys-library

## Decisione operativa
La prova visiva fuori campione resta aperta, ma non ha senso moltiplicare analogie iconografiche già note senza annotazioni indipendenti. Priorità a verificare il ruolo effettivo delle tre regioni Voynich con criteri fissati prima dell'analisi, non a postularne il significato geografico.
