# VOYNICH — EXP-GEN-01, generated-corpus falsification

**2026-11-12 | EXPLORATORY, FAIL | RC1.4.2 unchanged**

For the first time in this branch, the fixed three-component probabilistic model is sampled as **new token sequences** rather than merely scored on genuine preceding tokens. Every generated folio begins with empty history; only **layout** (lines/paragraphs, lengths, Currier label) is taken from held-out pages. Real words from held-out pages are not fed to the sampler. Global word probabilities are learned from *base* folios, but the set of possible word forms is transductively obtained from the corpus, as in the original model.

## Locked model, no synthetic-score tuning

* Global Currier-stratified unigram G, with 0.10 additive smoothing.
* 5% selection from the previously generated words of the same folio.
* 2% selection of a glyph-edit-distance-one variant of the words in the previous two generated lines of the **current paragraph**.
* 93% global G (with unavailable folio/edit components falling back to G). The edit component is renormalized over recent words which have at least one permitted neighbor. This is an explicitly noted implementation convention because the earlier conditional feature-score did not form a complete distribution when a neighbor set was empty.
* For the first word of each line, forms beginning with `y` are upweighted by exp(1); implemented exactly by rejection sampling to yield normalized probabilities. This **is not** a suffix-specific `yX/oX` rule, so recovering its matched OR is not an independent discovery.
* Four ablation variants: global baseline; +folio; +folio+position; +folio+position+edit1 (unified). Five fixed RNG seeds (`1101..1105`) each, for both `ZL3b` and `IT2a` = 40 generations.

## Observed data and output

The heldout test section consists of 54 folios, 1,202 aligned lines, 9,967 ZL3b tokens / 10,003 IT2a tokens. For each rendition the generator produces **exactly** the corresponding number of word positions, preserving the true layout but not the true words.

| ZL3b mean, 5 seeds | Density | Jaccard adjacency | Local exact repetition | Hapax / types | Matched yX/oX OR |
|---|---:|---:|---:|---:|---:|
| Real heldout | 0.9468 | 0.0271 | 0.0569 | 0.7157 | 3.60 |
| Global baseline | 0.9278 | 0.0144 | 0.0285 | 0.5825 | 0.93 |
| + Folio memory | 0.9262 | 0.0197 | 0.0386 | 0.5591 | 1.11 |
| + Position | 0.9251 | 0.0197 | 0.0381 | 0.5560 | 2.98 |
| + Edit-one memory | 0.9270 | 0.0185 | 0.0366 | 0.5584 | 2.75 |

| IT2a mean, 5 seeds | Density | Jaccard adjacency | Local exact repetition | Hapax / types | Matched yX/oX OR |
|---|---:|---:|---:|---:|---:|
| Real heldout | 0.9632 | 0.0290 | 0.0592 | 0.6965 | 3.20 |
| Global baseline | 0.9507 | 0.0156 | 0.0311 | 0.5589 | 1.02 |
| + Folio memory | 0.9512 | 0.0195 | 0.0382 | 0.5408 | 1.05 |
| + Position | 0.9520 | 0.0197 | 0.0389 | 0.5343 | 2.92 |
| + Edit-one memory | 0.9536 | 0.0196 | 0.0382 | 0.5388 | 2.75 |

**Verdict: fail.** The generator can imitate some position effects (by design), and folio memory increases line-to-line repetition, but the models cannot recover the observed high hapax ratio, local repetition, and row adjacency simultaneously. In both transcriptions, all 5 unified runs miss the original full-corpus hapax band, and all 5 miss its repetition band. **The historical four bands were defined on a different, larger corpus and therefore do not constitute calibrated pass/fail thresholds for the shorter heldout sample**; comparisons with the matched heldout reference above take precedence. The code prints the old bands only as an additional descriptive diagnostic.

The synthetic `edit1_between_adjacent_rows` statistic also stays below the observed heldout value. Its implementation is a related, not necessarily identical, endpoint to previously published edit-one counts.

## Limits

* This is **not a new blind corpus**; hypotheses and folio holdout have already been examined in earlier explorations. A fixed split is necessary but insufficient for a novel confirmatory test.
* Two Voynich transcriptions from the same physical manuscript are dependent evidence, not independent manuscripts.
* Known total word types (including test-only types) create a transductive advantage. The model **cannot invent novel types outside this dictionary**, so it is by construction a limited model of productive word formation.
* The four legacy benchmark acceptance bands concern the full source corpus rather than 9,967/10,003-token heldout segments, and printed `bands_pass` values cannot be interpreted as proper acceptance test results.
* The model samples the original folio's known line lengths and paragraph divisions; it has **not generated a full physical manuscript from scratch**.
* The positional `y` bias is **explicit** and the matched OR can therefore be artificially improved. No inference that the underlying original system used such a rule is warranted.
* The edit neighbor component is normalized and samples only *known* types. A truly constructive model needs an independent, out-of-vocabulary form-generation mechanism.

## Reproduce

Python 3.11+ and NumPy. From inside the extracted archive:

```bash
python generate_gate.py
```

The complete verified source inputs and immutable experiment scripts are bundled under `upstream/`. The program uses the cached prior `edit1_results.json` parameter context, and explicitly fixes the production parameters above without consulting its test scores. It overwrites only its own `results.json` and `replicates.csv` in the same folder. It will verify input SHA-256 during parser setup. `log.txt` records an actual completed run.

## Next meaningful discriminant

A *productive glyph-word generator* that can create previously unseen but morphologically related forms. Such a model must preserve a fixed production rule and be measured on truly quarantined folios. A rise in hapax without the required adjacency or row structure is not success.
