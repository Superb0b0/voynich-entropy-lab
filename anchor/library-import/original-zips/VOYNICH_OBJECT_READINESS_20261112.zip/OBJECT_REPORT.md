# EXP-OBJECT-01 · Audit di fattibilità semantica con oggetti concreti

**Data:** 12 novembre 2026. **Esito:** `BLOCKED_NO_ADJUDICATED_BINARY_LABELS`.

## Che cosa è stato eseguito

1. Ricognizione dei materiali già presenti, compresi i 206 profili visuali storici. Nessuna mutazione dei dati RC1.4.2.
2. Valutazione del catalogo pubblico `geoffitect/voynich/data/visual/object_catalog.json` (Git blob `f7ad74ea8e6810d8259b22d8381d4ccd73544d72`). Contiene *bounding box, fonti di salienza e riferimenti a parole*, non etichette ontologiche indipendenti `root`, `star`, `leaf` o `jar`. Il modello di rilevamento non fornisce quindi la verità di riferimento richiesta.
3. Estrazione conservativa di **55 attestazioni positive**, **21 categorie** e **36 ID distinti di folio/pannello** dalle descrizioni puntuali di René Zandbergen: https://voynich.nu/illustr.html. Le categorie `approximate` riflettono incertezze esplicite ("simile a", "sembra"). NON si tratta di etichette indipendentemente verificate nel presente esperimento.
4. Confronto esatto con i **131 folii** del precedente esperimento di collegamento testo–profili: **19 attestazioni riferite a 16 folii**. I riferimenti multipannello non sono stati aggregati forzatamente.
5. Elaborazione di una scheda di annotazione per tutti i 131 folii e di una lista di **67 folii prioritari** per verifiche di oggetti di confronto nel medesimo gruppo `I × L × Q`.

## Esito della fattibilità

| Criterio | Risultato |
|---|---:|
| Pagine eleggibili nella precedente analisi | 131 |
| Attestazioni positive raccolte | 55 |
| Identificativi di pagina/pannello citati | 36 |
| Attestazioni su join diretto eleggibile | 19 |
| Folii distinti con almeno un'attestazione positiva | 16 |
| Categorie con almeno 2 positivi eleggibili | 4/21 |
| Categorie con meno di 2 positivi eleggibili | 17/21 |
| **Assenze verificate** | **0** |
| **Endpoint binari identificabili con questi dati** | **0** |

**Non è stato eseguito alcun test parola–oggetto**: una classe con soli esempi positivi e nessun esempio negativo verificato non permette un test presenza/assenza identificabile. Una pagina non menzionata da una fonte *non è una pagina in cui quell'oggetto è assente*.

## Piano di annotazione indipendente

- Impostare una rubrica iconografica preventiva: `PRESENT_VERIFIED`, `ABSENT_VERIFIED`, `UNCERTAIN`, `NOT_VISIBLE`, evitando inferenze sul significato delle parole.
- Due annotatori indipendenti, ciechi al testo e alle frequenze lessicali; registrare disaccordi e arbitrato. Citare sempre la posizione dell'oggetto e la fonte dell'immagine originale.
- Prima annotare 67 folii prioritari con campionamento comparabile nel gruppo `I × L × Q`, non usare la classificazione della sezione come surrogato dell'oggetto.
- I pannelli di pagine ripiegate richiedono un crosswalk *specifico*, non una proiezione su `fNNNr/v`.
- Congelare etichette, registri delle esclusioni, feature testuali, split per **foglio fisico** e codici di analisi prima di stimare associazioni. Per le categorie rare impiegare un modello di controllo esplicito, non ricercare automaticamente parole “migliori” senza correzione per confronti multipli.
- Con `object_gate.py` sono richiesti almeno **5 positivi e 5 negativi con revisione indipendente** per una valutazione preliminare di ogni categoria. Questa è una soglia tecnica minima, **non una garanzia di potenza statistica**. Verificare inoltre variabilità entro `I × L × Q` e sufficiente copertura di quires prima del test.

## Distinzione necessaria

Queste descrizioni provengono da una fonte consultata **dopo** diversi esperimenti sul Voynich: sono conoscenze pubbliche già accessibili, non un campione di test mai esaminato. Non attribuire loro status di holdout indipendente. Non promuovere alcun `archetype_score` a verità iconografica, né sbloccare la pipeline RC1.4.2 (`CLOSED_PENDING_VALIDATION`, rilievo RP-01 ancora aperto).

## Riproduzione

```bash
python build_object_registry.py
python build_annotation_plan.py
python object_gate.py
```

L'ultima istruzione ritorna volutamente codice di uscita **2** in assenza di etichette complete; questo è il comportamento corretto del *fail closed*.
