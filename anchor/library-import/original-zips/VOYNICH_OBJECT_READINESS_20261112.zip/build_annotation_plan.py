#!/usr/bin/env python3
"""Independent image-annotation task sheet; UNKNOWN does not mean absent."""
import pathlib,csv,json,collections
P=pathlib.Path(__file__).resolve().parent
with (P/'joined_manifest.csv').open() as f: folios=list(csv.DictReader(f))
with (P/'object_positive_attestations.csv').open() as f: att=list(csv.DictReader(f))
match=collections.defaultdict(list)
for a in att:match[a['folio_key']].append(a)
attested_folios={a['folio_key'] for a in att}
category=sorted(set(a['object_category'] for a in att))
with (P/'object_annotation_sheet.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['folio','I','L','Q','token_count','status','evidence_categories','source','reviewer_1','reviewer_2','final_adjudication']+category)
 for row in folios:
  key=row['folio'];good=match[key];names=sorted(set(x['object_category'] for x in good))
  w.writerow([key,row['I'],row['L'],row['Q'],row['tokens'],'UNREVIEWED',';'.join(names), 'https://voynich.nu/illustr.html' if good else '', '', '', '']+[('POSITIVE_SOURCE' if c in names else 'UNKNOWN') for c in category])
# Which objects can be contrasted at all within the previous I*L*Q strata?
byid={r['folio']:r for r in folios}; strata=collections.defaultdict(list)
for r in folios:strata[(r['I'],r['L'],r['Q'])].append(r['folio'])
rows=[]
for c in category:
 present=[k for k,L in match.items() if k in byid and c in {a['object_category'] for a in L}]
 candidate=set()
 for k in present:
  r=byid[k];candidate.update(set(strata[(r['I'],r['L'],r['Q'])])-{k})
 rows.append({'object':c,'positive_eligible':len(present),'unique_strata_with_positive':len({(byid[k]['I'],byid[k]['L'],byid[k]['Q']) for k in present}),'other_pages_in_same_strata_needing_review':len(candidate),'verified_absent':0,'testable_now':'NO'})
with (P/'object_strata_readiness.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
priority=[]
for r in folios:
 same=match[r['folio']]
 count=sum(1 for z in rows if z['positive_eligible'] and z['object'] in {a['object_category'] for a in same})
 adjacent=sum(1 for z in rows if r['folio'] not in attested_folios and (r['I'],r['L'],r['Q']) in {(byid[k]['I'],byid[k]['L'],byid[k]['Q']) for k in match if k in byid and z['object'] in {a['object_category'] for a in match[k]}})
 if count or adjacent:priority.append((0 if count else 1, -adjacent, r['folio'],r['I'],r['L'],r['Q'],';'.join(sorted(set(a['object_category'] for a in same))),adjacent))
priority.sort()
with (P/'annotation_priority.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['folio','I','L','Q','existing_positive_categories','same_stratum_categories_to_review','review_type'])
 for a,b,key,i,l,q,positive,adj in priority:w.writerow([key,i,l,q,positive,adj,'confirm_positive' if a==0 else 'blind_presence_absence'])
print(json.dumps({'folios':len(folios),'object_categories':len(category),'priority_candidates':len(priority),'priority_source_positive':sum(bool(match[r['folio']]) for r in folios),'categories_without_2_positive':sum(r['positive_eligible']<2 for r in rows),'categories_with_2plus_positive':sum(r['positive_eligible']>=2 for r in rows),'minimum_required':'two independently scored image annotators + explicit absent and unknown labels per object, with panel-aware joins'},indent=2))
