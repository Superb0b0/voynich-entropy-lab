#!/usr/bin/env python3
"""Positive-only source attestation registry, NOT absence-labelled dataset."""
import csv, json, pathlib, re, collections
ROOT=pathlib.Path(__file__).resolve().parent
rows=[]
source='https://voynich.nu/illustr.html'
def add(cat, pages, evidence, uncertainty='explicit'):
    for p in pages.split():
        rows.append({'folio_key':p, 'object_category':cat,'presence':1,'source':source,'evidence':evidence,'certainty':uncertainty,'negative_control_valid':False})
add('snake','f49r','Two snakes around the plant roots')
add('dragon','f25v','Dragon eating a leaf')
add('bird','f86v3','Two birds, one nesting and one flying')
add('frog','f102r2','Frog on a pharmaceutical panel')
add('lizard','f102r2','Smaller lizard-like creature','approximate')
add('sheep_or_goat','f116v','Sheep or goat in the margin','approximate')
add('animal_unspecified','f79v f80v','Unspecified animal in illustration')
add('animal_like_root','f34v f46v f90v1','Root with animal-like appearance','approximate')
add('sun','f67v2 f67v1 f68r1 f68r2 f68v1 f85r2','Sun depiction mentioned in illustration details')
add('moon','f67r1 f67v2 f68r1 f68r2 f68r3 f70r2 f86v4','Moon depiction mentioned in illustration details')
add('stars_astronomical','f67v1 f68r1 f68r2 f68r3 f68v3 f68v2 f68v1','Stars/constellations in specific astronomical panels')
add('T_O_map','f68v3 f86v3','T-O-like world map motif','approximate')
add('cross','f79v','Cross held by upper left figure')
add('ring','f79v f80v f82r','Ring-like object held by figure','approximate')
add('flower_held','f76v f85r2 f86v4','Flower-like object held by a figure','approximate')
add('small_bottle','f85r2','Small bottle-like object','approximate')
add('cup','f86v4','Cup-like object','approximate')
add('flask','f86v4','Flask-like object','approximate')
add('castle_tower','f85v f86r','Rosettes foldout buildings, generic parent folios only','approximate')
add('root_with_eyes','f17r','Roots appear to contain eyes','approximate')
add('star_marginal','f58r f58v f106r f106v f107r f108v f111r f111v f116r','Marginal stars discussed, selected pages only')
# reject source categories that would encode section trivially e.g. all pharmaceutical pages have pots
with (ROOT/'object_positive_attestations.csv').open('w',newline='',encoding='utf8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
allowed=set()
with (ROOT/'joined_manifest.csv').open() as f:
 for r in csv.DictReader(f):allowed.add(r['folio'])
# The historical multipanel source folios are not direct folio join candidates.
exact=[r for r in rows if r['folio_key'] in allowed]
D=collections.defaultdict(set)
for r in exact:D[r['object_category']].add(r['folio_key'])
metrics={
 'positive_attestations':len(rows),
 'unique_source_folios':len({r['folio_key'] for r in rows}),
 'eligible_semantic_test_folios':len(allowed),
 'attestations_on_eligible_exact_folios':len(exact),
 'eligible_folios_with_any_positive_attestation':len({r['folio_key'] for r in exact}),
 'positive_folios_per_category_on_eligible_join':{k:len(v) for k,v in sorted(D.items())},
 'verified_negative_attestations':0,
 'valid_binary_presence_absence_targets':0,
 'decision':'FAIL_CLOSED_NO_VALID_NEGATIVE_LABELS',
 'limitations':['Source only enumerates selected positive examples, does not assert negative labels for unlisted pages.', 'Panel-specific f68r1 or f86v4 cannot be linked to a whole folio without panel-level crosswalk.', 'Many categories nearly identify the conventional image section.', 'Historical V1 visual profiles provenance issue RP-01 remains open.']
}
(ROOT/'object_readiness.json').write_text(json.dumps(metrics,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(metrics,indent=2,ensure_ascii=False))
