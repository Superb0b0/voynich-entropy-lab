#!/usr/bin/env python3
"""Fail-closed preflight for concrete-object text-image tests.

Status POSITIVE_SOURCE = bibliographic attestation, NOT an adjudicated independent image label.
UNKNOWN and missing cells are never interpreted as object absence.
"""
from __future__ import annotations
import csv,json,pathlib,collections,sys
P=pathlib.Path(__file__).resolve().parent
sheet=P/'object_annotation_sheet.csv'
rows=list(csv.DictReader(sheet.open(encoding='utf8',newline='')))
meta={'folios':len(rows),'unique_folios':len({r['folio'] for r in rows})}
assert len(rows)==131 and len({r['folio'] for r in rows})==131, 'Unexpected eligible folio count'
cols=[c for c in rows[0] if c not in {'folio','I','L','Q','token_count','status','evidence_categories','source','reviewer_1','reviewer_2','final_adjudication'}]
passes=[]; blockers=[]
for col in cols:
 lab=collections.Counter(r[col].strip().upper() for r in rows)
 negatives=lab.get('ABSENT_VERIFIED',0)
 positives=lab.get('PRESENT_VERIFIED',0)
 if positives>=5 and negatives>=5:
  passes.append(col)
 else: blockers.append({'object':col,'verified_present':positives,'verified_absent':negatives,'source_only_positive':lab.get('POSITIVE_SOURCE',0)})
meta['categories']=len(cols);meta['candidate_test_targets']=passes;meta['blocked_targets']=blockers;meta['status']='READY_FOR_FURTHER_DESIGN' if passes else 'BLOCKED_NO_ADJUDICATED_BINARY_LABELS'
print(json.dumps(meta,indent=2,ensure_ascii=False))
if not passes:sys.exit(2)
